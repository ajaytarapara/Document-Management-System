import { dirname } from "path";
import { fileURLToPath } from "url";
import { FlatCompat } from "@eslint/eslintrc";
import eslintConfigPrettier from "eslint-config-prettier/flat";
import prettierPlugin from "eslint-plugin-prettier";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import globals from "globals";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
});

export default [
  // Next.js core rules
  ...compat.extends("next/core-web-vitals", "next/typescript"),

  // Handle Prettier formatting + disable conflicting rules
  eslintConfigPrettier,

  // Base settings
  {
    files: ["**/*.{js,jsx,ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      sourceType: "module",
      globals: {
        ...globals.browser,
        ...globals.node,
      },
    },
    plugins: {
      prettier: prettierPlugin,
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      // Prettier formatting as error
      "prettier/prettier": "error",

      // React Hooks best practices
      ...reactHooks.configs.recommended.rules,

      // React Refresh (for Fast Refresh)
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
    },
  },

  // Ignore folders like dist, build, etc.
  {
    ignores: ["dist", ".next", "node_modules"],
  },
];
