"use client";

// React
import { Suspense, useEffect } from "react";

// Third-party libraries
import { PersistGate } from "redux-persist/integration/react";
import { Provider } from "react-redux";

// App-specific components
import { Loader, ToasterContainer } from "@core/components";

// App-specific utilities
import { setLoaderDispatcher } from "@core/utils/axiosLoaderManager";

// App-specific hooks
import { useAppDispatch } from "@main/hooks";

// App-specific store
import { hideLoader, persistor, showLoader, store } from "@main/store";

// App-specific styles
import { AppTheme } from "@main/styles";

const App = ({ children }: { children: React.ReactNode }) => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    setLoaderDispatcher(show => {
      dispatch(show ? showLoader() : hideLoader());
    });
  }, [dispatch]);

  return (
    <AppTheme>
      <Loader />
      <Suspense fallback={<Loader />}>
        {children}
        <ToasterContainer />
      </Suspense>
    </AppTheme>
  );
};

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <Provider store={store}>
      <PersistGate loading={<Loader />} persistor={persistor}>
        <App>{children}</App>
      </PersistGate>
    </Provider>
  );
}
