import React, { FC } from "react";
import { Providers } from "./provider";
import "./globals.css";
import { Jost } from "next/font/google";
import "./toast.css";
interface IRootLayoutProps {
  children: React.ReactNode;
}

const jost = Jost({
  subsets: ["latin"],
  variable: "--font-jost",
});

// eslint-disable-next-line react-refresh/only-export-components
export const metadata = {
  title: "DMS",
  description: "Document Management System",
  icons: {
    icon: "/dms_favicon.svg",
  },
};

const RootLayout: FC<Readonly<IRootLayoutProps>> = ({ children }) => (
  <html lang="en" suppressHydrationWarning className={jost.variable}>
    <body suppressHydrationWarning>
      <Providers>{children}</Providers>
    </body>
  </html>
);

export default RootLayout;
