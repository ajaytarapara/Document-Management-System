"use client";

// React & Next.js
import { useEffect, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

// Third-party libraries
import Cookies from "js-cookie";

// App-specific constants
import { ROUTES } from "@core/constants/PAGE_URLS";

// App-specific utilities
import { decodeJwt, ROLE_CLAIM_URI } from "@core/utils";

// App-specific assets
import { Error } from "src/assets";
import { Role } from "@core/models";

export default function NotFound() {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = Cookies.get("token");
    const payload = decodeJwt(token ?? "");
    const role = payload?.[ROLE_CLAIM_URI];

    let redirectTo = ROUTES.LOGIN;

    if (token) {
      setIsAuthenticated(true);
      switch (role) {
        case Role.Admin:
          redirectTo = ROUTES.ADMIN.DASHBOARD;
          break;
        case Role.Office_User:
          redirectTo = ROUTES.OFFICE_USER.DASHBOARD;
          break;
        case Role.User:
          redirectTo = ROUTES.OFFICE_USER.DASHBOARD;
          break;
        default:
          redirectTo = ROUTES.LOGIN;
      }
    }

    const timeout = setTimeout(() => {
      router.push(redirectTo);
    }, 3000);

    return () => clearTimeout(timeout);
  }, [router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center px-4">
      <div className="w-full max-w-xs sm:max-w-md md:max-w-lg lg:max-w-xl">
        <Image src={Error} alt="Banner" className="w-full h-auto object-contain" priority />
      </div>
      <p className="mt-4 text-gray-500 text-sm sm:text-base">
        Redirecting to {isAuthenticated ? "dashboard..." : "login..."}
      </p>
    </div>
  );
}
