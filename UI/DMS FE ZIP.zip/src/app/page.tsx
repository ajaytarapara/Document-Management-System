const Home = () => <div>Next App</div>;

export default Home;
