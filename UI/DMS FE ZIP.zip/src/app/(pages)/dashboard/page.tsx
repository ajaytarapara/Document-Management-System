const Dashboard = () => <>Dashboard page</>;
export default Dashboard;
