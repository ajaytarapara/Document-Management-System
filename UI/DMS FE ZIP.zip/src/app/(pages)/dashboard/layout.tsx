export default function DashboardPage({ children }: { children: React.ReactNode }) {
  return (
    <>
      <div>Dashboard layout</div>
      <div>{children}</div>
    </>
  );
}
