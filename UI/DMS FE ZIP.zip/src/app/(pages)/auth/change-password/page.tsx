"use client";

import { LoggedInLayout } from "@core/components";
import { ChangePassForm } from "@main/components";
import { Grid } from "@mui/material";

const ChangePassword = () => {
  return (
    <LoggedInLayout>
      <Grid container className="container mx-auto px-4 sm:px-6 lg:px-8 bg-background p-6">
        <ChangePassForm />
      </Grid>
    </LoggedInLayout>
  );
};

export default ChangePassword;
