"use client";

// React & Next.js
import Image from "next/image";

// Third-party libraries
import { Eye, EyeOff, Lock, User } from "lucide-react";

// MUI components
import { Box, Divider, Grid, IconButton, InputAdornment, Stack } from "@mui/material";

// App-specific styled components
import { Card } from "@core/styledComponents";

// App-specific hooks
import { useLoginForm } from "./Login.hook";

// App-specific constants & utils
import { Constant } from "@core/constants/Constant";
import { getRequiredMessage, handleThunkWithDecrypt } from "@core/utils";

// App-specific components
import { CommonButton, CommonTextField } from "@core/components";

// App-specific assets
import { Banner } from "src/assets";
import { GoogleIcon, MicrosoftIcon } from "src/assets/Icons";
import { API_URLS } from "@core/constants";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { useAppDispatch } from "@main/hooks";
import { exchangeCode, getSubUser, setCurrentUser, setOriginalUser, setSubUser, setUserName } from "@main/store";
import Cookie from "js-cookie";
import { Role } from "@core/models";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { toast } from "react-toastify";
import { ILoginResponse, ISubUser } from "@main/models";
import Link from "next/link";

const Login = () => {
  const { register, handleSubmit, errors, onSubmit, showPassword, togglePasswordVisibility } = useLoginForm();
  const searchParams = useSearchParams();
  const router = useRouter();
  const dispatch = useAppDispatch();

  const handleOAuthLogin = (provider: typeof Constant.COMMON.GOOGLE | typeof Constant.COMMON.MICROSOFT) => {
    const redirectUrl =
      provider === Constant.COMMON.GOOGLE
        ? `${process.env.NEXT_PUBLIC_API_URL}${API_URLS.ADMIN.GOOGLELOGIN}`
        : `${process.env.NEXT_PUBLIC_API_URL}${API_URLS.ADMIN.MICROSOFTLOGIN}`;
    window.location.href = redirectUrl;
  };

  useEffect(() => {
    const code = searchParams.get("code");
    const error = searchParams.get("error");

    const handleExchangeCode = async (code: string) => {
      const response = await handleThunkWithDecrypt<ILoginResponse, { code: string }>(dispatch, exchangeCode, {
        code,
      });
      if (response?.data) {
        const { token, role, username, isFirstTimeLogin } = response.data;
        Cookie.set("token", token, { expires: 1 });
        Cookie.set("isFirstTimeLogin", isFirstTimeLogin.toString());
        window.history.replaceState(null, "", window.location.pathname);
        if (!isFirstTimeLogin) {
          if (role === Role.Admin) {
            router.push(ROUTES.ADMIN.DASHBOARD);
          } else if (role === Role.Office_User) {
            router.push(ROUTES.OFFICE_USER.DASHBOARD);
          } else if (role === Role.User) {
            router.push(ROUTES.USER.DASHBOARD);
          }
        } else {
          router.push(ROUTES.ADMIN.CHANGE_PASSWORD);
        }
        dispatch(setUserName(username));
        const decryptedResponse = await handleThunkWithDecrypt<ISubUser[], null>(dispatch, getSubUser, null);
        const apiSubUsers = decryptedResponse?.data || [];
        dispatch(setSubUser(apiSubUsers));
        const staticUser: ISubUser = {
          id: Number(response?.data?.userId),
          username: response?.data?.username ?? "",
        };
        dispatch(setCurrentUser(staticUser));
        dispatch(setOriginalUser(staticUser));
      }
    };

    const showErrorToast = (errorType: string) => {
      const errorMessages: Record<string, string> = {
        unauthorized: Constant.MESSAGE.UNAUTHORIZED,
        email_not_found: Constant.MESSAGE.EMAILNOTFOUND,
        user_not_found: Constant.MESSAGE.USERNOTFOUND,
        access_denied: Constant.MESSAGE.ACESSDENIED,
        not_allowed_method: Constant.MESSAGE.NOT_ALLOWED_METHOD,
      };
      toast.error(errorMessages[errorType] || Constant.MESSAGE.UNKNOWNERROR);
      window.history.replaceState(null, "", window.location.pathname);
    };

    if (error) {
      showErrorToast(error);
    }

    if (code) {
      handleExchangeCode(code);
    }
  }, [searchParams, router, dispatch]);

  return (
    <Grid container className="flex flex-wrap justify-center items-center !h-full">
      <Grid size={{ sm: 12, md: 6 }} className="hidden lg:block h-full">
        <Image src={Banner} alt="Banner" className="w-full h-full object-cover" />
      </Grid>
      <Grid size={{ sm: 12, md: 6 }} className="flex justify-center items-center p-6">
        <Card className="w-1/2 transition duration-200 hover:shadow-xl" variant="outlined">
          <Box>
            <p className="text-[#00092a] text-lg sm:text-xl md:text-2xl lg:text-3xl flex justify-center items-center font-semibold transition-transform duration-200 hover:scale-105 gap-3">
              DMS
            </p>
            <p className="text-[#00092a] text-sm sm:text-base md:text-lg lg:text-xl flex justify-center !mb-5 mt-1 !font-bold-700 transition-transform duration-200 hover:scale-105">
              Document Management System
            </p>
          </Box>
          <Stack
            spacing={2}
            component="form"
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col w-full gap-2"
          >
            <CommonTextField
              name="userName"
              placeholder="Username"
              type="text"
              fullWidth
              className="transition-all duration-200 text-sm sm:text-base md:text-lg"
              register={register}
              errors={errors}
              validation={{
                required: getRequiredMessage("Username"),
                maxLength: {
                  value: 50,
                  message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
                },
              }}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <User
                        size={24}
                        className="text-bolder text-black transition-transform duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    </InputAdornment>
                  ),
                },
              }}
            />

            <CommonTextField
              name="password"
              placeholder="Password"
              type={showPassword ? "text" : "password"}
              fullWidth
              variant="outlined"
              className="transition-all duration-200 text-sm sm:text-base md:text-lg"
              register={register}
              errors={errors}
              validation={{
                required: getRequiredMessage("Password"),
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              }}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <Lock
                        size={24}
                        className="text-bolder text-black transition-transform duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        disableRipple
                        onClick={togglePasswordVisibility}
                        edge="end"
                        size="small"
                        className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                      >
                        {showPassword ? (
                          <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        ) : (
                          <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
            />
            <Link
              href={ROUTES.FORGOT_PASSWORD}
              className="!ml-auto relative group text-[#00092a] text-sm sm:text-base md:text-lg"
            >
              <span className="relative z-10">Forgot password?</span>
              <span className="absolute left-0 -bottom-1.5 h-[2px] w-0 bg-[#00092a] transition-all duration-300 group-hover:w-full"></span>
            </Link>
            <CommonButton
              type="submit"
              fullWidth
              variant="contained"
              className="!max-h-[48px] h-full !text-base sm:!text-lg md:!text-xl font-bold"
            >
              Log in
            </CommonButton>
          </Stack>
          <Divider className="text-gray-400 p-4">OR</Divider>
          <div className="flex flex-row gap-5 w-full flex-wrap items-center">
            <button
              onClick={() => handleOAuthLogin("google")}
              type="button"
              className="flex-1 flex cursor-pointer items-center justify-center gap-2 border border-gray-300 rounded-md px-4 py-2 text-sm sm:text-base md:text-lg text-[#212529] hover:bg-gray-100 hover:shadow-md transition duration-200"
            >
              <span className="flex items-center gap-2">
                <GoogleIcon /> Google
              </span>
            </button>
            <button
              onClick={() => handleOAuthLogin("microsoft")}
              type="button"
              className="flex-1 flex cursor-pointer items-center justify-center gap-2 border border-gray-300 rounded-md px-4 py-2 text-sm sm:text-base md:text-lg text-[#323a42] hover:bg-gray-100 hover:shadow-md transition duration-200"
            >
              <span className="flex items-center gap-2">
                <MicrosoftIcon /> Microsoft
              </span>
            </button>
          </div>
        </Card>
      </Grid>
    </Grid>
  );
};

export default Login;
