"use client";

// React & Next.js
import Image from "next/image";

// Third-party libraries
import { User } from "lucide-react";

// MUI components
import { Box, Grid, InputAdornment, Stack } from "@mui/material";

// App-specific styled components
import { Card } from "@core/styledComponents";

// App-specific hooks
import { UseForgotPasswordForm } from "./forgotPassword.hook";

// App-specific constants & utils
import { Constant } from "@core/constants/Constant";
import { getRequiredMessage } from "@core/utils";

// App-specific components
import { CommonButton, CommonTextField } from "@core/components";

// App-specific assets
import { Banner } from "src/assets";
import { ROUTES } from "@core/constants/PAGE_URLS";
import Link from "next/link";

const ForgotPasswordForm = () => {
  const { register, handleSubmit, errors, onSubmit } = UseForgotPasswordForm();

  return (
    <Grid container className="flex flex-wrap justify-center items-center !h-full">
      <Grid size={{ sm: 12, md: 6 }} className="hidden lg:block h-full">
        <Image src={Banner} alt="Banner" className="w-full h-full object-cover" />
      </Grid>
      <Grid size={{ sm: 12, md: 6 }} className="flex justify-center items-center p-6">
        <Card className="w-1/2 transition duration-200 hover:shadow-xl" variant="outlined">
          <Box>
            <p className="text-[#00092a] text-[24px] flex justify-center items-center  font-semibold transition-transform duration-200 hover:scale-105 gap-3 mb-4">
              Forgot Password
            </p>
            <p className="text-[#00092a] text-[12px] text-center font-semibold mb-4">
              Enter your registered username and we&apos;ll send a one-time password (OTP) to your email.
            </p>
          </Box>
          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col w-full gap-2">
            <Stack spacing={4}>
              <Box>
                <CommonTextField
                  name="userName"
                  placeholder="Username"
                  type="text"
                  fullWidth
                  className="transition-all duration-200 !mb-0.5"
                  register={register}
                  errors={errors}
                  validation={{
                    required: getRequiredMessage("Username"),
                    maxLength: {
                      value: 50,
                      message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
                    },
                  }}
                  slotProps={{
                    input: {
                      startAdornment: (
                        <InputAdornment position="start">
                          <User
                            size={24}
                            className="text-bolder text-black transition-transform duration-200 hover:scale-110 hover:text-[#7E57C2]"
                          />
                        </InputAdornment>
                      ),
                    },
                  }}
                />
              </Box>
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className="!max-h-[48px] h-full !text-[18px] font-bold"
              >
                Submit
              </CommonButton>
              <Link href={ROUTES.LOGIN} className="!ml-auto relative group text-[#00092a]">
                <span className="relative z-10 text-lg">Back to login</span>
                <span className="absolute left-0 -bottom-1.5 h-[2px] w-0 bg-[#00092a] transition-all duration-300 group-hover:w-full"></span>
              </Link>
            </Stack>
          </Box>
        </Card>
      </Grid>
    </Grid>
  );
};

export default ForgotPasswordForm;
