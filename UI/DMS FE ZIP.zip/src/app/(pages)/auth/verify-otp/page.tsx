"use client";

import Image from "next/image";
import { Box, Grid, Stack } from "@mui/material";
import { Card } from "@core/styledComponents";
import { UseVerifyOTPForm } from "./verify-otp.hook";
import { CommonButton } from "@core/components";
import { Banner } from "src/assets";
import OTPInput from "react-otp-input";

const VerifyOTPForm = () => {
  const { register, handleSubmit, errors, onSubmit, setValue, watch } = UseVerifyOTPForm();
  const otp = watch("otp") || "";
  const isOtpComplete = otp.length === 4;

  return (
    <Grid container className="flex flex-wrap justify-center items-center !h-full">
      <Grid size={{ sm: 12, md: 6 }} className="hidden lg:block h-full">
        <Image src={Banner} alt="Banner" className="w-full h-full object-cover" />
      </Grid>
      <Grid size={{ sm: 12, md: 6 }} className="flex justify-center items-center p-6">
        <Card className="w-1/2 transition duration-200 hover:shadow-xl" variant="outlined">
          <Box>
            <p className="text-[#00092a] text-[24px] text-center font-semibold mb-4">Verify OTP</p>
          </Box>
          <p className="text-[#00092a] text-[12px] text-center font-semibold mb-4">
            Please enter the OTP sent to your registered email address associated with your username.
          </p>
          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col w-full gap-2">
            <Stack spacing={4}>
              <input type="hidden" {...register("otp", { required: "OTP is required" })} />
              <OTPInput
                value={watch("otp") || ""}
                onChange={val => setValue("otp", val)}
                numInputs={4}
                shouldAutoFocus
                inputType="number"
                renderInput={props => (
                  <input
                    {...props}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="one-time-code"
                    className="!w-[56px] !h-[56px] text-[20px] font-bold rounded-full border-2 border-[#00092a] text-center focus:border-[#7E57C2] focus:outline-none"
                  />
                )}
                containerStyle="flex justify-center gap-3"
              />
              {errors.otp && <span className="text-sm text-red-500 text-center">{errors.otp.message as string}</span>}
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className={`!max-h-[48px] h-full !text-[18px] font-bold ${
                  !isOtpComplete ? "opacity-50 cursor-not-allowed" : ""
                }`}
                disabled={!isOtpComplete}
              >
                Submit
              </CommonButton>
            </Stack>
          </Box>
        </Card>
      </Grid>
    </Grid>
  );
};

export default VerifyOTPForm;
