import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { IVerifyOTP } from "@main/models";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { handleThunkWithDecrypt, triggerLoader } from "@core/utils";
import { useEffect, useMemo } from "react";
import Cookie from "js-cookie";
import { useAppDispatch } from "@main/hooks";
import { verifyOTP } from "@main/store";

export const UseVerifyOTPForm = () => {
  const router = useRouter();
  const userName = useMemo(() => Cookie.get("userName") || "", []);
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<IVerifyOTP>({
    defaultValues: {
      userName: userName,
    },
  });

  useEffect(() => {
    const userName = Cookie.get("userName");
    if (!userName) {
      router.push(ROUTES.LOGIN);
    }
  }, [router]);

  const onSubmit = async (formData: IVerifyOTP) => {
    triggerLoader(true);
    const userName = Cookie.get("userName");
    const finalFormData: IVerifyOTP = {
      ...formData,
      userName: userName ?? "",
    };
    const response = await handleThunkWithDecrypt<boolean, IVerifyOTP>(dispatch, verifyOTP, finalFormData);
    if (response.data) {
      router.push(ROUTES.RESET_PASSWORD);
    }
    triggerLoader(false);
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    setValue,
    watch,
  };
};
