"use client";

import { SetupPasswordForm } from "@main/components";

const SetupPassword = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-grow bg-[#e1dcef]">
        <div className="pt-[90px] md:pt-[100px] pb-[80px] mx-6 xl:mx-auto lg:mx-6 md:mx-6 sm:xs-6 xs:mx-4">
          <SetupPasswordForm />
        </div>
      </main>
    </div>
  );
};

export default SetupPassword;
