"use client";

// React & Next.js
import Image from "next/image";

// Third-party libraries
import { EyeOff, Eye } from "lucide-react";

// MUI components
import { Box, Grid, IconButton, InputAdornment, Stack } from "@mui/material";

// App-specific styled components
import { Card } from "@core/styledComponents";

// App-specific hooks
import { UseResetPasswordForm } from "./resetPassword.hook";

// App-specific constants & utils
import { Constant } from "@core/constants/Constant";
import { getRequiredMessage } from "@core/utils";

// App-specific components
import { CommonButton, CommonTextField } from "@core/components";

// App-specific assets
import { Banner } from "src/assets";

const ResetPasswordForm = () => {
  const {
    register,
    handleSubmit,
    errors,
    onSubmit,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  } = UseResetPasswordForm();

  return (
    <Grid container className="flex flex-wrap justify-center items-center !h-full">
      <Grid size={{ sm: 12, md: 6 }} className="hidden lg:block h-full">
        <Image src={Banner} alt="Banner" className="w-full h-full object-cover" />
      </Grid>
      <Grid size={{ sm: 12, md: 6 }} className="flex justify-center items-center p-6">
        <Card className="w-1/2 transition duration-200 hover:shadow-xl" variant="outlined">
          <Box>
            <p className="text-[#00092a] text-[24px] flex justify-center items-center  font-semibold transition-transform duration-200 hover:scale-105 gap-3 mb-4">
              Reset Password
            </p>
          </Box>
          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col w-full gap-2">
            <Stack spacing={4}>
              <CommonTextField
                label="New Password"
                {...register("newPassword", {
                  required: getRequiredMessage("New Password"),
                  pattern: {
                    value: Constant.REGEX.PASSWORD_COMPLEXITY,
                    message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                  },
                })}
                errors={errors}
                required
                slotProps={{
                  input: {
                    type: isShowNewPass ? "text" : "password",
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          disableRipple
                          onClick={() => setIsShowNewPass(!isShowNewPass)}
                          edge="end"
                          size="small"
                          className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                        >
                          {!isShowNewPass ? (
                            <EyeOff
                              size={20}
                              className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                            />
                          ) : (
                            <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                          )}
                        </IconButton>
                      </InputAdornment>
                    ),
                  },
                }}
              />
              <CommonTextField
                label="Confirm Password"
                {...register("confirmPassword", {
                  required: getRequiredMessage("Confirm Password"),
                  validate: value => value === getValues("newPassword") || "Confirm Password must match New Password",
                  pattern: {
                    value: Constant.REGEX.PASSWORD_COMPLEXITY,
                    message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                  },
                })}
                errors={errors}
                required
                slotProps={{
                  input: {
                    type: isShowConfirmNewPass ? "text" : "password",
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          disableRipple
                          onClick={() => setIsShowConfirmNewPass(!isShowConfirmNewPass)}
                          edge="end"
                          size="small"
                          className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                        >
                          {!isShowConfirmNewPass ? (
                            <EyeOff
                              size={20}
                              className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                            />
                          ) : (
                            <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                          )}
                        </IconButton>
                      </InputAdornment>
                    ),
                  },
                }}
              />
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className="!max-h-[48px] h-full !text-[18px] font-bold"
              >
                Submit
              </CommonButton>
            </Stack>
          </Box>
        </Card>
      </Grid>
    </Grid>
  );
};

export default ResetPasswordForm;
