"use client";

import { useEffect, useState } from "react";
import { Box, Typography } from "@mui/material";
import { GetFolderTabs } from "@main/models";
import { decryptObject, getTextColorForBackground } from "@core/utils";
import { getFolderTabs } from "@main/store";
import { IAPIResponse } from "@core/models";
import { useSearchParams } from "next/navigation";
import { useAppDispatch } from "@main/hooks";
import CryptoJS from "crypto-js";
import { PreviewTable } from "@main/components";
export default function VerifiedFolderPage() {
  const [selectedTab, setSelectedTab] = useState<string>("");
  const [tabs, setTabs] = useState<GetFolderTabs>({ folderTabDto: [], folderName: "" });
  const [tab, setTab] = useState<string>("");
  const searchParams = useSearchParams();
  const secretKey = process.env.NEXT_PUBLIC_AES_IV;
  const token = searchParams.get("token");
  const bytes = CryptoJS.AES.decrypt(token as string, secretKey || "");
  const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  const folderIdString = decryptedData.fid;
  const viewOnly = decryptedData.viewOnly;
  const dispatch = useAppDispatch();

  // 📌 Fetch folder tabs on component mount
  useEffect(() => {
    const fetchTabs = async (folderId: string) => {
      if (!token) return null;

      // Dispatch Redux action to fetch folder tabs
      const res = await dispatch(getFolderTabs({ folderId }));

      // Check if API call succeeded
      if (getFolderTabs.fulfilled.match(res)) {
        const encryptedString = res.payload?.data;

        // Decrypt API response
        const decrypted: IAPIResponse<GetFolderTabs> = decryptObject(encryptedString);

        if (decrypted?.data) {
          // Update state with folder tabs
          setTabs({ folderTabDto: decrypted?.data.folderTabDto, folderName: decrypted?.data.folderName });

          // Auto-select the first tab
          setTab(decrypted.data.folderTabDto[0].id);
          setSelectedTab(decrypted.data.folderTabDto[0].id);
        }
      }
    };

    fetchTabs(folderIdString);
  }, []);
  return (
    <Box p={4} textAlign="center" className="bg-[#e1dcef] min-h-screen h-full">
      <Typography variant="h5" color="success.main">
        ✅ Verified Successfully!
      </Typography>
      <Typography mt={2}>Access granted to {tabs.folderName}</Typography>

      <div className="mt-9">
        <Box
          className="flex whitespace-nowrap"
          sx={{
            "&::-webkit-scrollbar-track": { backgroundColor: "transparent" },
            "&::-webkit-scrollbar-thumb": { backgroundColor: "#ccc", borderRadius: "4px" },
          }}
        >
          {tabs?.folderTabDto.map((tab, idx) => {
            const isSelected = tab.id === selectedTab;
            const textColor = getTextColorForBackground(tab?.color);

            return (
              <Box
                key={idx}
                className="min-w-[120px] max-w-[160px] px-4 py-3 text-sm font-semibold text-center truncate cursor-pointer transition-all duration-300 ease-in-out"
                style={{
                  backgroundColor: tab.color,
                  color: textColor,
                  borderRadius: "12px 12px 0 0",
                  transform: isSelected ? "scale(1.1)" : "scale(1)",
                  paddingTop: isSelected ? "1rem" : "0.75rem",
                  paddingBottom: isSelected ? "1rem" : "0.75rem",
                }}
                title={tab.tabName}
                onClick={() => {
                  setSelectedTab(tab.id);
                  setTab(tab.id);
                }}
              >
                {tab.tabName}
              </Box>
            );
          })}
        </Box>
      </div>
      <PreviewTable selectedTabId={tab} viewOnly={viewOnly} />
    </Box>
  );
}
