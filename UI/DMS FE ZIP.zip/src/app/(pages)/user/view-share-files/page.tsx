"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState, ChangeEvent } from "react";
import { useAppDispatch } from "@main/hooks";
import { decryptObject } from "@core/utils";
import { CommonButton, CommonTextField, Dialog } from "@core/components";
import { Box, Typography, Stack } from "@mui/material";
import { sendOTP, verifyOTPForShare } from "@main/store";
import { toast } from "react-toastify";
import { ROUTES } from "@core/constants/PAGE_URLS";
import CryptoJS from "crypto-js";
import { ShareStep } from "@core/models";
import { Constant, SHARE_TYPE } from "@core/constants/Constant";

interface ShareToken {
  folderId: number | number[];
  email: string;
  viewOnly: boolean;
  expiresAt: number;
  type: string;
}

export default function ViewFolderPage() {
  const searchParams = useSearchParams();
  const shareToken = searchParams.get("shareToken");
  const initialStep = (searchParams.get("step") as ShareStep) || ShareStep.Email;
  const [step, setStep] = useState(initialStep);
  const [emailInput, setEmailInput] = useState<string>("");
  const [otp, setOtp] = useState<string>("");
  const [decodedToken, setDecodedToken] = useState<ShareToken | null>(null);
  const dispatch = useAppDispatch();
  const [timer, setTimer] = useState<number>(300);
  const data = {
    fid: decodedToken?.folderId,
    viewOnly: decodedToken?.viewOnly,
  };
  const secretKey = process.env.NEXT_PUBLIC_AES_IV;
  // Encrypt as a single string
  const encrypted = CryptoJS.AES.encrypt(JSON.stringify(data), secretKey || "").toString();
  const router = useRouter();
  useEffect(() => {
    if (typeof shareToken === "string") {
      const decoded = atob(shareToken);
      const parsed: ShareToken = JSON.parse(decoded);
      setDecodedToken(parsed);
    }
  }, [shareToken]);

  useEffect(() => {
    if (step === ShareStep.Otp && timer > 0) {
      const interval = setInterval(() => setTimer(t => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [step, timer]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };
  const handleEmailSubmit = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (!decodedToken) return;

    if (emailInput.toLowerCase() !== decodedToken.email.toLowerCase()) {
      toast.error(Constant.MESSAGE.EMAIL_NOT_VARIFY);
      return;
    }
    await dispatch(sendOTP({ email: emailInput }));
    setStep(ShareStep.Otp);
    setTimer(300);
  };

  const handleOtpSubmit = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();

    const res = await dispatch(verifyOTPForShare({ email: emailInput, code: otp }));
    if (verifyOTPForShare.fulfilled.match(res)) {
      if (res.payload?.data) {
        const encryptedString = res.payload?.data;
        const decrypted: { verified: boolean } = decryptObject<{ verified: boolean }>(encryptedString);
        if (decrypted?.verified) {
          if (decodedToken?.type === SHARE_TYPE.FOLDER) {
            router.push(`${ROUTES.PREVIEW_FOLDER}?token=${encodeURIComponent(encrypted)}`);
          } else if (decodedToken?.type === SHARE_TYPE.TAB) {
            router.push(`${ROUTES.PREVIEW_TAB}?token=${encodeURIComponent(encrypted)}`);
          } else if (decodedToken?.type === SHARE_TYPE.FILE) {
            router.push(`${ROUTES.PREVIEW_FILE}?token=${encodeURIComponent(encrypted)}`);
          }
        }
      }
    }
  };

  return (
    <div>
      {step === ShareStep.Email && (
        <Dialog open={true} title="" description="" showActions={false} onClose={() => {}}>
          <Box p={3} minWidth={400} textAlign="center">
            <Typography variant="h6" fontWeight={600} gutterBottom>
              ✉️ Confirm Your Email
            </Typography>
            <Typography variant="body2" color="text.secondary" mb={3}>
              Enter the email used to access the folder.
            </Typography>
            <Stack spacing={2}>
              <CommonTextField
                name="email"
                label="Your Email"
                placeholder="example@email.com"
                value={emailInput}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setEmailInput(e.target.value)}
                required
                sx={{ "& .MuiOutlinedInput-root": { height: 45 } }}
              />
              <CommonButton
                size="large"
                sx={{ height: 45 }}
                onClick={(e: React.MouseEvent<HTMLButtonElement>) => handleEmailSubmit(e)} // call directly
              >
                Send OTP
              </CommonButton>
            </Stack>
          </Box>
        </Dialog>
      )}

      {step === ShareStep.Otp && (
        <Dialog open={true} title="" description="" showActions={false} onClose={() => {}}>
          <Box p={3} minWidth={400} textAlign="center">
            <Typography variant="h6" fontWeight={600} gutterBottom>
              🔐 Enter OTP
            </Typography>
            <Typography variant="body2" color="text.secondary" mb={3}>
              Enter the OTP sent to your email.
            </Typography>
            <Typography variant="caption" color="primary" display="block" mb={2}>
              {" "}
              Expires in: {formatTime(timer)}{" "}
            </Typography>
            <Stack spacing={2}>
              <CommonTextField
                name="otp"
                label="OTP"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setOtp(e.target.value)}
                required
                sx={{ "& .MuiOutlinedInput-root": { height: 45 } }}
              />
              <CommonButton
                size="large"
                sx={{ height: 45 }}
                onClick={(e: React.MouseEvent<HTMLButtonElement>) => handleOtpSubmit(e)}
              >
                Verify & Access
              </CommonButton>
            </Stack>
          </Box>
        </Dialog>
      )}
    </div>
  );
}
