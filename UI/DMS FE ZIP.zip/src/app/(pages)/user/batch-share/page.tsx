"use client";

import { LoggedInLayout } from "@core/components";
import { BatchShare } from "@main/components";

const BatchShareOfficeUser = () => {
  return (
    <LoggedInLayout>
      <BatchShare />
    </LoggedInLayout>
  );
};

export default BatchShareOfficeUser;
