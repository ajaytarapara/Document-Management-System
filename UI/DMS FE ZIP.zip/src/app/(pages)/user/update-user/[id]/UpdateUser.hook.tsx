import { useParams } from "next/navigation";
import { useForm } from "react-hook-form";

import { useAppDispatch } from "@main/hooks";
import { ILoginResponse, IUpdateUserForm, IUsersResponse } from "@main/models";
import { getUserById, updateUser, useSelectorAuthState } from "@main/store";
import { IAPIResponse, LoginTypeEnum } from "@core/models";
import { decryptObject, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { useEffect, useState } from "react";
import { ROUTES } from "@core/constants/PAGE_URLS";

/**
 * Custom hook for managing the Update User form logic.
 * Handles:
 * - Fetching user details by ID
 * - Populating and submitting the form
 * - Navigating between pages
 * - Accessing logged-in user information
 *
 * @returns {object} Form utilities, user data, and navigation handlers
 */
export const useUpdateUserForm = () => {
  const dispatch = useAppDispatch();
  const params = useParams();
  const navigate = useNavigate();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  const [user, setUser] = useState<IUpdateUserForm | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
    control,
  } = useForm<IUpdateUserForm>({
    defaultValues: {
      userName: "",
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      address: "",
      city: "",
      postalCode: 0,
      isActive: false,
    },
  });

  const loginType = watch("loginType");

  /**
   * Fetches and sets user data by ID for editing.
   * Decrypts API response and populates the form with user data.
   *
   * @param {string} userId - ID of the user to fetch.
   */
  const fetchUserData = async (userId: string) => {
    const decryptedResponse = await handleThunkWithDecrypt<IAPIResponse<IUpdateUserForm>, string>(
      dispatch,
      getUserById,
      userId
    );

    if (decryptedResponse?.data) {
      const userData = decryptedResponse.data as unknown as IUpdateUserForm;
      setUser(userData);
      reset(userData);
    }
  };

  /**
   * Handles form submission for updating user details.
   * Dispatches update action with updated form data.
   * Navigates back to the View Users page upon success.
   *
   * @param {IUpdateUserForm} data - Updated user form values.
   */
  const onSubmit = async (data: IUpdateUserForm) => {
    const resultAction = await dispatch(
      updateUser({
        id: params?.id as string,
        address: data.address,
        city: data.city,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        phoneNumber: data.phoneNumber,
        userName: data.userName,
        postalCode: Number(data.postalCode),
        isActive: data.isActive,
        privilegeView: data.privilegeView ?? false,
        privilegeDownload: data.privilegeDownload ?? false,
        privilegeDelete: data.privilegeDelete ?? false,
        hideLockTabs: data.hideLockTabs ?? false,
        loginType: data.loginType ?? LoginTypeEnum.USERNAME,
      })
    );
    if (updateUser.fulfilled.match(resultAction)) {
      const encryptedString = resultAction.payload?.data;
      const decrypted: IAPIResponse<IUsersResponse> = decryptObject<IAPIResponse<IUsersResponse>>(
        encryptedString as unknown as string
      );
      if (decrypted?.data) {
        setTimeout(() => {
          navigate(ROUTES.OFFICE_USER.VIEW_USER);
        }, 1500);
      }
    }
  };

  /**
   * Navigates to the View Users page without saving changes.
   */

  const backToViewUsers = () => {
    navigate(ROUTES.OFFICE_USER.VIEW_USER);
  };

  useEffect(() => {
    const id = params?.id;
    if (id) {
      fetchUserData(id as string);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params?.id]);

  return {
    user,
    control,
    errors,
    loginType,
    decryptedLoggedUser,
    register,
    handleSubmit,
    backToViewUsers,
    onSubmit,
  };
};
