import emotionStyled from "@emotion/styled";
import { Button } from "@mui/material";

export const StyledButton = emotionStyled(Button)`
  background-color: #7E57C2;
  color: white;
  max-width: 100px;
  width: 100%;
  text-transform: capitalize;
  &:hover {
    background-color: #6a45b3;
  }
`;

export const StyledCancelButton = emotionStyled(Button)`
  max-width: 100px;
  width: 100%;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #7E57C2;
  &:hover {
    background-color: #e1dcef;
  }
`;
