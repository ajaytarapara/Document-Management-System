"use client";
import { Box, Typography } from "@mui/material";
import { useSearchParams } from "next/navigation";
import CryptoJS from "crypto-js";
import { PreviewTable } from "@main/components";
export default function VerifiedFolderPage() {
  const searchParams = useSearchParams();
  const secretKey = process.env.NEXT_PUBLIC_AES_IV;
  const token = searchParams.get("token");
  const bytes = CryptoJS.AES.decrypt(token as string, secretKey || "");
  const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  const tabIdString = decryptedData.fid;
  const viewOnly = decryptedData.viewOnly;

  return (
    <Box p={4} textAlign="center" className="bg-[#e1dcef] min-h-screen h-full">
      <Typography variant="h5" color="success.main">
        ✅ Verified Successfully!
      </Typography>
      <Typography mt={2}>Access granted to tab</Typography>

      <PreviewTable selectedTabId={tabIdString} viewOnly={viewOnly || "true"} />
    </Box>
  );
}
