"use client";

import React from "react";
import { CreateUserForm } from "@main/components";

const CreateUserPage = () => {
  return <CreateUserForm />;
};

export default CreateUserPage;
