"use client";

import { LoggedInLayout } from "@core/components";
import { FolderFile } from "@main/components";

const UserFolderFile = () => {
  return (
    <LoggedInLayout>
      <FolderFile />
    </LoggedInLayout>
  );
};

export default UserFolderFile;
