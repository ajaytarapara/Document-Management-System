"use client";

import { CommonTable, CommonTextField, Dialog, LoggedInLayout } from "@core/components";
import { useDmsForm } from "./DmsForm.hook";
import { Eye, EyeOff, FileUp, Share2, Trash2 } from "lucide-react";
import { Constant } from "@core/constants/Constant";
import { formatFileSize, getRequiredMessage } from "@core/utils";
import { CommonDMSDrawer, ShareDmsFileModal } from "@main/components";
import { DeleteFileProps, DeleteFormValues, EditFileProps, EditFormValues } from "@main/models";
import { shareDmsForm } from "@main/store";
import { useEffect, useState } from "react";
import { InputAdornment, IconButton } from "@mui/material";
import { Success } from "src/assets";
import Image from "next/image";
import { useSubmittedDmsForm } from "./SubmittedDmsForm.hook";

interface DocumentsTableProps {
  selectedFiles: File[];
  setSelectedFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

const DmsForms = () => {
  const {
    dmsFormColumns,
    pageIndex,
    fileName,
    errors,
    register,
    dispatch,
    pageSize,
    openShareModal,
    fileInputRef,
    isDialogOpen,
    selectedRowIds,
    selectedFiles,
    openDeleteDialog,
    openEditDialog,
    shareFormId,
    dmsFormsData,
    totalCount,
    editErrors,
    totalPage,
    downloadSuccessDialog,
    setSorting,
    editRegister,
    handleEditFile,
    setSelectedFiles,
    handleToggleDeleteDialog,
    handleCloseEditDialog,
    setPageIndex,
    handleFileButtonClick,
    handleFileChange,
    setPageSize,
    handleDialogClose,
    onSubmit,
    closeShareModal,
    handleDeleteFile,
    handleOpenShareModal,
    handleDownloadDialogClose,
  } = useDmsForm();
  const submitted = useSubmittedDmsForm();
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center pb-4 md:pb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">DMS Forms</h4>
        </div>
        <div className="my-4 bg-white">
          <div className="p-4 pb-0">
            <h5 className="font-semibold text-lg text-[#00092a]">Submitted Forms</h5>
          </div>
          <CommonTable
            data={submitted.submittedForms}
            columns={submitted.submittedColumns}
            pageIndex={submitted.pageIndex}
            pageSize={submitted.pageSize}
            totalPage={submitted.totalPage}
            totalCount={submitted.totalCount}
            onPageChange={submitted.setPageIndex}
            onPageSizeChange={submitted.setPageSize}
            onSortingChange={submitted.setSorting}
            emptyMessage={Constant.MESSAGE.NO_FILES_SUBMITTED}
          />
        </div>

        <div className="p-4 bg-white rounded-lg">
          <div className="border border-dashed border-gray-300 rounded-md min-h-[130px] h-full flex justify-center items-center">
            <div className="flex flex-col justify-center items-center p-2">
              <FileUp strokeWidth={1} className="h-10 w-10 text-[#7E57C2] z-10" />
              <p className="text-[#b0c0d4] text-[16px] mt-2 text-center">Add additional Pdf Fillable Form(s) here</p>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <input
              type="file"
              ref={fileInputRef}
              accept="application/pdf"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />

            <button
              type="button"
              onClick={handleFileButtonClick}
              className="w-full sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3] cursor-pointer"
            >
              Select File
            </button>
          </div>
        </div>
        <div className="mt-4 bg-white">
          <div className="flex justify-end p-4 pb-0">
            <button
              type="button"
              disabled={!selectedRowIds.length}
              onClick={() => handleOpenShareModal("Multiple Forms")}
              className="w-full sm:w-auto flex px-4 py-[9px] text-sm font-medium bg-[#7E57C2] disabled:bg-[#d2caf5] text-white rounded-md shadow hover:bg-[#6C4FB3] cursor-pointer"
            >
              <Share2 size={18} /> <span className="ml-2">Multiple Share</span>
            </button>
          </div>
          <CommonTable
            data={dmsFormsData}
            columns={dmsFormColumns}
            pageIndex={pageIndex}
            pageSize={pageSize}
            totalPage={totalPage}
            totalCount={totalCount}
            onPageChange={setPageIndex}
            onPageSizeChange={setPageSize}
            onSortingChange={setSorting}
            emptyMessage={Constant.MESSAGE.NO_FILES_UPLOADED}
          />
        </div>

        <CommonDMSDrawer
          open={openEditDialog}
          onClose={handleCloseEditDialog}
          title="Edit File Name"
          description={<EditFile editErrors={editErrors} editRegister={editRegister} />}
          onSubmit={handleEditFile}
          submitLabel={Constant.COMMON.SAVE}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType="button"
        />

        <Dialog
          open={openDeleteDialog}
          onClose={handleToggleDeleteDialog}
          title="Delete File"
          description={<DeleteFile errors={errors} register={register} />}
          onSubmit={handleDeleteFile}
          submitLabel={Constant.COMMON.SUBMIT}
          buttonType="submit"
          cancelLabel={Constant.COMMON.CANCEL}
        />

        <CommonDMSDrawer
          open={isDialogOpen}
          onClose={handleDialogClose}
          title="Upload Documents"
          description={<DocumentsTable selectedFiles={selectedFiles} setSelectedFiles={setSelectedFiles} />}
          onSubmit={onSubmit}
          disableSubmit={!selectedFiles.length}
          submitLabel={Constant.COMMON.UPLOAD}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType="button"
        />

        <ShareDmsFileModal
          open={openShareModal}
          folderId={shareFormId}
          onClose={closeShareModal}
          onShare={async (formId, formData) => {
            return await dispatch(
              shareDmsForm({
                formIds: selectedRowIds.length ? selectedRowIds : [formId],
                data: formData,
              })
            ).unwrap();
          }}
          fileName={fileName}
        />

        <CommonDMSDrawer
          open={downloadSuccessDialog}
          onClose={handleDownloadDialogClose}
          title={`Download File - ${fileName}`}
          description={<DownloadFile />}
          submitLabel={Constant.COMMON.OKAY}
          onSubmit={handleDownloadDialogClose}
          buttonType="button"
        />

        <Dialog
          open={submitted.openPreviewModal}
          onClose={submitted.handleClosePreviewModel}
          title={submitted.fileName}
          maxWidth="xl"
          fullWidth
          showActions={false}
        >
          {submitted.fileUrl && <iframe src={submitted.fileUrl} width="100%" height="700px" />}
        </Dialog>
      </div>
    </LoggedInLayout>
  );
};

const DeleteFile: React.FC<DeleteFileProps> = ({ errors, register }) => {
  const [showPassword, setShowPassword] = useState(false);

  /**
   * Toggles the visibility of the password field.
   * - Switches between showing and hiding the password by updating `showPassword` state.
   */
  const togglePasswordVisibility = () => setShowPassword(prev => !prev);
  return (
    <div>
      <p className="mb-4 text-sm text-gray-700">Caution! Are you sure you want to delete this file?</p>
      <div className="relative">
        <CommonTextField<DeleteFormValues>
          name="password"
          placeholder="Password"
          label="Password"
          type={showPassword ? "text" : "password"}
          register={register}
          validation={{
            required: getRequiredMessage("Password"),
          }}
          errors={errors}
          slotProps={{
            input: {
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    disableRipple
                    onClick={togglePasswordVisibility}
                    edge="end"
                    size="small"
                    className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                  >
                    {showPassword ? (
                      <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                    ) : (
                      <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            },
          }}
        />
      </div>
    </div>
  );
};

const EditFile: React.FC<EditFileProps> = ({ editErrors, editRegister }) => {
  return (
    <div>
      <CommonTextField<EditFormValues>
        name="name"
        placeholder="Name"
        label="Name"
        register={editRegister}
        validation={{
          required: getRequiredMessage("File Name"),
        }}
        errors={editErrors}
      />
    </div>
  );
};

const DownloadFile: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <div className="flex items-center space-x-3">
      <Image
        src={Success}
        alt="Success"
        className={`w-8 h-8 transform transition-all duration-700 ease-in-out ${
          visible ? "rotate-0 opacity-100" : "-rotate-45 opacity-0"
        }`}
      />
      <p className={`text-green-700 font-semibold transition-opacity duration-[1500ms] ease-in-out delay-150`}>
        File downloaded successfully
      </p>
    </div>
  );
};

const DocumentsTable = ({ selectedFiles, setSelectedFiles }: DocumentsTableProps) => {
  /**
   * Removes a selected file from the list based on its index.
   *
   * @param indexToRemove - The index of the file to be removed from the selected files array.
   */
  const handleDelete = (indexToRemove: number) => {
    setSelectedFiles(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };
  return (
    <div className="shadow-sm overflow-x-auto">
      <table className="min-w-full table-auto border-collapse">
        <thead className="bg-[#e1dcef]">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">File Name</th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">Size & Format</th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-[#00092A] rounded-tr-md">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {selectedFiles.map((item, index) => (
            <tr key={index} className="hover:bg-gray-50 transition">
              <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">{item.name}</td>
              <td className="px-4 py-3 text-sm text-gray-800">
                {formatFileSize(item.size)} ({item.type})
              </td>
              <td className="px-4 py-3">
                <div className="flex justify-center items-center gap-3 flex-wrap">
                  <Trash2 className="w-5 h-5 text-[#EF5350] cursor-pointer" onClick={() => handleDelete(index)} />
                </div>
              </td>
            </tr>
          ))}
          {selectedFiles.length === 0 && (
            <tr>
              <td colSpan={3} className="px-4 py-6 text-center text-sm text-gray-500">
                {Constant.MESSAGE.NO_FILES_UPLOADED}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DmsForms;
