"use client";
import { PreviewFile } from "@main/components";
import { Box, Typography } from "@mui/material";
import { useSearchParams } from "next/navigation";

export default function VerifiedFolderPage() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  return (
    <Box p={4} textAlign="center" className="bg-[#e1dcef] min-h-screen h-full">
      <Typography variant="h5" color="success.main">
        ✅ Verified Successfully!
      </Typography>
      <Typography mt={2}>Now you have Access to this Files</Typography>

      <PreviewFile token={token} />
    </Box>
  );
}
