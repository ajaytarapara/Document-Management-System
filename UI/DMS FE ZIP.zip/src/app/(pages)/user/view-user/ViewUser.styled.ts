import { Button, styled } from "@mui/material";

export const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#7E57C2",
  color: "white",
  width: "100%",
  fontSize: "0.85rem",
  textTransform: "capitalize",
  "&:hover": {
    backgroundColor: "#6a45b3",
  },
  [theme.breakpoints.up("sm")]: {
    width: "auto",
    minWidth: "100px",
    maxWidth: "150px",
    fontSize: "0.95rem",
  },
  [theme.breakpoints.up("md")]: {
    fontSize: "1rem",
  },
}));
