"use client";

import { useEffect, useState } from "react";
import { useAppDispatch } from "@main/hooks";
import { createColumnHelper, SortingState } from "@tanstack/react-table";
import { Edit, Trash2 } from "lucide-react";

import { ILoginResponse, IUserDetail, PaginationRequest, PaginationResponse } from "@main/models";
import { deleteUser, getUsers, useSelectorAuthState } from "@main/store";
import { decryptObject, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { IAPIResponse } from "@core/models";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { Constant } from "@core/constants/Constant";

/**
 * Custom hook to manage the logic and state for the "View Users" page.
 * Handles fetching paginated user data, sorting, delete operations, and navigation.
 */
export const useViewUserForm = () => {
  const [userData, setUserData] = useState<IUserDetail[]>([]);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState<number>(0);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { loggedInUser } = useSelectorAuthState();

  const columnHelper = createColumnHelper<IUserDetail>();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  /**
   * Fetches paginated and sorted user data.
   * @param page - The page number to fetch.
   * @param currentSorting - The current sorting state.
   */
  const getUsersData = async (page = pageIndex, currentSorting = sorting) => {
    const sort = currentSorting[0];

    const decryptedResponse = await handleThunkWithDecrypt<PaginationResponse<IUserDetail>, PaginationRequest>(
      dispatch,
      getUsers,
      {
        pageNumber: page,
        pageSize,
        sortBy: sort?.id,
        sortOrder: sort?.desc ? "Desc" : "Asc",
      }
    );

    const items = decryptedResponse?.data?.items ?? [];
    const total = decryptedResponse?.data?.totalCount ?? 0;
    const totalPg = decryptedResponse?.data?.totalPages ?? Math.ceil(total / pageSize);

    setUserData(items);
    setTotalPages(totalPg);
  };

  /**
   * Columns used in the user table.
   */
  const userColumns = [
    columnHelper.accessor("userName", {
      header: "Username",
    }),
    columnHelper.accessor("name", {
      header: "Name",
    }),
    columnHelper.accessor("email", {
      header: "Email",
    }),
    columnHelper.accessor("phoneNumber", {
      header: "Contact No.",
    }),

    ...(decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER
      ? [
          columnHelper.accessor("privilegeDelete", {
            header: "Has Privilege Delete",
          }),
          columnHelper.accessor("privilegeDownload", {
            header: "Has Privilege Download",
          }),
        ]
      : []),
    columnHelper.accessor("isActive", {
      header: "Status",
      cell: info => (info.getValue() ? <span>Active</span> : <span>Inactive</span>),
    }),
    columnHelper.display({
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const user = row.original;
        return (
          <div className="flex gap-2">
            <button
              onClick={() => navigate(`${ROUTES.OFFICE_USER.UPDATE_USER}/${user.id}`)}
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Edit size={18} />
            </button>
            <button
              onClick={() => handleOpenDeleteDialog(user.id)}
              className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Trash2 size={18} />
            </button>
          </div>
        );
      },
    }),
  ];

  /**
   * Deletes a selected user by their ID.
   * If successful, refetches the user list and navigates to the same page.
   */
  const handleDeleteUser = async () => {
    if (selectedUserId !== null) {
      const result = await dispatch(deleteUser(selectedUserId));
      if (deleteUser.fulfilled.match(result)) {
        setOpenDeleteDialog(false);
        setSelectedUserId(null);
        setTimeout(() => {
          navigate(ROUTES.OFFICE_USER.VIEW_USER);
        }, 1500);
        getUsersData();
      }
    }
  };

  /**
   * Opens the delete confirmation dialog and sets selected user ID.
   * @param userId - The ID of the user to be deleted.
   */
  const handleOpenDeleteDialog = (userId: string) => {
    setSelectedUserId(userId);
    setOpenDeleteDialog(true);
  };

  /**
   * Closes the delete confirmation dialog and clears selected user ID.
   */
  const handleCloseDeleteDialog = () => {
    setSelectedUserId(null);
    setOpenDeleteDialog(false);
  };

  /**
   * Navigates to the dashboard page.
   */
  const backToDashboard = () => {
    navigate(ROUTES.OFFICE_USER.DASHBOARD);
  };

  useEffect(() => {
    getUsersData(pageIndex, sorting);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, sorting, pageSize]);

  return {
    userData,
    userColumns,
    openDeleteDialog,
    pageIndex,
    totalPages,
    pageSize,
    setPageSize,
    setPageIndex,
    setSorting,
    backToDashboard,
    handleCloseDeleteDialog,
    handleDeleteUser,
  };
};
