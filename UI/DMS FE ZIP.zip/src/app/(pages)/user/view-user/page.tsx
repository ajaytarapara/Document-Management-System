"use client";

import { UserRoundSearch } from "lucide-react";
import { ColumnDef } from "@tanstack/react-table";
import DeleteIcon from "@mui/icons-material/Delete";

import { IUserDetail } from "@main/models";
import { CommonTable, Dialog, LoggedInLayout } from "@core/components";
import { useViewUserForm } from "./ViewUser.hook";
import { StyledButton } from "./ViewUser.styled";
import { Constant } from "@core/constants/Constant";

const ViewUserPage = () => {
  const {
    userData,
    userColumns,
    openDeleteDialog,
    pageIndex,
    totalPages,
    pageSize,
    setPageSize,
    setPageIndex,
    setSorting,
    backToDashboard,
    handleCloseDeleteDialog,
    handleDeleteUser,
  } = useViewUserForm();

  return (
    <LoggedInLayout>
      <div className="container bg-white rounded shadow-md sm:xs-6 mx-auto">
        <div className="flex justify-between py-6 px-6 border-b border-[#7E57C2] sm:py-4 sm:px-5 xs:py-3 xs:px-2">
          <div className="flex items-center flex-wrap xs:flex-col xs:items-start">
            <UserRoundSearch strokeWidth={2.3} color="#00092A" className="w-6 h-6 md:w-7 md:h-7" />
            <h2 className="text-[#00092A] font-semibold text-xl lg:text-2xl ml-3 xs:ml-0 xs:mt-2 xs:text-lg">
              View Users
            </h2>
          </div>
          <div>
            <StyledButton onClick={backToDashboard} className="w-full sm:w-auto">
              {Constant.COMMON.BACK}
            </StyledButton>
          </div>
        </div>

        <div className="overflow-x-auto pt-3">
          <CommonTable<IUserDetail>
            data={userData}
            columns={userColumns as ColumnDef<IUserDetail, unknown>[]}
            pageSize={pageSize}
            pageIndex={pageIndex}
            totalPage={totalPages}
            emptyMessage={Constant.MESSAGE.NO_USERS_FOUND_MESSAGE}
            onPageChange={page => setPageIndex(page)}
            onPageSizeChange={size => {
              setPageSize(size);
              setPageIndex(pageIndex);
            }}
            onSortingChange={setSorting}
          />
        </div>
      </div>
      <Dialog
        open={openDeleteDialog}
        onClose={handleCloseDeleteDialog}
        title="Delete User"
        description={Constant.MESSAGE.DELETE_USER_CONFIRMATION_MESSAGE}
        onSubmit={handleDeleteUser}
        icon={<DeleteIcon color="action" />}
        submitLabel={Constant.COMMON.DELETE}
        cancelLabel={Constant.COMMON.CANCEL}
        buttonType="button"
      />
    </LoggedInLayout>
  );
};
export default ViewUserPage;
