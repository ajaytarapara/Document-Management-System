"use client";

import { CreateUserForm } from "@main/components";
import React from "react";

const CreateUserPage = () => {
  return <CreateUserForm />;
};

export default CreateUserPage;
