"use client";

import { CommonDrawer, LoggedInLayout } from "@core/components";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { IPaginatedResponse } from "@core/models";
import {
  dateRangeTypeOptions,
  encryptString,
  formatFileSizeInGbMbFormat,
  getDateLabel,
  handleThunkWithDecrypt,
} from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import { IBreakdownRecord, IFileRecordStatsRequest, IFileRecordStatsResponse, IUsersResponse } from "@main/models";
import { getAllActiveOfficeUsers, getOfficeUserAnalyticsData } from "@main/store";
import { Autocomplete, MenuItem, Pagination, Select, SelectChangeEvent, TextField } from "@mui/material";
import { Eye } from "lucide-react";
import { useRouter } from "next/navigation";
import React, { useCallback } from "react";
import { useEffect, useState } from "react";

const AdminUserAnalytics = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const [activeUsers, setActiveUsers] = useState<IUsersResponse[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [request, setRequest] = useState<IFileRecordStatsRequest>({
    pageNumber: 1,
    pageSize: 10,
    searchTerm: "",
    sortBy: "",
    sortDirection: "",
    dateRangeType: "current_week",
    customStartDate: undefined,
    customEndDate: undefined,
    officeUserId: undefined,
    isForOfficeUser: true,
  });
  const [totalCount, setTotalCount] = useState<number>(0);
  const [fileStatsRecords, setFileStatsRecords] = useState<IFileRecordStatsResponse[]>([]);
  const [selectedBreakdown, setSelectedBreakdown] = useState<IBreakdownRecord[]>([]);
  const [selectedUserName, setSelectedUserName] = useState<string>("");
  const [errors, setErrors] = useState({
    start: "",
    end: "",
  });

  /**
   * Handles changes to the date range type in the request state.
   * - Always updates `dateRangeType` with the selected value.
   * - If the selected value is not `"custom"`, resets `customStartDate` and `customEndDate`
   *   to `undefined` so they are excluded from the API request.
   */
  const handleChange = (event: SelectChangeEvent) => {
    const value = event.target.value;
    setRequest(prev => ({
      ...prev,
      dateRangeType: value,
    }));

    if (value !== "custom") {
      setRequest(prev => ({
        ...prev,
        customStartDate: undefined,
        customEndDate: undefined,
      }));
    }
  };

  /**
   * Fetches all active office users from the server.
   * - Dispatches the `getAllActiveOfficeUsers` async action.
   * - Checks if the response is fulfilled.
   * - Decrypts the encrypted response payload.
   * - If valid user data is present, updates the state with the list of active users.
   */
  const getAllUsers = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IUsersResponse[]>(dispatch, getAllActiveOfficeUsers);
    if (response?.data) {
      setActiveUsers(response.data);
    }
  }, [dispatch]);

  /**
   * Updates the request state with the selected office user ID.
   * If no user is selected (id is an empty string), `officeUserId` is set to `undefined`
   * so it will be omitted from the API request payload.
   */
  const handleUserChange = (id: string | "") => {
    setRequest(prev => ({
      ...prev,
      officeUserId: id !== "" ? id : undefined,
    }));
  };

  /**
   * Resets specific filters in the request state to their default values.
   * - Sets `dateRangeType` back to `"current_week"`.
   * - Clears `officeUserId`, `customStartDate`, and `customEndDate` by setting them to `undefined`
   *   so they are excluded from the API request payload.
   */
  const handleClickClearButton = () => {
    setRequest(prev => ({
      ...prev,
      dateRangeType: "current_week",
      officeUserId: undefined,
      customStartDate: undefined,
      customEndDate: undefined,
    }));
    const newRequest: IFileRecordStatsRequest = {
      ...request,
      dateRangeType: "current_week",
      officeUserId: undefined,
      customStartDate: undefined,
      customEndDate: undefined,
      pageNumber: 1,
    };
    getFileRecordStats(newRequest);
  };

  /**
   * Fetches file record statistics from the API using the current request state.
   * - Dispatches the `getOfficeUserAnalyticsData` thunk with the `request` payload.
   * - Decrypts the API response using `handleThunkWithDecrypt`.
   * - On success, updates `fileStatsRecords` with the returned items and `totalCount`
   *   with the total number of records.
   */
  const getFileRecordStats = async (newRequest?: IFileRecordStatsRequest) => {
    const response = await handleThunkWithDecrypt<
      IPaginatedResponse<IFileRecordStatsResponse>,
      IFileRecordStatsRequest
    >(dispatch, getOfficeUserAnalyticsData, newRequest ? newRequest : request);
    if (response?.data) {
      setFileStatsRecords(response.data.items);
      setTotalCount(response.data.totalCount);
    }
  };

  /**
   * Closes the drawer and resets the related state values.
   * - Sets `drawerOpen` to `false` to close the drawer.
   * - Clears the `selectedBreakdown` data by setting it to an empty array.
   * - Resets the `selectedUserName` to an empty string.
   */
  const handleDrawerClose = () => {
    setDrawerOpen(false);
    setSelectedBreakdown([]);
    setSelectedUserName("");
  };

  /**
   * Handles the click event for the plus icon on a file record.
   * - Stores the selected record's breakdown data in `selectedBreakdown`.
   * - Stores the selected record's user name in `selectedUserName`.
   * - Opens the drawer to display the breakdown details.
   *
   * @param record - The file record whose details should be displayed.
   */
  const handleClickPlusIcon = (record: IFileRecordStatsResponse) => {
    setSelectedBreakdown(record.breakdown);
    setSelectedUserName(record.officeUserName);
    setDrawerOpen(true);
  };

  /**
   * Validates the date range selection in the request state.
   * - Only runs validations if `dateRangeType` is `"custom"`.
   * - Checks if both start and end dates are provided.
   * - Ensures the end date is not before the start date.
   * - Updates the `errors` state with any validation messages.
   *
   * @returns {boolean} - Returns `true` if the form is valid, otherwise `false`.
   */
  const validate = (): boolean => {
    let isValid = true;
    const newErrors = { start: "", end: "" };
    if (request.dateRangeType === "custom") {
      if (!request.customStartDate) {
        newErrors.start = "Start date is required";
        isValid = false;
      }
      if (!request.customEndDate) {
        newErrors.end = "End date is required";
        isValid = false;
      }
      if (request.customStartDate && request.customEndDate) {
        if (new Date(request.customEndDate) < new Date(request.customStartDate)) {
          newErrors.end = "End date must be after start date";
          isValid = false;
        }
      }
    }
    setErrors(newErrors);
    return isValid;
  };

  /**
   * Handles the search action.
   * - Runs validation first.
   * - If valid, triggers the API call to fetch file record statistics.
   */
  const handleSearch = () => {
    if (validate()) {
      getFileRecordStats();
    }
  };

  /**
   * Handles the click event for an office user record.
   * - Encrypts the `officeUserId` from the clicked record.
   * - Serializes and encodes the current `request` state for safe URL usage.
   * - Navigates to the sub-user analytics page with `uid` (encrypted user ID)
   *   and `req` (encoded request payload) as query parameters.
   *
   * @param record - The file record containing the `officeUserId` to encrypt and use in navigation.
   */
  const handleClickOfficeUser = (record: IFileRecordStatsResponse) => {
    const encodedRequest = encodeURIComponent(encryptString(JSON.stringify(request)));
    router.push(`${ROUTES.ADMIN.SUB_USER_ANALYTICS}?uid=${record.officeUserId}&req=${encodedRequest}`);
  };

  useEffect(() => {
    getAllUsers();
  }, [getAllUsers]);

  useEffect(() => {
    getFileRecordStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request.pageNumber]);

  const totalPages = Math.ceil(totalCount / request.pageSize);
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">Office User Analytics</h4>
        </div>
        <div className="p-4 md:p-8 bg-white rounded-lg">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">Office User</h6>
              <div className="w-full">
                <Autocomplete
                  size="small"
                  options={activeUsers}
                  getOptionLabel={option => option.userName}
                  value={activeUsers.find(user => user.id === request.officeUserId) || null}
                  onChange={(event, newValue) => {
                    handleUserChange(newValue ? newValue.id : "");
                  }}
                  isOptionEqualToValue={(option, value) => option.id === value.id}
                  renderInput={params => <TextField {...params} placeholder="Select an office" />}
                  fullWidth
                  ListboxProps={{
                    sx: {
                      maxHeight: 188,
                      overflowY: "scroll",
                      "&::-webkit-scrollbar": {
                        display: "none",
                      },
                      scrollbarWidth: "none",
                      msOverflowStyle: "none",
                    },
                  }}
                />
              </div>
            </div>
            <div>
              <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">Date Range Type</h6>
              <div className="w-full">
                <Select
                  fullWidth
                  value={request.dateRangeType}
                  onChange={handleChange}
                  displayEmpty
                  sx={{ height: 40 }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        maxHeight: 188,
                        overflowY: "scroll",
                        "&::-webkit-scrollbar": {
                          display: "none",
                        },
                        scrollbarWidth: "none",
                        msOverflowStyle: "none",
                      },
                    },
                  }}
                >
                  {dateRangeTypeOptions.map(option => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Select>
              </div>
            </div>
            <div>
              <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">Start Date</h6>
              <TextField
                type="date"
                fullWidth
                disabled={request.dateRangeType !== "custom"}
                value={request.customStartDate ? request.customStartDate : ""}
                onChange={e =>
                  setRequest(prev => ({
                    ...prev,
                    customStartDate: e.target.value,
                  }))
                }
                size="small"
                sx={{
                  height: 40,
                  "& .MuiInputBase-root": {
                    height: 40,
                    backgroundColor: request.dateRangeType === "custom" ? "white" : "#f0f0f0",
                  },
                }}
                error={!!errors.start}
                helperText={errors.start}
              />
            </div>
            <div>
              <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">End Date</h6>
              <TextField
                type="date"
                fullWidth
                disabled={request.dateRangeType !== "custom"}
                value={request.customEndDate ? request.customEndDate : ""}
                onChange={e =>
                  setRequest(prev => ({
                    ...prev,
                    customEndDate: e.target.value,
                  }))
                }
                size="small"
                sx={{
                  height: 40,
                  "& .MuiInputBase-root": {
                    height: 40,
                    backgroundColor: request.dateRangeType === "custom" ? "white" : "#f0f0f0",
                  },
                }}
                error={!!errors.end}
                helperText={errors.end}
              />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-start gap-4">
            <button
              onClick={() => {
                handleSearch();
              }}
              className="w-full cursor-pointer sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
            >
              Search
            </button>
            <button
              onClick={() => {
                handleClickClearButton();
              }}
              className="w-full sm:w-auto cursor-pointer !rounded-md !px-6 !py-2 bg-[#f0f0f0] text-gray-800 hover:bg-gray-200 transition"
            >
              Clear
            </button>
          </div>
        </div>
        <div className="p-4 md:p-8 bg-white rounded-lg mt-4">
          <div className="overflow-auto w-full">
            <table className="min-w-[800px] w-full border border-[#dee2e6]">
              <thead className="bg-[#f5f6f9]">
                <tr className="text-sm text-[#888] whitespace-nowrap">
                  <th className="px-3 py-3 text-left">Office</th>
                  <th className="px-3 py-3 text-left">Total Size [GB(MB)]</th>
                  <th className="px-3 py-3 text-left">Folder Count</th>
                  <th className="px-3 py-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="text-sm text-gray-800">
                {fileStatsRecords.map((record, index) => {
                  return (
                    <tr key={index} className="border-t border-[#dee2e6] bg-white">
                      <td
                        onClick={() => handleClickOfficeUser(record)}
                        className="px-3 py-3 text-left text-blue-600 hover:underline cursor-pointer"
                      >
                        {record.officeUserName}
                      </td>
                      <td className="px-3 py-3 text-left">{formatFileSizeInGbMbFormat(record.totalFileSizeBytes)}</td>
                      <td className="px-3 py-3 text-left">{record.totalFolderCount}</td>
                      <td className="px-3 py-3 text-center">
                        <div
                          onClick={() => {
                            handleClickPlusIcon(record);
                          }}
                          className="flex items-center justify-center cursor-pointer transition-all duration-300"
                        >
                          <Eye className="w-5 h-5 text-[#7E57C2] cursor-pointer inline-block" />
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {fileStatsRecords.length === 0 && (
                  <tr className="border-t border-[#dee2e6]">
                    <td colSpan={4} className="px-3 py-3 text-center text-sm text-gray-500">
                      No records found!!
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            <CommonDrawer open={drawerOpen} onClose={() => handleDrawerClose()} title="Details">
              <table className="w-full text-sm border border-[#dee2e6]">
                <thead className="bg-[#f5f6f9]">
                  <tr className="text-sm text-[#888] whitespace-nowrap">
                    <th className="px-3 py-2 text-center">Office</th>
                    <th className="px-3 py-2 text-center">
                      {getDateLabel(request.dateRangeType, request.customStartDate, request.customEndDate)}
                    </th>
                    <th className="px-3 py-2 text-center">Total Size [GB (MB)]</th>
                    <th className="px-3 py-2 text-center">Folder Count</th>
                  </tr>
                </thead>
                <tbody className="text-sm text-gray-800">
                  {selectedBreakdown.map((breakDown, idx) => (
                    <tr key={idx} className="bg-white border-t border-[#dee2e6]">
                      <td className="px-3 py-2 text-center">{selectedUserName}</td>
                      <td className="px-3 py-2 text-center">{breakDown.label}</td>
                      <td className="px-3 py-2 text-center">
                        {formatFileSizeInGbMbFormat(breakDown.totalFileSizeBytes)}
                      </td>
                      <td className="px-3 py-2 text-center">{breakDown.folderCount}</td>
                    </tr>
                  ))}
                  {selectedBreakdown.length === 0 && (
                    <tr className="border-t border-[#dee2e6]">
                      <td colSpan={4} className="px-3 py-2 text-center text-sm text-gray-500">
                        No records found!!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </CommonDrawer>
          </div>
          {fileStatsRecords.length > 0 && (
            <div className="mt-4 flex justify-end">
              <Pagination
                count={totalPages}
                page={request.pageNumber}
                onChange={(_, page) => {
                  setRequest(prev => ({
                    ...prev,
                    pageNumber: page,
                  }));
                }}
                color="primary"
                variant="outlined"
                shape="rounded"
              />
            </div>
          )}
        </div>
      </div>
    </LoggedInLayout>
  );
};

export default AdminUserAnalytics;
