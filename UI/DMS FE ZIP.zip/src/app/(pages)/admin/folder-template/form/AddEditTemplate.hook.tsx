import { useForm } from "react-hook-form";
import { handleThunkWithDecrypt, triggerLoader } from "@core/utils";
import {
  IAddUserTemplateRequest,
  IUpdateUserTemplateRequest,
  IUserTemplateResponseWithTabsVM,
  IUserTemplateTabResponse,
} from "@main/models";
import { useAppDispatch } from "@main/hooks";
import { addFolderTemplate, getFolderTemplateById, getMaxTabLimitAPI, updateFolderTemplate } from "@main/store";
import { useCallback, useEffect, useState } from "react";

export const useFolderTemplateForm = (userId: string | null, templateId: string | null, handleBack: () => void) => {
  const dispatch = useAppDispatch();
  const [existingTabs, setExistingTabs] = useState<IUserTemplateTabResponse[]>([]);
  const [maxTabLimit, setMaxTabLimit] = useState<number>(12);
  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: { errors },
    reset,
  } = useForm<IAddUserTemplateRequest>({
    defaultValues: {
      name: "",
      tabsCount: "1",
      tabs: [],
    },
  });

  /**
   * Fetches a folder template by its ID and populates the form with its data.
   * - Uses the custom `handleThunkWithDecrypt` helper to dispatch and decrypt the API response.
   * - If the response contains valid data:
   *    - Extracts `name`, `tabs`, and `tabsCount` from the template.
   *    - Resets the form fields using `reset()` with the fetched values.
   *    - Stores the existing tabs in local state for further use.
   */
  const fetchTemplate = useCallback(async () => {
    if (templateId) {
      const response = await handleThunkWithDecrypt<IUserTemplateResponseWithTabsVM, { id: string }>(
        dispatch,
        getFolderTemplateById,
        { id: templateId }
      );

      if (response?.data) {
        const { name, tabs, tabsCount } = response.data;
        reset({
          name,
          tabsCount,
          tabs,
        });
        setExistingTabs(tabs);
      }
    }
  }, [dispatch, reset, templateId]);

  useEffect(() => {
    fetchTemplate();
  }, [fetchTemplate]);

  /**
   * Fetches the maximum tab limit for the current user.
   * - Checks if `userId` is available before proceeding.
   * - Calls the `getMaxTabLimitAPI` thunk using `handleThunkWithDecrypt`.
   * - Sends `officeUserId` as payload to the API.
   * - If a valid response is returned, updates the local `maxTabLimit` state.
   */
  const fetchMaxTabLimit = useCallback(async () => {
    if (userId) {
      const response = await handleThunkWithDecrypt<null, { officeUserId: string }>(dispatch, getMaxTabLimitAPI, {
        officeUserId: userId,
      });

      if (response?.data) {
        const maxTabLimit = response.data;
        setMaxTabLimit(maxTabLimit);
      }
    }
  }, [dispatch, userId]);

  useEffect(() => {
    fetchMaxTabLimit();
  }, [fetchMaxTabLimit]);

  /**
   * Handles form submission for adding or updating a folder template.
   * - Prevents submission if `userId` is not available.
   * - Triggers a loading indicator.
   * - If `templateId` is present, constructs an update request and dispatches `updateFolderTemplate`.
   * - If `templateId` is absent, constructs an add request and dispatches `addFolderTemplate`.
   * - On successful response for either case, navigates back using `handleBack()`.
   * - Hides the loading indicator once the operation completes.
   *
   * @param formValues - The form data entered by the user.
   */
  const onSubmit = async (formValues: IAddUserTemplateRequest) => {
    if (!userId) return;

    triggerLoader(true);
    if (templateId) {
      const updateRequest: IUpdateUserTemplateRequest = {
        ...formValues,
        id: templateId,
        userId: userId,
      };
      const resultAction = await dispatch(updateFolderTemplate(updateRequest));
      if (updateFolderTemplate.fulfilled.match(resultAction)) {
        handleBack();
      }
    } else {
      const addRequest: IAddUserTemplateRequest = {
        ...formValues,
        userId: userId,
      };
      const resultAction = await dispatch(addFolderTemplate(addRequest));
      if (addFolderTemplate.fulfilled.match(resultAction)) {
        handleBack();
      }
    }
    triggerLoader(false);
  };

  return {
    register,
    handleSubmit,
    errors,
    existingTabs,
    onSubmit,
    watch,
    reset,
    control,
    maxTabLimit,
  };
};
