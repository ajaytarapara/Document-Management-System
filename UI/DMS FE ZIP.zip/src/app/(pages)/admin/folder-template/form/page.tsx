"use client";

import { CommonButton, CommonTextField, LoggedInLayout } from "@core/components";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { getRandomColor, getRequiredMessage } from "@core/utils";
import { Box, Checkbox, MenuItem, TextField } from "@mui/material";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { useFolderTemplateForm } from "./AddEditTemplate.hook";
import { Controller } from "react-hook-form";

const AdminAddEditFolderTemplate = () => {
  const searchParams = useSearchParams();
  const router = useRouter();
  const userIdParam = searchParams.get("uid");
  const templateIdParam = searchParams.get("templateid");

  useEffect(() => {
    if (!userIdParam) {
      router.push(ROUTES.ADMIN.FOLDER_TEMPLATES);
    }
  }, [userIdParam, router]);

  const handleBackButton = () => {
    if (userIdParam) {
      router.push(`${ROUTES.ADMIN.FOLDER_TEMPLATES}?uid=${userIdParam}`);
    }
  };

  const { register, errors, handleSubmit, onSubmit, watch, existingTabs, control, maxTabLimit } = useFolderTemplateForm(
    userIdParam,
    templateIdParam,
    handleBackButton
  );
  const tabsCount = Number(watch("tabsCount") || 1);
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">
            {templateIdParam ? "Edit Template" : "Create Template"}
          </h4>
          <button
            onClick={handleBackButton}
            className="px-4 py-2 text-sm font-medium text-white bg-[#7E57C2] hover:bg-[#6C4FB3] rounded-md shadow"
          >
            Back
          </button>
        </div>
        <div className="p-4 md:p-8 bg-white rounded-lg space-y-6">
          <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col w-full gap-6">
            <Box className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Box>
                <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">Template Name:</h6>
                <CommonTextField
                  name="name"
                  placeholder="Template Name"
                  type="text"
                  required
                  fullWidth
                  register={register}
                  errors={errors}
                  validation={{
                    required: getRequiredMessage("Template Name"),
                  }}
                />
              </Box>
              <Box>
                <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-1">Number of Tabs:</h6>
                <Controller
                  name="tabsCount"
                  control={control}
                  defaultValue={tabsCount.toString()}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      select
                      fullWidth
                      error={!!errors.tabsCount}
                      helperText={errors.tabsCount?.message}
                    >
                      {Array.from({ length: maxTabLimit }, (_, i) => (
                        <MenuItem key={i + 1} value={(i + 1).toString()}>
                          {i + 1}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Box>
            </Box>
            <Box className="hidden sm:grid grid-cols-6 gap-4 bg-[#f9fafb] p-2 rounded-t font-semibold text-sm text-[#00092a]">
              <div className="col-span-4 flex items-center">Name</div>
              <div className="flex items-center justify-center">Color</div>
              <div className="flex items-center justify-center">Tab Lock</div>
            </Box>

            {Array.from({ length: tabsCount }).map((_, index) => {
              const tabIndex = index + 1;
              const nameField = `tabs.${index}.name` as const;
              const colorField = `tabs.${index}.color` as const;
              const defaultTab = existingTabs[index];

              return (
                <Box
                  key={index}
                  className="grid grid-cols-1 sm:grid-cols-6 gap-4 items-start bg-[#f9fafb] p-2 rounded-t"
                >
                  <div className="sm:col-span-4">
                    <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Name</label>
                    <CommonTextField
                      name={nameField}
                      placeholder={`tab_name${tabIndex}`}
                      type="text"
                      fullWidth
                      required
                      defaultValue={defaultTab?.name ?? `tab_name${tabIndex}`}
                      className="bg-white"
                      register={register}
                      errors={errors}
                      validation={{
                        required: getRequiredMessage(`Tab ${tabIndex} Name`),
                      }}
                    />
                  </div>

                  <div className="flex justify-between sm:justify-center sm:col-span-2 gap-4">
                    <div className="flex flex-col items-start sm:items-center w-full">
                      <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Color</label>
                      <TextField
                        type="color"
                        fullWidth
                        {...register(colorField, {
                          required: getRequiredMessage(`Tab ${tabIndex} Color`),
                        })}
                        defaultValue={defaultTab?.color ?? getRandomColor()}
                        className="w-12 h-10 border rounded bg-white cursor-pointer"
                      />
                    </div>
                    <div className="flex flex-col items-start sm:items-center">
                      <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Tab Lock</label>
                      <Controller
                        name={`tabs.${index}.isLock`}
                        control={control}
                        defaultValue={defaultTab?.isLock ?? false}
                        render={({ field }) => <Checkbox {...field} checked={field.value} />}
                      />
                    </div>
                  </div>
                </Box>
              );
            })}
            <Box className="flex justify-end gap-4 mt-4">
              <CommonButton
                type="submit"
                variant="contained"
                className="!max-h-[48px] h-full !text-sm sm:!text-[16px] font-bold px-4 sm:px-6"
              >
                Save
              </CommonButton>
            </Box>
          </Box>
        </div>
      </div>
    </LoggedInLayout>
  );
};

export default AdminAddEditFolderTemplate;
