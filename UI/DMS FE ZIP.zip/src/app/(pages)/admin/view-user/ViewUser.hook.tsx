"use client";

import { useCallback, useEffect, useState } from "react";
import { useAppDispatch } from "@main/hooks";
import { createColumnHelper, SortingState } from "@tanstack/react-table";
import { Edit, Trash2 } from "lucide-react";
import { useForm } from "react-hook-form";

import {
  ILoginResponse,
  IUserDetail,
  IUserFilter,
  OfficeUser,
  PaginationResponse,
  UserFilterRequest,
} from "@main/models";
import { deleteUser, getAllOfficeUsers, getUsers, useSelectorAuthState } from "@main/store";
import { decryptObject, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { IAPIResponse } from "@core/models";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { Constant } from "@core/constants/Constant";

/**
 * Custom hook to manage the View Users page.
 * Handles data fetching, filtering, pagination, sorting, user deletion, and navigation.
 *
 * @returns {object} Hook state and handlers for the View Users page
 */
export const useViewUserForm = () => {
  const [userData, setUserData] = useState<IUserDetail[]>([]);
  const [officeUsers, setOfficeUsers] = useState<OfficeUser[]>([]);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [totalPage, SetTotalPage] = useState<number>(0);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [filters, setFilters] = useState<IUserFilter>({
    officeUser: "",
    roleType: "",
    userName: "",
  });

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const columnHelper = createColumnHelper<IUserDetail>();
  const { loggedInUser } = useSelectorAuthState();
  const { control, register, handleSubmit, reset, watch } = useForm<IUserFilter>({
    defaultValues: {
      userName: "",
      officeUser: "",
      roleType: "",
    },
  });

  const watchedUserName = watch("userName");
  const watchedOfficeUser = watch("officeUser");
  const watchedRoleType = watch("roleType");

  const isFilterEmpty = !watchedUserName?.trim() && !watchedOfficeUser && !watchedRoleType;

  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  const officeUserOptions = [
    { label: "All", value: "" },
    ...officeUsers.map(user => ({
      label: `${user.name} (${user.userName})`,
      value: user.name,
    })),
  ];

  /**
   * Fetches paginated user data based on the provided page, size, sorting, and filters.
   *
   * @param {number} [page=pageIndex] - Current page number.
   * @param {number} [size=pageSize] - Number of users per page.
   * @param {SortingState} [currentSorting=sorting] - Current table sorting state.
   * @param {IUserFilter} [currentFilters=filters] - Current applied filters.
   */
  const getUsersData = async (
    page = pageIndex,
    size = pageSize,
    currentSorting = sorting,
    currentFilters = filters
  ) => {
    const sort = currentSorting[0];
    const searchKey = JSON.stringify(currentFilters);
    const decryptedResponse = await handleThunkWithDecrypt<PaginationResponse<IUserDetail>, UserFilterRequest>(
      dispatch,
      getUsers,
      {
        pageNumber: page,
        pageSize: size,
        sortBy: sort?.id,
        sortOrder: sort?.desc ? "Desc" : "Asc",
        searchKey: searchKey,
      }
    );

    const items = decryptedResponse?.data?.items ?? [];
    const total = decryptedResponse?.data?.totalCount ?? 0;
    const totalPages = decryptedResponse?.data?.totalPages ?? 0;
    SetTotalPage(totalPages);
    setUserData(items ?? []);
    setTotalCount(total);
  };

  /**
   * Fetches all office users and sets them in local state for dropdown filtering.
   */
  const getAllUsers = useCallback(async () => {
    const decryptedResponse = await handleThunkWithDecrypt(dispatch, getAllOfficeUsers, null);
    const items = decryptedResponse?.data ?? [];
    setOfficeUsers(items as OfficeUser[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Deletes the currently selected user (by ID) and refreshes the user list.
   * Also closes the delete confirmation dialog.
   */
  const handleDeleteUser = async () => {
    if (selectedUserId !== null) {
      const result = await dispatch(deleteUser(selectedUserId));
      if (deleteUser.fulfilled.match(result)) {
        setOpenDeleteDialog(false);
        setSelectedUserId(null);
        setTimeout(() => {
          navigate(ROUTES.ADMIN.VIEW_USER);
        }, 1500);
        getUsersData();
      }
    }
  };

  /**
   * Opens the delete confirmation dialog for the selected user ID.
   *
   * @param {number} userId - ID of the user to be deleted.
   */
  const handleOpenDeleteDialog = (userId: string) => {
    setSelectedUserId(userId);
    setOpenDeleteDialog(true);
  };

  /**
   * Closes the delete confirmation dialog and resets selected user ID.
   */
  const handleCloseDeleteDialog = () => {
    setSelectedUserId(null);
    setOpenDeleteDialog(false);
  };

  /**
   * Form submit handler for applying user filters.
   *
   * @param {IUserFilter} data - Filter values submitted from the form.
   */
  const onSubmit = (data: IUserFilter) => {
    setFilters(data);
    setPageIndex(1);
  };

  /**
   * Columns used in the user table.
   */
  const userColumns = [
    columnHelper.accessor("userName", {
      header: "Username",
    }),
    columnHelper.accessor("name", {
      header: "Name",
    }),
    columnHelper.accessor("email", {
      header: "Email",
    }),
    columnHelper.accessor("phoneNumber", {
      header: "Contact No.",
    }),

    ...(decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER
      ? [
          columnHelper.accessor("privilegeDelete", {
            header: "Has Privilege Delete",
          }),
          columnHelper.accessor("privilegeDownload", {
            header: "Has Privilege Download",
          }),
        ]
      : []),
    columnHelper.accessor("isActive", {
      header: "Status",
      cell: info => (info.getValue() ? <span>Active</span> : <span>Inactive</span>),
    }),
    columnHelper.display({
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const user = row.original;
        return (
          <div className="flex gap-2">
            <button
              onClick={() => navigate(`${ROUTES.ADMIN.UPDATE_USER}/${user.id}`)}
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Edit size={18} />
            </button>
            <button
              onClick={() => handleOpenDeleteDialog(user.id)}
              className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Trash2 size={18} />
            </button>
          </div>
        );
      },
    }),
  ];

  /**
   * Navigates back to the admin dashboard.
   */
  const backToDashboard = () => {
    navigate(ROUTES.ADMIN.DASHBOARD);
  };

  /**
   * Navigates to the Create User page.
   */
  const navigateToCreateUser = () => {
    navigate(ROUTES.ADMIN.CREATE_USER);
  };

  /**
   * Clears all applied filters and resets the filter form to default values.
   */
  const handleClearFilters = () => {
    const defaultValues: IUserFilter = {
      officeUser: "",
      roleType: "",
      userName: "",
    };
    setFilters(defaultValues);
    reset(defaultValues);
    setPageIndex(1);
  };

  useEffect(() => {
    getUsersData(pageIndex, pageSize, sorting, filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sorting, filters]);

  useEffect(() => {
    getAllUsers();
  }, [getAllUsers]);

  return {
    userData,
    userColumns,
    control,
    openDeleteDialog,
    pageSize,
    totalCount,
    pageIndex,
    totalPage,
    officeUserOptions,
    isFilterEmpty,
    setPageIndex,
    setSorting,
    setPageSize,
    backToDashboard,
    onSubmit,
    handleSubmit,
    register,
    handleCloseDeleteDialog,
    handleDeleteUser,
    navigateToCreateUser,
    handleClearFilters,
  };
};
