import emotionStyled from "@emotion/styled";
import { Button } from "@mui/material";

export const StyledButton = emotionStyled(Button)`
  background-color: #7E57C2;
  color: white;
  max-width: 100px;
  width: 100%;
  text-transform: capitalize;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #6a45b3;
  }

  &:disabled {
    background-color: #e1dcef;
    color: #9e9e9e;         
    cursor: not-allowed !important;
  }
`;

export const StyledCancelButton = emotionStyled(Button)`
  max-width: 100px;
  width: 100%;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #7E57C2;
  &:hover {
    background-color: #e1dcef;
  }
`;
