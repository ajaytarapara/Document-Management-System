"use client";

import { Box } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { UserRoundSearch } from "lucide-react";
import { ColumnDef } from "@tanstack/react-table";
import { Control, FieldValues } from "react-hook-form";

import { IUserDetail, IUserFilter } from "@main/models";
import { CommonTable, CommonTextField, Dialog, LoggedInLayout, Select } from "@core/components";
import { Constant } from "@core/constants/Constant";
import { useViewUserForm } from "./ViewUser.hook";
import { StyledButton, StyledCancelButton } from "./ViewUser.styled";

const ViewUserPage = () => {
  const {
    userData,
    userColumns,
    control,
    openDeleteDialog,
    pageSize,
    totalCount,
    pageIndex,
    totalPage,
    officeUserOptions,
    isFilterEmpty,
    setPageIndex,
    setSorting,
    setPageSize,
    backToDashboard,
    onSubmit,
    handleSubmit,
    register,
    handleCloseDeleteDialog,
    handleDeleteUser,
    navigateToCreateUser,
    handleClearFilters,
  } = useViewUserForm();

  return (
    <LoggedInLayout>
      <div className="container bg-white rounded shadow-md mx-auto mb-6">
        <div className="flex flex-col justify-between py-6 sm:py-4 xs:py-3">
          <div className="flex justify-between flex-wrap items-center px-6 sm:px-5 xs:px-2 gap-4">
            <div className="flex items-center flex-wrap xs:items-start">
              <UserRoundSearch strokeWidth={2.3} color="#00092A" className="w-6 h-6 md:w-7 md:h-7" />
              <h2 className="text-[#00092A] font-semibold text-lg sm:text-xl lg:text-2xl ml-0 sm:ml-3 mt-2 sm:mt-0">
                View Users
              </h2>
            </div>
            <div className="flex gap-4">
              <StyledButton onClick={backToDashboard}>{Constant.COMMON.BACK}</StyledButton>
              <div className="min-w-[100px]">
                <StyledButton onClick={navigateToCreateUser}>Add User</StyledButton>
              </div>
            </div>
          </div>

          <hr className="border-b border-[#7E57C2] my-4" />
          <div className="pt-4 px-6 sm:px-5 xs:px-2">
            <Box
              component="form"
              id="filter-user-form"
              onSubmit={handleSubmit(onSubmit)}
              noValidate
              className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end"
            >
              <CommonTextField<IUserFilter>
                name="userName"
                placeholder="User Name"
                label="User Name"
                register={register}
                sx={TextFieldSx}
              />

              <Select
                name="officeUser"
                label="Office User"
                placeholder="Office User"
                control={control as unknown as Control<FieldValues>}
                options={officeUserOptions}
                dropdownHeight={190}
                sx={SelectSx}
              />

              <div className="flex gap-4">
                <StyledCancelButton
                  type="button"
                  disabled={isFilterEmpty}
                  onClick={handleClearFilters}
                  variant="outlined"
                  className="w-full sm:w-auto h-11"
                >
                  {Constant.COMMON.CLEAR}
                </StyledCancelButton>
                <StyledButton disabled={isFilterEmpty} id="filter-user-form" type="submit" className="w-full sm:w-auto">
                  {Constant.COMMON.SEARCH}
                </StyledButton>
              </div>
            </Box>
          </div>
        </div>
      </div>

      <div className="container bg-white rounded shadow-md mx-auto">
        <div className="overflow-x-auto">
          <CommonTable<IUserDetail>
            data={userData}
            columns={userColumns as ColumnDef<IUserDetail>[]}
            pageSize={pageSize}
            pageIndex={pageIndex}
            totalPage={totalPage}
            emptyMessage={
              isFilterEmpty
                ? Constant.MESSAGE.NO_USERS_FOUND_MESSAGE
                : Constant.MESSAGE.NO_USERS_FOUND_FOR_SELECTED_FILTER_MESSAGE
            }
            totalCount={totalCount}
            onPageChange={setPageIndex}
            onPageSizeChange={size => {
              setPageSize(size);
              setPageIndex(pageIndex);
            }}
            onSortingChange={setSorting}
          />
        </div>
      </div>

      <Dialog
        open={openDeleteDialog}
        icon={<DeleteIcon />}
        onClose={handleCloseDeleteDialog}
        title="Delete User"
        description={Constant.MESSAGE.DELETE_USER_CONFIRMATION_MESSAGE}
        onSubmit={handleDeleteUser}
        submitLabel={Constant.COMMON.DELETE}
        cancelLabel={Constant.COMMON.CANCEL}
        buttonType="button"
      />
    </LoggedInLayout>
  );
};

export default ViewUserPage;

const TextFieldSx = {
  "& .MuiInputBase-input": {
    height: "20px",
    padding: "12px",
  },
};

const SelectSx = {
  height: 44,
  "& .MuiSelect-select": {
    padding: "12px",
  },
};
