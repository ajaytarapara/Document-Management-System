import { useParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";

import { useAppDispatch } from "@main/hooks";
import { IUpdateUserForm, ILoginResponse, IUsersResponse, OfficeUser } from "@main/models";
import { getAllOfficeUsers, getUserById, updateUser, useSelectorAuthState } from "@main/store";
import { IAPIResponse, LoginTypeEnum } from "@core/models";
import { decryptObject, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { ROUTES } from "@core/constants/PAGE_URLS";

/**
 * Custom hook to manage the update user form logic.
 * Handles fetching user data, managing form state, and submitting updated user info.
 *
 * @returns Object containing form handlers, user data, office options, and navigation utilities.
 */

export const useUpdateUserForm = () => {
  const dispatch = useAppDispatch();
  const params = useParams();
  const navigate = useNavigate();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  const [user, setUser] = useState<IUpdateUserForm | null>(null);
  const [officeUsers, setOfficeUsers] = useState<OfficeUser[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    control,
  } = useForm<IUpdateUserForm>({
    defaultValues: {
      userName: "",
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      address: "",
      city: "",
      assignedOffices: "",
      postalCode: 0,
      maxTabLimit: 1,
      isActive: false,
    },
  });

  const loginType = watch("loginType");

  /**
   * Options list derived from fetched office users for dropdown/select input.
   */
  const officeUserOptions = [
    ...officeUsers.map(user => ({
      id: user.id,
      name: user.userName,
    })),
  ];

  /**
   * Fetches all office users from the server and updates state.
   */
  const getUsersData = async () => {
    const decryptedResponse = await handleThunkWithDecrypt(dispatch, getAllOfficeUsers, null);
    const items = decryptedResponse?.data ?? [];
    setOfficeUsers(items as OfficeUser[]);
  };

  /**
   * Fetches a specific user's data by ID and sets it in the form.
   *
   * @param userId - The ID of the user to fetch.
   */
  const fetchUserData = async (userId: string) => {
    const decryptedResponse = await handleThunkWithDecrypt<IAPIResponse<IUpdateUserForm>, string>(
      dispatch,
      getUserById,
      userId
    );

    if (decryptedResponse?.data) {
      const userData = decryptedResponse.data as unknown as IUpdateUserForm;
      setUser(userData);
      reset(userData);
    }
  };

  /**
   * Handles form submission for updating a user.
   *
   * @param data - Form values containing updated user information.
   */
  const onSubmit = async (data: IUpdateUserForm) => {
    const result = await dispatch(
      updateUser({
        id: params?.id as string,
        address: data.address,
        city: data.city,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        phoneNumber: data.phoneNumber,
        userName: data.userName,
        postalCode: Number(data.postalCode),
        isActive: data.isActive,
        assignedOffices: data.assignedOffices ?? "",
        privilegeView: data.privilegeView ?? false,
        privilegeDownload: data.privilegeDownload ?? false,
        privilegeDelete: data.privilegeDelete ?? false,
        hideLockTabs: data.hideLockTabs ?? false,
        maxTabLimit: data.maxTabLimit ?? 1,
        loginType: data.loginType ?? LoginTypeEnum.USERNAME,
      })
    );
    if (updateUser.fulfilled.match(result)) {
      const encryptedString = result.payload?.data;
      const decrypted: IAPIResponse<IUsersResponse> = decryptObject<IAPIResponse<IUsersResponse>>(
        encryptedString as unknown as string
      );
      if (decrypted?.data) {
        navigate(ROUTES.ADMIN.VIEW_USER);
      }
    }
  };

  /**
   * Navigates the user back to the "View Users" admin page.
   */
  const backToViewUsers = () => {
    navigate(ROUTES.ADMIN.VIEW_USER);
  };

  useEffect(() => {
    const init = async () => {
      await getUsersData();
      if (params?.id) {
        await fetchUserData(params.id as string);
      }
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params?.id]);

  useEffect(() => {
    if (user && officeUsers.length > 0) {
      reset(user);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [officeUsers, user]);
  return {
    user,
    errors,
    control,
    officeUserOptions,
    decryptedLoggedUser,
    loginType,
    handleSubmit,
    onSubmit,
    register,
    backToViewUsers,
  };
};
