"use client";

import { UserRoundPlus } from "lucide-react";
import { Control, FieldValues } from "react-hook-form";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";

import { useUpdateUserForm } from "./UpdateUser.hook";
import { Constant, loginTypeOptions } from "@core/constants/Constant";
import { getRequiredMessage } from "@core/utils";
import {
  CommonMultiSelectAutocomplete,
  CommonCheckbox,
  CommonTextField,
  LoggedInLayout,
  Select,
  StyledFormLabel,
  CommonButton,
} from "@core/components";
import { IUpdateUserForm } from "@main/models";
import { StyledCancelButton } from "./UpdateUserForm.styled";
import { LoginTypeEnum } from "@core/models";

export default function EditUserPage() {
  const {
    user,
    errors,
    control,
    officeUserOptions,
    decryptedLoggedUser,
    loginType,
    handleSubmit,
    onSubmit,
    register,
    backToViewUsers,
  } = useUpdateUserForm();

  if (!user) return null;

  return (
    <LoggedInLayout>
      <div className="container bg-white rounded shadow-md mx-auto">
        <div className="py-2 px-3 md:py-4 sm:px-6 border-b border-[#7E57C2] ">
          <div className="flex items-center">
            <UserRoundPlus strokeWidth={2.3} color="#00092A" className="w-6 h-6 md:w-7 md:h-7" />
            <h2 className="text-[#00092A] font-semibold text-xl lg:text-2xl ml-3 xs:ml-0 xs:mt-2 xs:text-lg">
              {Constant.COMMON.UPDATE}{" "}
              {decryptedLoggedUser?.data?.role === Constant.COMMON.ADMIN
                ? Constant.COMMON.OFFICE_USER
                : Constant.COMMON.USER}
            </h2>
          </div>
          <div className="mt-2 sm:mt-3">
            <h4 className="text-[#727272] font-semibold text-xs sm:text-sm">
              {Constant.MESSAGE.INSTRUCTION_FOR_UPDATE_USER}
            </h4>
          </div>
        </div>
        <Box component="form" className="p-4" id="create-user-form" onSubmit={handleSubmit(onSubmit)} noValidate>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="userName"
                placeholder="Username"
                label="Username"
                disabled
                register={register}
                validation={{
                  required: getRequiredMessage("Username"),
                  pattern: {
                    value: Constant.REGEX.USERNAME_REGEX,
                    message: Constant.MESSAGE.INVALID_USERNAME,
                  },
                  maxLength: { value: 50, message: Constant.MESSAGE.USER_NAME_MAX_LIMIT },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="firstName"
                placeholder="First Name"
                label="First Name"
                required
                register={register}
                validation={{
                  required: getRequiredMessage("First Name"),
                  maxLength: { value: 50, message: Constant.MESSAGE.USER_NAME_MAX_LIMIT },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="lastName"
                placeholder="Last Name"
                label="Last Name"
                required
                register={register}
                validation={{
                  required: getRequiredMessage("Last Name"),
                  maxLength: { value: 50, message: Constant.MESSAGE.USER_NAME_MAX_LIMIT },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="email"
                placeholder="Email"
                label="Email"
                required
                register={register}
                disabled={loginType == LoginTypeEnum.SSO || loginType == LoginTypeEnum.BOTH}
                validation={{
                  required: getRequiredMessage("Email"),
                  maxLength: { value: 50, message: Constant.MESSAGE.USER_NAME_MAX_LIMIT },
                  pattern: { value: Constant.REGEX.EMAIL_REGEX, message: Constant.MESSAGE.INVALID_EMAIL },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="phoneNumber"
                placeholder="Phone Number"
                label="Phone Number"
                required
                register={register}
                validation={{
                  required: getRequiredMessage("Phone Number"),
                  pattern: {
                    value: Constant.REGEX.PHONE_REGEX,
                    message: Constant.MESSAGE.INVALID_PHONE,
                  },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="address"
                placeholder="Address"
                label="Address"
                register={register}
                validation={{
                  maxLength: { value: 200, message: Constant.MESSAGE.ADDRESS_MAX_LIMIT },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="city"
                placeholder="City"
                label="City"
                register={register}
                validation={{
                  maxLength: { value: 50, message: Constant.MESSAGE.USER_NAME_MAX_LIMIT },
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="postalCode"
                placeholder="Postal Code"
                label="Postal Code"
                required
                register={register}
                validation={{
                  required: getRequiredMessage("Postal Code"),
                  pattern: {
                    value: Constant.REGEX.POSTAL_CODE_REGEX,
                    message: Constant.MESSAGE.INVALID_POSTAL_CODE,
                  },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonTextField<IUpdateUserForm>
                name="maxTabLimit"
                placeholder="Maximum Tabs Limit"
                label="Maximum Tabs Limit"
                type="number"
                required
                register={register}
                validation={{
                  required: getRequiredMessage("Max Tab Limit"),
                  max: { value: 12, message: Constant.COMMON.MAX_TAB_LIMIT },
                  min: { value: 1, message: Constant.COMMON.MIN_TAB_LIMIT },
                }}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <Select
                name="loginType"
                label="Login Type"
                required
                placeholder="Select login type"
                errors={errors}
                fullWidth
                validations={{ required: Constant.MESSAGE.LOGIN_TYPE_REQUIRED }}
                control={control as unknown as Control<FieldValues>}
                options={loginTypeOptions}
              />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <StyledFormLabel>Is Active</StyledFormLabel>
              <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
                <CommonCheckbox<IUpdateUserForm> name="isActive" label="Is Active" control={control} />
              </div>
            </Grid>
            <Grid size={{ xs: 12, sm: 6, md: 4 }}>
              <CommonMultiSelectAutocomplete
                name="assignedOffices"
                control={control}
                label="Assign Offices"
                options={officeUserOptions}
                placeholder="Select Office"
                errors={errors}
              />
            </Grid>
          </Grid>
          <div className="my-6">
            <Grid container spacing={2} justifyContent={"flex-end"}>
              <Grid alignItems={"flex-end"} justifyContent={"flex-end"}>
                <StyledCancelButton
                  onClick={backToViewUsers}
                  variant="outlined"
                  className="text-[#263238] w-full sm:w-auto font"
                >
                  {Constant.COMMON.CANCEL}
                </StyledCancelButton>
              </Grid>
              <Grid alignItems={"flex-end"} justifyContent={"flex-end"}>
                <CommonButton type="submit" variant="contained" form="create-user-form" className="w-full sm:w-auto">
                  {Constant.COMMON.SAVE}
                </CommonButton>
              </Grid>
            </Grid>
          </div>
        </Box>
      </div>
    </LoggedInLayout>
  );
}
