import emotionStyled from "@emotion/styled";
import { Button } from "@mui/material";

export const StyledCancelButton = emotionStyled(Button)`
  max-width: 100px;
  width: 100%;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #7E57C2;
  &:hover {
    background-color: #e1dcef;
  }
`;
