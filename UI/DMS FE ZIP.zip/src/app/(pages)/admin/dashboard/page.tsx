"use client";

import { LoggedInLayout } from "@core/components";
import {
  ChartNoAxesCombined,
  FilePenLine,
  FolderUp,
  UserCog,
  UserLock,
  UserRound,
  UserRoundPlus,
  UserRoundSearch,
} from "lucide-react";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { useNavigate } from "@core/utils";

export type CardProps = {
  icon: React.ReactNode;
  label: string;
  route: string;
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const Card = ({ icon, label, route }: CardProps) => {
    return (
      <div
        onClick={() => navigate(route)}
        className="group bg-white border border-transparent hover:border-[#7E57C2] rounded-2xl py-6 px-4 cursor-pointer flex flex-col items-center text-center transition-all duration-300 shadow-md hover:shadow-2xl hover:-translate-y-1"
      >
        <div className="relative h-[48px] w-[48px] mb-4 flex items-center justify-center transition-all duration-300 transform group-hover:scale-110 group-hover:rotate-6">
          {icon}
          <div className="absolute inset-0 rounded-full bg-[#7E57C2] opacity-10 group-hover:opacity-20 transition-opacity duration-300"></div>
        </div>
        <span className="text-sm sm:text-base font-medium text-[#00092a] group-hover:text-[#7E57C2] transition-colors duration-300">
          {label}
        </span>
      </div>
    );
  };

  const items: CardProps[] = [
    {
      icon: <UserRound className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "User Login",
      route: ROUTES.ADMIN.USER_LOGIN,
    },
    {
      icon: <UserRoundPlus className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "Create User",
      route: ROUTES.ADMIN.CREATE_USER,
    },
    {
      icon: <UserRoundSearch className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "View User",
      route: ROUTES.ADMIN.VIEW_USER,
    },
    {
      icon: <FolderUp className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "Folder Templates",
      route: ROUTES.ADMIN.FOLDER_TEMPLATES,
    },
    {
      icon: <UserCog className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "My Account",
      route: ROUTES.ADMIN.ACCOUNT,
    },
    {
      icon: <UserLock className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "Change Password",
      route: ROUTES.ADMIN.CHANGE_PASSWORD,
    },
    {
      icon: <FilePenLine className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "DMS Forms",
      route: ROUTES.ADMIN.DMS_FORMS,
    },
    {
      icon: <ChartNoAxesCombined className="h-6 w-6 text-[#7E57C2] z-10" />,
      label: "User Analytics",
      route: ROUTES.ADMIN.OFFICE_USER_ANALYTICS,
    },
  ];

  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">Admin Dashboard</h4>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {items.map((item, index) => (
            <Card key={index} {...item} />
          ))}
        </div>
      </div>
    </LoggedInLayout>
  );
};

export default AdminDashboard;
