"use client";

import { CommonTable, CommonTextField, Dialog, LoggedInLayout } from "@core/components";
import { useDmsForm } from "./DmsForm.hook";
import { Autocomplete, IconButton, InputAdornment, TextField } from "@mui/material";
import { Eye, EyeOff, FileUp, Trash2 } from "lucide-react";
import { Constant } from "@core/constants/Constant";
import { formatFileSize, getRequiredMessage } from "@core/utils";
import { DeleteFileProps, DeleteFormValues, EditFileProps, EditFormValues } from "@main/models";
import { useState } from "react";
import { PdfPreview } from "@main/components";
import { CommonDMSDrawer } from "@main/components";
interface DocumentsTableProps {
  selectedFiles: File[];
  setSelectedFiles: React.Dispatch<React.SetStateAction<File[]>>;
}

const DmsForms = () => {
  const {
    dmsFormColumns,
    pageIndex,
    pageSize,
    activeUsers,
    selectedUserId,
    fileInputRef,
    isDialogOpen,
    selectedFiles,
    totalPage,
    dmsFormsData,
    totalCount,
    openEditDialog,
    handleCloseEditDialog,
    editErrors,
    editRegister,
    handleEditFile,
    openDeleteDialog,
    handleToggleDeleteDialog,
    errors,
    handleDeleteFile,
    register,
    setSelectedFiles,
    handleSearchClick,
    handleFileButtonClick,
    handleFileChange,
    setSelectedUserId,
    setSorting,
    handleDialogClose,
    onSubmit,
    handlePageChange,
    handlePageSizeChange,
    handleClosePreviewModel,
    openPreviewModal,
    fileUrl,
    fileName,
  } = useDmsForm();
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">DMS Forms</h4>
        </div>

        <div className="p-4 md:p-6 bg-white rounded-lg">
          <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-2">
            Select office user to see DMS forms:
          </h6>
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4 gap-2 w-full">
            <div className="w-full sm:w-[400px]">
              <Autocomplete
                size="small"
                options={activeUsers}
                getOptionLabel={option => option.userName}
                value={activeUsers.find(user => user.id === selectedUserId) || null}
                onChange={(event, newValue) => {
                  setSelectedUserId(newValue ? newValue.id : "");
                }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                renderInput={params => <TextField {...params} placeholder="Search Users..." />}
                fullWidth
                slotProps={{
                  listbox: {
                    sx: {
                      maxHeight: 188,
                      overflowY: "scroll",
                      "&::-webkit-scrollbar": {
                        display: "none",
                      },
                      scrollbarWidth: "none",
                      msOverflowStyle: "none",
                    },
                  },
                }}
              />
            </div>
            <button
              type="button"
              disabled={!selectedUserId}
              onClick={() => handleSearchClick(selectedUserId)}
              className="w-full sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white disabled:bg-[#d2caf5] rounded-md shadow hover:bg-[#6C4FB3] cursor-pointer"
            >
              Search
            </button>
          </div>
        </div>
        <div className="p-4 bg-white rounded-lg mt-4">
          <div className="border border-dashed border-gray-300 rounded-md min-h-[130px] h-full flex justify-center items-center">
            <div className="flex flex-col justify-center items-center p-2">
              <FileUp strokeWidth={1} className="h-10 w-10 text-[#7E57C2] z-10" />
              <p className="text-[#b0c0d4] text-[16px] mt-2 text-center">Add additional Pdf Fillable Form(s) here</p>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <input
              type="file"
              ref={fileInputRef}
              accept="application/pdf"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />

            <button
              type="button"
              onClick={handleFileButtonClick}
              className="w-full sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3] cursor-pointer"
            >
              Select File
            </button>
          </div>
        </div>
        <div className="mt-4">
          <CommonTable
            data={dmsFormsData}
            columns={dmsFormColumns}
            pageSize={pageSize}
            pageIndex={pageIndex}
            totalPage={totalPage}
            totalCount={totalCount}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onSortingChange={setSorting}
            emptyMessage={Constant.MESSAGE.NO_FILES_UPLOADED_FOR_USER}
          />
        </div>

        <CommonDMSDrawer
          open={isDialogOpen}
          onClose={handleDialogClose}
          title="Upload Documents"
          description={<DocumentsTable selectedFiles={selectedFiles} setSelectedFiles={setSelectedFiles} />}
          onSubmit={onSubmit}
          disableSubmit={!selectedFiles.length}
          submitLabel={Constant.COMMON.UPLOAD}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType="button"
        />

        <CommonDMSDrawer
          open={openEditDialog}
          onClose={handleCloseEditDialog}
          title="Edit File Name"
          description={<EditFile editErrors={editErrors} editRegister={editRegister} />}
          onSubmit={handleEditFile}
          submitLabel={Constant.COMMON.SAVE}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType="button"
        />

        <Dialog
          open={openDeleteDialog}
          onClose={handleToggleDeleteDialog}
          title="Delete File"
          description={<DeleteFile errors={errors} register={register} />}
          onSubmit={handleDeleteFile}
          maxWidth={"sm"}
          fullWidth
          submitLabel={Constant.COMMON.SUBMIT}
          cancelLabel={Constant.COMMON.CANCEL}
          buttonType="submit"
        />

        <PdfPreview open={openPreviewModal} onClose={handleClosePreviewModel} fileName={fileName} fileUrl={fileUrl} />
      </div>
    </LoggedInLayout>
  );
};

const DeleteFile: React.FC<DeleteFileProps> = ({ errors, register }) => {
  const [showPassword, setShowPassword] = useState(false);

  /**
   * Toggles the visibility of the password field.
   * - Switches between showing and hiding the password by updating `showPassword` state.
   */
  const togglePasswordVisibility = () => setShowPassword(prev => !prev);
  return (
    <div>
      <p className="mb-4 text-sm text-gray-700">Caution! Are you sure you want to delete this file?</p>
      <div className="relative">
        <CommonTextField<DeleteFormValues>
          name="password"
          placeholder="Password"
          label="Password"
          type={showPassword ? "text" : "password"}
          register={register}
          validation={{
            required: getRequiredMessage("Password"),
          }}
          errors={errors}
          slotProps={{
            input: {
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    disableRipple
                    onClick={togglePasswordVisibility}
                    edge="end"
                    size="small"
                    className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                  >
                    {showPassword ? (
                      <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                    ) : (
                      <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                    )}
                  </IconButton>
                </InputAdornment>
              ),
            },
          }}
        />
      </div>
    </div>
  );
};

const EditFile: React.FC<EditFileProps> = ({ editErrors, editRegister }) => {
  return (
    <div>
      <CommonTextField<EditFormValues>
        name="name"
        placeholder="Name"
        label="Name"
        register={editRegister}
        validation={{
          required: getRequiredMessage("File Name"),
        }}
        errors={editErrors}
      />
    </div>
  );
};

const DocumentsTable = ({ selectedFiles, setSelectedFiles }: DocumentsTableProps) => {
  /**
   * Removes a selected file from the list based on its index.
   *
   * @param indexToRemove - The index of the file to be removed from the selected files array.
   */
  const handleDelete = (indexToRemove: number) => {
    setSelectedFiles(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };
  return (
    <div className="shadow-sm overflow-x-auto">
      <table className="min-w-full table-auto border-collapse">
        <thead className="bg-[#e1dcef]">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">File Name</th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">Size & Format</th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-[#00092A] rounded-tr-md">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {selectedFiles.map((item, index) => (
            <tr key={index} className="hover:bg-gray-50 transition">
              <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">{item.name}</td>
              <td className="px-4 py-3 text-sm text-gray-800">
                {formatFileSize(item.size)} ({item.type})
              </td>
              <td className="px-4 py-3">
                <div className="flex justify-center items-center gap-3 flex-wrap">
                  <Trash2 className="w-5 h-5 text-[#EF5350] cursor-pointer" onClick={() => handleDelete(index)} />
                </div>
              </td>
            </tr>
          ))}
          {selectedFiles.length === 0 && (
            <tr>
              <td colSpan={3} className="px-4 py-6 text-center text-sm text-gray-500">
                No files uploaded yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DmsForms;
