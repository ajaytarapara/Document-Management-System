import { useCallback, useEffect, useRef, useState } from "react";
import { ColumnDef, SortingState } from "@tanstack/react-table";
import { Edit, Trash2 } from "lucide-react";
import { useAppDispatch } from "@main/hooks";
import {
  IUsersResponse,
  IDmsForm,
  PaginationResponse,
  DmsFormPaginationRequest,
  DeleteFormValues,
  EditFormValues,
  IRequestUploadDmsForms,
  RenameDmsFormRequest,
} from "@main/models";
import {
  deleteDmsForm,
  getAllActiveOfficeUsers,
  getAllDmsForms,
  getDmsFormById,
  renameDmsForm,
  uploadDmsForms,
} from "@main/store";
import { handleThunkWithDecrypt } from "@core/utils";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { Constant } from "@core/constants/Constant";

/**
 * Custom hook to manage DMS (Document Management System) form functionalities including:
 * - Fetching active users
 * - Fetching DMS forms by user with pagination and sorting
 * - Uploading DMS forms
 * - Editing form names
 * - Deleting forms (with password validation)
 * - Handling pagination and file dialog operations
 *
 * @returns An object containing state, form handlers, and UI interaction handlers
 */
export const useDmsForm = () => {
  const dispatch = useAppDispatch();

  const [activeUsers, setActiveUsers] = useState<IUsersResponse[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [dmsFormsData, setDmsFormsData] = useState<IDmsForm[]>([]);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [totalPage, SetTotalPage] = useState<number>(0);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [openEditDialog, setOpenEditDialog] = useState<boolean>(false);
  const [deleteFileId, setDeleteFileId] = useState<string | null>(null);
  const [openPreviewModal, setOpenPreviewModal] = useState<boolean>(false);
  const [fileUrl, setFileUrl] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<DeleteFormValues>();

  const {
    register: editRegister,
    handleSubmit: handleEditSubmit,
    formState: { errors: editErrors },
    reset: editReset,
  } = useForm<EditFormValues>();

  /**
   * Fetches all active users from the backend and sets them in local state.
   */
  const getAllUsers = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IUsersResponse[]>(dispatch, getAllActiveOfficeUsers);
    if (response?.data) {
      setActiveUsers(response.data);
    }
  }, [dispatch]);

  /**
   * Fetches DMS forms for a specific user with pagination and sorting.
   *
   * @param page - The page number to fetch.
   * @param size - The number of records per page.
   * @param currentSorting - The current sorting state.
   * @param selectedUserId - The user ID to fetch forms for.
   */

  const getDmsForms = async (page = pageIndex, size = pageSize, currentSorting = sorting, selectedUserId: string) => {
    const sort = currentSorting[0];

    const decryptedResponse = await handleThunkWithDecrypt<PaginationResponse<IDmsForm>, DmsFormPaginationRequest>(
      dispatch,
      getAllDmsForms,
      {
        pageNumber: page,
        pageSize: size,
        sortBy: sort?.id,
        sortOrder: sort?.desc ? "Desc" : "Asc",
        userId: selectedUserId,
      }
    );

    const items = decryptedResponse?.data?.items ?? [];
    const total = decryptedResponse?.data?.totalCount ?? 0;
    const totalPages = decryptedResponse?.data?.totalPages ?? 0;

    SetTotalPage(totalPages);
    setDmsFormsData(items);
    setTotalCount(total);
  };

  /**
   * Columns used in the DMS forms table.
   */
  const dmsFormColumns: ColumnDef<IDmsForm>[] = [
    {
      accessorKey: "name",
      header: "Available Fillable DMS forms Name",
      cell: ({ row }) => {
        const name = row.original.name;
        const file = row.original.url;
        return (
          <span
            onClick={() => handleOpenPreviewModal(file, name)}
            className="text-[#7E57C2] hover:underline cursor-pointer"
          >
            {name}
          </span>
        );
      },
    },
    {
      accessorKey: "size",
      header: "Size(Mb)",
      cell: info => info.getValue(),
    },
    {
      accessorKey: "createdAt",
      header: "Created Date",
      cell: info => info.getValue(),
    },
    {
      accessorKey: "Action",
      header: "Actions",
      enableSorting: false,
      cell: ({ row }) => {
        const id = row.original.id;
        return (
          <div className="flex gap-2">
            <button
              onClick={() => handleOpenEditDialog(id)}
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Edit size={18} />
            </button>
            <button
              onClick={() => handleToggleDeleteDialog(id)}
              className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Trash2 size={18} />
            </button>
          </div>
        );
      },
    },
  ];

  /**
   * Handles the upload of selected files for a given user.
   * Validates user selection.
   * Dispatches the upload action.
   * Refreshes the list upon success.
   *
   * @param e - Optional form event to prevent default submission.
   */

  const onSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (selectedUserId == "") {
      toast.error(Constant.MESSAGE.NO_USER_SELECTED);
      setIsDialogOpen(false);
      return;
    }
    if (selectedFiles.length === 0) return;

    const result = await handleThunkWithDecrypt<string, IRequestUploadDmsForms>(dispatch, uploadDmsForms, {
      forms: selectedFiles,
      userId: selectedUserId,
    });

    if (result.isSuccessful && result.data) {
      setSelectedFiles([]);
      setIsDialogOpen(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      getDmsForms(pageIndex, pageSize, sorting, result.data);
    }
  };

  /**
   * Fetches DMS forms based on selected user ID from the search dropdown.
   *
   * @param id - The selected user's ID.
   */
  const handleSearchClick = (id: string) => {
    setPageIndex(1);
    getDmsForms(1, pageSize, sorting, id);
  };

  /**
   * Programmatically triggers the hidden file input element.
   */
  const handleFileButtonClick = () => {
    fileInputRef.current?.click();
  };

  /**
   * Handles file selection change event and updates the selected files state.
   * Opens the dialog for file upload.
   *
   * @param e - File input change event.
   */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setSelectedFiles(Array.from(files));
      setIsDialogOpen(true);
    }
  };

  /**
   * Closes the file upload dialog and resets its state.
   */
  const handleDialogClose = () => {
    setIsDialogOpen(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  /**
   * Toggles the delete confirmation dialog and stores the file ID.
   *
   * @param id - ID of the file to delete.
   */
  const handleToggleDeleteDialog = (id?: string) => {
    if (id !== undefined) {
      setDeleteFileId(id);
    }
    setOpenDeleteDialog(prev => !prev);
    reset();
  };

  /**
   * Opens the edit dialog and pre-fills the form with the current file name.
   *
   * @param id - ID of the file to rename.
   */
  const handleOpenEditDialog = async (id?: string) => {
    if (id !== undefined) {
      setOpenEditDialog(prev => !prev);
      const result = await handleThunkWithDecrypt<IDmsForm, { formId: string; userId: string }>(
        dispatch,
        getDmsFormById,
        {
          formId: String(id),
          userId: String(selectedUserId),
        }
      );
      if (result?.data?.name) {
        editReset({ name: result.data.name });
        setDeleteFileId(id);
      }
    }
  };

  /**
   * Closes the edit dialog and resets the form.
   */
  const handleCloseEditDialog = () => {
    setOpenEditDialog(false);
    editReset();
  };

  /**
   * Handles deletion of a file after validating the password.
   * - Dispatches the delete action.
   * - Refreshes the list if successful.
   */
  const handleDeleteFile = handleSubmit(async data => {
    if (deleteFileId !== null && data.password) {
      const result = await dispatch(
        deleteDmsForm({
          dmsFormId: deleteFileId,
          userId: selectedUserId,
          password: data.password,
        })
      );

      if (deleteDmsForm.fulfilled.match(result)) {
        getDmsForms(pageIndex, pageSize, sorting, selectedUserId);
        setOpenDeleteDialog(false);
        reset();
      }
    }
  });

  /**
   * Handles renaming of a DMS file.
   * - Dispatches the rename action.
   * - Refreshes the list if successful.
   */
  const handleEditFile = handleEditSubmit(async data => {
    if (deleteFileId !== null) {
      const result = await handleThunkWithDecrypt<string, RenameDmsFormRequest>(dispatch, renameDmsForm, {
        dmsFormId: deleteFileId,
        newFileName: data.name,
        userId: selectedUserId as string,
      });
      if (result.isSuccessful) {
        getDmsForms(pageIndex, pageSize, sorting, selectedUserId as string);
        setOpenEditDialog(false);
        editReset();
      }
    }
  });

  /**
   * Updates current page index and fetches data for new page.
   *
   * @param newPageIndex - The page index to switch to.
   */
  const handlePageChange = (newPageIndex: number) => {
    setPageIndex(newPageIndex);
    if (selectedUserId) {
      getDmsForms(newPageIndex, pageSize, sorting, selectedUserId);
    }
  };

  /**
   * Updates page size and resets the page index.
   *
   * @param newSize - Number of records per page.
   */
  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize);
    setPageIndex(1);
    if (selectedUserId) {
      getDmsForms(1, newSize, sorting, selectedUserId);
    }
  };

  /**
   * Close preview modal and reset file state.
   */
  const handleClosePreviewModel = () => {
    setFileUrl("");
    setOpenPreviewModal(false);
  };

  /**
   * Open preview modal for a given file.
   */
  const handleOpenPreviewModal = (url: string, fileName: string) => {
    setOpenPreviewModal(true);
    setFileUrl(url);
    setFileName(fileName);
  };

  useEffect(() => {
    getAllUsers();
  }, [getAllUsers]);

  useEffect(() => {
    if (Number(selectedUserId) > 0) {
      getDmsForms(pageIndex, pageSize, sorting, selectedUserId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sorting]);

  return {
    dmsFormColumns,
    pageIndex,
    pageSize,
    activeUsers,
    selectedUserId,
    fileInputRef,
    isDialogOpen,
    selectedFiles,
    totalPage,
    dmsFormsData,
    totalCount,
    openEditDialog,
    handleCloseEditDialog,
    editErrors,
    editRegister,
    handleEditFile,
    openDeleteDialog,
    handleToggleDeleteDialog,
    errors,
    handleDeleteFile,
    register,
    setSelectedFiles,
    handleSearchClick,
    handleFileButtonClick,
    handleFileChange,
    setSelectedUserId,
    setSorting,
    handleDialogClose,
    onSubmit,
    handlePageChange,
    handlePageSizeChange,
    handleClosePreviewModel,
    openPreviewModal,
    fileUrl,
    fileName,
    handleOpenPreviewModal,
  };
};
