"use client";
import { LoggedInLayout } from "@core/components";
import { AccountForm } from "@main/components";

const ProfilePage = () => {
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 bg-background p-6">
        <AccountForm />
      </div>
    </LoggedInLayout>
  );
};

export default ProfilePage;
