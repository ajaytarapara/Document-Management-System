"use client";

import React from "react";

import CreateFolder from "@main/components/FolderComponents/CreateFolder";

const CreateFolderForm = () => {
  return <CreateFolder />;
};

export default CreateFolderForm;
