"use client";

import React from "react";

import GetFolder from "@main/components/FolderComponents/GetFolder";

const CreateFolderForm = () => {
  return <GetFolder />;
};

export default CreateFolderForm;
