"use client";

import { EmailOtpVerification } from "@main/components";

export default function ViewDmsFormPage() {
  return <EmailOtpVerification />;
}
