import { Checkbox, styled } from "@mui/material";

export const StyledCheckbox = styled(Checkbox)(({ theme }) => ({
  color: theme.palette.primary.main,
  padding: "3px 5px",
  "&.Mui-checked": {
    color: theme.palette.primary.main,
  },
}));
