import React from "react";
import EditableForms from "@main/components/EditableForms";
import { LoggedInLayout } from "@core/components";

export default function DmsFormPage() {
  return (
    <LoggedInLayout>
      <div className="px-2">
        <div className="flex items-center pb-4 md:pb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">DMS Form Builder</h4>
        </div>
        <EditableForms />
      </div>
    </LoggedInLayout>
  );
}
