"use client";

import { LoggedInLayout } from "@core/components";
import { SplitAndUpload } from "@main/components";

const SplitAndUploadPdfSubUser = () => {
  return (
    <LoggedInLayout>
      <SplitAndUpload />
    </LoggedInLayout>
  );
};

export default SplitAndUploadPdfSubUser;
