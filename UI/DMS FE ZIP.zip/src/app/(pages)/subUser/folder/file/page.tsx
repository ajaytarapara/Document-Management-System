"use client";

import { LoggedInLayout } from "@core/components";
import { FolderFile } from "@main/components";

const SubUserFolderFile = () => {
  return (
    <LoggedInLayout>
      <FolderFile />
    </LoggedInLayout>
  );
};

export default SubUserFolderFile;
