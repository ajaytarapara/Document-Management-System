"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useAppDispatch } from "@main/hooks";
import { Button, Grid, Typography } from "@mui/material";
import { Constant } from "@core/constants/Constant";
import { CommonDrawer, CommonTextField } from "@core/components";
import { decryptObject, handleThunkWithDecrypt } from "@core/utils";
import { FolderDto, UpdateFolderArgs } from "@main/models";
import { getFolderById, updateFolder } from "@main/store";

interface EditFolderDrawerProps {
  open: boolean;
  onClose: () => void;
  folderId: string | null;
  fetchFolder: () => void;
}

export interface EditFolderFormValues {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
}

export const EditFolderDrawer = ({ open, onClose, folderId, fetchFolder }: EditFolderDrawerProps) => {
  const dispatch = useAppDispatch();
  const [tabCount, setTabCount] = useState(0);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<EditFolderFormValues>({
    defaultValues: {
      firstName: "",
      lastName: "",
      fileNumber: "",
      folderName: "",
    },
  });

  /**
   * Fetches folder data by folderId from the API.
   * - Dispatches the `getFolderById` thunk to retrieve folder details.
   * - Decrypts the encrypted response payload into a `FolderDto` object.
   * - Resets the form values with the decrypted folder data.
   * - Updates the tab count state from the folder data.
   *
   * Returns early if `folderId` is not provided.
   */
  const fetchFolderData = async () => {
    if (!folderId) return;
    const res = await dispatch(getFolderById({ id: folderId }));
    if (getFolderById.fulfilled.match(res)) {
      const encryptedString = res.payload.data;
      const decrypted: FolderDto = decryptObject<FolderDto>(encryptedString);
      if (decrypted) {
        reset({
          firstName: decrypted.firstName,
          lastName: decrypted.lastName,
          fileNumber: decrypted.fileNumber,
          folderName: decrypted.folderName,
        });
        setTabCount(decrypted.tabCount);
      }
    }
  };

  useEffect(() => {
    if (open) fetchFolderData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  /**
   * Handles the folder update form submission.
   * - Returns early if `folderId` is not available.
   * - Calls `handleThunkWithDecrypt` to dispatch the `updateFolder` thunk
   *   with the provided form data and decrypts the response.
   * - Refreshes the folder data by calling `fetchFolder`.
   * - Closes the form/modal by invoking `onClose`.
   */
  const onSubmit = async (data: EditFolderFormValues) => {
    if (!folderId) return;
    await handleThunkWithDecrypt<string, UpdateFolderArgs>(dispatch, updateFolder, {
      id: folderId,
      data,
    });
    fetchFolder();
    onClose();
  };

  return (
    <CommonDrawer open={open} onClose={onClose} title="Edit Folder" lgSize="40%">
      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="folderName"
              label="Folder Name"
              register={register}
              validation={{ required: Constant.MESSAGE.FOLDER_REQUIRED }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="fileNumber"
              label="File Number"
              register={register}
              validation={{ required: Constant.MESSAGE.FIRSTNAME_REQ }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="firstName"
              label="First Name"
              register={register}
              validation={{ required: Constant.MESSAGE.TAB_NAME_REQ }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="lastName"
              label="Last Name"
              register={register}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
            />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <Typography>Total Tab: {tabCount}</Typography>
          </Grid>
          <Grid size={{ xs: 12 }}>
            <Button type="submit" variant="contained" color="primary">
              Update Folder
            </Button>
          </Grid>
        </Grid>
      </form>
    </CommonDrawer>
  );
};
