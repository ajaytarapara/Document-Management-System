"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useAppDispatch } from "@main/hooks";
import { Button, Grid } from "@mui/material";
import { Constant } from "@core/constants/Constant";
import { CommonDrawer, CommonTextField } from "@core/components";
import { updateFile } from "@main/store";
import { handleThunkWithDecrypt } from "@core/utils";
import { UpdateFileArgs } from "@main/models";

interface EditFileDrawerProps {
  open: boolean;
  onClose: () => void;
  fileId: string;
  onSucess: () => void;
  fileName: string;
}

export interface EditFileFormValues {
  fileName: string;
}

export const EditFileDrawer = ({ open, onClose, fileId, onSucess, fileName }: EditFileDrawerProps) => {
  const dispatch = useAppDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<EditFileFormValues>({
    defaultValues: {
      fileName: "",
    },
  });

  /**
   * useEffect hook
   * Runs whenever modal is opened or fileName changes.
   * Resets the form with the provided `fileName` so user sees the current name.
   */
  useEffect(() => {
    if (open) {
      reset({ fileName });
    }
  }, [fileName, open, reset]);

  /**
   * onSubmit
   * Triggered when the form is submitted.
   * - Validates fileId
   * - Dispatches the updateFile action with new file name
   * - Calls onSucess() callback and closes the modal
   */
  const onSubmit = async (data: EditFileFormValues) => {
    if (!fileId) return;
    await handleThunkWithDecrypt<string, UpdateFileArgs>(dispatch, updateFile, {
      id: fileId,
      name: data.fileName,
    });
    onSucess();
    onClose();
  };

  return (
    <CommonDrawer open={open} onClose={onClose} title="Edit File" lgSize="40%">
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col h-full">
        <div className="flex-1">
          <Grid container spacing={2} className="mt-2">
            <Grid size={{ xs: 12 }}>
              <CommonTextField
                name="fileName"
                label="File Name"
                register={register}
                validation={{ required: Constant.MESSAGE.FILE_REQUIRED }}
                errors={errors}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              />
            </Grid>
          </Grid>
        </div>
        <div className="flex justify-end gap-3 border-t border-[#dee2e6] p-4">
          <Button className="h-10 font-bold" variant="outlined" onClick={onClose} color="primary">
            Cancel
          </Button>
          <Button type="submit" className="h-10 font-bold" variant="contained" color="primary">
            Update File
          </Button>
        </div>
      </form>
    </CommonDrawer>
  );
};
