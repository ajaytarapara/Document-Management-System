"use client";

import { MenuItem, Button, Grid, TextField } from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useAppDispatch } from "@main/hooks";
import { useEffect, useState } from "react";
import { Constant, SHARE_TYPE } from "@core/constants/Constant";
import { IAPIResponse } from "@core/models";
import { decryptObject } from "@core/utils";
import { FolderListDto, GetFolderList, GetFolderTabs } from "@main/models";
import { changeTab, getFolderList, getFolderTabs, moveFile } from "@main/store";
import { CommonDrawer } from "@core/components";

interface MoveFileProps {
  open: boolean;
  onClose: () => void;
  fileId: string[];
  onSucess?: () => void;
  type: "moveTab" | "moveFolder" | "";
  folderId: string;
}

interface MoveFileFormValues {
  folderId?: string;
  tabId: string;
}

export const MoveFileDrawer = ({ open, onClose, fileId, onSucess, type, folderId }: MoveFileProps) => {
  const dispatch = useAppDispatch();
  const {
    handleSubmit,
    control,
    watch,
    reset,
    formState: { errors },
  } = useForm<MoveFileFormValues>({});

  const [folders, setFolders] = useState<GetFolderList>({ getFolderDto: [] });
  const [tabs, setTabs] = useState<GetFolderTabs>({ folderTabDto: [],folderName:"" });

  const selectedFolderId = watch("folderId");

  /**
   * useEffect - Fetch folders when modal opens in "moveFolder" mode
   * Decrypts response and stores folder list in state
   */
  useEffect(() => {
    if (open && type === SHARE_TYPE.MOVE_FOLDER) {
      (async () => {
        const res = await dispatch(getFolderList());
        if (getFolderList.fulfilled.match(res)) {
          const encryptedString = res.payload?.data;
          const decrypted: IAPIResponse<GetFolderList> = decryptObject(encryptedString);

          if (decrypted?.data) {
            setFolders({ getFolderDto: decrypted.data.getFolderDto });
          }
        }
      })();
    }
  }, [open, type, dispatch]);

  /**
   * useEffect - Fetch tabs
   * - In "moveTab" mode: fetch tabs for provided folderId
   * - In "moveFolder" mode: fetch tabs for selected folderId
   */
  useEffect(() => {
    const fetchTabs = async (folderId: string) => {
      const res = await dispatch(getFolderTabs({ folderId }));
      if (getFolderTabs.fulfilled.match(res)) {
        const encryptedString = res.payload?.data;
        const decrypted: IAPIResponse<GetFolderTabs> = decryptObject(encryptedString);
        if (decrypted?.data) {
          setTabs({ folderTabDto: decrypted?.data.folderTabDto,folderName:decrypted?.data.folderName });
        }
      }
    };

    if (type === SHARE_TYPE.MOVE_TAB) {
      fetchTabs(folderId);
    } else if (selectedFolderId) {
      fetchTabs(selectedFolderId);
    }
  }, [type, selectedFolderId, folderId, dispatch]);

  /**
   * onSubmit - Handles form submission
   * - If moving to folder: dispatch moveFile action
   * - If moving tab only: dispatch changeTab action
   * - Calls success callback and closes modal
   */
  const onSubmit = async (data: MoveFileFormValues) => {
    if (type === SHARE_TYPE.MOVE_FOLDER) {
      await dispatch(moveFile({ fileId, targetFolderTabId: data.tabId, TargetFolderId: data.folderId }));
      reset();
      onSucess?.();
    } else {
      await dispatch(changeTab({ fileId: fileId[0], targetFolderTabId: data.tabId }));
      reset();
      onSucess?.();
    }
    onClose();
  };

  return (
    <CommonDrawer open={open} onClose={onClose} title="Move File" lgSize="40%">
      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2} className="mt-2">
          {type === SHARE_TYPE.MOVE_FOLDER && (
            <Grid size={{ xs: 12, md: 12 }}>
              <Controller
                name="folderId"
                control={control}
                defaultValue=""
                rules={{ required: Constant.MESSAGE.FOLDER_REQUIRED }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Select Folder"
                    fullWidth
                    select
                    size="small"
                    error={!!errors.folderId}
                    helperText={errors.folderId?.message}
                    slotProps={{
                      select: {
                        MenuProps: {
                          disablePortal: true,
                          PaperProps: { sx: { zIndex: 1500 } },
                        },
                      },
                    }}
                  >
                    {folders.getFolderDto.map((folder: FolderListDto) => (
                      <MenuItem key={folder.id} value={folder.id}>
                        {folder.folderName}
                      </MenuItem>
                    ))}
                  </TextField>
                )}
              />
            </Grid>
          )}
          <Grid size={{ xs: 12, md: 12 }}>
            <Controller
              name="tabId"
              control={control}
              defaultValue=""
              rules={{ required: "Tab is required" }}
              render={({ field }) => (
                <TextField
                  {...field}
                  label="Select Tab"
                  fullWidth
                  select
                  size="small"
                  error={!!errors.tabId}
                  helperText={errors.tabId?.message}
                  disabled={type === SHARE_TYPE.MOVE_FOLDER && !selectedFolderId}
                >
                  {tabs.folderTabDto.map(tab => (
                    <MenuItem key={tab.id} value={tab.id}>
                      {tab.tabName}
                    </MenuItem>
                  ))}
                </TextField>
              )}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 12 }} className="flex justify-end">
            <div className="flex gap-3">
              <Button className="h-12 font-bold" variant="outlined" onClick={onClose} color="primary">
                Cancel
              </Button>
              <Button type="submit" className="h-12 font-bold" variant="contained" color="primary">
                Move File
              </Button>
            </div>
          </Grid>
        </Grid>
      </form>
    </CommonDrawer>
  );
};
