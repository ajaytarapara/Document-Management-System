import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Typography } from "@mui/material";
import { X } from "lucide-react";

interface PDFDownloadModalProps {
  open: boolean;
  onClose: () => void;
}

export const PDFDownloadModal: React.FC<PDFDownloadModalProps> = ({ open, onClose }) => {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="xs"
      PaperProps={{
        className: "rounded-2xl",
      }}
    >
      <DialogTitle className="!p-4 border-b border-[#dee2e6]">
        <div className="flex items-center justify-between">
          <h5 className="font-medium text-xl text-black">Download PDFs</h5>
          <X className="text-gray-500 cursor-pointer" onClick={onClose} />
        </div>
      </DialogTitle>
      <DialogContent className="!p-4">
        <Typography className="text-gray-700 text-base">
          Would you like to download pdf(s) from current tab only or from all tabs?
        </Typography>
      </DialogContent>
      <DialogActions className="flex flex-col sm:flex-row justify-center gap-2 sm:gap-1 border-t border-[#dee2e6] !p-4">
        <button
          onClick={onClose}
          className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
        >
          Close
        </button>
        <button className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition">
          Current Tab
        </button>
        <button className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition">
          All Tabs
        </button>
      </DialogActions>
    </Dialog>
  );
};
