import { useForm } from "react-hook-form";
import { FolderDto, IEditFolderRequest } from "@main/models";
import { useCallback, useEffect } from "react";
import { decryptObject } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import { getFolderById, updateFolder } from "@main/store";

export const useFolderUpdateForm = (
  folderId: string | null,
  handleSetFolderDetails: (folderDetails: FolderDto) => void
) => {
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    watch,
    control,
    formState: { errors },
    reset,
  } = useForm<IEditFolderRequest>({
    defaultValues: {
      firstName: "",
      lastName: "",
      fileNumber: "",
      folderName: "",
    },
  });

  /**
   * Fetches folder data from the server using the decrypted folder ID.
   *
   * - Dispatches the `getFolderById` action with the folder ID.
   * - Decrypts the received folder data.
   * - Resets the form with the decrypted folder details.
   * - Updates local state with the folder details.
   */
  const fetchFolderData = useCallback(async () => {
    if (!folderId) return;
    const res = await dispatch(getFolderById({ id: folderId }));
    if (getFolderById.fulfilled.match(res)) {
      const encryptedString = res.payload.data;
      const decrypted: FolderDto = decryptObject<FolderDto>(encryptedString);
      if (decrypted) {
        reset({
          firstName: decrypted.firstName,
          lastName: decrypted.lastName,
          fileNumber: decrypted.fileNumber,
          folderName: decrypted.folderName,
        });
        handleSetFolderDetails(decrypted);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Runs on component mount to fetch the initial folder data.
   */
  useEffect(() => {
    fetchFolderData();
  }, [fetchFolderData]);

  /**
   * Handles the form submission for editing folder details.
   *
   * - Dispatches the `updateFolder` action with the folder ID and form data.
   *
   * @param data - The updated folder details entered by the user.
   */
  const onSubmit = async (data: IEditFolderRequest) => {
    if (!folderId) return;
    await dispatch(updateFolder({ id: folderId, data: data }));
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    watch,
    reset,
    control,
  };
};
