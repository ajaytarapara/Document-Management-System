import { CommonTextField } from "@core/components";
import { Box } from "@mui/material";
import { Minus, Plus } from "lucide-react";
import { Fragment, useState } from "react";
import { useFolderUpdateForm } from "./UpdateFolder.hook";
import { Constant } from "@core/constants/Constant";
import { FolderDto } from "@main/models";

interface UpdateFolderComponentProps {
  folderId: string | null;
  handleSetFolderDetails: (folderDetails: FolderDto) => void;
}

export const UpdateFolderComponent: React.FC<UpdateFolderComponentProps> = ({ folderId, handleSetFolderDetails }) => {
  const [isEditFolderButtonClicked, setIsEditFolderButtonClicked] = useState<boolean>(false);
  const [isFolderUpdateOpen, setIsFolderUpdateOpen] = useState<boolean>(true);

  const { register, errors, handleSubmit, onSubmit } = useFolderUpdateForm(folderId, handleSetFolderDetails);
  return (
    <div className="mt-6">
      <div className="rounded px-4 py-2 bg-white">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-lg md:text-xl text-[#00092a] tracking-wide">Folder Details</h4>
          <div
            className="w-[46px] h-[46px] flex items-center justify-center bg-gray-300 rounded-md cursor-pointer transition-all duration-300"
            onClick={() => setIsFolderUpdateOpen(!isFolderUpdateOpen)}
          >
            <div
              className={`transition-transform duration-500 ease-in-out ${isFolderUpdateOpen ? "rotate-180" : "rotate-0"}`}
            >
              {isFolderUpdateOpen ? <Minus className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
            </div>
          </div>
        </div>
      </div>
      <div
        className={`rounded border-t border-[#d7deec] transition-all duration-500 ease-in-out bg-white overflow-hidden ${
          isFolderUpdateOpen ? "max-h-[1000px] opacity-100 scale-100 p-4" : "max-h-0 opacity-0 scale-95"
        }`}
      >
        <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-[#00092a] mb-1">Folder Name</span>
              <CommonTextField
                name="folderName"
                disabled={!isEditFolderButtonClicked}
                register={register}
                validation={{ required: Constant.MESSAGE.FOLDER_REQUIRED }}
                errors={errors}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    height: 40,
                    backgroundColor: !isEditFolderButtonClicked ? "#f5f5f5" : "transparent",
                  },
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-[#00092a] mb-1">File Number</span>
              <CommonTextField
                name="fileNumber"
                disabled={!isEditFolderButtonClicked}
                register={register}
                validation={{ required: Constant.MESSAGE.FIRSTNAME_REQ }}
                errors={errors}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    height: 40,
                    backgroundColor: !isEditFolderButtonClicked ? "#f5f5f5" : "transparent",
                  },
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-[#00092a] mb-1">First Name</span>
              <CommonTextField
                name="firstName"
                disabled={!isEditFolderButtonClicked}
                register={register}
                validation={{ required: Constant.MESSAGE.TAB_NAME_REQ }}
                errors={errors}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    height: 40,
                    backgroundColor: !isEditFolderButtonClicked ? "#f5f5f5" : "transparent",
                  },
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-[#00092a] mb-1">Last Name</span>
              <CommonTextField
                name="lastName"
                disabled={!isEditFolderButtonClicked}
                register={register}
                errors={errors}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    height: 40,
                    backgroundColor: !isEditFolderButtonClicked ? "#f5f5f5" : "transparent",
                  },
                }}
              />
            </div>
          </div>
          <div className="flex justify-start items-center mt-4 gap-2">
            {!isEditFolderButtonClicked && (
              <button
                type="button"
                onClick={() => setIsEditFolderButtonClicked(true)}
                className="cursor-pointer whitespace-nowrap gap-2 px-3 py-2 text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3]"
              >
                <span>Edit Folder Detail</span>
              </button>
            )}
            {isEditFolderButtonClicked && (
              <Fragment>
                <button
                  type="submit"
                  className="cursor-pointer whitespace-nowrap gap-2 px-3 py-2 text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3]"
                >
                  <span>Save Folder Detail</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditFolderButtonClicked(false)}
                  className="cursor-pointer whitespace-nowrap gap-2 px-3 py-2 text-sm font-medium border border-[#7E57C2] text-[#7E57C2] rounded-md shadow hover:bg-[#F3EFFF]"
                >
                  <span>Cancel</span>
                </button>
              </Fragment>
            )}
          </div>
        </Box>
      </div>
    </div>
  );
};
