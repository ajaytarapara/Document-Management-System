"use client";

import React, { useRef, useMemo } from "react";
import { Checkbox, Radio, FormControl, MenuItem, Select as MUISelect, TextareaAutosize } from "@mui/material";
import { DraggableFieldProps, FieldBase } from "./types";
import { clamp } from "./utils";
import SignatureCanvas from "./SignatureCanvas";
import { Corner, corners, FieldType } from "@core/models";

const DraggableField: React.FC<DraggableFieldProps> = ({
  field,
  pageRect,
  onMove,
  onChangeValue,
  onResize,
  onSelect,
  readonly,
}) => {
  // Convert percentages into pixel positions based on pageRect
  const leftPx = (field.xPct / 100) * pageRect.width;
  const topPx = (field.yPct / 100) * pageRect.height;
  const widthPx = field.wPct ? (field.wPct / 100) * pageRect.width : 140;
  const heightPx = field.hPct ? (field.hPct / 100) * pageRect.height : 48;
  const hasError = !!field.error && typeof field.error === "string";

  // Refs for drag/resize state
  const handleRef = useRef<HTMLDivElement | null>(null);
  const offsetsRef = useRef<{ x: number; y: number } | null>(null);
  const resizeStateRef = useRef<{
    startX: number;
    startY: number;
    startW: number;
    startH: number;
    startLeft: number;
    startTop: number;
  } | null>(null);
  const suppressClickRef = useRef<boolean>(false);
  const currentHandleRef = useRef<string | null>(null);

  /**
   * Handle drag start (pointer down on drag handle).
   * Captures initial offsets for dragging.
   */
  const onPointerDown = (e: React.PointerEvent) => {
    const handle = handleRef.current;
    if (!handle) return;
    handle.setPointerCapture(e.pointerId);

    const fieldLeft = leftPx;
    const fieldTop = topPx;

    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;

    offsetsRef.current = {
      x: pointerX - fieldLeft,
      y: pointerY - fieldTop,
    };
  };

  /**
   * Handle dragging (pointer move).
   * Updates field position within page bounds.
   */
  const onPointerMove = (e: React.PointerEvent) => {
    if (!offsetsRef.current) return;

    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;

    // Ensure field stays within page bounds
    const maxLeft = Math.max(0, pageRect.width - widthPx);
    const maxTop = Math.max(0, pageRect.height - heightPx);

    const newLeft = clamp(pointerX - offsetsRef.current.x, 0, maxLeft);
    const newTop = clamp(pointerY - offsetsRef.current.y, 0, maxTop);

    const xPct = clamp((newLeft / pageRect.width) * 100, 0, 100);
    const yPct = clamp((newTop / pageRect.height) * 100, 0, 100);

    if (onMove) onMove(field.id, xPct, yPct);
  };

  /**
   * Handle drag end (pointer up).
   * Releases pointer capture and resets refs.
   */
  const onPointerUp = (e: React.PointerEvent) => {
    const handle = handleRef.current;
    if (handle && handle.hasPointerCapture(e.pointerId)) {
      handle.releasePointerCapture(e.pointerId);
    }
    offsetsRef.current = null;
    resizeStateRef.current = null;
  };

  /**
   * Handle resize start (dragging the bottom-right handle).
   */
  const onResizeDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);
    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;
    resizeStateRef.current = {
      startX: pointerX,
      startY: pointerY,
      startW: widthPx,
      startH: heightPx,
      startLeft: 0,
      startTop: 0,
    };
    // Prevent parent click/double-click from selecting/opening drawer after resizing starts
    suppressClickRef.current = true;
  };

  /**
   * Handle resizing (pointer move).
   * Updates width and height based on drag delta.
   */
  const onResizeMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!resizeStateRef.current) return;
    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;

    const dx = pointerX - resizeStateRef.current.startX;
    const dy = pointerY - resizeStateRef.current.startY;

    // Keep within page bounds and enforce min size
    const maxW = Math.max(10, pageRect.width - leftPx);
    const maxH = Math.max(10, pageRect.height - topPx);
    const newWpx = clamp(resizeStateRef.current.startW + dx, 10, maxW);
    const newHpx = clamp(resizeStateRef.current.startH + dy, 8, maxH);

    const wPct = clamp((newWpx / pageRect.width) * 100, 0.5, 100);
    const hPct = clamp((newHpx / pageRect.height) * 100, 0.3, 100);

    if (onResize) onResize(field.id, wPct, hPct);
  };

  /**
   * Handle resize end (pointer up).
   * Resets resize state and suppresses click until after event propagation.
   */
  const onResizeUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    if (target.hasPointerCapture(e.pointerId)) target.releasePointerCapture(e.pointerId);
    resizeStateRef.current = null;
    // Defer clearing suppression until after any click event fires
    setTimeout(() => {
      suppressClickRef.current = false;
    }, 0);
  };

  /**
   * Renders the appropriate UI based on the field type.
   * Uses useMemo to avoid unnecessary re-renders.
   */
  const visual = useMemo(() => {
    switch (field.type) {
      case FieldType.Text:
        return (
          <TextareaAutosize
            name={`field_${field.id}`}
            placeholder={field.placeholder ?? "Enter text here..."}
            value={typeof field.value === "string" ? field.value : ""}
            onChange={e => {
              if (onChangeValue) onChangeValue(field.id, e.target.value);
            }}
            required={!!field.required}
            minRows={2}
            className={`w-[200px] !min-h-[38px] text-[12px] p-2 bg-[#f4eeff] rounded ${
              hasError ? "border border-red-500" : "border border-[#ccc]"
            } ${readonly ? "resize-none" : "resize"}`}
          />
        );
      case FieldType.Checkbox:
        return (
          <div
            className={`bg-[#f4eeff] cursor-pointer p-2 rounded flex items-center w-fit ${
              field.isLabelVisible !== false ? "gap-2" : ""
            } ${hasError ? "border border-red-500" : "border border-transparent"}`}
          >
            <Checkbox
              checked={!!field.value}
              onChange={e => {
                if (onChangeValue) onChangeValue(field.id, e.target.checked);
              }}
              sx={{
                padding: 0,
                color: "primary.main",
                "&.Mui-checked": {
                  color: "primary.main",
                },
              }}
            />
            {field.isLabelVisible !== false && <span className="text-xs text-gray-700">{field.label}</span>}
          </div>
        );

      case FieldType.Radio:
        return (
          <div
            className={`bg-[#f4eeff] cursor-pointer p-2 w-fit rounded flex items-center ${
              field.isLabelVisible !== false ? "gap-2" : ""
            } ${hasError ? "border border-red-500" : "border border-transparent"}`}
          >
            <Radio
              checked={field.value == "true"}
              name={field.id}
              id={field.id}
              onChange={() => {
                if (onChangeValue) onChangeValue(field.id, "true");
              }}
              sx={{
                padding: 0,
                color: "primary.main",
                "&.Mui-checked": { color: "primary.main" },
              }}
            />
            {field.isLabelVisible !== false && <span className="text-xs text-gray-700">{field.label}</span>}
          </div>
        );
      case FieldType.Select:
        const selectOptions = field.options ?? ["Option 1", "Option 2"];
        const placeholderText = field.placeholder ?? "Select an option";
        return (
          <FormControl
            sx={{ width: 200, height: 48 }}
            onMouseDown={e => e.stopPropagation()}
            onPointerDown={e => e.stopPropagation()}
            onClick={e => e.stopPropagation()}
          >
            <MUISelect
              size="small"
              displayEmpty
              value={typeof field.value === "string" ? field.value : ""}
              onChange={e => {
                if (onChangeValue) onChangeValue(field.id, e.target.value as string);
              }}
              onMouseDown={e => e.stopPropagation()}
              onClick={e => e.stopPropagation()}
              onDoubleClick={e => {
                e.stopPropagation();
                if (onSelect) onSelect(field.id);
              }}
              MenuProps={{
                PaperProps: {
                  onMouseDown: (e: React.MouseEvent<HTMLDivElement>) => e.stopPropagation(),
                  onClick: (e: React.MouseEvent<HTMLDivElement>) => e.stopPropagation(),
                  style: { maxHeight: 250, overflowY: "auto" },
                },
              }}
              sx={{
                width: 200,
                height: 48,
                fontSize: "12px",
                backgroundColor: "#f4eeff",
                border: hasError ? "1px solid #d32f2f" : "1px solid #ccc",
                "& .MuiOutlinedInput-root": { backgroundColor: "#f4eeff" },
              }}
            >
              <MenuItem value="" disabled onClick={e => e.stopPropagation()}>
                {placeholderText}
              </MenuItem>
              {selectOptions.map(option => (
                <MenuItem key={option} value={option} onClick={e => e.stopPropagation()}>
                  {option}
                </MenuItem>
              ))}
            </MUISelect>
          </FormControl>
        );
      case FieldType.Highlight:
        return <div className="w-full h-full bg-yellow-200/35 mix-blend-multiply" />;
      case FieldType.Signature:
        return (
          <div
            className={`p-1 rounded w-full h-full ${hasError ? "border border-red-500" : "border border-transparent"}`}
          >
            <SignatureCanvas
              width={widthPx}
              height={heightPx}
              value={typeof field.value === "string" ? field.value : undefined}
              onChange={data => {
                if (onChangeValue) onChangeValue(field.id, data);
              }}
            />
          </div>
        );
      case FieldType.Eraser:
        return (
          <div className={`w-full h-full bg-white mix-blend-normal ${!readonly ? "border border-gray-300" : ""}`} />
        );
      default:
        return null;
    }
  }, [field, widthPx, heightPx, onChangeValue, onSelect, hasError, readonly]);

  /**
   * Check if click should be ignored (form/MUI elements).
   */
  const isClickBlocked = (el: HTMLElement): boolean => {
    const tag = el.tagName;
    const isFormElement = ["BUTTON", "INPUT", "SELECT", "TEXTAREA", "LABEL"].includes(tag);
    const isMUISelectTrigger = el.closest('[aria-haspopup="listbox"]');
    const isMenuItem = el.getAttribute("role") === "option" || el.closest('[role="option"]');
    return isFormElement || !!isMUISelectTrigger || !!isMenuItem;
  };

  /**
   * Handle single click on field.
   */
  const handleClick = (
    e: React.MouseEvent<HTMLDivElement>,
    field: FieldBase,
    suppressClickRef: React.RefObject<boolean>,
    onSelect?: (id: string) => void
  ) => {
    e.stopPropagation();
    if (suppressClickRef.current) return;
    if (field.type === FieldType.Text) return;
    const el = e.target as HTMLElement;
    if (isClickBlocked(el)) return;
    if (onSelect) onSelect(field.id);
  };

  /**
   * Handle double click on field.
   */
  const handleDoubleClick = (
    e: React.MouseEvent<HTMLDivElement>,
    field: FieldBase,
    suppressClickRef: React.RefObject<boolean>,
    onSelect?: (id: string) => void
  ) => {
    e.stopPropagation();
    if (suppressClickRef.current) return;
    if (field.type === FieldType.Text || field.type === FieldType.Select) if (onSelect) onSelect(field.id);
  };

  /**
   * Returns the CSS classes for positioning and cursor style
   * based on which corner of the field is being used for resizing.
   * @param corner - One of the four corners of the field
   * @returns CSS class string for corner position and cursor
   */
  const getCornerPosition = (corner: Corner) => {
    switch (corner) {
      case Corner.TopLeft:
        return "-top-1.5 -left-1.5 cursor-nwse-resize";
      case Corner.TopRight:
        return "-top-1.5 -right-1.5 cursor-nesw-resize";
      case Corner.BottomLeft:
        return "-bottom-1.5 -left-1.5 cursor-nesw-resize";
      case Corner.BottomRight:
        return "-bottom-1.5 -right-1.5 cursor-nwse-resize";
    }
  };

  /**
   * Handles pointer down on a specific corner of an eraser field.
   * Initializes resize state with starting pointer coordinates,
   * field dimensions, and field position.
   * Sets the active corner for resizing and suppresses click events.
   * @param corner - The corner being dragged
   */
  const onEraserResizeDown = (corner: Corner) => (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const target = e.currentTarget;
    target.setPointerCapture(e.pointerId);

    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;

    // Store initial pointer position, size, and position of the field
    resizeStateRef.current = {
      startX: pointerX,
      startY: pointerY,
      startW: widthPx,
      startH: heightPx,
      startLeft: leftPx,
      startTop: topPx,
    };
    currentHandleRef.current = corner;
    suppressClickRef.current = true;
  };

  /**
   * Handles pointer movement while resizing an eraser field.
   * Calculates new width, height, and position based on the dragged corner.
   * Ensures the field remains within page boundaries and applies minimum size.
   * Updates field dimensions and position in percentages via callbacks.
   * @param e - Pointer move event
   */
  const onEraserResizeMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!resizeStateRef.current || !currentHandleRef.current) return;

    const pointerX = e.clientX - pageRect.left;
    const pointerY = e.clientY - pageRect.top;

    const dx = pointerX - resizeStateRef.current.startX;
    const dy = pointerY - resizeStateRef.current.startY;

    let newW = resizeStateRef.current.startW;
    let newH = resizeStateRef.current.startH;
    let newLeft = resizeStateRef.current.startLeft;
    let newTop = resizeStateRef.current.startTop;

    const handle = currentHandleRef.current as Corner;
    switch (handle) {
      case Corner.BottomRight:
        newW += dx;
        newH += dy;
        break;
      case Corner.BottomLeft:
        newW -= dx;
        newH += dy;
        newLeft += dx;
        break;
      case Corner.TopRight:
        newW += dx;
        newH -= dy;
        newTop += dy;
        break;
      case Corner.TopLeft:
        newW -= dx;
        newH -= dy;
        newLeft += dx;
        newTop += dy;
        break;
    }

    // Clamp width and height to stay within page and respect minimum size
    newW = clamp(newW, 10, pageRect.width - newLeft);
    newH = clamp(newH, 10, pageRect.height - newTop);

    // Convert pixels to percentage for consistent storage
    const wPct = (newW / pageRect.width) * 100;
    const hPct = (newH / pageRect.height) * 100;
    const xPct = (newLeft / pageRect.width) * 100;
    const yPct = (newTop / pageRect.height) * 100;

    // Update field dimensions
    if (onResize) onResize(field.id, wPct, hPct);

    // Update position for corners that affect top or left
    if ([Corner.TopLeft, Corner.TopRight, Corner.BottomLeft].includes(handle)) {
      if (onMove) onMove(field.id, xPct, yPct);
    }
  };

  /**
   * Handles pointer up after resizing an eraser field.
   * Releases pointer capture, clears resize state, and re-enables click events.
   * @param e - Pointer up event
   */
  const onEraserResizeUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    if (target.hasPointerCapture(e.pointerId)) target.releasePointerCapture(e.pointerId);

    resizeStateRef.current = null;
    currentHandleRef.current = null;

    // Allow clicks again after resizing completes
    setTimeout(() => (suppressClickRef.current = false), 0);
  };
  return (
    <div
      className="absolute z-50 pointer-events-auto outline-none rounded bg-clip-padding-box"
      style={{
        left: leftPx,
        top: topPx,
        width: widthPx || 140,
        height: heightPx || 28,
      }}
      onClick={e => handleClick(e, field, suppressClickRef, onSelect)}
      onDoubleClick={e => handleDoubleClick(e, field, suppressClickRef, onSelect)}
      title={field.label || field.type}
    >
      <div className="relative w-full h-full">
        {!readonly && (
          <div
            ref={handleRef}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onClick={e => e.stopPropagation()}
            className="absolute -top-2 -left-2 w-4 h-4 bg-blue-600 text-white text-[10px] 
                   leading-3 rounded cursor-move flex items-center justify-center select-none"
            title="Drag to move"
          >
            ≡
          </div>
        )}

        {visual}

        {readonly && typeof field.error === "string" && field.error && (
          <div className="text-[#d32f2f] text-[11px] leading-[14px] mt-1 whitespace-nowrap [text-shadow:0_1px_0_#fff]">
            {field.error}
          </div>
        )}

        {!readonly && field.type === FieldType.Highlight && (
          <div
            onPointerDown={onResizeDown}
            onPointerMove={onResizeMove}
            onPointerUp={onResizeUp}
            onClick={e => e.stopPropagation()}
            onDoubleClick={e => e.stopPropagation()}
            className="absolute w-3 h-3 bg-blue-600 rounded-sm cursor-se-resize -right-1.5 -bottom-1.5"
            title="Drag to resize"
          />
        )}

        {!readonly && field.type === FieldType.Eraser && (
          <>
            {corners.map(corner => (
              <div
                key={corner}
                onPointerDown={onEraserResizeDown(corner)}
                onPointerMove={onEraserResizeMove}
                onPointerUp={onEraserResizeUp}
                onClick={e => e.stopPropagation()}
                onDoubleClick={e => e.stopPropagation()}
                className={`absolute w-3 h-3 bg-blue-600 rounded-sm ${getCornerPosition(corner)}`}
                title="Drag to resize"
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
};

export default DraggableField;
