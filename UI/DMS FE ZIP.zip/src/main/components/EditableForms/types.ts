export type FieldType = "text" | "checkbox" | "radio" | "select" | "highlight" | "signature" | "eraser";

export interface FieldBase {
  id: string;
  type: FieldType;
  pageIndex: number;
  xPct: number;
  yPct: number;
  wPct?: number;
  hPct?: number;
  name?: string;
  label?: string;
  placeholder?: string;
  options?: string[];
  value?: string | boolean;
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  regx?: string;
  errorMessage?: string;
  error?: string;
  groupId?: string;
  isLabelVisible?: boolean;
}
export interface PaletteButtonProps {
  type: FieldType;
  label: string;
  activeType: FieldType | null;
  onSelect: (type: FieldType) => void;
}

export interface SignatureCanvasProps {
  width: number;
  height: number;
  value?: string;
  onChange: (dataUrl: string) => void;
}

export interface DraggableFieldProps {
  field: FieldBase;
  pageRect: DOMRect;
  onMove?: (id: string, xPct: number, yPct: number) => void;
  onChangeValue?: (id: string, value: string | boolean) => void;
  onResize?: (id: string, wPct: number, hPct: number) => void;
  onSelect?: (id: string) => void;
  readonly?: boolean;
}

export interface PageLayerProps {
  pageIndex: number;
  fields: FieldBase[];
  onAdd?: (pageIndex: number, xPct: number, yPct: number, type: FieldType) => void | null;
  onMove?: (id: string, xPct: number, yPct: number) => void | null;
  onChangeValue?: (id: string, value: string | boolean) => void | null;
  activeType: FieldType | null;
  onResize?: (id: string, wPct: number, hPct: number) => void | null;
  selectedFieldId?: string | null;
  onSelectField?: (id: string | null) => void | null;
  readonly?: boolean;
}

export interface ShareToken {
  formId: number;
  email: string;
  viewOnly: boolean;
  expiresAt: number;
  userId: number;
}

export interface FileData {
  fields?: FieldBase[];
  name: string;
  url: string;
}

export interface ShareToken {
  formId: number;
  email: string;
  viewOnly: boolean;
  expiresAt: number;
  userId: number;
}
