import { FieldType } from "@core/models/enums";
import { FieldBase, FileData } from "./types";
import { PDFDocument, rgb } from "pdf-lib";
import { Constant } from "@core/constants/Constant";

/**
 * Downloads a PDF with visual representations of form fields.
 * Supports text, select, checkbox, radio, signature, highlight, and eraser fields.
 *
 * @param pdfUrl - URL of the original PDF.
 * @param fields - Array of FieldBase objects to render on the PDF.
 */
export async function downloadWithFields(pdfUrl: string, fields: FieldBase[]) {
  // Load the original PDF from URL
  const existingPdfBytes = await fetch(pdfUrl).then(res => res.arrayBuffer());
  const pdfDoc = await PDFDocument.load(existingPdfBytes);
  const pages = pdfDoc.getPages();

  for (const field of fields) {
    const page = pages[field.pageIndex];
    const { width, height } = page.getSize();

    // Convert field percentages to absolute positions
    const absX = (field.xPct / 100) * width;
    const absY = height - (field.yPct / 100) * height - ((field.hPct || 0) / 100) * height;
    const absW = ((field.wPct || 0) / 100) * width;
    const absH = ((field.hPct || 0) / 100) * height;

    // --------------------------
    // Handle Highlight Field
    // --------------------------
    if (field.type === FieldType.Highlight) {
      page.drawRectangle({
        x: absX,
        y: absY,
        width: absW,
        height: absH,
        color: rgb(1, 1, 0),
        opacity: 0.4,
      });
      continue;
    }

    // --------------------------
    // Handle Eraser Field
    // --------------------------
    if (field.type === FieldType.Eraser) {
      page.drawRectangle({
        x: absX,
        y: absY,
        width: absW,
        height: absH,
        color: rgb(1, 1, 1),
      });
      continue;
    }

    // --------------------------
    // Handle Signature Field
    // --------------------------
    if (field.type === FieldType.Signature && typeof field.value === "string") {
      const sigImage = field.value.split(",")[1];
      const sigBytes = Uint8Array.from(atob(sigImage), c => c.charCodeAt(0));
      const img = await pdfDoc.embedPng(sigBytes);
      page.drawImage(img, { x: absX, y: absY, width: absW, height: absH });
      continue;
    }

    // --------------------------
    // Handle Text and Select Fields
    // --------------------------
    if (field.type === FieldType.Text || field.type === FieldType.Select) {
      // Draw background rectangle
      page.drawRectangle({
        x: absX,
        y: absY,
        width: absW,
        height: absH,
        borderColor: rgb255(160, 160, 160),
        borderWidth: 1,
        color: rgb255(244, 238, 255),
        opacity: 0.3,
      });

      // Draw field label inside rectangle
      const textToShow = field.value ? String(field.value) : "";
      page.drawText(textToShow || (field.type === FieldType.Text ? "Text Field" : "Select Field"), {
        x: absX + 2,
        y: absY + absH / 2 - 6,
        size: 10,
        color: rgb255(50, 50, 50),
      });
      continue;
    }

    // --------------------------
    // Handle Checkbox / Radio Fields
    // --------------------------
    if (field.type === FieldType.Checkbox || field.type === FieldType.Radio) {
      const isRadio = field.type === FieldType.Radio;
      const boxSize = 14;
      const posX = absX;
      const posY = absY + absH / 2 - boxSize / 2;

      if (isRadio) {
        // Draw outer circle for radio button
        page.drawCircle({
          x: posX + boxSize / 2,
          y: posY + boxSize / 2,
          size: boxSize / 2,
          borderColor: rgb255(50, 50, 50),
          borderWidth: 1,
          color: rgb255(244, 238, 255),
          opacity: 0.3,
        });

        // Fill inner circle if selected
        if (field.value === "true") {
          page.drawCircle({
            x: posX + boxSize / 2,
            y: posY + boxSize / 2,
            size: boxSize / 4,
            color: rgb255(50, 50, 50),
          });
        }
      } else {
        // Draw checkbox rectangle
        page.drawRectangle({
          x: posX,
          y: posY,
          width: boxSize,
          height: boxSize,
          borderColor: rgb255(50, 50, 50),
          borderWidth: 1,
          color: rgb255(244, 238, 255),
          opacity: 0.3,
        });

        // Fill inner rectangle if checked
        if (field.value === "true") {
          page.drawRectangle({
            x: posX + 3,
            y: posY + 3,
            width: boxSize - 6,
            height: boxSize - 6,
            color: rgb255(50, 50, 50),
          });
        }
      }

      // Draw field label next to checkbox/radio
      page.drawText(field.label || "", {
        x: posX + boxSize + 4,
        y: posY + boxSize / 4,
        size: 10,
        color: rgb255(50, 50, 50),
      });
    }
  }

  // --------------------------
  // Save PDF and trigger download
  // --------------------------
  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([new Uint8Array(pdfBytes)], { type: "application/pdf" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "annotated.pdf";
  link.click();
}

/**
 * Clamps a number between min and max values.
 * @param n - The number to clamp.
 * @param min - Minimum allowed value.
 * @param max - Maximum allowed value.
 * @returns The clamped number.
 */
export function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

/**
 * Validates a form field based on its type and constraints.
 * @param f - FieldBase object to validate.
 * @returns Error message string if validation fails, otherwise undefined.
 */
export const validateField = (f: FieldBase): string | undefined => {
  const val = typeof f.value === "string" ? f.value : "";

  switch (f.type) {
    case FieldType.Text: {
      if (f.required && !val.trim()) return Constant.MESSAGE.FIELD_REQUIRED;
      if (typeof f.minLength === "number" && val.length < f.minLength)
        return Constant.MESSAGE.MIN_LENGTH(f.label || "Field", f.minLength);
      if (typeof f.maxLength === "number" && val.length > f.maxLength)
        return Constant.MESSAGE.MAX_LENGTH(f.label || "Field", f.maxLength);
      if (f.regx) {
        try {
          const re = new RegExp(f.regx);
          if (!re.test(val)) return f.errorMessage || Constant.MESSAGE.INVALID_EMAIL;
        } catch {}
      }
      return;
    }

    case FieldType.Select: {
      if (f.required && !val) return Constant.MESSAGE.FIELD_REQUIRED;
      if (val && f.options && !f.options.includes(val)) return Constant.MESSAGE.INVALID_SELECTION;
      if (f.regx) {
        try {
          const re = new RegExp(f.regx);
          if (!re.test(val)) return f.errorMessage || Constant.MESSAGE.INVALID_SELECTION;
        } catch {}
      }
      return;
    }

    case FieldType.Checkbox:
    case FieldType.Radio:
      if (f.required && !Boolean(f.value)) return Constant.MESSAGE.FIELD_REQUIRED;
      return;

    case FieldType.Signature: {
      if (f.required && !val) return Constant.MESSAGE.SIGNATURE_REQUIRED;
      return;
    }

    default:
      return;
  }
};

/**
 * Utility to convert Blob to Base64
 */
export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // Strip the "data:application/pdf;base64," part
      const base64 = result.split(",")[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Generates a Blob URL for previewing PDF with fields.
 */
export async function previewWithFields(pdfUrl: string, fields: FieldBase[]): Promise<string> {
  const existingPdfBytes = await fetch(pdfUrl).then(res => res.arrayBuffer());
  const pdfDoc = await PDFDocument.load(existingPdfBytes);
  const pages = pdfDoc.getPages();

  for (const field of fields) {
    const page = pages[field.pageIndex];
    const { width, height } = page.getSize();

    const absX = (field.xPct / 100) * width;
    const absY = height - (field.yPct / 100) * height - ((field.hPct || 0) / 100) * height;
    const absW = ((field.wPct || 0) / 100) * width;
    const absH = ((field.hPct || 0) / 100) * height;

    if (field.type === FieldType.Highlight) {
      page.drawRectangle({ x: absX, y: absY, width: absW, height: absH, color: rgb(1, 1, 0), opacity: 0.4 });
      continue;
    }

    if (field.type === FieldType.Eraser) {
      page.drawRectangle({ x: absX, y: absY, width: absW, height: absH, color: rgb(1, 1, 1) });
      continue;
    }

    if (field.type === FieldType.Signature && typeof field.value === "string") {
      const sigImage = field.value.split(",")[1];
      const sigBytes = Uint8Array.from(atob(sigImage), c => c.charCodeAt(0));
      const img = await pdfDoc.embedPng(sigBytes);
      page.drawImage(img, { x: absX, y: absY, width: absW, height: absH });
      continue;
    }

    if (field.type === FieldType.Text || field.type === FieldType.Select) {
      page.drawRectangle({
        x: absX,
        y: absY,
        width: absW,
        height: absH,
        borderColor: rgb255(160, 160, 160),
        borderWidth: 1,
        color: rgb255(244, 238, 255),
        opacity: 0.3,
      });
      const textToShow = field.value ? String(field.value) : "";
      page.drawText(textToShow || (field.type === FieldType.Text ? "Text Field" : "Select Field"), {
        x: absX + 2,
        y: absY + absH / 2 - 6,
        size: 10,
        color: rgb255(50, 50, 50),
      });
      continue;
    }

    if (field.type === FieldType.Checkbox || field.type === FieldType.Radio) {
      const isRadio = field.type === FieldType.Radio;
      const boxSize = 14;
      const posX = absX;
      const posY = absY + absH / 2 - boxSize / 2;

      if (isRadio) {
        page.drawCircle({
          x: posX + boxSize / 2,
          y: posY + boxSize / 2,
          size: boxSize / 2,
          borderColor: rgb255(50, 50, 50),
          borderWidth: 1,
          color: rgb255(244, 238, 255),
          opacity: 0.3,
        });
        if (field.value === "true")
          page.drawCircle({
            x: posX + boxSize / 2,
            y: posY + boxSize / 2,
            size: boxSize / 4,
            color: rgb255(50, 50, 50),
          });
      } else {
        // Draw checkbox rectangle
        page.drawRectangle({
          x: posX,
          y: posY,
          width: boxSize,
          height: boxSize,
          borderColor: rgb255(50, 50, 50),
          borderWidth: 1,
          color: rgb255(244, 238, 255),
          opacity: 0.3,
        });

        // Fill inner rectangle if checked
        if (field.value === "true") {
          page.drawRectangle({
            x: posX + 3,
            y: posY + 3,
            width: boxSize - 6,
            height: boxSize - 6,
            color: rgb255(50, 50, 50),
          });
        }
      }

      page.drawText(field.label || "", {
        x: posX + boxSize + 4,
        y: posY + boxSize / 4,
        size: 10,
        color: rgb255(50, 50, 50),
      });
    }
  }
  const pdfBytes = await pdfDoc.save();

  const blob = new Blob([new Uint8Array(pdfBytes.buffer as ArrayBuffer)], { type: "application/pdf" });

  return URL.createObjectURL(blob);
}

/**
 * Converts 0-255 RGB values to 0-1 scale for pdf-lib.
 * @param r Red (0-255)
 * @param g Green (0-255)
 * @param b Blue (0-255)
 * @returns Color in 0-1 range for pdf-lib
 */
export function rgb255(r: number, g: number, b: number) {
  return rgb(r / 255, g / 255, b / 255);
}

/**
 * Maps the API response result into a structured file data object
 * that contains file URL, name, and associated fields.
 *
 * @param result - API response object containing file data
 * @param role - (optional) role of the logged-in user used to determine base URL
 * @returns An object with fileUrl, fileName, and fields, or null if no data
 */
export function mapResultToFileData(result: { data?: FileData }, role?: string) {
  if (!result?.data) return null;

  const { fields = [], name, url } = result.data;

  const baseUrl =
    role === Constant.COMMON.OFFICEUSER ? process.env.NEXT_PUBLIC_ADMIN_API_URL : process.env.NEXT_PUBLIC_USER_API_URL;

  return {
    fileUrl: `${baseUrl}${url}`,
    fileName: name,
    fields,
  };
}

/**
 * Resolves API URL based on user role.
 * @param userRole role of the logged-in user
 * @param adminUrl endpoint for OFFICE_USER role
 * @param userUrl endpoint for normal user role
 */
export function resolveUrlByRole(userRole: string, adminUrl: string, userUrl: string): string {
  return userRole === Constant.COMMON.OFFICEUSER ? adminUrl : userUrl;
}
