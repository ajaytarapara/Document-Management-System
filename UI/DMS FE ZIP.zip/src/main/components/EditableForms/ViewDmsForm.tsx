"use client";

import { Folder, Save, SquareCheckBig } from "lucide-react";
import { decryptObject, encryptId, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { IDmsForm, ILoginResponse, SaveEditedFormRequest, SubmitEditedFormRequest } from "@main/models";
import {
  AppDispatch,
  getDmsFormById,
  getUserDmsFormById,
  saveEditedForm,
  submitEditedForm,
  useSelectorAuthState,
} from "@main/store";
import React, { useState, useEffect, useCallback } from "react";
import { FieldBase, ShareToken } from "./types";
import { useDispatch } from "react-redux";
import PDFViewer from "./PDFViewer";
import { zoomPlugin } from "@react-pdf-viewer/zoom";
import { FieldType, IAPIResponse } from "@core/models";
import { blobToBase64, mapResultToFileData, validateField } from "./utils";
import { CommonButton } from "@core/components";
import { toast } from "react-toastify";
import { useSearchParams } from "next/navigation";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { Constant } from "@core/constants/Constant";

interface ViewDmsFormProps {
  decodedToken: ShareToken;
}

export const ViewDmsForm: React.FC<ViewDmsFormProps> = ({ decodedToken }) => {
  const searchParams = useSearchParams();
  const initialEmail = searchParams.get("email") || "";
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const [fileUrl, setFileUrl] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [fields, setFields] = useState<FieldBase[]>([]);
  const zoomPluginInstance = zoomPlugin();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  /**
   * Fetches the PDF data and associated form fields from the backend.
   * Converts base64 to Uint8Array for PDF rendering.
   */
  const getPdfData = async () => {
    const result = await handleThunkWithDecrypt<IDmsForm, { formId: string; userId: string }>(
      dispatch,
      decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER ? getDmsFormById : getUserDmsFormById,
      {
        formId: encryptId(Number(decodedToken?.formId)),
        userId: encryptId(Number(decodedToken?.userId)),
      }
    );

    const mappedData = mapResultToFileData(result, decryptedLoggedUser?.data?.role);
    if (mappedData) {
      setFileUrl(mappedData.fileUrl);
      setFileName(mappedData.fileName);
      setFields(mappedData.fields);
    }
  };

  /**
   * Updates the value of a field and validates it.
   * @param id - The field ID.
   * @param value - The new field value.
   */
  const changeFieldValue = (id: string, value: string | boolean) => {
    setFields(prev =>
      prev.map(f => {
        // For radio buttons, check if they belong to the same group
        const clickedField = prev.find(field => field.id === id);

        if (clickedField?.type === FieldType.Radio && clickedField.groupId) {
          // Deselect all radios in the same group, select only the clicked one
          if (f.groupId === clickedField.groupId) {
            return { ...f, value: f.id === id ? "true" : "false" };
          }
          return f;
        }

        // Normal field or radio without group
        if (f.id === id) return { ...f, value };
        return f;
      })
    );
  };

  /**
   * Validates all fields and saves the form to the backend.
   * If validation fails, prevents save and shows a toast error.
   */
  const handleSave = useCallback(async () => {
    const validated = validateAllFields(fields);
    setFields(validated);

    const errors = validated.filter(f => f.error);

    if (errors.length > 0) {
      const errorMessages = errors.map(f => `${f.label || f.id}: ${f.error}`).join("\n");
      toast.error(`${errorMessages}`);
      return;
    }

    let base64File = "";
    if (fileUrl) {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      base64File = await blobToBase64(blob);
    }
    const payload: SaveEditedFormRequest = {
      formId: encryptId(Number(decodedToken?.formId)),
      userId: encryptId(Number(decodedToken?.userId)),
      file: base64File,
      fields: validated,
      userRole: decryptedLoggedUser?.data?.role,
      token: decryptedLoggedUser?.data?.token,
    };

    await dispatch(saveEditedForm(payload));
  }, [
    fields,
    fileUrl,
    dispatch,
    decodedToken?.userId,
    decodedToken?.formId,
    decryptedLoggedUser?.data?.role,
    decryptedLoggedUser?.data?.token,
  ]);

  /**
   * Submits the edited form:
   * Validates fields and shows errors if any
   * Converts file to base64 (if provided)
   * Builds payload with encrypted IDs, file, and fields
   * Dispatches submit action and redirects to Login on success
   */
  const handleSubmit = useCallback(async () => {
    const validated = validateAllFields(fields);
    setFields(validated);

    const errors = validated.filter(f => f.error);

    if (errors.length > 0) {
      const errorMessages = errors.map(f => `${f.label || f.id}: ${f.error}`).join("\n");
      toast.error(`${errorMessages}`);
      return;
    }

    let base64File = "";
    if (fileUrl) {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      base64File = await blobToBase64(blob);
    }

    const payload: SubmitEditedFormRequest = {
      formId: encryptId(Number(decodedToken?.formId)),
      userId: encryptId(Number(decodedToken?.userId)),
      file: base64File,
      fields: validated,
      submittedBy: initialEmail,
      userRole: decryptedLoggedUser?.data?.role,
      token: decryptedLoggedUser?.data?.token,
    };

    handleSave();
    const result = await dispatch(submitEditedForm(payload));
    if (submitEditedForm.fulfilled.match(result)) {
      navigate(ROUTES.LOGIN);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    fields,
    fileUrl,
    dispatch,
    decodedToken?.userId,
    decodedToken?.formId,
    initialEmail,
    decryptedLoggedUser?.data?.role,
  ]);

  /**
   * Effect: Fetches PDF data on component mount.
   * Runs only once because of empty dependency array.
   */
  useEffect(() => {
    getPdfData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Validates all fields in the provided array.
   * - Iterates over each field and applies `validateField`.
   * - Returns a new array of fields with the `error` property set.
   *
   * @param fields - The list of fields to validate.
   * @returns A new list of fields with updated error states.
   */
  const validateAllFields = (fields: FieldBase[]): FieldBase[] => {
    return fields.map(f => ({
      ...f,
      error: validateField(f),
    }));
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="w-full bg-white shadow-sm fixed z-50 pl-[14px]">
        <div className="w-full lg:px-[10px]">
          <div className="flex flex-wrap items-center justify-between py-4">
            <div className="flex items-center space-x-2">
              <Folder className="text-[#7E57C2] xl:h-[65px] xl:w-[45px] w-[35px] h-[35px] sm:h-[35px] md:h-[47px] lg:h-[50px] sm:w-[35px] md:w-[47px] lg:w-[50px]" />
              <div className="text-3xl font-semibold bg-gradient-to-r from-[#7E57C2] to-[#AB47BC] text-transparent bg-clip-text">
                DMS ( Document Management System )
              </div>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-grow bg-[#e1dcef]">
        <div className="pt-[80px] md:pt-[100px] pb-[80px] mx-4 sm:mx-6 lg:mx-6 xl:mx-auto">
          <div className="px-8">
            <div className="flex justify-between items-center">
              <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide my-6">
                DMS Form - {fileName}
              </h4>
              <div className="flex justify-end gap-3 p-4">
                <CommonButton
                  className="!max-h-[36px] h-full !text-sm sm:!text-[16px] font-bold px-4 sm:px-6"
                  variant="contained"
                  onClick={handleSubmit}
                >
                  <span className="flex gap-2">
                    <SquareCheckBig size={18} /> Submit DMS Form
                  </span>
                </CommonButton>
                <CommonButton
                  className="!max-h-[36px] h-full !text-sm sm:!text-[16px] font-bold px-4 sm:px-6"
                  variant="contained"
                  onClick={handleSave}
                >
                  <span className="flex gap-2">
                    <Save size={18} /> Save DMS Form
                  </span>
                </CommonButton>
              </div>
            </div>

            <div className="bg-white py-6">
              <PDFViewer
                pdfData={fileUrl}
                fields={fields}
                activeType={null}
                addField={() => {}}
                moveField={() => {}}
                changeFieldValue={changeFieldValue}
                resizeField={() => {}}
                selectedFieldId={null}
                onSelectField={() => {}}
                readonly={true}
                zoomPluginInstance={zoomPluginInstance}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
