import React from "react";
import { PaletteButtonProps } from "./types";

const PaletteButton: React.FC<PaletteButtonProps> = ({ type, label, activeType, onSelect }) => {
  const isActive = activeType === type;
  return (
    <button
      type="button"
      onClick={() => onSelect(type)}
      className={`w-full text-left rounded-xl border p-2 mb-2 text-sm transition-all duration-200 cursor-pointer ${
        isActive
          ? "border-purple-500 ring-1 bg-purple-50 text-[#7e57c2] shadow-md"
          : "border-gray-200 bg-white hover:bg-purple-50 hover:border-purple-300 hover:shadow-sm text-gray-700"
      }`}
    >
      {label} {isActive ? "(placing…)" : ""}
    </button>
  );
};

export default PaletteButton;
