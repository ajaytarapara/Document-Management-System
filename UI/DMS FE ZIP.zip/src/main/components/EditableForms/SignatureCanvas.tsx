"use client";

import React, { useRef, useEffect } from "react";
import { CommonButton } from "@core/components/form-elements";
import { SignatureCanvasProps } from "./types";

const SignatureCanvas: React.FC<SignatureCanvasProps> = ({ width, height, value, onChange }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const didDrawRef = useRef(false);
  const dpr = typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1;

  /**
   * Initialize and update the canvas whenever width, height, or value changes.
   * Handles device pixel ratio scaling and restores an existing signature image if provided.
   */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = Math.max(1, Math.floor(width * dpr));
    canvas.height = Math.max(1, Math.floor(height * dpr));
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#111827";
    if (value) {
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
      };
      img.src = value;
    }
  }, [width, height, value, dpr]);

  /**
   * Get relative position of the pointer inside the canvas.
   */
  const getPos = (e: React.PointerEvent) => {
    const rect = (e.target as HTMLCanvasElement).getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  /**
   * Start drawing when pointer is pressed down.
   */
  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    didDrawRef.current = false;
    canvas.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    lastRef.current = getPos(e);
  };

  /**
   * Draw stroke while moving the pointer if drawing is active.
   */
  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.stopPropagation();
    if (!drawingRef.current) return;
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    didDrawRef.current = true;
    const p = getPos(e);
    const l = lastRef.current || p;
    ctx.beginPath();
    ctx.moveTo(l.x, l.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    lastRef.current = p;
  };

  /**
   * Finish drawing stroke when pointer is released or cancelled.
   * Exports the canvas as a PNG DataURL and passes it via `onChange`.
   */
  const finish = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (canvas.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    drawingRef.current = false;
    lastRef.current = null;
    const data = canvas.toDataURL("image/png");
    onChange(data);
  };

  /**
   * Reset drawing state if pointer leaves the canvas.
   */
  const onLeave = () => {
    drawingRef.current = false;
    lastRef.current = null;
  };

  /**
   * Clear the entire canvas and reset value.
   */
  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange("");
  };

  return (
    <div className="relative w-full h-full">
      <canvas
        ref={canvasRef}
        style={{ width, height, backgroundColor: "#f4eeff", borderRadius: 4, border: "1px solid #9CA3AF" }}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={finish}
        onPointerCancel={finish}
        onPointerLeave={onLeave}
        onClick={e => {
          if (didDrawRef.current) {
            e.stopPropagation();
            didDrawRef.current = false;
          }
        }}
      />
      <CommonButton
        type="button"
        className="!absolute !right-1 !bottom-1 !text-xs !px-0 !py-0.5 !min-w-[50px] !bg-white !border !rounded"
        onClick={e => {
          e.stopPropagation();
          clear();
        }}
      >
        Clear
      </CommonButton>
    </div>
  );
};

export default SignatureCanvas;
