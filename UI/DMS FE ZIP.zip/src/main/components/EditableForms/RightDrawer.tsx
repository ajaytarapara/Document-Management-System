"use client";

import React from "react";
import { Drawer, IconButton } from "@mui/material";
import { X } from "lucide-react";

interface RightDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
}

const RightDrawer: React.FC<RightDrawerProps> = ({ open, onClose, title = "Details", children }) => {
  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: "30%",
          bgcolor: "#faf9ff",
          display: "flex",
          flexDirection: "column",
        },
      }}
    >
      <div className="flex justify-between items-center px-4 py-3 border-b bg-[#7E57C2] text-white">
        <h2 className="text-lg font-semibold">{title}</h2>
        <IconButton onClick={onClose} sx={{ color: "white" }}>
          <X />
        </IconButton>
      </div>
      <div className="px-4 py-4 overflow-auto">{children}</div>
    </Drawer>
  );
};

export default RightDrawer;
