"use client";

import React from "react";
import { FieldBase } from "./types";
import { CommonButton, CommonTextField } from "@core/components/form-elements";
import { Checkbox, FormControlLabel, Divider } from "@mui/material";
import { Trash2 } from "lucide-react";
import { FieldType } from "@core/models/enums";

interface FieldPropertiesDrawerProps {
  field: FieldBase;
  onUpdate: (patch: Partial<FieldBase>) => void;
  onAddOption: () => void;
  onRemoveOption: (index: number) => void;
  onChangeOption: (index: number, value: string) => void;
  onUpdateFields?: (updater: (prev: FieldBase[]) => FieldBase[]) => void;
}

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="text-md font-semibold text-[#7e57c2] mt-3 mb-2">{children}</div>
);

const Row: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className }) => (
  <div className={`grid grid-cols-1 md:grid-cols-1 gap-3 ${className ?? ""}`}>{children}</div>
);

const FieldPropertiesDrawer: React.FC<FieldPropertiesDrawerProps> = ({
  field,
  onUpdate,
  onAddOption,
  onRemoveOption,
  onChangeOption,
  onUpdateFields,
}) => {
  /**
   * Updates a field's value, handling grouped radios correctly.
   *
   * @param field - The current field being updated
   * @param checked - The new checked value
   * @param onUpdate - Callback to update a single field
   * @param onUpdateFields - Optional callback to update multiple fields (needed for radio groups)
   */
  function handleDefaultCheckedChange(
    field: FieldBase,
    checked: boolean,
    onUpdate: (patch: Partial<FieldBase>) => void,
    onUpdateFields?: (updateFn: (prev: FieldBase[]) => FieldBase[]) => void
  ) {
    if (field.type === FieldType.Radio && field.groupId && onUpdateFields) {
      // Update all radios in the same group
      onUpdateFields(prevFields =>
        prevFields.map(f => {
          if (f.type === FieldType.Radio && f.groupId === field.groupId) {
            return { ...f, value: f.id === field.id && checked ? "true" : "false" };
          }
          return f;
        })
      );
    } else if (field.type === FieldType.Checkbox) {
      onUpdate({ value: checked ? "true" : "false" });
    } else {
      onUpdate({ value: String(checked) });
    }
  }
  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <SectionTitle>Basic</SectionTitle>
        <Row>
          <CommonTextField
            name="field_name"
            label="Name"
            value={field.name ?? ""}
            onChange={e => onUpdate({ name: e.target.value })}
          />
          <CommonTextField
            name="field_label"
            label="Label"
            value={field.label ?? ""}
            onChange={e => onUpdate({ label: e.target.value })}
          />
        </Row>
        {(field.type === FieldType.Text || field.type === FieldType.Select) && (
          <Row>
            <CommonTextField
              name="field_placeholder"
              label="Placeholder"
              value={field.placeholder ?? ""}
              onChange={e => onUpdate({ placeholder: e.target.value })}
            />
          </Row>
        )}
      </div>

      {(field.type === FieldType.Checkbox || field.type === FieldType.Radio) && (
        <>
          <Divider />
          <div className="space-y-3">
            <SectionTitle>Default Value</SectionTitle>
            <FormControlLabel
              control={
                <Checkbox
                  checked={field.value === "true"}
                  onChange={e => handleDefaultCheckedChange(field, e.target.checked, onUpdate, onUpdateFields)}
                />
              }
              label="Checked by default"
            />

            <FormControlLabel
              control={
                <Checkbox
                  checked={field.isLabelVisible !== false}
                  onChange={e => onUpdate({ isLabelVisible: e.target.checked })}
                />
              }
              label="Show Label on PDF"
            />

            {field.type === FieldType.Radio && (
              <div className="mt-3">
                <CommonTextField
                  value={field.groupId ?? ""}
                  placeholder="Enter group ID"
                  type="text"
                  name="Group"
                  label="Add group Id to create radio group"
                  onChange={e => onUpdate({ groupId: e.target.value })}
                  className="border rounded px-2 py-1 text-sm w-[300px]"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Radios with the same Group ID will behave as a single group.
                </p>
              </div>
            )}
          </div>
        </>
      )}

      {field.type === FieldType.Text && (
        <>
          <Divider />
          <div className="space-y-3">
            <SectionTitle>Validations</SectionTitle>
            <FormControlLabel
              control={
                <Checkbox checked={field.required == true} onChange={e => onUpdate({ required: e.target.checked })} />
              }
              label="Required"
            />
            <Row>
              <CommonTextField
                name="min_length"
                label="Min Length"
                type="number"
                inputProps={{ min: 0 }}
                value={field.minLength ?? ""}
                onChange={e => onUpdate({ minLength: e.target.value ? Number(e.target.value) : undefined })}
              />
              <CommonTextField
                name="max_length"
                label="Max Length"
                type="number"
                inputProps={{ min: 0 }}
                value={field.maxLength ?? ""}
                onChange={e => onUpdate({ maxLength: e.target.value ? Number(e.target.value) : undefined })}
              />
            </Row>
            <SectionTitle>Custom Validation</SectionTitle>
            <Row>
              <CommonTextField
                name="pattern"
                label="Pattern (RegExp)"
                value={field.regx ?? ""}
                onChange={e => onUpdate({ regx: e.target.value })}
              />
              <CommonTextField
                name="pattern_message"
                label="Error Message"
                value={field.errorMessage ?? ""}
                onChange={e => onUpdate({ errorMessage: e.target.value })}
              />
            </Row>
          </div>
        </>
      )}

      {field.type === FieldType.Select && (
        <>
          <Divider />
          <div className="space-y-3">
            <SectionTitle>Options</SectionTitle>
            <div className="space-y-2 max-h-[250px] overflow-y-auto overflow-x-hidden">
              {(field.options ?? []).map((opt, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <CommonTextField
                    name={`opt_${idx}`}
                    size="small"
                    value={opt}
                    onChange={e => onChangeOption(idx, e.target.value)}
                    className="flex-1"
                  />
                  <button
                    onClick={() => onRemoveOption(idx)}
                    title="Remove option"
                    type="button"
                    className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex justify-end">
              <CommonButton className="!mt-2" variant="contained" size="small" onClick={onAddOption}>
                Add Option
              </CommonButton>
            </div>

            <SectionTitle>Validations</SectionTitle>
            <FormControlLabel
              control={
                <Checkbox checked={field.required == true} onChange={e => onUpdate({ required: e.target.checked })} />
              }
              label="Required"
            />
          </div>
        </>
      )}
    </div>
  );
};

export default FieldPropertiesDrawer;
