"use client";

import React from "react";
import Sidebar from "./Sidebar";
import PDFViewer from "./PDFViewer";
import FieldPropertiesDrawer from "./FieldPropertiesDrawer";
import RightDrawer from "./RightDrawer";
import { CommonButton } from "@core/components";
import { Save, Share2 } from "lucide-react";
import { useEditableForm } from "./EditableForms.hook";
import { ShareDmsFileModal } from "../DmsForms/ShareDmsFormsModal";
import { shareDmsForm } from "@main/store";

export default function EditableForms() {
  const {
    fields,
    fileName,
    activeType,
    fileUrl,
    setActiveType,
    addField,
    moveField,
    resizeField,
    deleteField,
    clearAll,
    changeFieldValue,
    changeFieldName,
    updateField,
    handleSave,
    selectedFieldId,
    setSelectedFieldId,
    selectedField,
    zoomPluginInstance,
    ZoomInButton,
    ZoomOutButton,
    ZoomPopover,
    handleOpenShareModal,
    openShareModal,
    closeShareModal,
    shareFormId,
    dispatch,
  } = useEditableForm();
  return (
    <div>
      <div className="bg-gray-50 p-4">
        <p className="font-semibold text-lg text-[#00092a]">File name : {fileName}</p>
      </div>
      <div className="bg-white flex justify-between py-2 border-b border-t border-[#7E57C2]">
        <div className="flex items-center gap-2 px-2 py-1">
          <ZoomOutButton />
          <ZoomPopover />
          <ZoomInButton />
        </div>
        <div className="flex justify-end gap-3 items-center pr-3">
          <CommonButton
            type="button"
            variant="contained"
            onClick={() => handleOpenShareModal(fileName)}
            className="!max-h-[36px] h-full !text-sm sm:!text-[16px] font-bold px-4 sm:px-6"
          >
            <span className="flex gap-2">
              <Share2 size={18} /> Share DMS Form
            </span>
          </CommonButton>

          <CommonButton
            className="!max-h-[36px] h-full !text-sm sm:!text-[16px] font-bold px-4 sm:px-6"
            variant="contained"
            onClick={handleSave}
          >
            <span className="flex gap-2">
              <Save size={18} /> Save DMS Form
            </span>
          </CommonButton>
        </div>
      </div>
      <div className="flex h-[100dvh] bg-gray-50 flex-col md:flex-row">
        <Sidebar
          activeType={activeType}
          setActiveType={setActiveType}
          fields={fields}
          clearAll={clearAll}
          changeFieldName={changeFieldName}
          deleteField={deleteField}
        />

        <main className="flex-1 overflow-y-hidden">
          <div className="h-full bg-white py-4">
            <PDFViewer
              pdfData={fileUrl}
              fields={fields}
              activeType={activeType}
              addField={addField}
              moveField={moveField}
              changeFieldValue={changeFieldValue}
              resizeField={resizeField}
              selectedFieldId={selectedFieldId}
              onSelectField={setSelectedFieldId}
              zoomPluginInstance={zoomPluginInstance}
              readonly={false}
            />
          </div>
        </main>

        <RightDrawer open={!!selectedField} onClose={() => setSelectedFieldId(null)} title="Field Properties">
          {selectedField && (
            <FieldPropertiesDrawer
              field={selectedField}
              onUpdate={patch => updateField(selectedField.id, patch)}
              onUpdateFields={updater => {
                const updatedFields = updater(fields);
                updatedFields.forEach(f => updateField(f.id, f));
              }}
              onRemoveOption={idx => {
                const opts = [...(selectedField.options ?? [])];
                opts.splice(idx, 1);
                updateField(selectedField.id, { options: opts });
              }}
              onAddOption={() => {
                const opts = [...(selectedField.options ?? [])];
                opts.push(`Option ${opts.length + 1}`);
                updateField(selectedField.id, { options: opts });
              }}
              onChangeOption={(idx, val) => {
                const opts = [...(selectedField.options ?? [])];
                opts[idx] = val;
                updateField(selectedField.id, { options: opts });
              }}
            />
          )}
        </RightDrawer>

        <ShareDmsFileModal
          open={openShareModal}
          folderId={shareFormId}
          onClose={closeShareModal}
          onShare={async (formId, formData) => {
            return await dispatch(
              shareDmsForm({
                formIds: [formId],
                data: formData,
              })
            ).unwrap();
          }}
          fileName={fileName}
        />
      </div>
    </div>
  );
}
