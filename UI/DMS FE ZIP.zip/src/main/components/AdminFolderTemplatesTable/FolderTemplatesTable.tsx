"use client";

import { IUserTemplateResponse } from "@main/models";
import { Pagination } from "@mui/material";
import { Pencil, Trash2 } from "lucide-react";

type Props = {
  data: IUserTemplateResponse[];
  currentPage: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
};

export const FolderTemplatesTable = ({
  data,
  currentPage,
  pageSize,
  totalCount,
  onPageChange,
  onDelete,
  onEdit,
}: Props) => {
  const totalPages = Math.ceil(totalCount / pageSize);
  return (
    <>
      <div className="shadow-sm overflow-x-auto">
        <table className="min-w-full table-auto border-collapse">
          <thead className="bg-[#e1dcef]">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">Template</th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">Tabs Count</th>
              <th className="px-4 py-3 text-center text-sm font-semibold text-[#00092A] rounded-tr-md">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.map((item, index) => (
              <tr key={index} className="hover:bg-gray-50 transition">
                <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">{item.name}</td>
                <td className="px-4 py-3 text-sm text-gray-800">{item.tabsCount}</td>
                <td className="px-3 sm:px-4 py-2 sm:py-3">
                  <div className="flex justify-center items-center gap-2 sm:gap-3 flex-wrap">
                    <Pencil
                      className="w-4 h-4 sm:w-5 sm:h-5 text-[#7E57C2] cursor-pointer"
                      onClick={() => onEdit(item.id)}
                    />
                    <Trash2
                      className="w-4 h-4 sm:w-5 sm:h-5 text-[#EF5350] cursor-pointer"
                      onClick={() => onDelete(item.id)}
                    />
                  </div>
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center text-sm text-gray-500">
                  No Records Found!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <div className="mt-4 flex justify-end">
          <Pagination
            count={totalPages}
            page={currentPage}
            onChange={(_, page) => onPageChange(page)}
            color="primary"
            variant="outlined"
            shape="rounded"
          />
        </div>
      )}
    </>
  );
};
