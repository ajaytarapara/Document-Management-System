import { useForm } from "react-hook-form";

import { useAppDispatch } from "@main/hooks";
import { ICreateUserForm, ILoginResponse, IUsersResponse } from "@main/models";
import { createUser, useSelectorAuthState } from "@main/store";
import { IAPIResponse } from "@core/models";
import { decryptObject, useNavigate } from "@core/utils";
import { ROUTES } from "@core/constants/PAGE_URLS";

export const useCreateUserForm = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
  } = useForm<ICreateUserForm>();

  const onSubmit = async (data: ICreateUserForm) => {
    const result = await dispatch(createUser(data));
    if (createUser.fulfilled.match(result)) {
      const encryptedString = result.payload?.data;
      const decrypted: IAPIResponse<IUsersResponse> = decryptObject<IAPIResponse<IUsersResponse>>(
        encryptedString as unknown as string
      );
      if (decrypted?.data) {
        reset();
        setTimeout(() => {
          navigate(ROUTES.ADMIN.VIEW_USER);
        }, 1500);
      }
    }
  };

  const backToViewUsers = () => {
    navigate(ROUTES.ADMIN.DASHBOARD);
  };

  return {
    errors,
    control,
    decryptedLoggedUser,
    register,
    handleSubmit,
    backToViewUsers,
    onSubmit,
  };
};
