import emotionStyled from "@emotion/styled";
import { Button, FormControl, Select } from "@mui/material";

export const StyledCancelButton = emotionStyled(Button)`
  max-width: 100px;
  width: 100%;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #7E57C2;
  &:hover {
    background-color: #e1dcef;
  }
`;

export const StyledFormControl = emotionStyled(FormControl)({
  minWidth: 100,
  height: 28,
  margin: 0,
});

export const StyledSelect = emotionStyled(Select)({
  height: 28,
  "& .MuiSelect-select": {
    padding: "8px 12px",
    fontSize: "14px",
  },
});
