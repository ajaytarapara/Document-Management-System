import { CommonTextField } from "@core/components";
import { decryptObject, getTextColorForBackground } from "@core/utils";
import {
  AddToTabModal,
  FileTable,
  PDFDownloadModal,
  UpdateFolderComponent,
  UploadDocumentDrawer,
} from "@main/components";
import { Box, InputAdornment } from "@mui/material";
import { FolderDown, Minus, Plus, Search, Share2, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { shareFile, shareMultipleFile, useSelectorAuthState } from "@main/store";
import { IAPIResponse, Role } from "@core/models";
import { FolderDto, ILoginResponse } from "@main/models";
import { MoveFileDrawer } from "../EditModels/moveFile";
import { ShareFolderDrawer } from "../FolderComponents/ShareFolderModal";
import JSZip from "jszip";
import { useAppDispatch } from "@main/hooks";
import { SHARE_TYPE } from "@core/constants/Constant";
// import { saveAs } from "file-saver";

export const FolderFile = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const encryptedId = searchParams.get("fid");
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [showMoveFileModal, setShowMoveFileModal] = useState<boolean>(false);
  const [showAddToTabModal, setShowAddToTabModal] = useState<boolean>(false);
  const [folderDetails, setFolderDetails] = useState<FolderDto>();
  const [showPDFModal, setShowPDFModal] = useState<boolean>(false);
  const [showUploadDocumentModal, setShowUploadDocumentModal] = useState<boolean>(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const isAnySelected = selectedIds.length > 0;
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedByDrag, setUploadedByDrag] = useState<boolean>(false);
  const [tab, setTab] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState("");
  const [success, setSucess] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState<boolean>(false);
  const [shareType, setShareType] = useState<string>("");
  const inputRef = useRef<HTMLInputElement>(null);
  const [selectedTab, setSelectedTab] = useState<string>("");
  const [selectedFilesDownLoad, setSelectedFilesDwonload] = useState<{ id: string; name: string; url: string }[]>([]);
  const [length, setLength] = useState(0);

  const dispatch = useAppDispatch();
  /**
   * Memoized folder ID derived from the encrypted ID in the URL.
   *
   * - If `encryptedId` exists, it is decoded and decrypted to get the actual folder ID.
   * - Returns `null` if no `encryptedId` is provided.
   */
  const folderId = useMemo(() => {
    return encryptedId ? encryptedId : null;
  }, [encryptedId]);

  /**
   * Redirects the user to the appropriate "View Folder" route
   * if no `encryptedId` is available in the URL.
   *
   * - Office users are redirected to the Office User view.
   * - Regular users are redirected to the User view.
   */
  useEffect(() => {
    if (!encryptedId) {
      if (decryptedLoggedUser?.data?.role === Role.Office_User) {
        router.push(ROUTES.OFFICE_USER.VIEW_FOLDER);
      } else {
        router.push(ROUTES.USER.VIEW_FOLDER);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [encryptedId, router]);

  /**
   * Updates the state with the provided folder details.
   *
   * @param folderDetails - The details of the folder being set.
   */
  const handleSetFolderDetails = (folderDetails: FolderDto) => {
    setFolderDetails(folderDetails);
    setTab(folderDetails.tabs[0].id);
    setSelectedTab(folderDetails.tabs[0].id);
  };

  /**
   * Determines the share type based on the provided value.
   * - Returns the matching `SHARE_TYPE` (FOLDER, FILE).
   * - Returns an empty string if no type is provided.
   * - Defaults to `SHARE_TYPE.TAB` if no match is found.
   *
   * @param shareType - The type of share as a string.
   * @returns A valid share type string.
   */
  const getShareType = (shareType: string): string => {
    switch (shareType) {
      case SHARE_TYPE.FOLDER:
        return SHARE_TYPE.FOLDER;
      case SHARE_TYPE.FILE:
        return SHARE_TYPE.FILE;
      case "":
        return "";
      default:
        return SHARE_TYPE.TAB;
    }
  };

  /**
   * Resolves the folder identifier(s) based on the share type.
   * - If sharing a folder, returns the folderId.
   * - If sharing files, returns the selected file IDs.
   * - If sharing a tab, returns the tab ID.
   * - Defaults to an empty string if no match is found.
   *
   * @param shareType - The type of share (FOLDER, FILE, or TAB).
   * @param folderId - The folder identifier.
   * @param selectedIds - Array of selected file IDs.
   * @param tab - The tab identifier.
   * @returns The resolved ID(s) depending on share type.
   */
  const getFolderId = (shareType: string, folderId: string, selectedIds: string[], tab: string) => {
    switch (shareType) {
      case SHARE_TYPE.FOLDER:
        return folderId;
      case SHARE_TYPE.FILE:
        return selectedIds;
      case SHARE_TYPE.TAB:
        return tab;
      default:
        return "";
    }
  };

  /**
   * Handles adding selected files to the state.
   *
   * @param files - The FileList of selected or dropped files.
   * @param byDrag - Flag indicating whether files were added via drag-and-drop.
   */
  const handleFiles = (files: FileList | null, byDrag = false) => {
    if (files) {
      setSelectedFiles(prev => [...prev, ...Array.from(files)]);
      setUploadedByDrag(byDrag);
    }
  };

  /**
   * Handles drag events for the drop zone (dragenter, dragover, dragleave).
   *
   * @param e - The drag event from the drop zone.
   */
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  /**
   * Handles the drop event when files are dragged and released in the drop zone.
   *
   * @param e - The drop event from the drop zone.
   */
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    handleFiles(e.dataTransfer.files, true);
  };

  /**
   * Handles file selection from the file input element.
   *
   * @param e - The change event from the file input.
   */
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files, false);
    if (e.target.files?.length && e.target.files.length > 0) {
      setShowUploadDocumentModal(true);
    }
  };

  /**
   * Removes a file from the list of selected files by index.
   *
   * @param indexToRemove - The index of the file to be removed.
   */
  const removeFile = (indexToRemove: number) => {
    setSelectedFiles(prev => {
      const updatedFiles = prev.filter((_, index) => index !== indexToRemove);
      if (updatedFiles.length === 0) {
        setUploadedByDrag(false);
      }
      return updatedFiles;
    });
  };

  /**
   * Closes the upload document modal and resets file-related states.
   */
  const handleCloseUploadDocumentModal = () => {
    setShowUploadDocumentModal(false);
    setSelectedFiles([]);
    setUploadedByDrag(false);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  const handleConfirmAddToTabFile = () => {};

  /**
   * Downloads selected files as a single ZIP archive.
   * - Iterates through the provided list of files.
   * - Builds the full file URL using the API base URL.
   * - Ensures each file has a `.pdf` extension.
   * - Fetches each file from the server and adds it to a JSZip instance.
   * - Handles errors gracefully by logging failed fetches without interrupting the loop.
   * - Generates the ZIP archive as a blob and triggers a download in the browser.
   *
   * @param selectedFilesDownLoad - Array of files to be downloaded, containing `id`, `name`, and `url`.
   */
  const handleDownloadZip = async (selectedFilesDownLoad: { id: string; name: string; url: string }[]) => {
    const zip = new JSZip();

    for (const file of selectedFilesDownLoad) {
      const fileUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${file.url}`;
      const fileName = file.name.endsWith(".pdf") ? file.name : `${file.name}.pdf`;

      try {
        const response = await fetch(fileUrl);
        if (!response.ok) {
          throw new Error(`Failed to fetch file: ${fileUrl}`);
        }

        const blob = await response.blob();
        zip.file(fileName, blob);
      } catch (error) {
        console.error(`Error fetching ${fileUrl}:`, error);
      }
    }

    zip.generateAsync({ type: "blob" }).then(content => {
      const link = document.createElement("a");
      link.href = URL.createObjectURL(content);
      link.download = "selected_files.zip";
      link.click();
    });
  };
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">
          Folder name : {folderDetails?.folderName}
        </h4>
      </div>
      <div className="rounded px-4 py-2 bg-white">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-lg md:text-xl text-[#00092a] tracking-wide">File number : 18075</h4>
          <div
            className="w-[46px] h-[46px] flex items-center justify-center bg-gray-300 rounded-md cursor-pointer transition-all duration-300"
            onClick={() => setIsOpen(!isOpen)}
          >
            <div className={`transition-transform duration-500 ease-in-out ${isOpen ? "rotate-180" : "rotate-0"}`}>
              {isOpen ? <Minus className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
            </div>
          </div>
        </div>
      </div>
      <div
        className={`rounded border-t border-[#d7deec] transition-all duration-500 ease-in-out bg-white overflow-hidden ${
          isOpen ? "max-h-[1000px] opacity-100 scale-100 p-4" : "max-h-0 opacity-0 scale-95"
        }`}
      >
        <div className="grid grid-cols-1 md:grid-cols-1 gap-6 md:gap-8">
          {/* cols-1 ni jagya e 2 karvanu */}
          <div className="grid grid-cols-1 md:grid-cols-1 gap-6 md:gap-8">
            {/* cols-1 ni jagya e 2 karvanu */}
            <div className="space-y-4">
              <div className="flex justify-start">
                <button
                  onClick={() => {
                    setShareModalOpen(true);
                    setShareType(SHARE_TYPE.FOLDER);
                  }}
                  className="bg-[#f0f8f1] gap-2 flex items-center border border-[#d2e3d5] px-3 py-2 rounded text-sm md:text-base"
                >
                  <Share2 className="w-5 h-5 text-[#4caf50]" />
                  <span className="font-medium text-[#4caf50]">Folder Share</span>
                </button>
              </div>
              <div
                className={`border-2 border-dashed ${
                  dragActive ? "border-green-400 bg-green-50" : "border-gray-300"
                } rounded p-6 flex flex-col gap-2 items-center text-gray-500 text-center transition-all`}
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
              >
                {!uploadedByDrag && (
                  <>
                    <span className="text-4xl">📄</span>
                    <p className="text-sm md:text-base">Drag and Drop PDF file(s) here</p>
                  </>
                )}
                {uploadedByDrag && selectedFiles.length > 0 && (
                  <ul className="w-full space-y-2">
                    {selectedFiles.map((file, index) => (
                      <li
                        key={index}
                        className="bg-white border rounded flex justify-between items-center px-3 py-1 text-sm text-gray-700"
                      >
                        <span className="truncate">{file.name}</span>
                        <button onClick={() => removeFile(index)} className="text-red-500 hover:text-red-700">
                          <X className="w-4 h-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="flex justify-start">
                {!uploadedByDrag && (
                  <button
                    onClick={() => {
                      inputRef.current?.click();
                      setSucess(false);
                    }}
                    className="px-4 py-2 rounded text-sm md:text-base border transition-colors duration-200 bg-[#198754] border-[#198754] text-white hover:bg-green-700"
                  >
                    Select File
                  </button>
                )}
                {uploadedByDrag && selectedFiles.length > 0 && (
                  <button
                    onClick={() => {
                      setShowUploadDocumentModal(true);
                      setSucess(false);
                    }}
                    className="px-4 py-2 rounded text-sm md:text-base border transition-colors duration-200 bg-[#198754] border-[#198754] text-white hover:bg-green-700"
                  >
                    Click here to Upload Files
                  </button>
                )}
                <input
                  type="file"
                  accept="application/pdf"
                  multiple
                  ref={inputRef}
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>

              <UploadDocumentDrawer
                open={showUploadDocumentModal}
                onClose={handleCloseUploadDocumentModal}
                selectedFiles={selectedFiles}
                removeFile={removeFile}
                tabs={folderDetails?.tabs}
                folderId={folderId}
                handleSucess={() => {
                  setSucess(true);
                }}
              />
            </div>
            {/* <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 h-fit">
          {/* <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 h-fit">
            <button className="flex flex-col group items-center justify-center px-2 py-2 border border-[#d2d2d2] hover:border-[#7E57C2] cursor-pointer rounded hover:shadow-lg transition h-24">
              <div className="text-black">
                <FolderDown className="w-9 h-9" />
              </div>
              <span className="text-xs mt-1 font-medium text-[#00092a] group-hover:text-[#7E57C2] text-center">
                Archive
              </span>
            </button>
          </div> */}
          </div>
        </div>
      </div>
      <div className="mt-9">
        <Box
          className="flex whitespace-nowrap"
          sx={{
            "&::-webkit-scrollbar-track": {
              backgroundColor: "transparent",
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: "#ccc",
              borderRadius: "4px",
            },
          }}
        >
          {folderDetails?.tabs.map((tab, idx) => {
            const isSelected = tab.id === selectedTab;
            const textColor = getTextColorForBackground(tab.color);

            return (
              <Box
                key={idx}
                className={`min-w-[120px] max-w-[160px] px-4 py-3 text-sm font-semibold text-center truncate cursor-pointer transition-all duration-300 ease-in-out`}
                style={{
                  backgroundColor: tab.color,
                  color: textColor,
                  borderRadius: "12px 12px 0 0",
                  transform: isSelected ? "scale(1.1)" : "scale(1)",
                  paddingTop: isSelected ? "1rem" : "0.75rem",
                  paddingBottom: isSelected ? "1rem" : "0.75rem",
                }}
                title={tab.tabName}
                onClick={() => {
                  setSelectedTab(tab.id);
                  setTab(tab.id);
                }}
              >
                {tab.tabName}
              </Box>
            );
          })}
        </Box>
      </div>
      <div className="p-4 bg-white rounded-bl rounded-br">
        {length > 0 && (
          <div className="flex flex-col gap-4 md:flex-row md:justify-between md:items-center w-full">
            <CommonTextField
              name="search"
              placeholder="Enter Name for search"
              type="text"
              fullWidth
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="transition-all duration-200 w-full md:max-w-md"
              sx={{
                "& .MuiInputBase-root": {
                  height: "40px",
                  fontSize: "14px",
                },
                "& input": {
                  padding: "8px 12px",
                },
              }}
              slotProps={{
                input: {
                  endAdornment: (
                    <InputAdornment position="end">
                      <Search
                        size={20}
                        className="text-bolder transition-transform duration-200 hover:scale-110 text-[#7E57C2]"
                      />
                    </InputAdornment>
                  ),
                },
              }}
            />

            <div className="flex flex-wrap justify-start md:justify-end gap-2 w-full">
              <button
                type="button"
                disabled={!isAnySelected}
                className={`flex items-center gap-2 whitespace-nowrap justify-center px-3 py-2 text-sm font-medium rounded-md shadow ${
                  isAnySelected
                    ? "bg-[#7E57C2] text-white cursor-pointer hover:bg-[#6C4FB3]"
                    : "bg-gray-300 text-gray-600 cursor-not-allowed"
                }`}
                onClick={() => {
                  setShareType(SHARE_TYPE.FILE);
                  setShareModalOpen(true);
                }}
              >
                <Share2 className="h-4 w-4" />
                <span>File</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setShareType(SHARE_TYPE.TAB);
                  setShareModalOpen(true);
                }}
                className="flex items-center cursor-pointer whitespace-nowrap justify-center gap-2 px-3 py-2 text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3]"
              >
                <Share2 className="h-4 w-4" />
                <span>Tab</span>
              </button>
              <button
                type="button"
                disabled={!isAnySelected}
                onClick={() => {
                  handleDownloadZip(selectedFilesDownLoad);
                }}
                className={`flex items-center gap-2 whitespace-nowrap justify-center px-3 py-2 text-sm font-medium rounded-md shadow ${
                  isAnySelected
                    ? "bg-[#7E57C2] text-white cursor-pointer hover:bg-[#6C4FB3]"
                    : "bg-gray-300 text-gray-600 cursor-not-allowed"
                }`}
              >
                <FolderDown className="h-4 w-4" />
                <span>PDF</span>
              </button>
              <button
                type="button"
                disabled={!isAnySelected}
                onClick={() => setShowMoveFileModal(true)}
                className={`flex items-center gap-2 whitespace-nowrap justify-center px-3 py-2 text-sm font-medium rounded-md shadow ${
                  isAnySelected
                    ? "bg-[#7E57C2] text-white cursor-pointer hover:bg-[#6C4FB3]"
                    : "bg-gray-300 text-gray-600 cursor-not-allowed"
                }`}
              >
                <span>Move</span>
              </button>
            </div>
          </div>
        )}
        <FileTable
          onSelectionChange={setSelectedIds}
          selectedTabId={tab}
          searchTerm={searchTerm}
          success={success}
          folderId={folderId}
          selectedFiles={selectedFilesDownLoad}
          setSelectedFiles={setSelectedFilesDwonload}
          length={setLength}
        />
        {/* <MoveFileModal
          open={showMoveFileModal}
          onClose={() => setShowMoveFileModal(false)}
          onConfirm={handleConfirmMoveFile}
        /> */}
        {showMoveFileModal && (
          <MoveFileDrawer
            open={showMoveFileModal}
            onClose={() => {
              setShowMoveFileModal(false);
            }}
            onSucess={() => {
              setSucess(true);
            }}
            folderId={folderId as string}
            type={SHARE_TYPE.MOVE_FOLDER}
            fileId={selectedIds}
          />
        )}
        {showAddToTabModal && (
          <AddToTabModal
            open={showAddToTabModal}
            onClose={() => setShowAddToTabModal(false)}
            onConfirm={handleConfirmAddToTabFile}
          />
        )}
        {shareModalOpen && (
          <ShareFolderDrawer
            open={shareModalOpen}
            type={getShareType(shareType)}
            folderId={getFolderId(shareType, folderId as string, selectedIds, tab)}
            onClose={() => setShareModalOpen(false)}
            onShare={async (id, formData) => {
              if (shareType === SHARE_TYPE.FOLDER || shareType === SHARE_TYPE.TAB) {
                await dispatch(shareFile({ id: id as string, data: formData }));
              } else {
                await dispatch(shareMultipleFile(formData));
              }
            }}
            multiple={shareType == SHARE_TYPE.FILE ? true : false}
          />
        )}
        {showPDFModal && <PDFDownloadModal open={showPDFModal} onClose={() => setShowPDFModal(false)} />}
      </div>
      <UpdateFolderComponent folderId={folderId} handleSetFolderDetails={handleSetFolderDetails} />
    </div>
  );
};
