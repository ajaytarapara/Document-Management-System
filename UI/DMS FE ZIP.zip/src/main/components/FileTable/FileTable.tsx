import React, { useEffect, useState } from "react";
import { FolderDown, Share2, Move, FolderPlus, Pencil, Trash2 } from "lucide-react";
import { Checkbox, Tooltip } from "@mui/material";
import { useAppDispatch } from "@main/hooks";
import { decryptObject } from "@core/utils";
import { IAPIResponse } from "@core/models";
import { useForm } from "react-hook-form";
import { EditFileDrawer } from "../EditModels/editFile";
import { ConfirmDeleteModal } from "../DeleteFolderTemplateModal/DeleteFolderTemplateModal";
import { MoveFileDrawer } from "../EditModels/moveFile";
import { PdfPreview } from "../PdfPreview/PdfPreview";
import { ShareFolderDrawer } from "../FolderComponents/ShareFolderModal";
import { FileListDtos } from "@main/models";
import { TableFooterPagination } from "@core/components";
import { getFileByTabs, deleteFile, shareFile } from "@main/store";

interface FileTableProps {
  selectedTabId: string;
  onSelectionChange: (selectedIds: string[]) => void;
  searchTerm: string;
  success: boolean;
  folderId: string | null;
  selectedFiles: { id: string; name: string; url: string }[];
  setSelectedFiles: React.Dispatch<React.SetStateAction<{ id: string; name: string; url: string }[]>>;
  length: (length: number) => void;
}
export const FileTable: React.FC<FileTableProps> = ({
  selectedTabId,
  onSelectionChange,
  searchTerm,
  success,
  folderId,
  selectedFiles,
  setSelectedFiles,
  length,
}) => {
  const [selected, setSelected] = useState<string[]>([]);
  const [files, setFiles] = useState<FileListDtos>({ fileListDto: [], totalCount: 0 });
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortColumn, setSortColumn] = useState("id");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [fileId, setFileId] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [openMoveModal, setOpenMoveModal] = useState(false);
  const [type, setType] = useState<"moveTab" | "moveFolder" | "">("");
  const [openPreviewModal, setOpenPreviewModal] = useState(false);
  const [fileUrl, setFileUrl] = useState("");
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const isAllSelected = selected.length === files?.fileListDto?.length;
  const dispatch = useAppDispatch();
  const { control } = useForm({
    defaultValues: {
      pageSize: "10",
    },
  });
  /**
   * Handle selecting or deselecting a single file row.
   * Updates both selected IDs and selected file objects.
   */
  const handleSelectRowFiles = (file: { id: string; name: string; url: string }) => {
    const isAlreadySelected = selected.some(id => id === file.id);

    let updatedIds: string[] = [];
    let updatedFiles: { id: string; name: string; url: string }[] = [];

    if (isAlreadySelected) {
      updatedIds = selected.filter(id => id !== file.id);
      updatedFiles = selectedFiles.filter(f => f.id !== file.id);
    } else {
      updatedIds = [...selected, file.id];
      updatedFiles = [...selectedFiles, file];
    }

    setSelected(updatedIds);
    setSelectedFiles(updatedFiles);
    onSelectionChange(updatedIds);
  };
  /**
   * Handle "select all" checkbox click.
   * Selects or clears all files in the table.
   */
  const handleSelectAllFiles = () => {
    if (isAllSelected) {
      setSelected([]);
      setSelectedFiles([]);
      onSelectionChange([]);
    } else {
      const allIds = files.fileListDto.map(f => f.id);
      const allFiles = files.fileListDto.map(f => ({ id: f.id, name: f.name, url: f.url }));
      setSelected(allIds);
      setSelectedFiles(allFiles);
      onSelectionChange(allIds);
    }
  };
  /**
   * Downloads a file from API and triggers browser download.
   */
  const handleDownloadFile = async (fileUrl: string, fileName: string) => {
    const fullUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${fileUrl}`;
    try {
      const response = await fetch(fullUrl, {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error("Failed to fetch file");
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = fileName.endsWith(".pdf") ? fileName : `${fileName}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.log(error);
    }
  };
  /**
   * Handle selecting or deselecting a row by file ID.
   */
  const handleSelectRow = (id: string) => {
    const newSelected = selected.includes(id) ? selected.filter(i => i !== id) : [...selected, id];
    setSelected(newSelected);
    onSelectionChange(newSelected);
  };
  /**
   * Handle sorting by column (toggles asc/desc).
   */
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(prev => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
    setPage(1);
  };
  /**
   * Fetch files whenever filters, pagination, or search changes.
   */
  useEffect(() => {
    fetchFiles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTabId, page, pageSize, searchTerm, sortColumn, sortDirection, success]);
  /**
   * Fetch file list for the current tab and update table state.
   */
  const fetchFiles = async () => {
    if (selectedTabId) {
      const res = await dispatch(
        getFileByTabs({
          page,
          pageSize: pageSize,
          sortColumn: sortColumn,
          sortDirection: sortDirection,
          searchTerm: searchTerm,
          id: selectedTabId,
        })
      );

      if (getFileByTabs.fulfilled.match(res)) {
        const encryptedString = res.payload?.data;
        const decrypted: IAPIResponse<FileListDtos> = decryptObject<IAPIResponse<FileListDtos>>(encryptedString);
        if (decrypted?.data) {
          setFiles(decrypted.data);
          length(decrypted.data.fileListDto.length);
          const totalItems = decrypted.data.totalCount || 0;
          setTotalPages(Math.ceil(totalItems / pageSize));
        }
      }
    }
  };
  /**
   * Handle file delete action.
   * Closes modal and refreshes file list after delete.
   */
  const handleDelete = async () => {
    await dispatch(deleteFile({ id: fileId }));
    setDeleteModalOpen(false);
    fetchFiles();
  };
  /**
   * Close preview modal and reset file state.
   */
  const handleClosePreviewModel = () => {
    setFileName("");
    setFileUrl("");
    setOpenPreviewModal(false);
  };
  /**
   * Open preview modal for a given file.
   */
  const handleOpenPreviewModal = (url: string, name: string) => {
    setOpenPreviewModal(true);
    setFileUrl(`${process.env.NEXT_PUBLIC_USER_API_URL}${url}`);
    setFileName(name);
  };
  return files?.fileListDto.length === 0 ? (
    <div className="px-3 flex justify-center text-xl font-bold">No files Uploaded in this Tab</div>
  ) : (
    <div className="mt-4">
      <div className="overflow-auto w-full">
        <table className="min-w-[800px] w-full border border-[#dee2e6]">
          <thead className="bg-[#f5f6f9]">
            <tr className="text-sm text-[#888] whitespace-nowrap">
              <th className="px-3 text-left">
                <Checkbox checked={isAllSelected} onChange={handleSelectAllFiles} />
              </th>
              <th className="px-3 text-left cursor-pointer" onClick={() => handleSort("name")}>
                Preview {sortColumn === "name" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
              </th>
              <th className="px-3 text-left cursor-pointer" onClick={() => handleSort("createdAt")}>
                Upload Date {sortColumn === "createdAt" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
              </th>
              <th className="px-3 text-left">File | Share</th>
              <th className="px-3 text-left">Move | Tab</th>
              <th className="px-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="text-sm text-gray-800">
            {files?.fileListDto?.map(file => (
              <tr key={file.id} className="border-t border-[#dee2e6]">
                <td className="px-3 text-left">
                  <Checkbox
                    checked={selected.includes(file.id)}
                    onChange={() => {
                      handleSelectRow(file.id);
                      handleSelectRowFiles(file);
                    }}
                  />
                </td>
                <td
                  onClick={() => {
                    handleOpenPreviewModal(file.url, file.name);
                  }}
                  className="px-3 text-left text-blue-600 underline cursor-pointer"
                >
                  {file.name}
                </td>
                <td className="px-3 text-left">
                  {file.createdAt ? new Date(file.createdAt).toLocaleDateString() : "-"}
                </td>
                <td className="px-3 text-left">
                  <div className="flex gap-2 items-center">
                    <Tooltip title="Download File" arrow>
                      <FolderDown
                        onClick={() => {
                          handleDownloadFile(file.url, file.name);
                        }}
                        className="w-5 h-5 cursor-pointer"
                      />
                    </Tooltip>
                    <div className="h-5 w-px bg-gray-300" />
                    <Tooltip title="Share File" arrow>
                      <Share2
                        onClick={() => {
                          setShareModalOpen(true);
                          setFileId(file.id);
                        }}
                        className="w-5 h-5 cursor-pointer"
                      />
                    </Tooltip>
                  </div>
                </td>
                <td className="px-3 text-left">
                  <div className="flex gap-2 items-center">
                    <Tooltip title="Change Folder" arrow>
                      <Move
                        className="w-5 h-5"
                        onClick={() => {
                          setOpenMoveModal(true);
                          setType("moveFolder");
                          setFileId(file.id);
                        }}
                      />
                    </Tooltip>
                    <div className="h-5 w-px bg-gray-300" />
                    <Tooltip title="Change Tab" arrow>
                      <FolderPlus
                        className="w-5 h-5"
                        onClick={() => {
                          setOpenMoveModal(true);
                          setType("moveTab");
                          setFileId(file.id);
                        }}
                      />
                    </Tooltip>
                  </div>
                </td>
                <td className="px-3 text-center">
                  <div className="flex gap-2 items-center justify-center">
                    <Tooltip title="Change Name" arrow>
                      <Pencil
                        className="w-5 h-5"
                        onClick={() => {
                          setEditModalOpen(true);
                          setFileId(file.id);
                          setFileName(file.name);
                        }}
                      />
                    </Tooltip>
                    <div className="h-5 w-px bg-gray-300" />
                    <Tooltip title="Delete File" arrow>
                      <Trash2
                        className="w-5 h-5"
                        onClick={() => {
                          setDeleteModalOpen(true);
                          setFileId(file.id);
                        }}
                      />
                    </Tooltip>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex justify-end">
        <TableFooterPagination
          control={control}
          totalPage={totalPages}
          pageIndex={page}
          onPageChange={setPage}
          onPageSizeChange={newSize => {
            setPageSize(newSize);
            setPage(1);
          }}
        />
        <EditFileDrawer
          open={editModalOpen}
          onClose={() => {
            setEditModalOpen(false);
            setFileName("");
          }}
          fileId={fileId}
          fileName={fileName}
          onSucess={fetchFiles}
        />
        <PdfPreview open={openPreviewModal} onClose={handleClosePreviewModel} fileName={fileName} fileUrl={fileUrl} />
        <ConfirmDeleteModal open={deleteModalOpen} onClose={() => setDeleteModalOpen(false)} onConfirm={handleDelete} />
        <MoveFileDrawer
          open={openMoveModal}
          onClose={() => {
            setOpenMoveModal(false);
          }}
          onSucess={fetchFiles}
          folderId={folderId as string}
          type={type}
          fileId={[fileId]}
        />
        <ShareFolderDrawer
          open={shareModalOpen}
          folderId={fileId}
          onClose={() => setShareModalOpen(false)}
          onShare={async (id, formData) => {
            await dispatch(shareFile({ id: id as string, data: formData }));
          }}
          type="File"
        />
      </div>
    </div>
  );
};
