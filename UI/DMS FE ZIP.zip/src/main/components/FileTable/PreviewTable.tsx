import React, { useEffect, useState } from "react";
import { FolderDown } from "lucide-react";
import { Tooltip } from "@mui/material";
import { useAppDispatch } from "@main/hooks";
import { decryptObject } from "@core/utils";
import { IAPIResponse } from "@core/models";
import { useForm } from "react-hook-form";
import { PdfPreview } from "../PdfPreview/PdfPreview";
import { FileListDtos } from "@main/models";
import { TableFooterPagination } from "@core/components";
import { getFileByTabs } from "@main/store";
interface PreviewTableProps {
  selectedTabId: string;
  viewOnly: boolean;
}
export const PreviewTable: React.FC<PreviewTableProps> = ({ selectedTabId, viewOnly }) => {
  const [files, setFiles] = useState<FileListDtos>({ fileListDto: [], totalCount: 0 });
  const [totalPages, setTotalPages] = useState(1);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortColumn, setSortColumn] = useState("id");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [fileName, setFileName] = useState<string>("");
  const [openPreviewModal, setOpenPreviewModal] = useState(false);
  const [fileUrl, setFileUrl] = useState("");

  const dispatch = useAppDispatch();
  const { control } = useForm({
    defaultValues: {
      pageSize: "10",
    },
  });

  /**
   * Downloads a file from API and triggers browser download.
   */
  const handleDownloadFile = async (fileUrl: string, fileName: string) => {
    const fullUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${fileUrl}`;
    try {
      const response = await fetch(fullUrl, {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error("Failed to fetch file");
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = fileName.endsWith(".pdf") ? fileName : `${fileName}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.log(error);
    }
  };
  /**
   * Handle sorting by column (toggles asc/desc).
   */
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(prev => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
    setPage(1);
  };
  /**
   * Fetch files whenever filters, pagination, or search changes.
   */
  useEffect(() => {
    fetchFiles();
  }, [selectedTabId, page, pageSize, sortColumn, sortDirection]);
  /**
   * Fetch file list for the current tab and update table state.
   */
  const fetchFiles = async () => {
    if (selectedTabId) {
      const res = await dispatch(
        getFileByTabs({
          page,
          pageSize: pageSize,
          sortColumn: sortColumn,
          sortDirection: sortDirection,
          searchTerm: "",
          id: selectedTabId,
        })
      );

      if (getFileByTabs.fulfilled.match(res)) {
        const encryptedString = res.payload?.data;
        const decrypted: IAPIResponse<FileListDtos> = decryptObject<IAPIResponse<FileListDtos>>(encryptedString);
        if (decrypted?.data) {
          setFiles(decrypted.data);
          const totalItems = decrypted.data.totalCount || 0;
          setTotalPages(Math.ceil(totalItems / pageSize));
        }
      }
    }
  };

  /**
   * Close preview modal and reset file state.
   */
  const handleClosePreviewModel = () => {
    setFileName("");
    setFileUrl("");
    setOpenPreviewModal(false);
  };
  /**
   * Open preview modal for a given file.
   */
  const handleOpenPreviewModal = (url: string, name: string) => {
    setOpenPreviewModal(true);
    setFileUrl(`${process.env.NEXT_PUBLIC_USER_API_URL}${url}`);
    setFileName(name);
  };
  return files.fileListDto.length === 0 ? (
    <div className="px-3 flex justify-start text-xl font-bold mt-10">No File found for this Tab</div>
  ) : (
    <div className="mt-2">
      {" "}
      {/* reduced gap from tab to table */}
      <div className="overflow-auto w-full">
        <table className="min-w-[800px] w-full border border-[#e5e7eb] rounded-xl shadow-md overflow-hidden">
          <thead className="bg-[#f0f2f8]">
            <tr className="text-sm text-gray-600">
              {viewOnly === false && <th className="px-4 py-4 text-left font-semibold">File</th>}
              <th className="px-4 py-4 text-left font-semibold cursor-pointer" onClick={() => handleSort("name")}>
                Preview {sortColumn === "name" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
              </th>
              <th
                className="px-4 py-4 text-center font-semibold cursor-pointer"
                onClick={() => handleSort("createdAt")}
              >
                Upload Date {sortColumn === "createdAt" ? (sortDirection === "asc" ? "↑" : "↓") : ""}
              </th>
              <th className="px-4 py-4 text-center font-semibold">Size</th>
            </tr>
          </thead>

          <tbody className="text-sm text-gray-800">
            {files?.fileListDto?.map((file, idx) => (
              <tr
                key={file.id}
                className={`border-t border-gray-200 hover:bg-gray-100 transition-colors ${
                  idx % 2 === 0 ? "bg-white" : "bg-gray-50"
                }`}
              >
                {viewOnly === false && (
                  <td className="px-4 py-4">
                    <div className="flex gap-2 items-center">
                      <Tooltip title="Download File" arrow>
                        <FolderDown
                          onClick={() => handleDownloadFile(file.url, file.name)}
                          className="w-5 h-5 cursor-pointer text-green-600 hover:text-green-800"
                        />
                      </Tooltip>
                    </div>
                  </td>
                )}

                <td
                  onClick={() => handleOpenPreviewModal(file.url, file.name)}
                  className="px-4 py-4 text-blue-600 underline cursor-pointer font-medium"
                >
                  {file.name}
                </td>
                <td className="px-4 py-4 text-center">
                  {file.createdAt ? new Date(file.createdAt).toLocaleDateString() : "-"}
                </td>
                <td className="px-4 py-4 text-center">{file.size}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Footer */}
      <div className="mt-6 flex justify-end">
        <TableFooterPagination
          control={control}
          totalPage={totalPages}
          pageIndex={page}
          onPageChange={setPage}
          onPageSizeChange={newSize => {
            setPageSize(newSize);
            setPage(1);
          }}
        />
        <PdfPreview open={openPreviewModal} onClose={handleClosePreviewModel} fileName={fileName} fileUrl={fileUrl} />
      </div>
    </div>
  );
};
