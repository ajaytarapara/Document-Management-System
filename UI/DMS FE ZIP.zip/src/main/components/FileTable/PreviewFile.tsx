import React, { useEffect, useState } from "react";
import { FolderDown, Eye } from "lucide-react";
import { Tooltip, Box, Typography, IconButton, Card, CardContent, Grid } from "@mui/material";
import { useAppDispatch } from "@main/hooks";
import { decryptObject } from "@core/utils";
import { IAPIResponse } from "@core/models";
import { PdfPreview } from "../PdfPreview/PdfPreview";
import { FileListDtos } from "@main/models";
import { getFileList } from "@main/store";
import CryptoJS from "crypto-js";

interface PreviewFileProps {
  token: string | null;
}

export const PreviewFile: React.FC<PreviewFileProps> = ({ token }) => {
  const [files, setFiles] = useState<FileListDtos>({ fileListDto: [], totalCount: 0 });
  const [fileName, setFileName] = useState<string>("");
  const [openPreviewModal, setOpenPreviewModal] = useState(false);
  const [fileUrl, setFileUrl] = useState("");

  const dispatch = useAppDispatch();
  const secretKey = process.env.NEXT_PUBLIC_AES_IV;
  const bytes = CryptoJS.AES.decrypt(token as string, secretKey || "");
  const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  const viewOnly = decryptedData.viewOnly;
  const tabIdList: string[] = decryptedData.fid ? decryptedData.fid.split(",").map((id: string) => id.trim()) : [];

  useEffect(() => {
    const fetchFiles = async (folderIds: string[]) => {
      if (!token || folderIds.length === 0) return null;
      const res = await dispatch(getFileList({ id: folderIds }));
      if (getFileList.fulfilled.match(res)) {
        const encryptedString = res.payload?.data;
        const decrypted: IAPIResponse<FileListDtos> = decryptObject(encryptedString);
        if (decrypted?.data) {
          setFiles(decrypted.data);
        }
      }
    };

    fetchFiles(tabIdList);
  }, [token]);

  const handleDownloadFile = async (fileUrl: string, fileName: string) => {
    const fullUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${fileUrl}`;
    try {
      const response = await fetch(fullUrl, { method: "GET" });
      if (!response.ok) throw new Error("Failed to fetch file");

      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = fileName.endsWith(".pdf") ? fileName : `${fileName}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.log(error);
    }
  };

  const handleClosePreviewModel = () => {
    setFileName("");
    setFileUrl("");
    setOpenPreviewModal(false);
  };

  const handleOpenPreviewModal = (url: string, name: string) => {
    setOpenPreviewModal(true);
    setFileUrl(`${process.env.NEXT_PUBLIC_USER_API_URL}${url}`);
    setFileName(name);
  };

  return (
    <Box className="mt-6">
      <Grid container spacing={3}>
        {files?.fileListDto?.map(file => (
          <Grid size={{ xs: 12, md: 6 }} key={file.id}>
            <Card className="shadow-md hover:shadow-xl transition-all rounded-2xl border border-gray-200">
              <CardContent className="flex items-center justify-between p-4">
                {/* File Info */}
                <Box>
                  <Typography variant="h6" className="font-semibold text-gray-800 text-left mb-3">
                    {file.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Uploaded: {file.createdAt ? new Date(file.createdAt).toLocaleDateString() : "-"}
                  </Typography>
                </Box>

                {/* Actions */}
                <Box className="flex items-center gap-3">
                  <Typography variant="body2" color="text.secondary">
                    Size: {file.size}
                  </Typography>
                  <Tooltip title="Preview File" arrow>
                    <IconButton color="primary" onClick={() => handleOpenPreviewModal(file.url, file.name)}>
                      <Eye className="w-5 h-5" />
                    </IconButton>
                  </Tooltip>

                  {viewOnly === false && (
                    <Tooltip title="Download File" arrow>
                      <IconButton color="success" onClick={() => handleDownloadFile(file.url, file.name)}>
                        <FolderDown className="w-5 h-5" />
                      </IconButton>
                    </Tooltip>
                  )}
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* PDF Preview Modal */}
      <PdfPreview open={openPreviewModal} onClose={handleClosePreviewModel} fileName={fileName} fileUrl={fileUrl} />
    </Box>
  );
};
