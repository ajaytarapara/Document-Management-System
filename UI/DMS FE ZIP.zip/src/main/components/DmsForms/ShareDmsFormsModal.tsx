"use client";
import React from "react";
import { Button, Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { useSelectorAuthState } from "@main/store";
import { decryptObject, getRequiredMessage } from "@core/utils";
import { ILoginResponse, ShareDmsForms, ShareDmsFileModalProps } from "@main/models";
import { IAPIResponse } from "@core/models";
import { Constant } from "@core/constants/Constant";
import { CommonDrawer, CommonTextField } from "@core/components";

export const ShareDmsFileModal: React.FC<ShareDmsFileModalProps> = ({ open, folderId, onClose, onShare, fileName }) => {
  const { loggedInUser } = useSelectorAuthState();
  const decryptedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const userEmail = decryptedUser?.data?.email ?? "";
  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<ShareDmsForms>({
    defaultValues: {
      fromEmail: userEmail,
      toEmail: "",
      toName: "",
      subject: "",
      message: "",
      linkExpiration: 24,
    },
  });

  /**
   * Submits the share folder form.
   * - Validates input using `react-hook-form`.
   * - Invokes `onShare` with the folder ID and form data.
   * - Resets the form and closes the dialog after submission.
   */
  const submit = handleSubmit(async data => {
    if (!folderId) return;
    const response = await onShare(folderId, data);

    if (response?.data) {
      handleCloseDialog();
    }
  });

  /**
   * Validates whether a given email string matches the required comma-separated email pattern.
   *
   * @param email - The email string to validate.
   * @returns `true` if all emails in the string are valid; otherwise, `false`.
   */
  const isValidEmail = (email: string): boolean => {
    return Constant.REGEX.MULTIPLE_EMAIL_WITH_COMMA_SEPRATED_VALUE.test(email.trim());
  };

  /**
   * Handles closing of the share modal dialog.
   * - Closes the dialog using `onClose`.
   * - Resets the form using `reset`.
   */
  const handleCloseDialog = () => {
    onClose();
    reset();
  };

  return (
    <CommonDrawer open={open} onClose={handleCloseDialog} title={fileName}>
      <form onSubmit={submit}>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="fromEmail"
              register={register}
              validation={{
                required: getRequiredMessage("From email"),
                pattern: {
                  value: Constant.REGEX.MULTIPLE_EMAIL_WITH_COMMA_SEPRATED_VALUE,
                  message: Constant.COMMON.EMAIL_INVALID_FORMAT,
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              errors={errors}
              label="From Email"
              disabled
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="toEmail"
              register={register}
              validation={{
                required: getRequiredMessage("To email"),
                validate: {
                  format: (value: string | number | undefined) => {
                    const emails = String(value || "")
                      .split(";")
                      .map(e => e.trim());
                    const allValid = emails.every(email => isValidEmail(email));
                    return allValid || Constant.COMMON.EMAIL_INVALID_FORMAT;
                  },
                  notSelf: (value: string | number | undefined) =>
                    !String(value || "")
                      .split(";")
                      .map(v => v.trim())
                      .includes(userEmail) || Constant.MESSAGE.EMAIL_CANNOT_BE_SAME,
                },
              }}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              errors={errors}
              label="To Email (separate multiple with `;`)"
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="toName"
              register={register}
              validation={{ required: getRequiredMessage("To name") }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="To Name (separate multiple with `;`)"
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="subject"
              register={register}
              validation={{ required: getRequiredMessage("Subject") }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="Subject"
            />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <CommonTextField name="message" register={register} errors={errors} label="Message" multiline rows={3} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <CommonTextField
              name="linkExpiration"
              register={register}
              validation={{
                required: getRequiredMessage("Expiration"),
                min: { value: 1, message: Constant.MESSAGE.MIN_EXPIRATION },
              }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="Link Expiration Time (hrs)"
              type="number"
            />
          </Grid>
        </Grid>
      </form>
      <div className="flex gap-3 justify-end mt-4">
        <Button variant="outlined" onClick={handleCloseDialog}>
          {Constant.COMMON.CANCEL}
        </Button>
        <Button onClick={submit} variant="contained">
          {Constant.COMMON.SHARE}
        </Button>
      </div>
    </CommonDrawer>
  );
};
