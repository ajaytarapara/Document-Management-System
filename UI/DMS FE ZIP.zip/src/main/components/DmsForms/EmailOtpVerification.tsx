"use client";

import { useSearchParams } from "next/navigation";
import { useEffect, useState, FormEvent, ChangeEvent } from "react";
import { useAppDispatch } from "@main/hooks";
import { decryptObject } from "@core/utils";
import { CommonButton, CommonTextField } from "@core/components";
import { Box, Typography, Stack, Dialog, DialogTitle } from "@mui/material";
import { sendOTP, verifyOTPForShare } from "@main/store";
import { ShareStep } from "@core/models";
import { toast } from "react-toastify";
import { Constant } from "@core/constants/Constant";
import { ShareToken, ViewDmsForm } from "../EditableForms";

export function EmailOtpVerification() {
  const searchParams = useSearchParams();
  const shareToken = searchParams.get("shareToken");

  const initialStep = (searchParams.get("step") as ShareStep) || ShareStep.Email;
  const [step, setStep] = useState(initialStep);

  const initialEmail = searchParams.get(ShareStep.Email) || "";
  const [emailInput, setEmailInput] = useState<string>(initialEmail);
  const [otp, setOtp] = useState<string>("");
  const [decodedToken, setDecodedToken] = useState<ShareToken | null>(null);
  const dispatch = useAppDispatch();
  const [timer, setTimer] = useState<number>(300);

  /**
   * Effect: Decodes the shareToken from the URL (if available) and
   * extracts the ShareToken object, storing it in local state.
   */
  useEffect(() => {
    if (typeof shareToken === "string") {
      const decoded = atob(shareToken);
      const parsed: ShareToken = JSON.parse(decoded);
      setDecodedToken(parsed);
    }
  }, [shareToken]);

  /**
   * Effect: Starts a countdown timer when the current step is "otp".
   * Decreases the timer every second until it reaches 0.
   * Cleans up the interval when the effect is re-run or unmounted.
   */
  useEffect(() => {
    if (step === ShareStep.Otp && timer > 0) {
      const interval = setInterval(() => setTimer(t => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [step, timer]);

  /**
   * Converts seconds into MM:SS format for display.
   *
   * @param {number} seconds - Total seconds to format
   * @returns {string} Time string in "MM:SS" format
   */
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  /**
   * Handles email submission:
   * - Prevents default form submission
   * - Validates email against the decoded token
   * - Dispatches OTP request if valid
   * - Switches to OTP step and starts countdown
   * - Persists email in URL for future reloads
   *
   * @param {FormEvent<HTMLFormElement>} e - Form submit event
   */
  const handleEmailSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!decodedToken) return;
    if (emailInput.toLowerCase() !== decodedToken.email.toLowerCase()) {
      toast.error(Constant.MESSAGE.EMAIL_NOT_VARIFY);
      return;
    }
    await dispatch(sendOTP({ email: emailInput }));
    setStep(ShareStep.Otp);
    setTimer(300);

    // persist email in URL
    const url = new URL(window.location.href);
    url.searchParams.set(ShareStep.Email, emailInput);
    window.history.replaceState({}, "", url.toString());
  };

  /**
   * Handles OTP submission:
   * - Prevents default form submission
   * - Dispatches OTP verification with email and entered OTP code
   * - On success, decrypts verification result
   * - If verified, transitions to the "done" step
   *
   * @param {FormEvent<HTMLFormElement>} e - Form submit event
   */
  const handleOtpSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const res = await dispatch(verifyOTPForShare({ email: emailInput, code: otp }));
    if (verifyOTPForShare.fulfilled.match(res)) {
      if (res.payload?.data) {
        const encryptedString = res.payload?.data;
        const decrypted: { verified: boolean } = decryptObject<{ verified: boolean }>(encryptedString);
        if (decrypted?.verified) {
          setStep(ShareStep.Done);
        }
      }
    }
  };

  /**
   * Effect: Syncs the current step into the URL as a query parameter.
   * Useful for restoring state on refresh or sharing links.
   */
  useEffect(() => {
    const url = new URL(window.location.href);
    url.searchParams.set("step", step);
    window.history.replaceState({}, "", url.toString());
  }, [step]);

  return (
    <div>
      {step === ShareStep.Email && (
        <Dialog open={true} onClose={() => {}} fullWidth maxWidth="sm">
          <DialogTitle>
            <Typography className="!text-xl !font-semibold" fontWeight={600}>
              ✉️ Confirm Your Email
            </Typography>
          </DialogTitle>

          <form onSubmit={handleEmailSubmit} className="p-6 pt-0">
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Enter the email used to access the DMS form.
            </Typography>

            <Box minWidth={400}>
              <Stack spacing={2}>
                <CommonTextField
                  name="email"
                  label="Your Email"
                  placeholder="example@email.com"
                  value={emailInput}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setEmailInput(e.target.value)}
                  required
                />

                <CommonButton variant="contained" type="submit" size="large" sx={{ height: 45 }}>
                  Send OTP
                </CommonButton>
              </Stack>
            </Box>
          </form>
        </Dialog>
      )}

      {step === ShareStep.Otp && (
        <Dialog open={true} onClose={() => {}} fullWidth maxWidth="sm">
          <DialogTitle component="div">
            <Typography className="!text-xl !font-semibold" fontWeight={600}>
              🔐 Enter OTP
            </Typography>
          </DialogTitle>

          <form onSubmit={handleOtpSubmit} className="p-6 pt-0">
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Please enter the OTP sent to your email. Time left: {formatTime(timer)}
            </Typography>

            <Box minWidth={400}>
              <Stack spacing={2}>
                <CommonTextField
                  name="otp"
                  label="OTP"
                  placeholder="Enter 6-digit code"
                  value={otp}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setOtp(e.target.value)}
                  required
                  sx={{ "& .MuiOutlinedInput-root": { height: 45 } }}
                />
                <CommonButton type="submit" variant="contained" size="large" sx={{ height: 45 }}>
                  Verify OTP
                </CommonButton>
              </Stack>
            </Box>
          </form>
        </Dialog>
      )}

      {step === ShareStep.Done && decodedToken && <ViewDmsForm decodedToken={decodedToken} />}
    </div>
  );
}
