import React from "react";
import { Dialog, DialogTitle, DialogContent, IconButton } from "@mui/material";
import { X } from "lucide-react";
import { Viewer, Worker } from "@react-pdf-viewer/core";
import { defaultLayoutPlugin } from "@react-pdf-viewer/default-layout";

import "@react-pdf-viewer/core/lib/styles/index.css";
import "@react-pdf-viewer/default-layout/lib/styles/index.css";

interface PdfPreviewProps {
  open: boolean;
  onClose: () => void;
  fileUrl: string;
  fileName: string;
}

export const PdfPreview: React.FC<PdfPreviewProps> = ({ open, onClose, fileUrl, fileName }) => {
  const defaultLayoutPluginInstance = defaultLayoutPlugin();

  /**
   * Handles closing the PDF preview dialog.
   * Calls the `onClose` function passed as a prop.
   */
  const handleClose = () => {
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} fullWidth maxWidth="lg">
      <DialogTitle className="flex justify-between items-center">
        <span>{fileName}</span>
        <IconButton onClick={handleClose}>
          <X />
        </IconButton>
      </DialogTitle>
      <DialogContent style={{ height: "80vh", position: "relative" }}>
        {fileUrl && (
          <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
            <Viewer fileUrl={fileUrl} plugins={[defaultLayoutPluginInstance]} />
          </Worker>
        )}
      </DialogContent>
    </Dialog>
  );
};
