import { IPaginatedResponse } from "@core/models";
import { getReadableBorderColor, getTextColorForBackground, handleThunkWithDecrypt } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import {
  IBatchShareFileRequest,
  IBatchShareTabAndFileResponse,
  IFolderListResponse,
  IFolderTabListResponse,
} from "@main/models";
import {
  getAllBatchFolderList,
  getAllBatchFolderTabList,
  getFileByTabId,
  setSelectedIdsForTab,
  toggleFileForTab,
  useSelectorBatchShareState,
} from "@main/store";
import { Box, Checkbox, FormControl, MenuItem, Pagination, Select, SelectChangeEvent } from "@mui/material";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { PdfPreview } from "../PdfPreview/PdfPreview";
import React from "react";
import { BatchShareDrawer } from "./BatchShareDrawer";
import { SHARE_TYPE } from "@core/constants/Constant";

export const BatchShare = () => {
  const [selectedFolderId, setSelectedFolderId] = useState<string>("");
  const [folderList, setFolderList] = useState<IFolderListResponse[]>([]);
  const [folderTabList, setFolderTabList] = useState<IFolderTabListResponse[]>([]);
  const [selectedTab, setSelectedTab] = useState<string>("");
  const [request, setRequest] = useState<IBatchShareFileRequest>({
    pageNumber: 1,
    pageSize: 10,
    sortBy: "createdAt",
    sortDirection: "desc",
    tabId: "",
  });
  const [files, setFiles] = useState<IBatchShareTabAndFileResponse[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [fileName, setFileName] = useState<string>("");
  const [openPreviewModal, setOpenPreviewModal] = useState<boolean>(false);
  const [fileUrl, setFileUrl] = useState<string>("");
  const [showShareDrawer, setShowShareDrawer] = useState<boolean>(false);
  const router = useRouter();
  const dispatch = useAppDispatch();
  const { selectedFilesByFolderAndTab } = useSelectorBatchShareState();
  const selectedFiles = selectedFilesByFolderAndTab[selectedFolderId]?.[selectedTab] || [];
  const isAllSelected = files.length > 0 && selectedFiles.length === files.length;
  const allSelectedIds = Object.values(selectedFilesByFolderAndTab).flatMap(folder => Object.values(folder).flat());

  /**
   * Handles folder selection change.
   * - Updates the state with the selected folder ID.
   *
   * @param id - The ID of the selected folder.
   */
  const onChangeSelect = (id: string) => {
    setSelectedFolderId(id);
    handleFolderChange(id);
  };

  /**
   * Fetch file list for the current tab and update table state.
   */
  const fetchFiles = async (payload: IBatchShareFileRequest) => {
    const response = await handleThunkWithDecrypt<
      IPaginatedResponse<IBatchShareTabAndFileResponse>,
      IBatchShareFileRequest
    >(dispatch, getFileByTabId, payload);
    if (response.data) {
      setFiles(response.data.items);
      setTotalCount(response.data.totalCount);
    }
  };

  /**
   * Handles the folder selection change event.
   *
   * - If a valid folder ID is selected, fetches the list of tabs for that folder.
   * - Updates the `folderTabList` state with the response data.
   * - Clears the `folderTabList` if no folder is selected.
   * - Resets the `tabId` form value to ensure a fresh selection.
   *
   * @param folderId - The selected folder ID, or an empty string if no folder is selected.
   */
  const handleFolderChange = async (folderId: string | "") => {
    if (folderId !== "") {
      const response = await handleThunkWithDecrypt<IFolderTabListResponse[], string>(
        dispatch,
        getAllBatchFolderTabList,
        folderId
      );
      if (response?.data) {
        setFolderTabList(response.data);
        setSelectedTab(response.data[0].id);
        setRequest(prev => ({
          ...prev,
          tabId: response.data ? response.data[0].id : "",
        }));
        const payload: IBatchShareFileRequest = {
          ...request,
          tabId: response.data[0].id,
        };
        fetchFiles(payload);
      }
    } else {
      setFolderTabList([]);
    }
  };

  /**
   * Fetches the list of all active folders.
   *
   * - Dispatches the `getAllFolderList` thunk through `handleThunkWithDecrypt`.
   * - Decrypts the API response into a list of `IFolderListResponse` objects.
   * - Updates the local `folderList` state if data is returned.
   */
  const getAllActiveFolderList = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IFolderListResponse[]>(dispatch, getAllBatchFolderList);
    if (response?.data) {
      setFolderList(response.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getAllActiveFolderList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Open preview modal for a given file.
   */
  const handleOpenPreviewModal = (url: string, name: string) => {
    setOpenPreviewModal(true);
    setFileUrl(`${process.env.NEXT_PUBLIC_USER_API_URL}${url}`);
    setFileName(name);
  };

  /**
   * Close preview modal and reset file state.
   */
  const handleClosePreviewModel = () => {
    setFileName("");
    setFileUrl("");
    setOpenPreviewModal(false);
  };

  /**
   * Handle "select all" checkbox click.
   */
  const handleSelectAllFiles = () => {
    if (isAllSelected) {
      dispatch(setSelectedIdsForTab({ folderId: selectedFolderId, tabId: selectedTab, files: [] }));
    } else {
      dispatch(setSelectedIdsForTab({ folderId: selectedFolderId, tabId: selectedTab, files: files }));
    }
  };

  /**
   * Handle selecting or deselecting a row by file ID.
   */
  const handleSelectRow = (file: IBatchShareTabAndFileResponse) => {
    dispatch(toggleFileForTab({ folderId: selectedFolderId, tabId: selectedTab, file: file }));
  };

  const totalPages = Math.ceil(totalCount / request.pageSize);

  useEffect(() => {
    if (selectedTab !== "") fetchFiles(request);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request.pageNumber]);

  /**
   * Close the drawer.
   */
  const handleCloseShareDrawer = () => {
    setShowShareDrawer(false);
  };
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex justify-between items-center mb-6">
        <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">Batch Share</h4>
        <button
          onClick={() => router.back()}
          className="px-4 py-2 text-sm font-medium text-white bg-[#7E57C2] hover:bg-[#6C4FB3] rounded-md shadow cursor-pointer"
        >
          Back
        </button>
      </div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-6 bg-white shadow-sm rounded-md">
        <FormControl size="small" className="w-full sm:w-[250px]">
          <Select
            value={selectedFolderId}
            onChange={(event: SelectChangeEvent<string | "">) => {
              onChangeSelect(event.target.value === "" ? "" : event.target.value);
            }}
            displayEmpty
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 188,
                  overflowY: "scroll",
                  "&::-webkit-scrollbar": {
                    display: "none",
                  },
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                },
              },
            }}
          >
            <MenuItem value="">
              <em>Please select folder</em>
            </MenuItem>
            {folderList.map(folder => (
              <MenuItem key={folder.id} value={folder.id}>
                {folder.folderName}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <button
          type="submit"
          disabled={allSelectedIds.length === 0}
          onClick={() => setShowShareDrawer(true)}
          className={`
            w-full sm:w-auto 
            !rounded-md !px-6 !py-2 
            text-white transition
            ${allSelectedIds.length === 0 ? "bg-gray-400 cursor-not-allowed" : "bg-[#7E57C2] hover:bg-[#6C4FB3] cursor-pointer"}
          `}
        >
          Share
        </button>
      </div>
      {selectedFolderId !== "" && (
        <div className="mt-6 p-6 bg-white shadow-sm rounded-md">
          <Box
            className="flex whitespace-nowrap"
            sx={{
              "&::-webkit-scrollbar-track": {
                backgroundColor: "transparent",
              },
              "&::-webkit-scrollbar-thumb": {
                backgroundColor: "#ccc",
                borderRadius: "4px",
              },
            }}
          >
            {folderTabList.map((tab, idx) => {
              const isSelected = tab.id === selectedTab;
              const textColor = getTextColorForBackground(tab.tabColor);
              return (
                <Box
                  key={idx}
                  className="min-w-[120px] max-w-[160px] px-4 py-3 text-sm font-semibold text-center truncate cursor-pointer transition-all duration-300 ease-in-out"
                  style={{
                    backgroundColor: tab.tabColor,
                    color: textColor,
                    borderRadius: "12px 12px 0 0",
                    opacity: isSelected ? 1 : 0.6,
                    borderBottom: isSelected
                      ? `4px solid ${getReadableBorderColor(tab.tabColor)}`
                      : "4px solid transparent",
                    boxShadow: isSelected ? "0 4px 10px rgba(0,0,0,0.25)" : "none",
                    transform: isSelected ? "translateY(-2px)" : "none",
                  }}
                  title={tab.tabName}
                  onClick={() => {
                    setSelectedTab(tab.id);
                    setRequest(prev => ({
                      ...prev,
                      tabId: tab.id,
                    }));
                    const payload: IBatchShareFileRequest = {
                      ...request,
                      tabId: tab.id,
                    };
                    fetchFiles(payload);
                  }}
                >
                  {tab.tabName}
                </Box>
              );
            })}
          </Box>
          {files.length > 0 && (
            <React.Fragment>
              <div className="overflow-auto w-full">
                <table className="min-w-[800px] w-full border border-[#dee2e6]">
                  <thead className="bg-[#f5f6f9]">
                    <tr className="text-sm text-[#888] whitespace-nowrap">
                      <th className="px-3 text-left">
                        <Checkbox checked={isAllSelected} onChange={handleSelectAllFiles} />
                      </th>
                      <th className="px-3 text-center cursor-pointer">Preview</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm text-gray-800">
                    {files.map(file => (
                      <tr key={file.id} className="border-t border-[#dee2e6]">
                        <td className="px-3 text-left">
                          <Checkbox
                            checked={selectedFiles.map(f => f.id).includes(file.id)}
                            onChange={() => {
                              handleSelectRow(file);
                            }}
                          />
                        </td>
                        <td
                          onClick={() => {
                            handleOpenPreviewModal(file.url, file.name);
                          }}
                          className="px-3 text-center text-blue-600 underline cursor-pointer"
                        >
                          {file.name}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 flex justify-end">
                <Pagination
                  count={totalPages}
                  page={request.pageNumber}
                  onChange={(_, page) => {
                    setRequest(prev => ({
                      ...prev,
                      pageNumber: page,
                    }));
                  }}
                  color="primary"
                  variant="outlined"
                  shape="rounded"
                />
              </div>
            </React.Fragment>
          )}
          {files.length === 0 && (
            <div className="bg-[#f5f6f9] p-4 flex justify-center items-center rounded-bl-[4px] rounded-br-[4px] rounded-tr-[4px]">
              No files available!
            </div>
          )}
        </div>
      )}
      {openPreviewModal && (
        <PdfPreview open={openPreviewModal} onClose={handleClosePreviewModel} fileName={fileName} fileUrl={fileUrl} />
      )}
      {showShareDrawer && (
        <BatchShareDrawer open={showShareDrawer} onClose={handleCloseShareDrawer} type={SHARE_TYPE.FILE} />
      )}
    </div>
  );
};
