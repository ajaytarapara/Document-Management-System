import { CommonCheckbox, CommonDrawer, CommonTextField } from "@core/components";
import { IAPIResponse } from "@core/models";
import { decryptObject, handleThunkWithDecrypt } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import { IBatchShareRequestDto, IBatchShareTabAndFileResponse, ILoginResponse } from "@main/models";
import { batchShareFiles, useSelectorAuthState, useSelectorBatchShareState } from "@main/store";
import { Button, Grid } from "@mui/material";
import { useEffect } from "react";
import { useForm } from "react-hook-form";

interface BatchShareDrawerProps {
  open: boolean;
  onClose: () => void;
  type: string;
}

export const BatchShareDrawer: React.FC<BatchShareDrawerProps> = ({ open, onClose, type }) => {
  const { selectedFilesByFolderAndTab } = useSelectorBatchShareState();
  const files: IBatchShareTabAndFileResponse[] = Object.values(selectedFilesByFolderAndTab).flatMap(folder =>
    Object.values(folder).flat()
  );
  const { loggedInUser } = useSelectorAuthState();
  const decryptedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const userEmail = decryptedUser?.data?.email ?? "";
  const dispatch = useAppDispatch();

  const {
    control,
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<IBatchShareRequestDto>({
    defaultValues: {
      fromEmail: userEmail,
      toEmail: "",
      toName: "",
      subject: "",
      message: "",
      linkExpiration: 24,
      viewOnly: false,
      type: type,
    },
  });

  useEffect(() => {
    if (open) {
      reset({
        fromEmail: userEmail,
        toEmail: "",
        toName: "",
        subject: "",
        message: "",
        linkExpiration: 24,
        viewOnly: false,
        type: type,
      });
    }
  }, [open, userEmail, type, reset]);

  /**
   * Handles the share form submission.
   * - Returns early if `folderId` is not available.
   * - If multiple selection is enabled, assigns `folderId` as an array to `EntityIds`.
   * - Otherwise, sets the share `type` on the form data.
   * - Calls the `onShare` handler with the folder ID and prepared data.
   * - Closes the modal/dialog after submission.
   */
  const submit = handleSubmit(async data => {
    if (files.length === 0) return;
    data.fileIds = files.map(f => f.id) as string[];
    const response = await handleThunkWithDecrypt(dispatch, batchShareFiles, data);
    if (response.isSuccessful) onClose();
  });

  return (
    <CommonDrawer open={open} onClose={onClose} title="Batch Share">
      <div className="overflow-auto w-full">
        <div className="flex flex-wrap gap-2 text-sm text-gray-800">
          {files.map(file => (
            <span key={file.id} className="px-3 py-1 bg-gray-100 rounded-md border border-gray-300">
              {file.name}
            </span>
          ))}
        </div>
      </div>
      <div className="mt-4 p-4 border rounded-md border-[#adb5bd]">
        <form onSubmit={submit}>
          <input type="hidden" value={type} {...register("type")} />
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="fromEmail"
                register={register}
                validation={{
                  required: "From Email is required",
                  pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" },
                }}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                errors={errors}
                label="From Email"
                disabled
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="toEmail"
                register={register}
                validation={{
                  required: "To Email is required",
                  pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" },
                  validate: value => value !== userEmail || "From Email and To Email cannot be the same",
                }}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                errors={errors}
                label="To Email (separate multiple with `;`)"
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="toName"
                register={register}
                validation={{ required: "To Name is required" }}
                errors={errors}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                label="To Name (separate multiple with `;`)"
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="subject"
                register={register}
                validation={{ required: "Subject is required" }}
                errors={errors}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                label="Subject"
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <CommonTextField name="message" register={register} errors={errors} label="Message" multiline rows={3} />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <CommonTextField
                name="linkExpiration"
                register={register}
                validation={{
                  required: "Expiration is required",
                  min: { value: 1, message: "Must be at least 1 hour" },
                }}
                errors={errors}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                label="Link Expiration Time (hrs)"
                type="number"
              />
            </Grid>
            <Grid size={{ xs: 12 }}>
              <CommonCheckbox<IBatchShareRequestDto>
                label="View Only (Prevent Download)"
                control={control}
                name="viewOnly"
              />
            </Grid>
          </Grid>
          <div className="flex justify-end gap-3 mt-4">
            <Button onClick={onClose} variant="outlined">
              Cancel
            </Button>
            <Button type="submit" variant="contained">
              Share
            </Button>
          </div>
        </form>
      </div>
    </CommonDrawer>
  );
};
