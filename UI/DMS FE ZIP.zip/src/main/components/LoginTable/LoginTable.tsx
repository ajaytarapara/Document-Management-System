"use client";

import { IUserLoginSummaryVM } from "@main/models";
import { Eye } from "lucide-react";
import moment from "moment";

type Props = {
  data: IUserLoginSummaryVM[];
  handleActionButtonClick: (record: IUserLoginSummaryVM) => void;
};

export const LoginTable = ({ data, handleActionButtonClick }: Props) => {
  return (
    <div className="shadow-sm overflow-x-auto">
      <table className="min-w-full table-auto border-collapse">
        <thead className="bg-[#e1dcef]">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">Date</th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">Day</th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">Login Count</th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-[#00092A] rounded-tr-md">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {data.map((record, index) => (
            <tr key={index} className="hover:bg-gray-50 transition">
              <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                {moment(record.date).format("DD-MM-YYYY")}
              </td>
              <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">{record.day}</td>
              <td className="px-4 py-3 text-sm text-gray-800">{record.loginCount}</td>
              <td className="px-4 py-3 text-center">
                <Eye
                  className="w-5 h-5 text-[#7E57C2] cursor-pointer inline-block"
                  onClick={() => handleActionButtonClick(record)}
                />
              </td>
            </tr>
          ))}
          {data.length === 0 && (
            <tr>
              <td colSpan={4} className="px-4 py-6 text-center text-sm text-gray-500">
                No login records found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
