import React, { useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Select, MenuItem, SelectChangeEvent } from "@mui/material";
import { X } from "lucide-react";

interface AddToTabFileModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const AddToTabModal: React.FC<AddToTabFileModalProps> = ({ open, onClose, onConfirm }) => {
  const [selectedTabId, setSelectedTabId] = useState<number | "">("");
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="xs"
      PaperProps={{
        className: "rounded-2xl",
      }}
    >
      <DialogTitle className="!p-4 border-b border-[#dee2e6]">
        <div className="flex items-center justify-between">
          <h5 className="font-medium text-xl text-black">Tab</h5>
          <X className="text-gray-500 cursor-pointer" onClick={onClose} />
        </div>
      </DialogTitle>
      <DialogContent className="!p-4">
        <div className="w-full">
          <h6 className="font-semibold text-sm text-black tracking-wide mb-1">Dividers List</h6>
          <Select
            fullWidth
            value={selectedTabId}
            onChange={(event: SelectChangeEvent<number | "">) =>
              setSelectedTabId(event.target.value === "" ? "" : Number(event.target.value))
            }
            displayEmpty
            MenuProps={{
              PaperProps: {
                sx: {
                  maxHeight: 188,
                  overflowY: "scroll",
                  "&::-webkit-scrollbar": {
                    display: "none",
                  },
                  scrollbarWidth: "none",
                  msOverflowStyle: "none",
                },
              },
            }}
          >
            <MenuItem value="">
              <em>Select Tab</em>
            </MenuItem>
            {Array.from({ length: 12 }, (_, i) => (
              <MenuItem key={i + 1} value={(i + 1).toString()}>
                {i + 1}
              </MenuItem>
            ))}
          </Select>
        </div>
      </DialogContent>
      <DialogActions className="flex justify-center gap-1 border-t border-[#dee2e6] !p-4">
        <button
          onClick={onClose}
          className="!rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
        >
          Close
        </button>
        <button
          onClick={onConfirm}
          className="!rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
        >
          Save
        </button>
      </DialogActions>
    </Dialog>
  );
};
