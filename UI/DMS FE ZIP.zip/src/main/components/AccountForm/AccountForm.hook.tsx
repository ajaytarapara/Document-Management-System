import { useForm } from "react-hook-form";
import { useCallback, useEffect, useState } from "react";
import { IAccountForm, IAccountUser } from "@main/models";
import Cookies from "js-cookie";
import { decodeJwt, handleThunkWithDecrypt, mapRoleIdToEnum } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import { getAccountDetail, setUserName, updateAccountDetail } from "@main/store";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { useRouter } from "next/navigation";

export const useAccountForm = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const dispatch = useAppDispatch();
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
    reset,
    watch,
  } = useForm<IAccountForm>();
  const watchedLoginType = watch("loginType");
  const onSubmit = async (data: IAccountForm) => {
    setIsSubmitting(true);
    const response = await handleThunkWithDecrypt(dispatch, updateAccountDetail, data);
    if (response.isSuccessful) {
      dispatch(setUserName(data.userName));
    }
    setIsSubmitting(false);
  };

  const getAccountDetails = useCallback(async () => {
    const token = Cookies.get("token");
    const payload = decodeJwt(token ?? "");
    const userId = payload?.userId;
    if (userId !== undefined) {
      const response = await handleThunkWithDecrypt<IAccountUser, number>(
        dispatch,
        getAccountDetail,
        parseInt(userId, 10)
      );
      if (response?.data) {
        const accountData = response.data;
        const formValues: IAccountForm = {
          firstName: accountData.firstName,
          lastName: accountData.lastName,
          role: mapRoleIdToEnum(accountData.role),
          email: accountData.email,
          userName: accountData.userName,
          phoneNumber: accountData.phoneNumber,
          postalCode: String(accountData.postalCode),
          address: accountData.address,
          city: accountData.city ?? "",
          id: parseInt(userId, 10),
          loginType: accountData.loginType,
        };
        reset(formValues);
      }
    }
  }, [dispatch, reset]);

  useEffect(() => {
    getAccountDetails();
  }, [getAccountDetails]);

  const navigateToChangePass = () => {
    router.push(ROUTES.ADMIN.CHANGE_PASSWORD);
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    isSubmitting,
    getValues,
    navigateToChangePass,
    watchedLoginType,
  };
};
