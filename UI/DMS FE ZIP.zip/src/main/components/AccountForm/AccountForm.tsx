import { Card, CardContent, CardHeader } from "@mui/material";
import { CommonButton, CommonTextField } from "@core/components";
import { useAccountForm } from "./AccountForm.hook";
import { getRequiredMessage } from "@core/utils";
import { Constant } from "@core/constants/Constant";
import { LoginTypeEnum } from "@core/models";

export const AccountForm = () => {
  const { register, handleSubmit, errors, onSubmit, getValues, navigateToChangePass, watchedLoginType } =
    useAccountForm();
  return (
    <>
      <div className="flex flex-wrap justify-between">
        <h1 className="text-lg sm:text-2xl font-semibold text-foreground mb-4">
          My Account Information - {getValues("userName")}
        </h1>
        <CommonButton
          type="button"
          color="primary"
          className="!text-sm sm:!text-md md:!text-lg !font-semibold"
          variant="contained"
          onClick={navigateToChangePass}
        >
          Change Password
        </CommonButton>
      </div>
      <div className="flex justify-end gap-4 pt-4"></div>
      <form noValidate onSubmit={handleSubmit(onSubmit)}>
        <Card className="mb-8 p-2">
          <CardHeader title={<h2 className="text-lg sm:text-xl border-b pb-1 font-bold">Account Information</h2>} />
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <CommonTextField
                label="First Name"
                {...register("firstName", {
                  required: getRequiredMessage("First Name"),
                  maxLength: {
                    value: Constant.LENGTH.FIRST_NAME_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("First Name", Constant.LENGTH.FIRST_NAME_MAX),
                  },
                })}
                errors={errors}
                required
              />
              <CommonTextField
                label="Last Name"
                {...register("lastName", {
                  required: getRequiredMessage("Last Name"),
                  maxLength: {
                    value: Constant.LENGTH.LAST_NAME_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("Last Name", Constant.LENGTH.LAST_NAME_MAX),
                  },
                })}
                errors={errors}
                required
              />
              <CommonTextField
                label="Email"
                disabled={watchedLoginType == LoginTypeEnum.SSO || watchedLoginType == LoginTypeEnum.BOTH}
                {...register("email", {
                  required: getRequiredMessage("Email"),
                  maxLength: {
                    value: Constant.LENGTH.EMAIL_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("Email", Constant.LENGTH.EMAIL_MAX),
                  },
                  pattern: { value: Constant.REGEX.EMAIL_REGEX, message: Constant.MESSAGE.INVALID_EMAIL },
                })}
                errors={errors}
                required
              />
              <CommonTextField label="Role" {...register("role")} errors={errors} required disabled />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <CommonTextField
                label="User Name"
                disabled
                {...register("userName", {
                  required: getRequiredMessage("User Name"),
                  pattern: { value: Constant.REGEX.USERNAME_REGEX, message: "Invalid username format." },
                  maxLength: {
                    value: Constant.LENGTH.USER_NAME_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("User Name", Constant.LENGTH.USER_NAME_MAX),
                  },
                })}
                errors={errors}
                required
              />
              <CommonTextField
                label="Phone Number"
                {...register("phoneNumber", {
                  required: getRequiredMessage("Phone Number"),
                  pattern: { value: Constant.REGEX.PHONE_REGEX, message: Constant.MESSAGE.INVALID_PHONE },
                })}
                errors={errors}
                required
              />
              <CommonTextField
                label="Address"
                {...register("address", {
                  required: getRequiredMessage("Address"),
                  maxLength: {
                    value: Constant.LENGTH.ADDRESS_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("Address", Constant.LENGTH.ADDRESS_MAX),
                  },
                })}
                errors={errors}
                required
              />
              <CommonTextField
                label="Postal Code"
                {...register("postalCode", {
                  required: getRequiredMessage("Postal Code"),
                  pattern: {
                    value: Constant.REGEX.POSTAL_CODE_REGEX,
                    message: Constant.MESSAGE.INVALID_POSTAL_CODE,
                  },
                  validate: val => {
                    const num = Number(val);
                    return (num >= 100000 && num <= 999999) || "Postal Code must be between 100000 and 999999.";
                  },
                })}
                errors={errors}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <CommonTextField
                label="City"
                {...register("city", {
                  maxLength: {
                    value: Constant.LENGTH.CITY_MAX,
                    message: Constant.MESSAGE.MAX_LENGTH("City", Constant.LENGTH.CITY_MAX),
                  },
                })}
                errors={errors}
              />
              <CommonTextField label="LoginType" {...register("loginType")} errors={errors} required disabled />
            </div>

            <div className="flex justify-end gap-4 pt-4">
              <CommonButton
                type="submit"
                color="primary"
                className="!max-h-[48px] !text-sm sm:!text-md !font-semibold"
                variant="contained"
              >
                Save My Account Changes
              </CommonButton>
            </div>
          </CardContent>
        </Card>
      </form>
    </>
  );
};
