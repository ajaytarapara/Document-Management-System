import { handleThunkWithDecrypt } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import { IImpersonate, ISubUser } from "@main/models";
import { impersonateUser, setCurrentUser, useSelectorAuthState } from "@main/store";
import Cookies from "js-cookie";

export const UseSubUserBoxHeader = () => {
  const dispatch = useAppDispatch();
  const { currentUser } = useSelectorAuthState();
  const ImpersonateUser = async (user: ISubUser) => {
    const decryptedResponse = await handleThunkWithDecrypt<IImpersonate, { subUserId: number }>(
      dispatch,
      impersonateUser,
      {
        subUserId: user.id,
      }
    );
    Cookies.set("token", decryptedResponse?.data?.token || "");
    dispatch(setCurrentUser(user));
    window.location.reload();
  };

  return { ImpersonateUser, currentUser };
};
