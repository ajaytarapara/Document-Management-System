import React from "react";
import { Dialog, DialogTitle, DialogContent, DialogActions, Typography } from "@mui/material";

interface ConfirmDeleteModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
}

export const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  open,
  onClose,
  onConfirm,
  title = "Delete Confirmation",
  message = "Are you sure you want to delete this item?",
}) => {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="xs"
      PaperProps={{
        className: "rounded-2xl",
      }}
    >
      <DialogTitle className="!p-4 border-b border-[#dee2e6] !mb-0">
        <div className="flex items-center justify-between">
          <h5 className="font-medium text-xl text-black !mb-0">{title}</h5>
        </div>
      </DialogTitle>
      <DialogContent className="!p-4">
        <Typography className="text-center text-gray-700">{message}</Typography>
      </DialogContent>
      <DialogActions className="flex flex-col sm:flex-row justify-center gap-2 sm:gap-1 border-t border-[#dee2e6] !p-4">
        <button
          onClick={onClose}
          className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-red-600 text-white hover:bg-red-700 transition"
        >
          Delete
        </button>
      </DialogActions>
    </Dialog>
  );
};
