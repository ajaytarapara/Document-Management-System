import { useCallback, useEffect, useState } from "react";
import {
  FolderListResponseVM,
  IAddFolderTabRequestVM,
  IAddTemplateTabRequestVM,
  IUserTemplate,
  IUserTemplateTabs,
  IUserTemplateTabsUI,
} from "@main/models";
import { decryptObject, handleThunkWithDecrypt } from "@core/utils";
import { useAppDispatch } from "@main/hooks";
import {
  addFolderTabs,
  addUserTemplateTabs,
  getAllUserTemplateAvailableToAdd,
  getFoldersAvailable,
  getMaxTabLimit,
  getUserTemplateTabs,
} from "@main/store";
import { useRouter } from "next/navigation";

export const UseAddTemplateTabForm = () => {
  const dispatch = useAppDispatch();
  const [userTemplate, setUserTemplate] = useState<IUserTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [tabs, setTabs] = useState<IUserTemplateTabsUI[]>([]);
  const [newTab, setNewTab] = useState<Omit<IUserTemplateTabsUI, "id">>({
    name: "",
    color: "#000000",
    isLock: false,
  });
  const [maxLimit, setMaxLimit] = useState<number>(0);
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const steps = [
    { id: 1, title: "Step 1", description: "Choose template" },
    { id: 2, title: "Step 2", description: "Add tabs" },
    { id: 3, title: "Step 3", description: "Pick folder" },
  ];
  const [data, setData] = useState<FolderListResponseVM[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const getUserTemplate = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IUserTemplate[], null>(
      dispatch,
      getAllUserTemplateAvailableToAdd,
      null
    );
    if (response?.data) {
      setUserTemplate(response.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getUserTemplate();
  }, [getUserTemplate]);

  const getTemplateTabs = async (id: string) => {
    const response = await handleThunkWithDecrypt<IUserTemplateTabs[], string>(dispatch, getUserTemplateTabs, id);
    if (response?.data) {
      const tabState: IUserTemplateTabsUI[] = response?.data.map(tab => ({
        id: tab.id,
        name: tab.name,
        color: tab.color,
        isLock: tab.isLock,
        readonly: true,
        editing: false,
      }));
      setTabs(tabState);
    }
  };

  const handleAddTab = () => {
    if (!newTab.name.trim()) return;
    const newId = Date.now().toString();
    const newTabEntry: IUserTemplateTabsUI = {
      ...newTab,
      id: newId,
      editing: false,
      readonly: false,
    };
    setTabs(prev => [...prev, newTabEntry]);
    setNewTab({ name: "", color: "#000000", isLock: false });
  };

  const toggleEdit = (id: string) => {
    setTabs(prev => prev.map(tab => (tab.id === id && !tab.readonly ? { ...tab, editing: !tab.editing } : tab)));
  };

  const saveTab = (id: string) => {
    setTabs(prev => prev.map(tab => (tab.id === id ? { ...tab, editing: false } : tab)));
  };

  const updateTab = <K extends keyof IUserTemplateTabsUI>(id: string, field: K, value: IUserTemplateTabsUI[K]) => {
    setTabs(prev => prev.map(tab => (tab.id === id ? { ...tab, [field]: value } : tab)));
  };

  const deleteTab = (id: string) => {
    setTabs(prev => prev.filter(tab => tab.id !== id));
  };

  useEffect(() => {
    const fetchTabLimit = async () => {
      const response = await dispatch(getMaxTabLimit());
      if (getMaxTabLimit.fulfilled.match(response)) {
        if (response.payload?.data) {
          const encryptedString = response.payload?.data;
          const decrypted: { maxTabLimit: number } = decryptObject<{ maxTabLimit: number }>(encryptedString);
          if (decrypted?.maxTabLimit) {
            setMaxLimit(decrypted.maxTabLimit);
          }
        }
      }
    };
    fetchTabLimit();
  }, [dispatch]);

  useEffect(() => {
    const loadTabs = async () => {
      if (currentStep === 2 && selectedTemplate !== "" && tabs.length === 0) {
        await getTemplateTabs(selectedTemplate);
      }
    };
    loadTabs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep, selectedTemplate]);

  const handleUpdateTemplateSubmit = async () => {
    const newTabs = tabs.filter(tab => !tab.readonly);
    if (newTabs.length === 0 || selectedTemplate === "") return;
    const payload: IAddTemplateTabRequestVM = {
      templateId: selectedTemplate,
      templateTabs: newTabs.map(tab => ({
        templateId: selectedTemplate,
        tabName: tab.name.trim(),
        color: tab.color,
        isLock: tab.isLock ?? false,
      })),
    };

    const response = await handleThunkWithDecrypt<null, IAddTemplateTabRequestVM>(
      dispatch,
      addUserTemplateTabs,
      payload
    );

    if (response?.isSuccessful) {
      setTabs(prev => prev.filter(tab => tab.readonly));
      setNewTab({ name: "", color: "#000000", isLock: false });
      router.back();
    }
  };

  const handleAddFolderTabs = async () => {
    const newTabs = tabs.filter(tab => !tab.readonly);
    if (newTabs.length === 0 || selectedTemplate === "") return;
    const payload: IAddFolderTabRequestVM = {
      selectedFolder: selectedIds,
      templateTabs: newTabs.map(tab => ({
        templateId: selectedTemplate,
        tabName: tab.name.trim(),
        color: tab.color,
        isLock: tab.isLock ?? false,
      })),
    };

    const response = await handleThunkWithDecrypt<null, IAddFolderTabRequestVM>(dispatch, addFolderTabs, payload);

    if (response?.isSuccessful) {
      router.back();
    }
  };

  const isAllSelected = data.length > 0 && selectedIds.length === data.length;

  const toggleAll = () => {
    if (isAllSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(data.map(row => row.id));
    }
  };

  const toggleOne = (id: number) => {
    setSelectedIds(prev => (prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]));
  };

  const nextStep = () => {
    if (currentStep === 1 && selectedTemplate === "") {
      alert("Please select a template before continuing.");
      return;
    }

    if (currentStep === 2) {
      const hasNewTabs = tabs.some(tab => !tab.readonly);
      const hasEditingTabs = tabs.some(tab => tab.editing);
      const hasDuplicateName = new Set(tabs.map(t => t.name.trim().toLowerCase())).size !== tabs.length;
      const hasDuplicateColor = new Set(tabs.map(t => t.color)).size !== tabs.length;

      if (!hasNewTabs || hasEditingTabs || hasDuplicateName || hasDuplicateColor) {
        alert("Please add at least one valid tab without duplicates and finish editing before continuing.");
        return;
      }
    }

    if (currentStep < steps.length) {
      setCompletedSteps(prev => (prev.includes(currentStep) ? prev : [...prev, currentStep]));
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const getFolderList = async () => {
    const response = await handleThunkWithDecrypt<FolderListResponseVM[], { templateId: string; newTabCount: number }>(
      dispatch,
      getFoldersAvailable,
      { templateId: selectedTemplate, newTabCount: tabs.filter(tab => !tab.readonly).length }
    );
    if (response?.data) {
      setData(response?.data);
    }
  };

  useEffect(() => {
    if (currentStep === 3) {
      getFolderList();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep]);

  return {
    userTemplate,
    selectedTemplate,
    setSelectedTemplate,
    handleAddTab,
    tabs,
    newTab,
    setNewTab,
    toggleEdit,
    saveTab,
    updateTab,
    deleteTab,
    maxLimit,
    handleUpdateTemplateSubmit,
    router,
    data,
    selectedIds,
    toggleAll,
    toggleOne,
    isAllSelected,
    steps,
    currentStep,
    completedSteps,
    nextStep,
    prevStep,
    getTemplateTabs,
    handleAddFolderTabs,
  };
};
