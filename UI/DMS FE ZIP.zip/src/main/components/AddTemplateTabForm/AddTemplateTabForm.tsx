import { Card, Checkbox, styled } from "@mui/material";
import { UseAddTemplateTabForm } from "./AddTemplateTabForm.hook";
import { Constant } from "@core/constants/Constant";
import React, { useMemo, useState } from "react";
import { IUserTemplateTabs } from "@main/models";
import { FolderPlus, Pencil, Plus, Save, Trash2 } from "lucide-react";
import { StyledButton } from "./AddTemplateTabForm.styled";
import { StepIndicator } from "../AddStepsComponents/StepIndicator";
import { Step1TemplateSelection } from "../AddStepsComponents/Step1TemplateSelection";
import { Step2AddTabs } from "../AddStepsComponents/Step2AddTabs";
import { Step3SelectFolder } from "../AddStepsComponents/Step3SelectFolder";

export type EditableTab = IUserTemplateTabs & {
  editing?: boolean;
  readonly?: boolean;
};

type Props = {
  tabs: EditableTab[];
  onEdit: (id: string) => void;
  onSave: (id: string) => void;
  onChange: <K extends keyof EditableTab>(id: string, field: K, value: EditableTab[K]) => void;
  onDelete: (id: string) => void;
  onAddNew: () => void;
  newTab: Omit<EditableTab, "id">;
  setNewTab: (tab: Omit<EditableTab, "id">) => void;
  maxLimit: number;
  hasDuplicateName: boolean;
  hasDuplicateColor: boolean;
};

export const TabDetailsTable: React.FC<Props> = ({
  tabs,
  onEdit,
  onSave,
  onChange,
  onDelete,
  onAddNew,
  newTab,
  setNewTab,
  maxLimit,
  hasDuplicateName,
  hasDuplicateColor,
}) => {
  return (
    <div className="overflow-auto max-h-[400px]">
      <table className="min-w-full text-sm text-center">
        <thead>
          <tr className="border-b-2 border-gray-300 font-semibold text-gray-700">
            <th className="p-2">Action</th>
            <th className="p-2 min-w-[200px]">Name</th>
            <th className="p-2 min-w-[200px]">Color</th>
            <th className="p-2">Locked</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-transparent">
          {tabs.map((tab, index) => (
            <tr key={tab.id} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
              <td className="p-2 space-x-1">
                {!tab.readonly && (
                  <>
                    {tab.editing ? (
                      <button
                        type="button"
                        onClick={() => onSave(tab.id)}
                        className="text-black-600 hover:text-black-800"
                        title="Save"
                      >
                        <Save size={18} />
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onEdit(tab.id)}
                        className="text-gray-700 hover:text-black"
                        title="Edit"
                      >
                        <Pencil size={18} />
                      </button>
                    )}
                    <button
                      onClick={() => onDelete(tab.id)}
                      className="text-red-600 hover:text-red-800 ml-2"
                      title="Delete"
                      type="button"
                    >
                      <Trash2 size={18} />
                    </button>
                  </>
                )}
              </td>
              <td className="p-2">
                {tab.editing ? (
                  <input
                    type="text"
                    value={tab.name}
                    onChange={e => onChange(tab.id, "name", e.target.value)}
                    className="border px-2 py-1 w-full text-center rounded"
                  />
                ) : (
                  tab.name
                )}
              </td>
              <td className="p-2">
                <input
                  type="color"
                  value={tab.color}
                  disabled={!tab.editing}
                  onChange={e => onChange(tab.id, "color", e.target.value)}
                  className="cursor-pointer mx-auto w-[60%]"
                />
              </td>
              <td className="p-2">
                <input
                  type="checkbox"
                  checked={tab.isLock}
                  disabled={!tab.editing}
                  onChange={e => onChange(tab.id, "isLock", e.target.checked)}
                />
              </td>
            </tr>
          ))}
          {tabs.length < maxLimit && (
            <tr className="bg-gray-100">
              <td className="p-2">
                {newTab.name.trim() && !hasDuplicateName && !hasDuplicateColor && (
                  <button onClick={onAddNew} className="text-black-600 hover:text-black-800" title="Add">
                    <Plus size={18} />
                  </button>
                )}
              </td>
              <td className="p-2">
                <input
                  type="text"
                  placeholder="Tab name"
                  value={newTab.name}
                  onChange={e => setNewTab({ ...newTab, name: e.target.value })}
                  className="border px-2 py-1 w-full text-center rounded"
                />
              </td>
              <td className="p-2">
                <input
                  type="color"
                  value={newTab.color}
                  onChange={e => setNewTab({ ...newTab, color: e.target.value })}
                  className="cursor-pointer mx-auto w-[60%]"
                />
              </td>
              <td className="p-2">
                <input
                  type="checkbox"
                  checked={newTab.isLock}
                  onChange={e => setNewTab({ ...newTab, isLock: e.target.checked })}
                />
              </td>
            </tr>
          )}
        </tbody>
      </table>
      {(hasDuplicateName || hasDuplicateColor) && (
        <div className="text-red-600 font-medium text-sm mt-2">
          {hasDuplicateName && <div>Tab names must be unique.</div>}
          {hasDuplicateColor && <div>Tab colors must be unique.</div>}
        </div>
      )}
    </div>
  );
};
export const StyledCheckbox = styled(Checkbox)(({ theme }) => ({
  color: theme.palette.primary.main,
  padding: "3px 5px",
  "&.Mui-checked": {
    color: theme.palette.primary.main,
  },
}));

export const AddTemplateTabForm = () => {
  const {
    userTemplate,
    selectedTemplate,
    setSelectedTemplate,
    handleAddTab,
    tabs,
    newTab,
    setNewTab,
    toggleEdit,
    updateTab,
    saveTab,
    deleteTab,
    maxLimit,
    router,
    data,
    isAllSelected,
    selectedIds,
    toggleOne,
    toggleAll,
    steps,
    completedSteps,
    currentStep,
    nextStep,
    prevStep,
    getTemplateTabs,
    handleUpdateTemplateSubmit,
    handleAddFolderTabs,
  } = UseAddTemplateTabForm();

  const hasEditingTabs = useMemo(() => tabs.some(tab => tab.editing), [tabs]);
  const [selectedTemplateName, setSelectedTemplateName] = useState<string>("");
  const hasDuplicateName = useMemo(() => {
    const names = tabs.map(t => t.name.trim().toLowerCase());
    return new Set(names).size !== names.length;
  }, [tabs]);

  const hasDuplicateColor = useMemo(() => {
    const colors = tabs.map(t => t.color);
    return new Set(colors).size !== colors.length;
  }, [tabs]);

  const hasNewTabs = useMemo(() => tabs.some(tab => !tab.readonly), [tabs]);

  const isSubmitDisabled = !hasNewTabs || hasEditingTabs || hasDuplicateName || hasDuplicateColor;

  return (
    <Card className="mb-8 p-6">
      <div className="flex justify-between  border-b border-[#7E57C2] pb-3">
        <div className="flex items-center flex-wrap xs:flex-col xs:items-start">
          <FolderPlus strokeWidth={2.3} color="#00092A" className="w-6 h-6 md:w-7 md:h-7" />
          <h2 className="text-[#00092A] font-semibold text-xl lg:text-2xl ml-3 xs:ml-0 xs:mt-2 xs:text-lg">Add Tabs</h2>
        </div>
        <div>
          <StyledButton onClick={() => router.back()} className="w-full sm:w-auto">
            {Constant.COMMON.BACK}
          </StyledButton>
        </div>
      </div>
      <div className="mb-8">
        <StepIndicator steps={steps} currentStep={currentStep} completedSteps={completedSteps} />
      </div>
      {currentStep === 1 && (
        <Step1TemplateSelection
          userTemplate={userTemplate}
          selectedTemplate={selectedTemplate}
          setSelectedTemplate={setSelectedTemplate}
          getTemplateTabs={getTemplateTabs}
          setSelectedTemplateName={setSelectedTemplateName}
        />
      )}
      {currentStep === 2 && (
        <Step2AddTabs
          tabs={tabs}
          onEdit={toggleEdit}
          onSave={saveTab}
          onChange={updateTab}
          onDelete={deleteTab}
          onAddNew={handleAddTab}
          newTab={newTab}
          setNewTab={setNewTab}
          maxLimit={maxLimit}
          hasDuplicateName={hasDuplicateName}
          hasDuplicateColor={hasDuplicateColor}
          selectedTemplate={selectedTemplateName}
        />
      )}

      {currentStep === 3 && (
        <Step3SelectFolder
          data={data}
          selectedIds={selectedIds}
          isAllSelected={isAllSelected}
          toggleAll={toggleAll}
          toggleOne={toggleOne}
          newTab={tabs}
          selectedTemplate={selectedTemplateName}
        />
      )}
      <div className="flex gap-4 mt-6 justify-between flex-wrap">
        {/* Previous Button */}
        <button
          onClick={prevStep}
          disabled={currentStep === 1}
          className={`w-full sm:w-auto px-5 py-2 rounded-xl font-medium transition-all duration-200 ${
            currentStep === 1
              ? "bg-gray-300 text-gray-500 cursor-not-allowed"
              : "bg-white text-[#7e58c1] border border-[#7e58c1] hover:bg-[#7e58c1] hover:text-white"
          }`}
        >
          Previous
        </button>

        {/* Next or Final Action Button */}
        {currentStep === 3 ? (
          data.length === 0 ? (
            <button
              onClick={handleUpdateTemplateSubmit}
              className="w-full sm:w-auto px-5 py-2 rounded-xl font-medium bg-[#7e58c1] text-white hover:bg-[#7753b4]"
            >
              Update Template only
            </button>
          ) : selectedIds.length >= 0 ? (
            <div>
              <button
                onClick={handleUpdateTemplateSubmit}
                className="px-5 mr-2.5 py-2 rounded-xl font-medium bg-[#7e58c1] text-white hover:bg-[#7753b4]"
              >
                Update Template only
              </button>
              <button
                onClick={() => {
                  handleUpdateTemplateSubmit();
                  handleAddFolderTabs();
                }}
                disabled={selectedIds.length == 0}
                className={
                  selectedIds.length == 0
                    ? "px-5 py-2 rounded-xl font-medium bg-gray-300 text-gray-500 cursor-not-allowed"
                    : "px-5 py-2 rounded-xl font-medium bg-[#7e58c1] text-white hover:bg-[#7753b4]"
                }
              >
                Apply Folder Tab & Update Template
              </button>
            </div>
          ) : (
            <button
              disabled
              className="w-full sm:w-auto px-5 py-2 rounded-xl font-medium bg-gray-300 text-gray-500 cursor-not-allowed"
            >
              Select a folder to continue
            </button>
          )
        ) : (
          <button
            onClick={nextStep}
            disabled={
              currentStep === steps.length ||
              (currentStep === 2 && isSubmitDisabled) ||
              (currentStep === 1 && selectedTemplate === "")
            }
            className={`w-full sm:w-auto px-5 py-2 rounded-xl font-medium transition-all duration-200 ${
              currentStep === steps.length ||
              (currentStep === 2 && isSubmitDisabled) ||
              (currentStep === 1 && selectedTemplate === "")
                ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                : "bg-[#7e58c1] text-white hover:bg-[#7753b4]"
            }`}
          >
            Next
          </button>
        )}
      </div>
    </Card>
  );
};
