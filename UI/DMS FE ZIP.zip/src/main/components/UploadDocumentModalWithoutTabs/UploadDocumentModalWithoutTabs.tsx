import React from "react";
import { Trash2 } from "lucide-react";
import { formatFileSizeInKbMb, getFileExtension } from "@core/utils";
import { CommonDrawer } from "@core/components";

interface UploadDocumentDrawerProps {
  open: boolean;
  onClose: () => void;
  selectedFiles: File[];
  removeFile: (indexToRemove: number) => void;
  onUpload: () => void;
}

export const UploadDocumentDrawerWithoutTabs: React.FC<UploadDocumentDrawerProps> = ({
  open,
  onClose,
  selectedFiles,
  removeFile,
  onUpload,
}) => {
  /**
   * Triggers the close callback.
   */
  const handleClose = () => {
    onClose();
  };

  return (
    <CommonDrawer open={open} onClose={handleClose} title="Upload Documents">
      <div className="overflow-auto w-full">
        <table className="min-w-[800px] w-full border border-[#dee2e6]">
          <thead className="bg-[#f5f6f9]">
            <tr className="text-sm text-[#888] whitespace-nowrap">
              <th className="px-3 py-2 text-left">File Name</th>
              <th className="px-3 py-2 text-left">Size & Format</th>
              <th className="px-3 py-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="text-sm text-gray-800">
            {selectedFiles.map((file, index) => (
              <tr key={file.name} className="border-t border-[#dee2e6]">
                <td className="px-3 py-2 text-left">{file.name}</td>
                <td className="px-3 py-2 text-left">
                  {formatFileSizeInKbMb(file.size)} | {getFileExtension(file.name)}
                </td>
                <td className="px-3 py-2 text-center">
                  <div className="flex items-center justify-center">
                    <Trash2 onClick={() => removeFile(index)} className="w-5 h-5 cursor-pointer" />
                  </div>
                </td>
              </tr>
            ))}
            {selectedFiles.length === 0 && (
              <tr className="border-t border-[#dee2e6]">
                <td colSpan={4} className="px-4 py-2 text-center text-sm text-gray-500">
                  No file selected!
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-1 border-t border-[#dee2e6] p-4">
        <button
          onClick={handleClose}
          className="w-full sm:w-auto rounded-md px-6 py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
        >
          Close
        </button>
        <button
          onClick={onUpload}
          disabled={selectedFiles.length === 0}
          className={`w-full sm:w-auto !rounded-md !px-6 !py-2 text-white transition
            ${selectedFiles.length === 0 ? "bg-gray-400 cursor-not-allowed" : "bg-[#7E57C2] hover:bg-[#6C4FB3]"}
          `}
        >
          Upload
        </button>
      </div>
    </CommonDrawer>
  );
};
