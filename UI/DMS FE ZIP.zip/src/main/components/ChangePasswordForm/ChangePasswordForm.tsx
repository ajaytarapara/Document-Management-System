import { CommonButton, CommonTextField } from "@core/components";
import { Card, IconButton, InputAdornment, Stack } from "@mui/material";
import { UseChangePasswordForm } from "./ChangePasswordForm.hook";
import { getRequiredMessage } from "@core/utils";
import { Constant } from "@core/constants/Constant";
import { Eye, EyeOff } from "lucide-react";

export const ChangePassForm = () => {
  const {
    handleSubmit,
    onSubmit,
    register,
    errors,
    isShowOldPass,
    setIsShowOldPass,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  } = UseChangePasswordForm();

  return (
    <div className="w-full">
      <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold text-foreground mb-4">Change password</h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)}>
        <Card className="mb-8 p-4">
          <Stack spacing={2}>
            <CommonTextField
              label="Current Password"
              {...register("currentPassword", {
                required: getRequiredMessage("Current Password"),
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              })}
              errors={errors}
              required
              slotProps={{
                input: {
                  type: isShowOldPass ? "text" : "password",
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        disableRipple
                        onClick={() => setIsShowOldPass(!isShowOldPass)}
                        edge="end"
                        size="small"
                        className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                      >
                        {!isShowOldPass ? (
                          <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        ) : (
                          <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
            />
            <CommonTextField
              label="New Password"
              {...register("newPassword", {
                required: getRequiredMessage("New Password"),
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              })}
              errors={errors}
              required
              slotProps={{
                input: {
                  type: isShowNewPass ? "text" : "password",
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        disableRipple
                        onClick={() => setIsShowNewPass(!isShowNewPass)}
                        edge="end"
                        size="small"
                        className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                      >
                        {!isShowNewPass ? (
                          <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        ) : (
                          <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
            />
            <CommonTextField
              label="Confirm Password"
              {...register("confirmPassword", {
                required: getRequiredMessage("Confirm Password"),
                validate: value => value === getValues("newPassword") || "Confirm Password must match New Password",
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              })}
              errors={errors}
              required
              slotProps={{
                input: {
                  type: isShowConfirmNewPass ? "text" : "password",
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        disableRipple
                        onClick={() => setIsShowConfirmNewPass(!isShowConfirmNewPass)}
                        edge="end"
                        size="small"
                        className="!text-black !bg-transparent !border-none !hover:bg-transparent !p-0 !min-w-0 cursor-pointer transition-transform duration-200 hover:scale-110"
                      >
                        {!isShowConfirmNewPass ? (
                          <EyeOff size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        ) : (
                          <Eye size={20} className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]" />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
            />
            <CommonButton
              type="submit"
              color="primary"
              className="!max-h-[48px] !text-sm sm:!text-md md:!text-lg !max-w-md !font-semibold justify-end !ml-auto"
              variant="contained"
            >
              Change password
            </CommonButton>
          </Stack>
        </Card>
      </form>
    </div>
  );
};
