"use client";

import { Box, Button } from "@mui/material";
import { Constant } from "@core/constants/Constant";
import { CommonButton, CommonDrawer } from "@core/components";

interface ICommonDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  description?: string | React.ReactNode;
  children?: React.ReactNode;
  icon?: React.ReactNode;
  showActions?: boolean;
  onSubmit?: (e?: React.FormEvent) => void;
  submitLabel?: string;
  cancelLabel?: string;
  disableSubmit?: boolean;
  buttonType?: "button" | "submit" | "reset";
  anchor?: "left" | "right" | "top" | "bottom";
  customWidth?: number | string;
}

export const CommonDMSDrawer = ({
  open,
  onClose,
  description,
  children,
  showActions = true,
  onSubmit,
  submitLabel = `${Constant.COMMON.SUBMIT}`,
  cancelLabel = `${Constant.COMMON.CANCEL}`,
  disableSubmit = false,
  buttonType,
  title,
}: ICommonDrawerProps) => {
  return (
    <CommonDrawer open={open} onClose={onClose} title={title}>
      <Box flex={1} display="flex" flexDirection="column" gap={2}>
        {description && <Box>{description}</Box>}
        {children}
      </Box>
      {showActions && (
        <Box display="flex" justifyContent="flex-end" gap={2} mt={2}>
          <Button onClick={onClose} variant="outlined" className="!capitalize">
            {cancelLabel}
          </Button>
          <CommonButton
            disabled={disableSubmit}
            type={buttonType}
            variant="contained"
            onClick={buttonType === "button" ? onSubmit : undefined}
            className="!capitalize disabled:!opacity-50 disabled:!text-gray-300 disabled:!bg-[#7e57c2]"
          >
            {submitLabel}
          </CommonButton>
        </Box>
      )}
    </CommonDrawer>
  );
};
