import React, { useEffect, useState } from "react";
import { Select, SelectChangeEvent, MenuItem } from "@mui/material";
import { Trash2 } from "lucide-react";
import { decryptObject, fileToBase64, formatFileSizeInKbMb, getFileExtension } from "@core/utils";
import { FileUploadItemDto, TabResponse } from "@main/models";
import { useAppDispatch } from "@main/hooks";
import { CommonDrawer } from "@core/components";
import { uploadFile } from "@main/store";
import { IAPIResponse } from "@core/models";

interface UploadDocumentDrawerProps {
  open: boolean;
  onClose: () => void;
  selectedFiles: File[];
  removeFile: (indexToRemove: number) => void;
  tabs?: TabResponse[];
  folderId: string | null;
  handleSucess: () => void;
}

export const UploadDocumentDrawer: React.FC<UploadDocumentDrawerProps> = ({
  open,
  onClose,
  selectedFiles,
  removeFile,
  tabs,
  folderId,
  handleSucess,
}) => {
  const [selectedTabs, setSelectedTabs] = useState<Record<string, string | "">>({});
  const [duplicateFiles, setDuplicateFiles] = useState<string[]>([]);
  const [renameMap, setRenameMap] = useState<Record<string, string>>({});
  const [renameModalOpen, setRenameModalOpen] = useState(false);
  const [selectfile, setSelectedFile] = useState<File[]>();
  const dispatch = useAppDispatch();

  /**
   * Handles the tab selection change for a specific file.
   * - Extracts the new value from the select event.
   * - Updates the `selectedTabs` state by mapping the file name to the selected tab ID.
   *
   * @param fileName - Name of the file whose tab is being changed.
   * @param event - The select change event containing the new value.
   */
  const handleTabChange = (fileName: string, event: SelectChangeEvent<string | "">) => {
    const newValue = event.target.value;
    setSelectedTabs(prev => ({ ...prev, [fileName]: newValue }));
  };

  /**
   * Resets all tab selections and triggers the close callback.
   */
  const handleClose = () => {
    setSelectedTabs({});
    onClose();
  };
  /**
   * Handles closing of the rename dialog.
   * - Calls the success handler to notify parent component.
   * - Closes the rename modal.
   */
  const handleCloseDialog = () => {
    handleSucess();
    setRenameModalOpen(false);
  };
  /**
   * Handles uploading and renaming of files.
   * - Validates that no file rename input is empty.
   * - Converts each selected file to Base64 format.
   * - Maps each file with its new name and associated folder tab ID.
   * - Builds the payload and dispatches the upload action.
   * - Closes modal and triggers success handler upon completion.
   */
  const handleUpaloadAndRename = async () => {
    // Check if any rename field is empty
    const hasEmpty = duplicateFiles.some(file => !renameMap[file]?.trim());
    if (hasEmpty) {
      return;
    }
    // Convert each selected file to Base64 and prepare DTO
    const renamedDtos: FileUploadItemDto[] = [];
    if (selectfile) {
      for (const file of selectfile) {
        const base64Content = await fileToBase64(file);
        const folderTabId = selectedTabs[file.name];
        const newName = renameMap[file.name] ?? file.name;

        renamedDtos.push({
          fileName: newName,
          contentType: file.type,
          base64Content,
          folderTabId: folderTabId ? folderTabId : "",
        });
      }
      // Build final payload for retry upload
      const retryPayload = {
        folderId: folderId ?? "",
        files: renamedDtos,
      };
      // Dispatch upload action

      await dispatch(uploadFile(retryPayload));
      // Close modal and trigger callbacks
      setRenameModalOpen(false);
      handleSucess();
      handleClose();
    }
  };
  /**
   * Handles file upload for the selected folder.
   * - Converts each selected file into a Base64 string.
   * - Maps files into `FileUploadItemDto` objects including metadata (name, type, tabId).
   * - Builds a payload with the folderId and list of files.
   * - Dispatches the `uploadFile` thunk via `handleThunkWithDecrypt`.
   * - If the upload succeeds:
   *    - Executes the success handler (`handleSucess`).
   *    - Closes the modal/dialog (`onClose`).
   */
  const handleUpload = async () => {
    const fileUploadDtos: FileUploadItemDto[] = [];
    setSelectedFile(selectedFiles);
    for (const file of selectedFiles) {
      const base64Content = await fileToBase64(file);
      const folderTabId = selectedTabs[file.name];
      fileUploadDtos.push({
        fileName: file.name,
        contentType: file.type,
        base64Content,
        folderTabId: folderTabId ? folderTabId : "",
      });
    }

    const payload = {
      folderId: folderId ?? "",
      files: fileUploadDtos,
    };
    const response = await dispatch(uploadFile(payload));
    if (uploadFile.fulfilled.match(response)) {
      if (response.payload?.data) {
        const decrypted = decryptObject<IAPIResponse<string[]>>(response.payload.data);
        if (decrypted.data && decrypted.data?.length > 0) {
          setDuplicateFiles(decrypted.data);
          const initialRename: Record<string, string> = {};
          decrypted.data.forEach(name => {
            initialRename[name] = name;
          });
          setRenameMap(initialRename);
          setRenameModalOpen(true);
          onClose();
        } else {
          handleSucess();
          handleClose();
        }
      }
    }
  };

  useEffect(() => {
    if (tabs && selectedFiles.length > 0) {
      const defaultTabId = tabs[0]?.id ?? "";
      const initialSelections: Record<string, string | ""> = {};
      selectedFiles.forEach(file => {
        initialSelections[file.name] = defaultTabId;
      });
      setSelectedTabs(initialSelections);
    }
  }, [selectedFiles, tabs]);

  return (
    <>
      <CommonDrawer open={open} onClose={handleClose} title="Upload Documents">
        <div className="overflow-auto w-full">
          <table className="min-w-[800px] w-full border border-[#dee2e6]">
            <thead className="bg-[#f5f6f9]">
              <tr className="text-sm text-[#888] whitespace-nowrap">
                <th className="px-3 py-2 text-left">File Name</th>
                <th className="px-3 py-2 text-left">Size & Format</th>
                <th className="px-3 py-2 text-left">Tabs</th>
                <th className="px-3 py-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="text-sm text-gray-800">
              {selectedFiles.map((file, index) => (
                <tr key={file.name} className="border-t border-[#dee2e6]">
                  <td className="px-3 py-2 text-left">{file.name}</td>
                  <td className="px-3 py-2 text-left">
                    {formatFileSizeInKbMb(file.size)} | {getFileExtension(file.name)}
                  </td>
                  <td className="px-3 py-2 text-left">
                    <Select
                      value={selectedTabs[file.name] ?? ""}
                      onChange={event => {
                        handleTabChange(file.name, event);
                      }}
                      displayEmpty
                      fullWidth
                      MenuProps={{
                        PaperProps: {
                          sx: {
                            maxHeight: 188,
                            overflowY: "scroll",
                            "&::-webkit-scrollbar": { display: "none" },
                            scrollbarWidth: "none",
                            msOverflowStyle: "none",
                          },
                        },
                      }}
                      sx={{
                        height: 36,
                        fontSize: 14,
                        "& .MuiSelect-select": { padding: "6px 10px" },
                      }}
                    >
                      {tabs?.map(tab => (
                        <MenuItem key={tab.id} value={tab.id}>
                          {tab.tabName}
                        </MenuItem>
                      ))}
                    </Select>
                  </td>
                  <td className="px-3 py-2 text-center">
                    <div className="flex items-center justify-center">
                      <Trash2 onClick={() => removeFile(index)} className="w-5 h-5 cursor-pointer" />
                    </div>
                  </td>
                </tr>
              ))}
              {selectedFiles.length === 0 && (
                <tr className="border-t border-[#dee2e6]">
                  <td colSpan={4} className="px-4 py-2 text-center text-sm text-gray-500">
                    No file selected!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-1 border-t border-[#dee2e6] p-4">
          <button
            onClick={handleClose}
            className="w-full sm:w-auto rounded-md px-6 py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
          >
            Close
          </button>
          <button
            onClick={handleUpload}
            className="w-full sm:w-auto rounded-md px-6 py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
          >
            Upload
          </button>
        </div>
      </CommonDrawer>
      <CommonDrawer open={renameModalOpen} onClose={() => setRenameModalOpen(false)} title="Duplicate Files Found">
        <p className="text-sm text-gray-600 mb-2">These files already exist. Please rename before uploading:</p>
        {duplicateFiles.map(file => (
          <div key={file} className="flex items-center gap-2 mb-3">
            <span className="w-1/3 text-sm">{file}</span>
            <input
              type="text"
              value={renameMap[file]}
              onChange={e => setRenameMap(prev => ({ ...prev, [file]: e.target.value }))}
              className={`flex-1 border rounded-md px-2 py-1 text-sm ${
                !renameMap[file]?.trim() ? "border-red-500" : "border-gray-300"
              }`}
            />
            {!renameMap[file]?.trim() && <span className="text-xs text-red-500">Filename cannot be empty</span>}
          </div>
        ))}
        <p className="text-sm text-red-600 mb-2">
          **If you do not want to upload this files then Click on Cancel button{" "}
        </p>
        <div>
          <button
            onClick={() => {
              handleCloseDialog();
            }}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md"
          >
            Cancel
          </button>
          <button
            onClick={async () => {
              handleUpaloadAndRename();
            }}
            className="px-4 py-2 bg-[#7E57C2] text-white rounded-md"
          >
            Save & Upload
          </button>
        </div>
      </CommonDrawer>
    </>
  );
};
