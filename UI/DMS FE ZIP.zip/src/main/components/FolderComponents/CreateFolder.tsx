"use client";

import React, { useCallback, useEffect, useState } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { Box, Button, Checkbox, Grid, MenuItem, Select, TextField, Typography } from "@mui/material";
import { CommonTextField, LoggedInLayout } from "@core/components";
import { useAppDispatch } from "@main/hooks";
import { Constant } from "@core/constants/Constant";
import { decryptObject, handleThunkWithDecrypt } from "@core/utils";
import { useRouter } from "next/navigation";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { CreateFolderFormValues, IUserTemplate, IUserTemplateTabs } from "@main/models";
import { createFolder, getAllUserTemplate, getMaxTabLimit, getUserTemplateTabs } from "@main/store";
import { v4 as uuidv4 } from "uuid";
// Interface for form

const CreateFolderForm = () => {
  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<CreateFolderFormValues>({
    defaultValues: {
      tabs: [],
    },
  });

  const { fields, replace } = useFieldArray({
    control,
    name: "tabs",
    keyName: "keyId",
  });
  const [tabCount, setTabCount] = useState(1);
  const [maxTabLimit, setMaxTabLimit] = useState<number>(12);
  const [userTemplate, setUserTemplate] = useState<IUserTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");
  const [templateTabs, setTemplateTabs] = useState<IUserTemplateTabs[]>([]);

  const dispatch = useAppDispatch();
  const route = useRouter();

  useEffect(() => {
    const fetchTabLimit = async () => {
      const response = await dispatch(getMaxTabLimit());
      if (getMaxTabLimit.fulfilled.match(response)) {
        if (response.payload?.data) {
          const decrypted = decryptObject<{ maxTabLimit: number }>(response.payload.data);
          if (decrypted?.maxTabLimit) {
            setMaxTabLimit(decrypted.maxTabLimit);
            setTabCount(1);
          }
        }
      }
    };
    fetchTabLimit();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getRandomColor = () => {
    const letters = "0123456789ABCDEF";
    return (
      "#" +
      Array.from({ length: 6 })
        .map(() => letters[Math.floor(Math.random() * 16)])
        .join("")
    );
  };

  const setTabsFromState = (template: IUserTemplateTabs[], count: number) => {
    const newTabs: CreateFolderFormValues["tabs"] = [];

    for (let i = 0; i < count; i++) {
      if (i < template.length) {
        const tab = template[i];
        newTabs.push({
          tabName: tab.name,
          color: tab.color,
          isLock: tab.isLock,
        });
      } else {
        newTabs.push({
          tabName: `tabname${i + 1}`,
          color: getRandomColor(),
          isLock: false,
        });
      }
    }

    replace(
      newTabs.map(tab => ({
        ...tab,
        id: uuidv4(),
      }))
    );
  };
  const getUserTemplate = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IUserTemplate[], null>(dispatch, getAllUserTemplate, null);
    if (response?.data) {
      setUserTemplate(response.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getUserTemplate();
  }, [getUserTemplate]);

  useEffect(() => {
    const fetchTemplateTabs = async () => {
      if (!selectedTemplate) return;

      const response = await handleThunkWithDecrypt<IUserTemplateTabs[], string>(
        dispatch,
        getUserTemplateTabs,
        selectedTemplate
      );

      if (response?.data) {
        setTemplateTabs(response.data);
        setTabCount(response.data.length);
      } else {
        setTemplateTabs([]);
        setTabCount(1);
      }
    };

    fetchTemplateTabs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTemplate]);

  const onSubmit = async (data: CreateFolderFormValues) => {
    const formdata = {
      ...data,
      templateId: selectedTemplate,
    };
    const response = await handleThunkWithDecrypt(dispatch, createFolder, formdata);
    if (response.isSuccessful) {
      route.push(ROUTES.OFFICE_USER.VIEW_FOLDER);
    }
  };
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="font-semibold text-xl md:text-2xl mb-4">Create Folder</div>
          <Grid container spacing={2} className="bg-white shadow-2xl rounded-2xl p-6">
            {/* Main Fields */}
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="folderName"
                label="Folder Name"
                register={register}
                validation={{ required: Constant.MESSAGE.FOLDER_REQUIRED }}
                errors={errors}
                className="py-1 text-sm"
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="fileNumber"
                label="File Number"
                register={register}
                validation={{ required: Constant.MESSAGE.FILENUMBER_REQ }}
                errors={errors}
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="firstName"
                label="First Name"
                register={register}
                validation={{ required: Constant.MESSAGE.FIRSTNAME_REQ }}
                errors={errors}
                className="py-1 text-sm"
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }}>
              <CommonTextField
                name="lastName"
                sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                label="Last Name"
                register={register}
                errors={errors}
              />
            </Grid>

            <Grid size={{ xs: 12 }}>
              <CommonTextField name="comment" label="Comment" register={register} multiline rows={3} errors={errors} />
            </Grid>
            {userTemplate.length > 0 && (
              <Grid size={{ xs: 6 }}>
                <div className="font-bold text-[#00092A] mb-2">Select Template</div>
                <Select
                  fullWidth
                  value={selectedTemplate}
                  sx={{ height: 40 }}
                  onChange={async e => {
                    const templateId = e.target.value;
                    setSelectedTemplate(templateId);

                    const response = await handleThunkWithDecrypt<IUserTemplateTabs[], string>(
                      dispatch,
                      getUserTemplateTabs,
                      templateId
                    );
                    if (response?.data) {
                      setTemplateTabs(response.data);
                      setTabCount(response.data.length);
                      setTabsFromState(response.data, response.data.length);
                    } else {
                      setTemplateTabs([]);
                      setTabCount(1);
                      setTabsFromState([], 1);
                    }
                  }}
                >
                  {userTemplate.map(userTemplate => (
                    <MenuItem key={userTemplate.id} value={userTemplate.id}>
                      {userTemplate.name}
                    </MenuItem>
                  ))}
                </Select>
              </Grid>
            )}
            <Grid size={{ xs: 12, md: 6 }}>
              <div className="font-bold text-[#00092A] mb-2">How many tabs do you want to create?</div>
              <Select
                fullWidth
                value={tabCount}
                sx={{ height: 40 }}
                onChange={e => {
                  const newCount = Number(e.target.value);
                  setTabCount(newCount);
                  setTabsFromState(templateTabs, newCount);
                }}
              >
                {Array.from({ length: maxTabLimit }, (_, i) => i + 1).map(num => (
                  <MenuItem key={num} value={num}>
                    {num}
                  </MenuItem>
                ))}
              </Select>
            </Grid>
            {/* Tab Fields */}
            {!!selectedTemplate && (
              <Grid size={{ xs: 12 }}>
                <Box className="hidden sm:grid grid-cols-6 gap-4 bg-[#f9fafb] p-2 rounded-t font-semibold text-sm text-[#00092a]">
                  <div className="col-span-4 flex items-center">Name</div>
                  <div className="flex items-center justify-center">Color</div>
                  <div className="flex items-center justify-center">Tab Lock</div>
                </Box>
              </Grid>
            )}
            <Grid size={{ xs: 12 }}>
              {fields.map((field, index) => (
                <Box
                  key={field.keyId}
                  className="grid grid-cols-1 sm:grid-cols-6 gap-4 items-center bg-[#f9fafb] p-2 rounded-t"
                >
                  <Box className="col-span-4">
                    <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Name</label>
                    <CommonTextField
                      name={`tabs.${index}.tabName`}
                      register={register}
                      validation={{ required: Constant.MESSAGE.TAB_NAME_REQ }}
                      errors={errors}
                      sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                    />
                  </Box>

                  <Box className="flex justify-center">
                    <div className="flex flex-col items-start sm:items-center w-full">
                      <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Color</label>
                      <TextField
                        type="color"
                        {...register(`tabs.${index}.color`, { required: "Color is required" })}
                        className="w-full border rounded bg-white"
                        sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
                      />
                      {errors?.tabs?.[index]?.color && (
                        <Typography color="error" variant="caption">
                          {errors.tabs[index]?.color?.message}
                        </Typography>
                      )}
                    </div>
                  </Box>

                  <div className="flex flex-col items-start sm:items-center">
                    <label className="block text-xs font-medium text-[#00092a] mb-1 sm:hidden">Tab Lock</label>
                    <Controller
                      name={`tabs.${index}.isLock`}
                      control={control}
                      render={({ field }) => <Checkbox {...field} checked={field.value} />}
                    />
                  </div>
                </Box>
              ))}
            </Grid>

            {/* Submit */}
            <Grid size={{ xs: 12 }}>
              <Button variant="contained" color="primary" type="submit">
                Create Folder
              </Button>
            </Grid>
          </Grid>
        </form>
      </div>
    </LoggedInLayout>
  );
};

export default CreateFolderForm;
