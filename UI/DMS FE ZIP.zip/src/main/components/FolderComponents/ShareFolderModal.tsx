"use client";
import React, { useEffect } from "react";
import { Button, Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { CommonCheckbox, CommonDrawer, CommonTextField } from "@core/components";
import { useSelectorAuthState } from "@main/store";
import { decryptObject } from "@core/utils";
import { ILoginResponse } from "@main/models";
import { IAPIResponse } from "@core/models";

export interface ShareFolderForm {
  type: string;
  fromEmail: string;
  toEmail: string;
  toName: string;
  subject: string;
  message?: string;
  linkExpiration: number;
  viewOnly: boolean;
  EntityIds?: string[];
}

interface ShareFolderDrawerProps {
  open: boolean;
  folderId: string | string[] | null;
  onClose: () => void;
  onShare: (folderId: string | string[] | null, data: ShareFolderForm) => Promise<void>;
  type: string;
  multiple?: boolean;
}

export const ShareFolderDrawer: React.FC<ShareFolderDrawerProps> = ({
  open,
  folderId,
  onClose,
  onShare,
  type,
  multiple,
}) => {
  const { loggedInUser } = useSelectorAuthState();
  const decryptedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const userEmail = decryptedUser?.data?.email ?? "";

  const {
    control,
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ShareFolderForm>({
    defaultValues: {
      fromEmail: userEmail,
      toEmail: "",
      toName: "",
      subject: "",
      message: "",
      linkExpiration: 24,
      viewOnly: false,
      type: "",
    },
  });

  useEffect(() => {
    if (open) {
      reset({
        fromEmail: userEmail,
        toEmail: "",
        toName: "",
        subject: "",
        message: "",
        linkExpiration: 24,
        viewOnly: false,
        type: type,
      });
    }
  }, [open, userEmail, type, reset]);

  /**
   * Handles the share form submission.
   * - Returns early if `folderId` is not available.
   * - If multiple selection is enabled, assigns `folderId` as an array to `EntityIds`.
   * - Otherwise, sets the share `type` on the form data.
   * - Calls the `onShare` handler with the folder ID and prepared data.
   * - Closes the modal/dialog after submission.
   */
  const submit = handleSubmit(async data => {
    if (!folderId) return;
    if (multiple) {
      data.EntityIds = folderId as string[];
      data.type = type;
      await onShare(folderId, data);
    } else {
      data.type = type;
      await onShare(folderId, data);
    }
    onClose();
  });

  return (
    <CommonDrawer open={open} onClose={onClose} title="Share Folder">
      <form onSubmit={submit}>
        <input type="hidden" value={type} {...register("type")} />
        <Grid container spacing={2} className="py-2">
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="fromEmail"
              register={register}
              validation={{
                required: "From Email is required",
                pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" },
              }}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              errors={errors}
              label="From Email"
              disabled
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="toEmail"
              register={register}
              validation={{
                required: "To Email is required",
                pattern: { value: /\S+@\S+\.\S+/, message: "Invalid email format" },
                validate: value => value !== userEmail || "From Email and To Email cannot be the same",
              }}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              errors={errors}
              label="To Email (separate multiple with `;`)"
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="toName"
              register={register}
              validation={{ required: "To Name is required" }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="To Name (separate multiple with `;`)"
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <CommonTextField
              name="subject"
              register={register}
              validation={{ required: "Subject is required" }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="Subject"
            />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <CommonTextField name="message" register={register} errors={errors} label="Message" multiline rows={3} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <CommonTextField
              name="linkExpiration"
              register={register}
              validation={{
                required: "Expiration is required",
                min: { value: 1, message: "Must be at least 1 hour" },
              }}
              errors={errors}
              sx={{ "& .MuiOutlinedInput-root": { height: 40 } }}
              label="Link Expiration Time (hrs)"
              type="number"
            />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <CommonCheckbox<ShareFolderForm> label="View Only (Prevent Download)" control={control} name="viewOnly" />
          </Grid>
        </Grid>
        <div className="flex justify-end gap-3 mt-4">
          <Button onClick={onClose} variant="outlined">
            Cancel
          </Button>
          <Button type="submit" variant="contained">
            Share
          </Button>
        </div>
      </form>
    </CommonDrawer>
  );
};
