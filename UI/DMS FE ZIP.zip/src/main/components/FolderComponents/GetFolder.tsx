"use client";
import React, { useEffect, useState } from "react";
import { useAppDispatch } from "@main/hooks";
import { Button, Grid, IconButton } from "@mui/material";
import { Download, Edit, Share2, Trash2 } from "lucide-react";
import { ColumnDef, SortingState } from "@tanstack/react-table";
import { CommonTextField, Dialog, GeneralTable, LoggedInLayout } from "@core/components";
import { IAPIResponse, IDownloadFile, Role } from "@core/models";
import { decryptObject, handleThunkWithDecrypt, getFileExtension } from "@core/utils";
import { FolderDto, IPermissionResponse, ShareFolderArgs } from "@main/models";
import { deleteFolder, downloadFolder, getAllFolder, shareFile } from "@main/store";
import { EditFolderDrawer } from "../EditModels/editFolder";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { useRouter } from "next/navigation";
import { useSelectorAuthState } from "@main/store";
import { ILoginResponse } from "@main/models";
import { ShareFolderDrawer } from "./ShareFolderModal";
import JSZip from "jszip";
import { saveAs } from "file-saver";

const FolderTable = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;
  const folderColumns = (
    onEdit: (id: string) => void,
    onDelete: (id: string) => void,
    onDownload: (id: string) => void,
    onNameClick: (id: string) => void
  ): ColumnDef<FolderDto>[] => [
    {
      accessorKey: "folderName",
      header: "Folder Name",
      cell: ({ row, getValue }) => (
        <span className="text-[#4858c8] hover:underline cursor-pointer" onClick={() => onNameClick(row.original.id)}>
          {getValue() as string}
        </span>
      ),
    },
    {
      accessorKey: "firstName",
      header: "First Name",
    },

    {
      accessorKey: "lastName",
      header: "Last Name",
    },
    {
      accessorKey: "fileNumber",
      header: "File Number",
    },
    {
      accessorKey: "tabCount",
      header: "Tab Count",
    },
    {
      accessorKey: "createdAt",
      header: "Created At",
      cell: info => new Date(info.getValue() as string).toLocaleDateString(),
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const id = row.original.id;
        return (
          <div className="flex gap-2">
            <IconButton onClick={() => onEdit(id)} color="primary">
              <Edit />
            </IconButton>
            {permissions.privilegeDownload && !permissions.privilegeView && (
              <IconButton onClick={() => onDownload(id)} color="primary">
                <Download />
              </IconButton>
            )}
            <IconButton onClick={() => openShareModal(id)} color="primary">
              <Share2 />
            </IconButton>
            {permissions.privilegeDelete && !permissions.privilegeView && (
              <IconButton onClick={() => onDelete(id)} color="error">
                <Trash2 />
              </IconButton>
            )}
          </div>
        );
      },
    },
  ];

  const [folders, setFolders] = useState<FolderDto[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editFolderId, setEditFolderId] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<{
    privilegeDelete: boolean;
    privilegeDownload: boolean;
    privilegeView: boolean;
    hideLockTabs: boolean;
  }>({ privilegeDelete: false, privilegeDownload: false, privilegeView: false, hideLockTabs: false });
  /**
   * Opens the delete confirmation dialog for a specific folder.
   * - Sets the selected folder ID to be deleted.
   * - Marks the delete dialog as open.
   */
  const openDeleteDialog = (id: string) => {
    setSelectedFolderId(id);
    setDialogOpen(true);
  };

  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareFolderId, setShareFolderId] = useState<string | null>(null);

  const [sorting, setSorting] = useState<SortingState>([]);

  const [searchTerm, setSearchTerm] = useState("");
  /**
   * Handles changes in the search input field.
   * - Updates the search term state.
   * - Resets the page index to 0 for fresh search results.
   */
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setPageIndex(0);
  };

  /**
   * Opens the share modal for a specific folder.
   * - Sets the folder ID to share.
   * - Marks the share modal as open.
   */
  const openShareModal = (id: string) => {
    setShareFolderId(id);
    setShareModalOpen(true);
  };

  /**
   * Closes the share modal.
   * - Clears the folder ID for sharing.
   * - Marks the share modal as closed.
   */
  const closeShareModal = () => {
    setShareFolderId(null);
    setShareModalOpen(false);
  };

  /**
   * Closes the delete confirmation dialog.
   * - Hides the dialog.
   * - Clears the selected folder ID.
   */
  const closeDeleteDialog = () => {
    setDialogOpen(false);
    setSelectedFolderId(null);
  };

  /**
   * Confirms and deletes the selected folder.
   * - Returns early if no folder is selected.
   * - Dispatches the `deleteFolder` thunk with the selected folder ID.
   * - Refreshes the folder list.
   * - Closes the delete dialog.
   */
  const confirmDelete = async () => {
    if (selectedFolderId === null) return;

    await dispatch(deleteFolder({ id: selectedFolderId }));
    fetchFolders();
    closeDeleteDialog();
  };

  /**
   * Fetches the list of folders with pagination, sorting, and search functionality.
   * - Determines the sort field and sort order from the `sorting` state.
   * - Dispatches the `getAllFolder` thunk with pagination, sorting, and search params.
   * - Decrypts the encrypted API response into an `IAPIResponse<IPermissionResponse>`.
   * - Updates the folders list and total count in state from the decrypted data.
   * - Updates folder permissions in state if available.
   *
   * @param clear - Optional flag; when true, clears the search term before fetching.
   */
  const fetchFolders = async (clear?: boolean) => {
    const sortField = sorting[0]?.id || "";
    const sortOrder = sorting[0]?.desc ? "desc" : "asc";
    const res = await dispatch(
      getAllFolder({
        pageNumber: pageIndex + 1,
        pageSize,
        sortBy: sortField,
        sortDirection: sortOrder,
        searchTerm: clear ? "" : searchTerm.trim(),
      })
    );
    if (getAllFolder.fulfilled.match(res)) {
      const encryptedString = res.payload?.data;
      const decrypted: IAPIResponse<IPermissionResponse> =
        decryptObject<IAPIResponse<IPermissionResponse>>(encryptedString);
      if (decrypted?.data) {
        setFolders(decrypted.data.items || []);
        setTotalCount(decrypted.data.totalCount || 0);
      }
      if (decrypted?.data?.permissions) {
        setPermissions(decrypted.data.permissions);
      }
    }
  };

  useEffect(() => {
    fetchFolders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sorting]);

  /**
   * Opens the edit modal for a specific folder.
   * - Sets the `editFolderId` with the provided folder `id`.
   * - Opens the edit modal by updating state.
   */
  const handleEdit = (id: string) => {
    setEditFolderId(id);
    setEditModalOpen(true);
  };
  /**
   * Handles the folder download action.
   * - Refreshes the folders list by calling `fetchFolders`.
   */
  const handleDownlaod = async (id: string) => {
    const res = await dispatch(downloadFolder({ id: id }));
    if (downloadFolder.fulfilled.match(res)) {
      const encryptedString = res.payload?.data;
      const decrypted: IAPIResponse<IDownloadFile> = decryptObject<IAPIResponse<IDownloadFile>>(encryptedString);
      if (decrypted?.data) {
        const folderData = decrypted.data;
        const zip = new JSZip();

        // Create main folder
        const root = zip.folder(folderData.folderName);

        for (const tab of folderData.tabListDto) {
          // Create subfolder for each tab
          const tabFolder = root?.folder(tab.tabName);

          for (const file of tab.fileListDto) {
            const fullUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${file.url}`;
            const response = await fetch(fullUrl, {
              method: "GET",
            });
            const blob = await response.blob();
            // Add file to zip
            const arrayBuffer = await blob.arrayBuffer();
            tabFolder?.file(file.name + getFileExtension(file.url), arrayBuffer);
          }
        }

        // Generate zip and download
        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, `${folderData.folderName}.zip`);
      }
    }
  };

  /**
   * Handles the click action on a user's name.
   *
   * - Encrypts the user ID for secure URL usage.
   * - Navigates to the appropriate file route based on the logged-in user's role.
   *
   * @param id - The user ID associated with the clicked name.
   */
  const onNameClick = (id: string) => {
    if (decryptedLoggedUser?.data?.role === Role.Office_User) {
      router.push(`${ROUTES.OFFICE_USER.FILE}?fid=${id}`);
    } else {
      router.push(`${ROUTES.USER.FILE}?fid=${id}`);
    }
  };

  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className={`p-4 bg-white rounded-lg shadow-md mb-6`}>
          <h3 className="text-[#00092A] font-semibold mb-2">Search Folder</h3>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 8 }}>
              <CommonTextField
                name="search"
                value={searchTerm}
                onChange={handleSearchChange}
                placeholder="Search folders by FolderName,FirstName or LastName"
                className="mb-4 p-2 border rounded"
                sx={{ "& .MuiOutlinedInput-root": { height: 50 } }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 2 }}>
              <Button
                className="h-12 font-bold w-full"
                variant="contained"
                onClick={() => {
                  fetchFolders();
                }}
                color="primary"
              >
                Search Folder
              </Button>
            </Grid>
            <Grid size={{ xs: 12, md: 2 }}>
              <Button
                className="h-12 font-bold mx-2 w-full"
                variant="outlined"
                onClick={() => {
                  setSearchTerm("");
                  fetchFolders(true);
                }}
                color="primary"
              >
                Clear
              </Button>
            </Grid>
          </Grid>
        </div>

        <GeneralTable
          data={folders}
          columns={folderColumns(handleEdit, openDeleteDialog, handleDownlaod, onNameClick)}
          pageIndex={pageIndex}
          pageSize={pageSize}
          onPaginationChange={(newPage, newPageSize) => {
            setPageIndex(newPage);
            setPageSize(newPageSize);
          }}
          onSortingChange={setSorting}
          enablePagination
          totalCount={totalCount}
          className="bg-white shadow-xl rounded-xl"
          emptyMessage="No folders found."
        />
      </div>
      <Dialog
        open={dialogOpen}
        onClose={closeDeleteDialog}
        title="Delete Folder"
        description="Are you sure you want to delete this folder? This action cannot be undone."
        onSubmit={confirmDelete}
        submitLabel="Yes, Delete"
        cancelLabel="Cancel"
        buttonType="button"
      />
      <EditFolderDrawer
        open={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        fetchFolder={() => fetchFolders()}
        folderId={editFolderId}
      />
      <ShareFolderDrawer
        open={shareModalOpen}
        folderId={shareFolderId}
        onClose={closeShareModal}
        onShare={async (id, formData) => {
          await handleThunkWithDecrypt<string, ShareFolderArgs>(dispatch, shareFile, {
            id: id as string,
            data: formData,
          });
          fetchFolders();
        }}
        type="Folder"
      />
    </LoggedInLayout>
  );
};

export default FolderTable;
