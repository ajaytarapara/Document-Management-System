import { Box, TextField } from "@mui/material";

import { Dialog } from "@core/components";
import { useForgotPasswordForm } from "./ForgotPassword.hook";
import { StyledLink } from "./ForgotPassword.styled";

export const ForgotPassword = () => {
  const { open, setOpen, register, handleSubmit, errors, onSubmit } = useForgotPasswordForm();

  return (
    <>
      <Dialog
        title="Reset password"
        description="Enter your account's email address, and we'll send you a link to reset your password."
        open={open}
        onClose={() => setOpen(false)}
        onSubmit={handleSubmit(onSubmit)}
      >
        <Box component="form" noValidate>
          <TextField
            error={!!errors["email"]}
            helperText={errors["email"]?.message}
            variant="outlined"
            {...register("email", {
              required: "Email is required",
              pattern: {
                value: /^\S+@\S+$/i,
                message: "Invalid email address",
              },
            })}
            label="Email"
            fullWidth
          />
        </Box>
      </Dialog>
      <StyledLink type="button" onClick={() => setOpen(true)} variant="body2">
        Forgot your password?
      </StyledLink>
    </>
  );
};
