import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { useState } from "react";

import { IForgotPasswordForm } from "@main/models";

export const useForgotPasswordForm = () => {
  const [open, setOpen] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IForgotPasswordForm>();

  const onSubmit = async (formData: IForgotPasswordForm) => {
    console.log(formData);
    //TO DO: forgot password api call
    toast.success("Reset password email sent successful");
    setOpen(false);
  };

  return {
    open,
    setOpen,
    register,
    handleSubmit,
    errors,
    onSubmit,
  };
};
