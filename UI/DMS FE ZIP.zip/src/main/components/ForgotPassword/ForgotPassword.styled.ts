import emotionStyled from "@emotion/styled";
import { Link } from "@mui/material";

export const StyledLink = emotionStyled(Link)`
    align-self: center;
    cursor: pointer;
`;
