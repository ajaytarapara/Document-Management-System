import { CommonTextField } from "@core/components";
import { IconButton, Pagination } from "@mui/material";
import { Download, Edit, Trash2, X } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { UploadDocumentDrawerWithoutTabs } from "../UploadDocumentModalWithoutTabs/UploadDocumentModalWithoutTabs";
import { useAppDispatch } from "@main/hooks";
import { deleteUploadedFile, getAllUploadedFileForSplit, uploadFileForSplit } from "@main/store";
import { FileUploadDto, IFileUploadResponseForSplitVM, IUploadFileForSplitRequest } from "@main/models";
import { IPaginatedRequest, IPaginatedResponse } from "@core/models";
import { convertFileToBase64, handleThunkWithDecrypt } from "@core/utils";
import moment from "moment";
import { ConfirmDeleteModal } from "../DeleteFolderTemplateModal/DeleteFolderTemplateModal";
import { UploadFileSplitDrawer } from "./UpdateFileSplitModal/UpdateFileSplitModal";
import dynamic from "next/dynamic";
import { toast } from "react-toastify";
import NewSplitPdfModal from "../PdfPreviewModal/NewSplitPdfModal/NewSplitPdfModal";

const PdfPreviewModal = dynamic(() => import("@main/components/PdfPreviewModal/PdfPreviewModal"), {
  ssr: false,
});

export const SplitAndUpload = () => {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedByDrag, setUploadedByDrag] = useState<boolean>(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const [showUploadDocumentModal, setShowUploadDocumentModal] = useState<boolean>(false);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [filesFromBE, setFilesFromBE] = useState<IFileUploadResponseForSplitVM[]>([]);
  const [selectedDeleteId, setSelectedDeleteId] = useState<string | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [previewModalOpen, setPreviewModalOpen] = useState<boolean>(false);
  const [previewFileUrl, setPreviewFileUrl] = useState<string>("");
  const [previewFileName, setPreviewFileName] = useState<string>("");
  const [request, setRequest] = useState<IPaginatedRequest>({
    pageNumber: 1,
    pageSize: 10,
    sortBy: "createdAt",
    sortDirection: "desc",
  });
  const [fileForEdit, setFileForEdit] = useState<IFileUploadResponseForSplitVM | null>(null);
  const [openNewSplitPdfModal, setOpenNewSplitPdfModal] = useState<boolean>(false);
  const [splitFileNameFromUrl, setSplitFileNameFromUrl] = useState<string>("");
  const [splitFileName, setSplitFileName] = useState<string>("");
  const [selectedPages, setSelectedPages] = useState<number[]>([]);

  /**
   * Handles adding selected files to the state.
   *
   * @param files - The FileList of selected or dropped files.
   * @param byDrag - Flag indicating whether files were added via drag-and-drop.
   */
  const handleFiles = (files: FileList | null, byDrag = false) => {
    if (files) {
      setSelectedFiles(prev => [...prev, ...Array.from(files)]);
      setUploadedByDrag(byDrag);
    }
  };

  /**
   * Handles drag events for the drop zone (dragenter, dragover, dragleave).
   *
   * @param e - The drag event from the drop zone.
   */
  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  /**
   * Handles the drop event when files are dragged and released in the drop zone.
   *
   * @param e - The drop event from the drop zone.
   */
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const items = e.dataTransfer.items;

    if (items) {
      const isOnlyFiles = Array.from(items).every(item => item.kind === "file");
      if (isOnlyFiles) {
        const pdfFiles = Array.from(e.dataTransfer.files).filter(file => file.type === "application/pdf");
        if (pdfFiles.length > 0) {
          const dataTransfer = new DataTransfer();
          pdfFiles.forEach(file => dataTransfer.items.add(file));

          handleFiles(dataTransfer.files, true);
        } else {
          toast.error("Only PDF files are allowed");
        }
        return;
      }
    }
  };

  /**
   * Handles file selection from the file input element.
   *
   * @param e - The change event from the file input.
   */
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files, false);
    if (e.target.files?.length && e.target.files.length > 0) {
      setShowUploadDocumentModal(true);
    }
  };

  /**
   * Removes a file from the list of selected files by index.
   *
   * @param indexToRemove - The index of the file to be removed.
   */
  const removeFile = (indexToRemove: number) => {
    setSelectedFiles(prev => {
      const updatedFiles = prev.filter((_, index) => index !== indexToRemove);
      if (updatedFiles.length === 0) {
        setUploadedByDrag(false);
      }
      return updatedFiles;
    });
  };

  /**
   * Closes the upload document modal and resets file-related states.
   */
  const handleCloseUploadDocumentModal = () => {
    setShowUploadDocumentModal(false);
    setSelectedFiles([]);
    setUploadedByDrag(false);
    if (inputRef.current) {
      inputRef.current.value = "";
    }
  };

  /**
   * Handles uploading files for splitting.
   *
   * - Converts each selected file into a FileUploadDto with base64 encoding.
   * - Prepares the payload for the upload request.
   * - Dispatches the `uploadFileForSplit` action with the payload.
   */
  const handleUploadFileForSplit = async () => {
    const fileDtos: FileUploadDto[] = await Promise.all(
      selectedFiles.map(async file => ({
        name: file.name,
        type: file.type,
        base64: await convertFileToBase64(file),
      }))
    );

    const payload: IUploadFileForSplitRequest = {
      files: fileDtos,
    };
    await dispatch(uploadFileForSplit(payload));
    handleCloseUploadDocumentModal();
    fetchFileUploadedData();
  };

  /**
   * Fetches paginated data of uploaded files for splitting.
   *
   * - Dispatches the `getAllUploadedFileForSplit` thunk via `handleThunkWithDecrypt`.
   * - Decrypts the API response into a typed `IPaginatedResponse`.
   * - Updates the total file count in state if the response contains data.
   */
  const fetchFileUploadedData = async () => {
    const response = await handleThunkWithDecrypt<IPaginatedResponse<IFileUploadResponseForSplitVM>, IPaginatedRequest>(
      dispatch,
      getAllUploadedFileForSplit,
      request
    );
    if (response?.data) {
      setFilesFromBE(response.data.items);
      setTotalCount(response.data.totalCount);
    }
  };

  /**
   * Handles changes in the search input field.
   *
   * - Updates the `searchTerm` in the request state with the latest input value.
   *
   * @param e - The change event from the search input field.
   */
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRequest(prev => ({
      ...prev,
      searchTerm: e.target.value,
    }));
  };

  /**
   * Handles the search button click.
   *
   * - Triggers a fetch of the uploaded file data based on the current request state.
   */
  const handleSearchClick = () => {
    fetchFileUploadedData();
  };

  /**
   * Handles the confirmation of file deletion.
   *
   * - Dispatches the `deleteUploadedFile` action with the selected file ID.
   * - Closes the delete confirmation modal after successful deletion.
   * - Resets the selected file ID.
   * - Refreshes the uploaded file list.
   */
  const handleConfirmDelete = async () => {
    if (selectedDeleteId !== null) {
      await dispatch(deleteUploadedFile(selectedDeleteId));
      setShowDeleteModal(false);
      setSelectedDeleteId(null);
      fetchFileUploadedData();
    }
  };

  /**
   * Opens the delete confirmation modal for a specific file.
   *
   * @param id - The ID of the file to delete.
   */
  const handleOpenDeleteModal = (id: string) => {
    setSelectedDeleteId(id);
    setShowDeleteModal(true);
  };

  /**
   * Opens the edit modal for a specific file.
   *
   * - Sets the selected file in state for editing.
   * - Displays the edit modal.
   *
   * @param file - The file object selected for editing.
   */
  const handleOpenEditModal = (file: IFileUploadResponseForSplitVM) => {
    setFileForEdit(file);
    setShowEditModal(true);
  };

  /**
   * Closes the edit modal.
   *
   * - Clears the selected file from state.
   * - Hides the edit modal.
   */
  const handleCloseEditModal = () => {
    setFileForEdit(null);
    setShowEditModal(false);
  };

  /**
   * Opens the preview modal for a selected file.
   *
   * - Sets the preview file name in state.
   * - Appends a timestamp query parameter to the file URL to prevent caching issues.
   * - Updates the preview file URL in state.
   * - Displays the preview modal.
   *
   * @param file - The file object selected for preview.
   */
  const handleOpenPreviewModal = async (file: IFileUploadResponseForSplitVM) => {
    setPreviewFileName(file.name);
    const timestamp = new Date().getTime();
    const fileUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${file.url}?v=${timestamp}`;
    setPreviewFileUrl(fileUrl);
    setPreviewModalOpen(true);
  };

  /**
   * Closes the preview modal.
   *
   * - Hides the preview modal.
   * - Clears the preview file name and URL from state.
   */
  const handleClosePreviewModal = () => {
    setPreviewModalOpen(false);
    setPreviewFileUrl("");
    setPreviewFileName("");
  };

  useEffect(() => {
    fetchFileUploadedData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request.pageNumber]);

  /**
   * Handles the click event for the "Split PDF" button.
   *
   * - Closes the preview modal.
   * - Opens the new split PDF modal.
   * - Extracts the file name from the file URL.
   * - Sets the split file name in state.
   * - Adjusts the selected pages (converts zero-based indices to one-based).
   *
   * @param pages - The array of selected page indices (zero-based).
   * @param fileurl - The URL of the file to split.
   */
  const handleClickSplitPdfButton = (pages: number[], fileurl: string, fileName: string) => {
    handleClosePreviewModal();
    setOpenNewSplitPdfModal(true);

    const fileNameFromUrl = fileurl.split("?")[0].split("/").pop();
    if (fileNameFromUrl) {
      setSplitFileNameFromUrl(fileNameFromUrl);
      setSplitFileName(fileName);
      setSelectedPages(pages.map(i => i + 1));
    }
  };

  /**
   * Closes the new split PDF modal.
   *
   * - Hides the modal.
   * - Resets the split file name and selected pages.
   */
  const handleCloseNewSplitPdfModal = () => {
    setOpenNewSplitPdfModal(false);
    setSplitFileNameFromUrl("");
    setSplitFileName("");
    setSelectedPages([]);
  };

  /**
   * Downloads a file from the server and saves it to the user's device.
   *
   * - Constructs the full file URL using the base API URL.
   * - Sends a GET request to fetch the file.
   * - Converts the response into a Blob and creates a temporary URL.
   * - Triggers a download using a hidden `<a>` element.
   * - Ensures the file has a `.pdf` extension if missing.
   * - Cleans up the temporary object URL after download.
   *
   * @param fileUrl - The relative URL of the file to download.
   * @param fileName - The desired name of the file when saved locally.
   */
  const handleDownloadFile = async (fileUrl: string, fileName: string) => {
    const fullUrl = `${process.env.NEXT_PUBLIC_USER_API_URL}${fileUrl}`;
    try {
      const response = await fetch(fullUrl, {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error("Failed to fetch file");
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = fileName.endsWith(".pdf") ? fileName : `${fileName}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Download error:", error);
    }
  };

  const totalPages = Math.ceil(totalCount / request.pageSize);
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex justify-between items-center mb-6">
        <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">Split & Upload</h4>
        <button
          onClick={() => router.back()}
          className="px-4 py-2 text-sm font-medium text-white bg-[#7E57C2] hover:bg-[#6C4FB3] rounded-md shadow"
        >
          Back
        </button>
      </div>
      <div className="mt-4 p-4 bg-white rounded space-y-4">
        <div
          className={`border-2 border-dashed ${
            dragActive ? "border-green-400 bg-green-50" : "border-gray-300"
          } rounded p-6 flex flex-col gap-2 items-center text-gray-500 text-center transition-all`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        >
          {!uploadedByDrag && (
            <>
              <span className="text-4xl">📄</span>
              <p className="text-sm md:text-base">Drag and Drop PDF file(s) here</p>
            </>
          )}
          {uploadedByDrag && selectedFiles.length > 0 && (
            <ul className="w-full space-y-2">
              {selectedFiles.map((file, index) => (
                <li
                  key={index}
                  className="bg-white border rounded flex justify-between items-center px-3 py-1 text-sm text-gray-700"
                >
                  <span className="truncate">{file.name}</span>
                  <button onClick={() => removeFile(index)} className="text-red-500 hover:text-red-700">
                    <X className="w-4 h-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="flex justify-start">
          {!uploadedByDrag && (
            <button
              onClick={() => inputRef.current?.click()}
              className="px-4 py-2 rounded text-sm md:text-base border transition-colors duration-200 bg-[#198754] border-[#198754] text-white hover:bg-green-700"
            >
              Select File
            </button>
          )}
          {uploadedByDrag && selectedFiles.length > 0 && (
            <button
              onClick={() => {
                setShowUploadDocumentModal(true);
              }}
              className="px-4 py-2 rounded text-sm md:text-base border transition-colors duration-200 bg-[#198754] border-[#198754] text-white hover:bg-green-700"
            >
              Click here to Upload Files
            </button>
          )}
          <input
            type="file"
            accept="application/pdf"
            multiple
            ref={inputRef}
            className="hidden"
            onChange={handleFileSelect}
          />
        </div>
        <UploadDocumentDrawerWithoutTabs
          open={showUploadDocumentModal}
          onClose={handleCloseUploadDocumentModal}
          selectedFiles={selectedFiles}
          removeFile={removeFile}
          onUpload={handleUploadFileForSplit}
        />
      </div>
      <div className="mt-8 p-4 bg-white rounded space-y-4">
        <div className="flex justify-end w-full gap-2">
          <div>
            <CommonTextField
              name="search"
              placeholder="Enter Name for search"
              type="text"
              className="transition-all duration-200 md:w-[300px] w-full max-w-sm"
              onChange={handleSearchChange}
              sx={{
                "& .MuiInputBase-root": {
                  height: "40px",
                  fontSize: "14px",
                },
                "& input": {
                  padding: "8px 12px",
                },
              }}
            />
          </div>
          <button
            onClick={handleSearchClick}
            className="px-4 py-2 text-sm font-medium text-white bg-[#7E57C2] hover:bg-[#6C4FB3] rounded-md shadow"
          >
            Search
          </button>
        </div>
        <div className="overflow-auto w-full mt-4">
          <table className="min-w-[800px] w-full border border-[#dee2e6]">
            <thead className="bg-[#f5f6f9]">
              <tr className="text-sm text-[#888] whitespace-nowrap">
                <th className="px-3 py-2 text-left">File Name</th>
                <th className="px-3 py-2 text-left">Size</th>
                <th className="px-3 py-2 text-left">Created Date</th>
                <th className="px-3 py-2 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="text-sm text-gray-800">
              {filesFromBE.map(file => (
                <tr key={file.id} className="border-t border-[#dee2e6]">
                  <td className="px-3 py-2 text-left">
                    <span
                      className="cursor-pointer text-blue-600 hover:underline hover:text-blue-800"
                      onClick={() => handleOpenPreviewModal(file)}
                    >
                      {file.name}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-left">{file.size}</td>
                  <td className="px-3 py-2 text-left">{moment(file.createdAt).format("DD/MM/YYYY")}</td>
                  <td className="px-3 py-2 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <IconButton color="primary" onClick={() => handleOpenEditModal(file)}>
                        <Edit />
                      </IconButton>
                      <IconButton color="error" onClick={() => handleOpenDeleteModal(file.id)}>
                        <Trash2 />
                      </IconButton>
                      <IconButton color="primary" onClick={() => handleDownloadFile(file.url, file.name)}>
                        <Download />
                      </IconButton>
                    </div>
                  </td>
                </tr>
              ))}
              {filesFromBE.length === 0 && (
                <tr className="border-t border-[#dee2e6]">
                  <td colSpan={4} className="px-4 py-2 text-center text-sm text-gray-500">
                    No files available!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex justify-end">
          {filesFromBE.length > 0 && (
            <Pagination
              count={totalPages}
              page={request.pageNumber}
              onChange={(_, page) => {
                setRequest(prev => ({
                  ...prev,
                  pageNumber: page,
                }));
              }}
              color="primary"
              variant="outlined"
              shape="rounded"
            />
          )}
        </div>
        <ConfirmDeleteModal
          open={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={handleConfirmDelete}
          title="Delete File?"
          message="This action cannot be undone. Are you sure you want to delete this file?"
        />
        <UploadFileSplitDrawer
          open={showEditModal}
          onClose={handleCloseEditModal}
          handleSuccess={() => fetchFileUploadedData()}
          fileForEdit={fileForEdit}
        />
        <PdfPreviewModal
          open={previewModalOpen}
          onClose={handleClosePreviewModal}
          fileUrl={previewFileUrl}
          fileName={previewFileName}
          handleClickSplitPdfButton={handleClickSplitPdfButton}
        />
        <NewSplitPdfModal
          open={openNewSplitPdfModal}
          onClose={handleCloseNewSplitPdfModal}
          handleSuccess={() => fetchFileUploadedData()}
          splitFileNameFromUrl={splitFileNameFromUrl}
          selectedPages={selectedPages}
          splitFileName={splitFileName}
        />
      </div>
    </div>
  );
};
