import { Card, CardContent, MenuItem, Select } from "@mui/material";
import { StyledFormLabel } from "@core/components";
import { IUserTemplate } from "@main/models";

type Props = {
  userTemplate: IUserTemplate[];
  selectedTemplate: string;
  setSelectedTemplate: (id: string) => void;
  getTemplateTabs: (id: string) => void;
  setSelectedTemplateName: (name: string) => void;
};

export const Step1TemplateSelection: React.FC<Props> = ({
  userTemplate,
  selectedTemplate,
  setSelectedTemplate,
  getTemplateTabs,
  setSelectedTemplateName,
}) => {
  return (
    <Card className="mb-8 p-2">
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex flex-col">
            <StyledFormLabel>
              Please select template <span className="text-red-600">*</span>
            </StyledFormLabel>
            <Select
              fullWidth
              displayEmpty
              value={selectedTemplate}
              sx={{ height: 40 }}
              onChange={e => {
                const id = e.target.value;
                const template = userTemplate.find(t => t.id === id);
                setSelectedTemplate(id);
                setSelectedTemplateName(template?.name || "");
                getTemplateTabs(id);
              }}
            >
              <MenuItem value={""} disabled>
                Select Template
              </MenuItem>
              {userTemplate.map(userTemplate => (
                <MenuItem key={userTemplate.id} value={userTemplate.id}>
                  {userTemplate.name}
                </MenuItem>
              ))}
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
