import React, { useCallback, useEffect, useState } from "react";
import { Dialog, DialogTitle, DialogContent, Box, DialogActions, MenuItem, Select } from "@mui/material";
import { X } from "lucide-react";
import { handleThunkWithDecrypt } from "@core/utils";
import { IFolderListResponse, IFolderTabListResponse } from "@main/models";
import { getAllFolderList, getAllFolderTabList } from "@main/store";
import { useAppDispatch } from "@main/hooks";
import { useSplitPdf } from "./NewSplitPdfModal.hook";
import { CommonTextField } from "@core/components";
import { Constant } from "@core/constants/Constant";
import { Controller } from "react-hook-form";

interface NewSplitPdfModalProps {
  open: boolean;
  onClose: () => void;
  handleSuccess: () => void;
  splitFileNameFromUrl: string;
  splitFileName: string;
  selectedPages: number[];
}

const NewSplitPdfModal: React.FC<NewSplitPdfModalProps> = ({
  open,
  onClose,
  handleSuccess,
  splitFileNameFromUrl,
  splitFileName,
  selectedPages,
}) => {
  const [folderList, setFolderList] = useState<IFolderListResponse[]>([]);
  const [folderTabList, setFolderTabList] = useState<IFolderTabListResponse[]>([]);
  const dispatch = useAppDispatch();
  const { register, errors, control, handleSubmit, onSubmit, setValue } = useSplitPdf(
    splitFileNameFromUrl,
    splitFileName,
    onClose,
    handleSuccess,
    selectedPages,
    open
  );

  /**
   * Fetches the list of all active folders.
   *
   * - Dispatches the `getAllFolderList` thunk through `handleThunkWithDecrypt`.
   * - Decrypts the API response into a list of `IFolderListResponse` objects.
   * - Updates the local `folderList` state if data is returned.
   */
  const getAllActiveFolderList = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IFolderListResponse[]>(dispatch, getAllFolderList);
    if (response?.data) {
      setFolderList(response.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Handles the folder selection change event.
   *
   * - If a valid folder ID is selected, fetches the list of tabs for that folder.
   * - Updates the `folderTabList` state with the response data.
   * - Clears the `folderTabList` if no folder is selected.
   * - Resets the `tabId` form value to ensure a fresh selection.
   *
   * @param folderId - The selected folder ID, or an empty string if no folder is selected.
   */
  const handleFolderChange = async (folderId: string | "") => {
    if (folderId !== "") {
      const response = await handleThunkWithDecrypt<IFolderTabListResponse[], string>(
        dispatch,
        getAllFolderTabList,
        folderId
      );
      if (response?.data) {
        setFolderTabList(response.data);
      }
    } else {
      setFolderTabList([]);
    }
    setValue("tabId", "");
  };

  useEffect(() => {
    getAllActiveFolderList();
  }, [getAllActiveFolderList]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="sm"
      PaperProps={{
        className: "rounded-2xl",
      }}
    >
      <DialogTitle className="!p-4 border-b border-[#dee2e6] !mb-0">
        <div className="flex items-center justify-between">
          <h5 className="font-medium text-xl text-black !mb-0">Tab</h5>
          <X className="text-gray-500 cursor-pointer" onClick={onClose} />
        </div>
      </DialogTitle>
      <Box component="form" onSubmit={handleSubmit(onSubmit)} noValidate>
        <DialogContent className="!p-4 !space-y-4">
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              New Split Pdf Name <span className="text-red-500">*</span>
            </span>
            <CommonTextField
              name="newSplitPdfFileName"
              placeholder="Enter new pdf name"
              register={register}
              validation={{ required: Constant.MESSAGE.FILE_NAME_REQ }}
              errors={errors}
              sx={{
                "& .MuiOutlinedInput-root": {
                  height: 40,
                },
              }}
            />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              Select Folder <span className="text-red-500">*</span>
            </span>
            <Controller
              name="folderId"
              control={control}
              rules={{ required: Constant.MESSAGE.FOLDER_SELECTION_REQUIRED }}
              render={({ field }) => (
                <Select
                  fullWidth
                  {...field}
                  onChange={e => {
                    const selectedValue = e.target.value;
                    field.onChange(selectedValue);
                    handleFolderChange(selectedValue);
                  }}
                  displayEmpty
                  error={!!errors.folderId}
                  sx={{
                    height: 40,
                    ".MuiSelect-select": {
                      display: "flex",
                      alignItems: "center",
                      height: "40px",
                      paddingTop: "0 !important",
                      paddingBottom: "0 !important",
                    },
                  }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        maxHeight: 188,
                        overflowY: "scroll",
                        "&::-webkit-scrollbar": { display: "none" },
                        scrollbarWidth: "none",
                        msOverflowStyle: "none",
                      },
                    },
                  }}
                >
                  <MenuItem value="">
                    <em>Select Folder</em>
                  </MenuItem>
                  {folderList.map(folder => (
                    <MenuItem key={folder.id} value={folder.id}>
                      {folder.folderName}
                    </MenuItem>
                  ))}
                </Select>
              )}
            />
            {errors.folderId && <span className="text-xs text-red-500 mt-1">{errors.folderId.message as string}</span>}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              Select Tab <span className="text-red-500">*</span>
            </span>
            <Controller
              name="tabId"
              control={control}
              rules={{ required: Constant.MESSAGE.TAB_SELECTION_REQUIRED }}
              render={({ field }) => (
                <Select
                  fullWidth
                  {...field}
                  displayEmpty
                  error={!!errors.tabId}
                  sx={{
                    height: 40,
                    ".MuiSelect-select": {
                      display: "flex",
                      alignItems: "center",
                      height: "40px",
                      paddingTop: "0 !important",
                      paddingBottom: "0 !important",
                    },
                  }}
                  MenuProps={{
                    PaperProps: {
                      sx: {
                        maxHeight: 188,
                        overflowY: "scroll",
                        "&::-webkit-scrollbar": { display: "none" },
                        scrollbarWidth: "none",
                        msOverflowStyle: "none",
                      },
                    },
                  }}
                >
                  <MenuItem value="">
                    <em>Select Tab</em>
                  </MenuItem>
                  {folderTabList.map(folderTab => (
                    <MenuItem key={folderTab.id} value={folderTab.id}>
                      {folderTab.tabName}
                    </MenuItem>
                  ))}
                </Select>
              )}
            />
            {errors.tabId && <span className="text-xs text-red-500 mt-1">{errors.tabId.message as string}</span>}
          </div>
        </DialogContent>
        <DialogActions className="flex flex-col sm:flex-row justify-center gap-2 sm:gap-1 border-t border-[#dee2e6] !p-4">
          <button
            onClick={onClose}
            type="button"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
          >
            Close
          </button>
          <button
            type="submit"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
          >
            Save
          </button>
        </DialogActions>
      </Box>
    </Dialog>
  );
};

export default NewSplitPdfModal;
