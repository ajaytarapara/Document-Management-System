import { useForm } from "react-hook-form";
import { ISplitPdfFormValues, ISplitPdfRequest } from "@main/models";
import { useAppDispatch } from "@main/hooks";
import { useEffect } from "react";
import { splitAndReplace } from "@main/store";
import { handleThunkWithDecrypt } from "@core/utils";

export const useSplitPdf = (
  splitFileNameFromUrl: string,
  splitFileName: string,
  onClose: () => void,
  handleSuccess: () => void,
  selectedPages: number[],
  open: boolean
) => {
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    control,
    reset,
    setValue,
    formState: { errors },
  } = useForm<ISplitPdfFormValues>({
    defaultValues: {
      newSplitPdfFileName: "",
      folderId: "",
      tabId: "",
    },
  });

  useEffect(() => {
    reset({ newSplitPdfFileName: "", folderId: "", tabId: "" });
  }, [reset, open]);

  /**
   * Handles form submission for splitting a PDF.
   *
   * - Builds the request payload from form values and selected state.
   * - Dispatches the `splitAndReplace` thunk to process the PDF split.
   * - Executes the success handler on completion.
   * - Closes the modal after the operation.
   *
   * @param data - The form values entered by the user for splitting the PDF.
   */
  const onSubmit = async (data: ISplitPdfFormValues) => {
    const request: ISplitPdfRequest = {
      originalFileNameFromUrl: splitFileNameFromUrl,
      originalFileName: splitFileName,
      newSplitPdfFileName: data.newSplitPdfFileName,
      folderId: data.folderId,
      tabId: data.tabId,
      selectedPages: selectedPages,
    };
    const decryptedResponse = await handleThunkWithDecrypt<null, ISplitPdfRequest>(dispatch, splitAndReplace, request);
    if (decryptedResponse.isSuccessful) {
      handleSuccess();
      onClose();
    }
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    control,
    setValue,
  };
};
