import React, { useState } from "react";
import { Dialog, DialogTitle, DialogContent, IconButton, Button } from "@mui/material";
import { X } from "lucide-react";
import { Viewer, Worker } from "@react-pdf-viewer/core";
import { defaultLayoutPlugin } from "@react-pdf-viewer/default-layout";

import "@react-pdf-viewer/core/lib/styles/index.css";
import "@react-pdf-viewer/default-layout/lib/styles/index.css";

interface PdfPreviewModalProps {
  open: boolean;
  onClose: () => void;
  fileUrl: string;
  fileName: string;
  handleClickSplitPdfButton: (pages: number[], fileUrl: string, fileName: string) => void;
}

const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  open,
  onClose,
  fileUrl,
  fileName,
  handleClickSplitPdfButton,
}) => {
  const defaultLayoutPluginInstance = defaultLayoutPlugin();
  const [selectedPages, setSelectedPages] = useState<number[]>([]);
  const [totalPages, setTotalPages] = useState<number>(0);

  /**
   * Toggles the selection state of a specific page.
   *
   * - If the page is already selected, it is removed from the selection.
   * - Otherwise, it is added to the selection.
   *
   * @param page - The page number to toggle.
   */
  const togglePageSelection = (page: number) => {
    setSelectedPages(prev => (prev.includes(page) ? prev.filter(p => p !== page) : [...prev, page]));
  };

  /**
   * Clears all selected pages.
   */
  const clearAll = () => {
    setSelectedPages([]);
  };

  /**
   * Handles the PDF split action.
   *
   * - Calls the split handler with the selected pages and file url.
   * - Resets selected pages and total page count after the split action.
   */
  const handleSplit = () => {
    handleClickSplitPdfButton(selectedPages, fileUrl, fileName);
    setSelectedPages([]);
    setTotalPages(0);
  };

  /**
   * Handles closing the current modal or component.
   *
   * - Resets selected pages and total page count.
   * - Invokes the provided `onClose` callback to close the modal.
   */
  const handleClose = () => {
    setSelectedPages([]);
    setTotalPages(0);
    onClose();
  };

  return (
    <Dialog open={open} onClose={handleClose} fullWidth maxWidth="lg">
      <DialogTitle className="flex justify-between items-center">
        <span>{fileName}</span>
        <IconButton onClick={handleClose}>
          <X />
        </IconButton>
      </DialogTitle>
      <DialogContent style={{ height: "80vh", position: "relative" }}>
        {fileUrl && (
          <>
            <div className="flex items-center justify-between mb-3 border-b border-gray-300 pb-2">
              <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap max-h-[50px] pr-4">
                <p className="font-medium mr-2 shrink-0">Select Pages:</p>
                {[...Array(totalPages)].map((_, index) => {
                  const pageNum = index;
                  const isSelected = selectedPages.includes(pageNum);
                  return (
                    <button
                      key={pageNum}
                      onClick={() => togglePageSelection(pageNum)}
                      className={`px-2 py-1 rounded border text-sm font-medium shrink-0
                        ${isSelected ? "border-[#7E57C2] bg-[#ede7f6]" : "border-gray-400 bg-white"}
                      `}
                    >
                      {pageNum + 1}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center gap-2 shrink-0 pl-4">
                <Button variant="outlined" onClick={clearAll} size="small" className="!min-w-fit">
                  Clear All
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  size="small"
                  disabled={selectedPages.length === 0 || totalPages === 1}
                  onClick={handleSplit}
                  className="!min-w-fit"
                >
                  Split Selected Pages
                </Button>
              </div>
            </div>
            <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
              <Viewer
                fileUrl={fileUrl}
                plugins={[defaultLayoutPluginInstance]}
                onDocumentLoad={e => setTotalPages(e.doc.numPages)}
              />
            </Worker>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PdfPreviewModal;
