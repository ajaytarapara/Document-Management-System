import * as React from "react";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import type { ThemeOptions } from "@mui/material/styles";

interface AppThemeProps {
  children: React.ReactNode;
  disableCustomTheme?: boolean;
  themeComponents?: ThemeOptions["components"];
}

declare module "@mui/material/styles" {
  interface Palette {
    custom: {
      hoverPrimary: string;
    };
  }

  interface PaletteOptions {
    custom?: {
      hoverPrimary?: string;
    };
  }
}

export const AppTheme = (props: AppThemeProps) => {
  const { children, disableCustomTheme, themeComponents } = props;

  const theme = React.useMemo(() => {
    return disableCustomTheme
      ? {}
      : createTheme({
          palette: {
            primary: {
              main: "#7E57C2",
            },
            secondary: {
              main: "#00092A",
            },
            custom: {
              hoverPrimary: "#5E35B1",
            },
          },
          components: {
            MuiDialog: {
              styleOverrides: {
                paper: {
                  borderRadius: 5,
                  backgroundColor: "#ffffff",
                },
              },
            },
            MuiDialogTitle: {
              styleOverrides: {
                root: {
                  fontWeight: 700,
                  fontSize: "1.25rem",
                  color: "#263238",
                  padding: "10px 10px 10px 16px !important",
                  marginBottom: "24px",
                  borderBottom: "1px solid #9e9e9e",
                },
              },
            },
            MuiDialogContentText: {
              styleOverrides: {
                root: {
                  fontSize: "1rem",
                  color: "#555",
                },
              },
            },
            MuiButton: {
              styleOverrides: {
                root: {
                  textTransform: "capitalize",
                },
              },
            },
            ...(themeComponents ?? {}),
          },
        });
  }, [disableCustomTheme, themeComponents]);

  if (disableCustomTheme) {
    return <>{children}</>;
  }

  return (
    <ThemeProvider theme={theme} disableTransitionOnChange>
      {children}
    </ThemeProvider>
  );
};
