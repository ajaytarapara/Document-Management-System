export interface IUserTemplateResponse {
  id: string;
  name: string;
  tabsCount: string;
}
