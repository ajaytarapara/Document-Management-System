export interface IUserLoginSummaryVM {
  date: string;
  day: string;
  loginCount: number;
}

export interface IUserLoginSummaryResponseVM {
  userLoginSummaryVMs: IUserLoginSummaryVM[];
}

export interface IUsersResponse {
  id: string;
  userName: string;
}
