import { IPaginatedRequest } from "@core/models";

export interface IUserTemplateRequestVM extends IPaginatedRequest {
  userId: string;
}
