import { UseFormRegister, FieldErrors } from "react-hook-form";
import { PaginationRequest } from "../auth/User.interface";
import { IEncryptedApiResponse } from "@core/models";
import { FieldBase } from "@main/components/EditableForms";

export interface IDmsForm {
  id: string;
  name: string;
  size: number;
  url: string;
  createdAt: string;
  status: string;
  fields?: FieldBase[];
  submittedBy?: string;
  submittedAt?: string;
}

export interface IRequestUploadDmsForms {
  forms: File[];
  userId: string;
}

export interface DmsFormPaginationRequest extends PaginationRequest {
  userId: string;
  searchTerm?: string;
  sortBy?: string;
  sortDirection?: "asc" | "desc";
  status?: string;
  token?: string;
}

export interface RenameDmsFormRequest {
  dmsFormId: string;
  newFileName: string;
  userId: string;
}

export interface DeleteDmsFormRequest {
  dmsFormId: string;
  userId: string;
  password: string;
}

export interface GetDmsFormByIdRequest {
  formId: string;
  userId: string;
}

export interface GetDmsUserFormByIdRequest {
  id: number;
  userId: number;
}

export interface DeleteFormValues {
  password: string;
}

export interface EditFormValues {
  name: string;
}

export interface DeleteFileProps {
  register: UseFormRegister<DeleteFormValues>;
  errors: FieldErrors<DeleteFormValues>;
}

export interface EditFileProps {
  editRegister: UseFormRegister<EditFormValues>;
  editErrors: FieldErrors<EditFormValues>;
}

export interface ShareDmsForms {
  fromEmail: string;
  toEmail: string;
  toName: string;
  subject: string;
  message?: string;
  linkExpiration: number;
}

export interface ShareDmsFileModalProps {
  fileName: string;
  open: boolean;
  folderId: string | null;
  onClose: () => void;
  onShare: (folderId: string, data: ShareDmsForms) => Promise<IEncryptedApiResponse | undefined>;
}

export interface ShareDmsFormArgs {
  formIds: string[];
  data: ShareDmsForms;
}

export interface SaveEditedFormRequest {
  formId: string;
  userId: string;
  file: string;
  fields: FieldBase[];
  userRole?: string;
  token?: string;
}

export interface SubmitEditedFormRequest {
  formId: string;
  userId: string;
  file: string;
  fields: FieldBase[];
  submittedBy: string;
  userRole?: string;
  token?: string;
}
