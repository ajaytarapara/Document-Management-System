export interface FileUploadDto {
  name: string;
  type: string;
  base64: string;
}

export interface IUploadFileForSplitRequest {
  files: FileUploadDto[];
}

export interface IUpdateFileNameForSplitRequest {
  id: string;
  name: string;
}

export interface IUpdateFileNameForSplitForm {
  name: string;
}
