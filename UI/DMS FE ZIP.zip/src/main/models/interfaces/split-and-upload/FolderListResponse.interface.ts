export interface IFolderListResponse {
  id: string;
  folderName: string;
}
