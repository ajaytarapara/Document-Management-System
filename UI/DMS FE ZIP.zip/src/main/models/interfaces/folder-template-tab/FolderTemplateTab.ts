export interface IUserTemplate {
  id: string;
  name: string;
}

export interface IUserTemplateTabs {
  name: string;
  id: string;
  color: string;
  isLock: boolean;
}

export interface IUserTemplateTabsUI extends IUserTemplateTabs {
  editing?: boolean;
  readonly?: boolean;
}

export interface IUserTemplateTabVM {
  templateId: string;
  tabName: string;
  color: string;
  isLock?: boolean | null;
}

export interface IAddTemplateTabRequestVM {
  templateTabs: IUserTemplateTabVM[];
  templateId: string;
}

export interface FolderListResponseVM {
  id: number;
  folderName: string;
  firstName: string;
  lastName: string;
  fileNumber: string;
  tabsCount?: number;
}

export interface IAddFolderTabRequestVM {
  templateTabs: IUserTemplateTabVM[];
  selectedFolder: number[];
}
