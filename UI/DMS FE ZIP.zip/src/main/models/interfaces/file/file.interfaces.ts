import { PaginationRequest } from "../auth/User.interface";
import { FolderListDto, TabResponse } from "../folder/folder.interfaces";

export interface FilesUploadDto {
  folderId: string;
  files: FileUploadItemDto[];
}
export interface FileUploadItemDto {
  fileName: string;
  contentType: string;
  base64Content: string;
  folderTabId: string;
}
export interface FileListDto {
  id: string;
  name: string;
  url: string;
  type: string;
  size: string;
  createdAt?: string;
}
export interface FileListDtos {
  fileListDto: FileListDto[];
  totalCount: number;
}
export interface UpdateFileArgs {
  id: string;
  name: string;
}
export interface GetFiles {
  id: string[];
}
export interface GetFilesPageination {
  files: GetFiles;
  pagination: PaginationRequest;
}
export interface GetFolderTabs {
  folderTabDto: TabResponse[];
  folderName: string;
}
export interface GetFolderList {
  getFolderDto: FolderListDto[];
}
export interface MoveFileDto {
  fileId: string[];
  TargetFolderId?: string;
  targetFolderTabId: string;
}
export interface MoveFileTabDto {
  fileId: string;
  targetFolderTabId: string;
}
