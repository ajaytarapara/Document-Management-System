export interface IUserTemplateTabResponse {
  id: number;
  name: string;
  color: string;
  isLock: boolean;
}

export interface IUserTemplateResponseWithTabsVM {
  id: number;
  name: string;
  tabsCount: string;
  tabs: IUserTemplateTabResponse[];
}
