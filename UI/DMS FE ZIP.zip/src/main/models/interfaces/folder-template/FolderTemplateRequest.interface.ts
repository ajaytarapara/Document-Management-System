export interface IUserTemplateTabRequest {
  name: string;
  color: string;
  isLock: boolean;
}

export interface IAddUserTemplateRequest {
  userId: string;
  name: string;
  tabsCount: string;
  tabs: IUserTemplateTabRequest[];
}

export interface IUpdateUserTemplateRequest {
  id: string;
  userId: string;
  name: string;
  tabsCount: string;
  tabs: IUserTemplateTabRequest[];
}
