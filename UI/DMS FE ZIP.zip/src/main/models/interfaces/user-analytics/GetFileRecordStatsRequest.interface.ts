import { IPaginatedRequest } from "@core/models";

export interface IFileRecordStatsRequest extends IPaginatedRequest {
  dateRangeType: string;
  officeUserId?: string;
  customStartDate?: string;
  customEndDate?: string;
  isForOfficeUser: boolean;
}
