export interface IFileRecordStatsResponse {
  totalFolderCount: number;
  totalFileSizeBytes: number;
  breakdown: IBreakdownRecord[];
  officeUserName: string;
  userName: string;
  officeUserId: number;
}

export interface IBreakdownRecord {
  label: string;
  folderCount: number;
  totalFileSizeBytes: number;
}
