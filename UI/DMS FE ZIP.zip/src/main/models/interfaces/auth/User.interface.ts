export interface IUser {
  userId: string;
  email: string;
  username: string;
  fullName: string;
  role: string;
  token: string;
}

export interface ICreateUserForm {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  roleName?: string;
  lastLoginDate?: string;
  postalCode: number;
  userName: string;
  privilegeDelete: boolean;
  privilegeDownload: boolean;
  privilegeView: boolean;
  hideLockTabs: boolean;
  maxTabLimit?: number;
  isActive: boolean;
  loginType: string;
}

export interface IUserData {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  passwordHash: string;
  role: number;
  userName: string;
  address: string;
  postalCode: number;
  phoneNumber: number;
  isActive: boolean;
  createdBy: number;
  createdAt: string;
  city?: string | null;
  updatedBy?: number | null;
  updatedAt?: string | null;
  isDeleted?: boolean | null;
  deletedBy?: number | null;
  deletedAt?: string | null;
}

export interface IUserDetail {
  id: string;
  name: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  postalCode: number;
  userName: string;
  role: number;
  roleName: string;
  privilegeDelete: boolean | null;
  privilegeDownload: boolean | null;
  privilegeView: boolean | null;
  hideLockTabs: boolean | null;
  isActive: boolean;
}

export interface IUserFilter {
  userName: string;
  officeUser: string;
  roleType: "Office User" | "User" | "";
}

export interface UserFilterRequest extends PaginationRequest, Partial<IUserFilter> {}

export interface PaginationRequest {
  pageNumber: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: "Asc" | "Desc";
  searchKey?: string;
}

export interface PaginationResponse<T> {
  items: T[];
  totalCount: number;
  pageIndex: number;
  pageSize: number;
  totalPages: number;
  sortDirection?: string;
  sortColumn?: string;
}

export interface IUpdateUserForm {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  address: string;
  city: string;
  roleName?: string;
  lastLoginDate?: string;
  postalCode: number;
  assignedOffices?: string;
  userName: string;
  privilegeDelete: boolean;
  privilegeDownload: boolean;
  privilegeView: boolean;
  hideLockTabs: boolean;
  maxTabLimit?: number;
  isActive: boolean;
  loginType: string;
}

export interface OfficeUser {
  id: number;
  userName: string;
  name: string;
}
