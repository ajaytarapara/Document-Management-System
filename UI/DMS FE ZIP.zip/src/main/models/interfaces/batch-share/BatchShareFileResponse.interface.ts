export interface IBatchShareTabAndFileResponse {
  id: string;
  name: string;
  type: string;
  size: string;
  url: string;
  createdAt: string;
}
