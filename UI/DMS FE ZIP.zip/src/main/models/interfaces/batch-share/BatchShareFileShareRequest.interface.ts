export interface IBatchShareRequestDto {
  fileIds: string[];
  fromEmail: string;
  toEmail: string;
  toName: string;
  subject: string;
  message?: string;
  linkExpiration: number;
  viewOnly: boolean;
  type: string;
}
