import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { authReducer } from "./slices/authSlice";
import { loaderReducer } from "./slices/loaderSlice";

import storage from "redux-persist/lib/storage";
import { persistReducer, persistStore } from "redux-persist";
import { batchShareReducer } from "./slices/batchShareSlice";

// Combine individual reducers into a single root reducer
const rootReducer = combineReducers({
  loader: loaderReducer,
  auth: authReducer,
  batchShare: batchShareReducer,
});

// Configuration for redux-persist to enable state persistence
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["auth"],
};

// Create a persisted reducer using the config above
const persistedReducer = persistReducer(persistConfig, rootReducer);

// Configure the Redux store with the persisted reducer
export const store = configureStore({
  reducer: persistedReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
  devTools: true,
});

// Create a persistor to manage persistence logic
export const persistor = persistStore(store);

// Export types for use throughout the app
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
