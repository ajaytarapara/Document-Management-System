import { createSlice } from "@reduxjs/toolkit";

import { ILoaderState } from "@core/models";

const initialState: ILoaderState = {
  isLoading: false,
};

const loaderSlice = createSlice({
  name: "loader",
  initialState,
  reducers: {
    showLoader: (state: ILoaderState) => {
      state.isLoading = true;
    },
    hideLoader: (state: ILoaderState) => {
      state.isLoading = false;
    },
  },
});

export const { showLoader, hideLoader } = loaderSlice.actions;
export const loaderReducer = loaderSlice.reducer;
