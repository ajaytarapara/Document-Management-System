import { createAsyncThunk } from "@reduxjs/toolkit";

import { axiosInstance } from "@core/utils";
import { API_URLS } from "@core/constants";
import { IAPIResponse, IEncryptedApiResponse } from "@core/models";
import { ICreateUserForm, IUserData, UserFilterRequest, IUpdateUserForm } from "@main/models";

const baseUserUrl = `${API_URLS.ADMIN.GET_ALL_USER}`;
const getUserByIdUrl = `${API_URLS.ADMIN.getUserById}`;
const getAllOfficeUserUrl = `${API_URLS.ADMIN.getAllOfficeUser}`;

/**
 * Creates a new user.
 * - Sends a POST request with user form data.
 * - Returns the created user details.
 *
 * @param payload - The form data for creating a user.
 */
export const createUser = createAsyncThunk<
  IAPIResponse<IUserData>,
  ICreateUserForm,
  { rejectValue: IAPIResponse<null> }
>("user/create", async payload => {
  const response = await axiosInstance.post<IAPIResponse<IUserData>>(baseUserUrl, payload);
  return response.data;
});

/**
 * Fetches a paginated list of users with filters and sorting options.
 * - Defaults sorting by `CreatedAt` in descending order if no sort field is provided.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param payload - The filter, pagination, and sorting options.
 */
export const getUsers = createAsyncThunk<IEncryptedApiResponse, UserFilterRequest>("user/getAll", async payload => {
  const { pageNumber = 1, pageSize = 100, searchKey, ...filters } = payload;
  let { sortBy = "", sortOrder = "Asc" } = payload;

  if (sortBy === "") {
    sortOrder = "Desc";
    sortBy = "CreatedAt";
  }

  const requestBody = {
    pageNumber,
    pageSize,
    sortBy,
    sortOrder,
    searchKey,
    ...filters,
  };

  const response = await axiosInstance.post<IEncryptedApiResponse>(baseUserUrl, requestBody, {
    headers: { showToast: false },
  });

  return response.data;
});

/**
 * Updates user details.
 * - Sends a PUT request with updated user form data.
 * - Returns the updated user details.
 *
 * @param payload - The form data for updating a user.
 */
export const updateUser = createAsyncThunk<IAPIResponse<IUserData>, IUpdateUserForm>("user/update", async payload => {
  const response = await axiosInstance.put<IAPIResponse<IUserData>>(`${baseUserUrl}`, payload);
  return response.data;
});

/**
 * Fetches a user by their ID.
 * - Sends a GET request using the user ID.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param id - The unique identifier of the user.
 */
export const getUserById = createAsyncThunk<IEncryptedApiResponse, string>("user/getUserById", async id => {
  const response = await axiosInstance.get<IEncryptedApiResponse>(`${getUserByIdUrl}/${id}`, {
    headers: { showToast: false },
  });
  return response.data;
});

/**
 * Deletes a user by their ID.
 * - Sends a DELETE request with the user ID.
 * - Returns a success/failure response.
 *
 * @param userId - The unique identifier of the user to delete.
 */
export const deleteUser = createAsyncThunk<IAPIResponse<null>, string>("user/delete", async userId => {
  const response = await axiosInstance.delete<IAPIResponse<null>>(`${baseUserUrl}/${userId}`);
  return response.data;
});

/**
 * Fetches all office users.
 * - Sends a GET request.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 */
export const getAllOfficeUsers = createAsyncThunk<IEncryptedApiResponse, null>("user/getAllOfficeUsers", async () => {
  const response = await axiosInstance.get<IEncryptedApiResponse>(getAllOfficeUserUrl, {
    headers: { showToast: false },
  });
  return response.data;
});
