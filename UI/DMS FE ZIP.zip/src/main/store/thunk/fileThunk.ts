import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@core/constants";
import { axiosInstance } from "@core/utils";
import { IEncryptedApiResponse } from "@core/models";
import { FilesUploadDto, GetFiles, MoveFileDto, MoveFileTabDto, ShareFolderArgs, UpdateFileArgs } from "@main/models";
import { ShareFolderForm } from "@main/components";

const fileUpload = `${API_URLS.USER.FILE_UPLOAD}`;
const getFile = `${API_URLS.USER.GET_FILE}`;
const deleteFilePath = `${API_URLS.USER.DELETE_FILE}`;
const updateFilePath = `${API_URLS.USER.UPDATE_FILE}`;
const getFolderTabsPath = `${API_URLS.USER.GET_FOLDER_TAB}`;
const getAllFolders = `${API_URLS.USER.GET_FOLDER_LIST}`;
const movefiles = `${API_URLS.USER.MOVE_FILE}`;
const changeFileTab = `${API_URLS.USER.CHANGE_TAB}`;
const shareFileUrl = `${API_URLS.USER.SHARE_FILE}`;
const shareMulFileUrl = `${API_URLS.USER.SHARE_MUL_FILE}`;
const getMultipleFiles = `${API_URLS.USER.GET_MUL_FILES}`;
/**
 * 📂 Uploads a new file.
 * - Sends a POST request with file data.
 * - Returns the encrypted API response.
 *
 * @param data - File data (FilesUploadDto).
 */
export const uploadFile = createAsyncThunk<IEncryptedApiResponse, FilesUploadDto>(
  "uploadFile",
  async (data: FilesUploadDto) => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(fileUpload, data);
    return res.data;
  }
);

/**
 * 📂 Retrieves files inside a specific tab.
 * - Supports pagination, sorting, and search.
 * - Disables toast notifications in headers.
 * - Returns the encrypted API response.
 *
 * @param page - Current page number.
 * @param pageSize - Number of items per page.
 * @param sortDirection - Sorting order ("asc" / "desc").
 * @param sortColumn - Column to sort by.
 * @param searchTerm - Search keyword.
 * @param id - Tab ID.
 */
export const getFileByTabs = createAsyncThunk<
  IEncryptedApiResponse,
  { page: number; pageSize: number; sortDirection: string; sortColumn: string; searchTerm: string; id: string }
>("getFileByTabs", async ({ page, pageSize, sortDirection, sortColumn, searchTerm, id }) => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(`${getFile}/${id}`, {
    params: {
      page,
      pageSize,
      sortColumn,
      sortDirection,
      searchTerm,
    },
    headers: {
      showToast: false,
    },
  });
  return res.data;
});

/**
 * 🗑️ Deletes a file by its ID.
 * - Sends a DELETE request.
 * - Returns the encrypted API response.
 *
 * @param id - File ID to delete.
 */
export const deleteFile = createAsyncThunk<IEncryptedApiResponse, { id: string }>("deleteFile", async ({ id }) => {
  const res = await axiosInstance.delete<IEncryptedApiResponse>(`${deleteFilePath}/${id}`);
  return res.data;
});

/**
 * ✏️ Updates file details (rename or metadata).
 * - Sends a PUT request with update payload.
 * - Returns the encrypted API response.
 *
 * @param updateFile - File update data.
 */
export const updateFile = createAsyncThunk<IEncryptedApiResponse, UpdateFileArgs>(
  "updateFile",
  async (updateFile: UpdateFileArgs) => {
    const res = await axiosInstance.put<IEncryptedApiResponse>(`${updateFilePath}`, updateFile);
    return res.data;
  }
);

/**
 * 📑 Fetches all tabs (categories) of a specific folder.
 * - Sends a GET request with folderId.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param folderId - ID of the folder.
 */
export const getFolderTabs = createAsyncThunk<IEncryptedApiResponse, { folderId: string }>(
  "getFolderTabs",
  async ({ folderId }) => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(`${getFolderTabsPath}/${folderId}`, {
      headers: {
        showToast: false,
      },
    });
    return res.data;
  }
);

/**
 * 📂 Retrieves the complete folder list.
 * - Sends a GET request.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 */
export const getFolderList = createAsyncThunk<IEncryptedApiResponse>("getFolderList", async () => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(`${getAllFolders}`, {
    headers: {
      showToast: false,
    },
  });
  return res.data;
});

/**
 * 📦 Moves a file to another folder.
 * - Sends a POST request with move details.
 * - Returns the encrypted API response.
 *
 * @param data - Move file DTO.
 */
export const moveFile = createAsyncThunk<IEncryptedApiResponse, MoveFileDto>("moveFile", async (data: MoveFileDto) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(movefiles, data);
  return res.data;
});

/**
 * 🔀 Changes the tab of a file.
 * - Moves a file between tabs in the same folder.
 * - Returns the encrypted API response.
 *
 * @param data - Move file tab DTO.
 */
export const changeTab = createAsyncThunk<IEncryptedApiResponse, MoveFileTabDto>(
  "changeTab",
  async (data: MoveFileTabDto) => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(changeFileTab, data);
    return res.data;
  }
);

/**
 * Shares a single file with given permissions.
 * - Sends a PATCH request.
 * - Returns the encrypted API response.
 *
 * @param id - File ID.
 * @param data - Share file payload (permissions, roles).
 */
export const shareFile = createAsyncThunk<IEncryptedApiResponse, ShareFolderArgs>("shareFile", async ({ id, data }) => {
  const res = await axiosInstance.patch<IEncryptedApiResponse>(`${shareFileUrl}/${id}`, data);
  return res.data;
});

/**
 * Shares multiple files at once.
 * - Sends a POST request with file list and permissions.
 * - Returns the encrypted API response.
 *
 * @param data - Share multiple files payload.
 */
export const shareMultipleFile = createAsyncThunk<IEncryptedApiResponse | undefined, ShareFolderForm>(
  "shareFile",
  async data => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(shareMulFileUrl, data);
    return res.data;
  }
);
export const getFileList = createAsyncThunk<IEncryptedApiResponse, GetFiles>("getFileList", async (files: GetFiles) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(`${getMultipleFiles}`, files, {
    headers: {
      showToast: false,
    },
  });
  return res.data;
});
