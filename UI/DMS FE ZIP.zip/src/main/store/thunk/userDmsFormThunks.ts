import { createAsyncThunk } from "@reduxjs/toolkit";
import { axiosInstance } from "@core/utils";
import { IEncryptedApiResponse } from "@core/models";
import {
  IRequestUploadDmsForms,
  DmsFormPaginationRequest,
  RenameDmsFormRequest,
  DeleteDmsFormRequest,
  GetDmsFormByIdRequest,
  ShareDmsFormArgs,
} from "@main/models";
import { API_URLS } from "@core/constants";

const uploadDmsFormsUrl = `${API_URLS.ADMIN.uploadUserDmsForm}`;
const getAllDmsFormsUrl = `${API_URLS.ADMIN.getUserDmsForm}`;
const renameDmsFormsUrl = `${API_URLS.ADMIN.renameUserDmsForm}`;
const deleteDmsFormsUrl = `${API_URLS.ADMIN.deleteUserDmsForm}`;
const getByIdDmsFormsUrl = `${API_URLS.ADMIN.getByIdUserDmsForm}`;
const shareDmsFormsUrl = `${API_URLS.ADMIN.shareUserDmsForm}`;

export const uploadUserDmsForms = createAsyncThunk<IEncryptedApiResponse, IRequestUploadDmsForms>(
  "userdmsforms/upload",
  async request => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(uploadDmsFormsUrl, {
      dmsForms: request.forms,
      userId: request.userId,
    });
    return response.data;
  }
);

export const getAllUserDmsForms = createAsyncThunk<IEncryptedApiResponse, DmsFormPaginationRequest>(
  "userdmsforms/getAll",
  async payload => {
    const { userId, ...requestBody } = payload;

    const response = await axiosInstance.post<IEncryptedApiResponse>(`${getAllDmsFormsUrl}=${userId}`, requestBody, {
      headers: { showToast: false },
    });
    return response.data;
  }
);

export const renameUserDmsForm = createAsyncThunk<IEncryptedApiResponse, RenameDmsFormRequest>(
  "userdmsforms/rename",
  async ({ dmsFormId, newFileName, userId }) => {
    const response = await axiosInstance.put<IEncryptedApiResponse>(`${renameDmsFormsUrl}=${userId}`, {
      dmsFormId,
      newFileName,
    });
    return response.data;
  }
);

export const deleteUserDmsForm = createAsyncThunk<IEncryptedApiResponse, DeleteDmsFormRequest>(
  "userdmsforms/delete",
  async payload => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(deleteDmsFormsUrl, payload);
    return response.data;
  }
);

export const getUserDmsFormById = createAsyncThunk<IEncryptedApiResponse, GetDmsFormByIdRequest>(
  "userdmsforms/getById",
  async payload => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(getByIdDmsFormsUrl, payload, {
      headers: { showToast: false },
    });
    return response.data;
  }
);

export const shareUserDmsForm = createAsyncThunk<IEncryptedApiResponse | undefined, ShareDmsFormArgs>(
  "shareDmsform",
  async ({ formIds, data }) => {
    const res = await axiosInstance.patch<IEncryptedApiResponse>(shareDmsFormsUrl, {
      formIds,
      ...data,
    });
    return res.data;
  }
);
