import { createAsyncThunk } from "@reduxjs/toolkit";
import { axiosInstance } from "@core/utils";
import { IEncryptedApiResponse } from "@core/models";
import {
  IRequestUploadDmsForms,
  DmsFormPaginationRequest,
  RenameDmsFormRequest,
  DeleteDmsFormRequest,
  GetDmsFormByIdRequest,
  ShareDmsFormArgs,
  SaveEditedFormRequest,
  SubmitEditedFormRequest,
} from "@main/models";
import { API_URLS } from "@core/constants";
import { resolveUrlByRole } from "@main/components/EditableForms";

const uploadDmsFormsUrl = `${API_URLS.ADMIN.uploadDmsForm}`;
const getAllDmsFormsUrl = `${API_URLS.ADMIN.getDmsForm}`;
const renameDmsFormsUrl = `${API_URLS.ADMIN.renameDmsForm}`;
const deleteDmsFormsUrl = `${API_URLS.ADMIN.deleteDmsForm}`;
const getByIdDmsFormsUrl = `${API_URLS.ADMIN.getByIdDmsForm}`;
const shareDmsFormsUrl = `${API_URLS.ADMIN.shareDmsForm}`;
const saveDmsFormsUrl = `${API_URLS.ADMIN.saveDmsForm}`;
const submitEditedFormUrl = `${API_URLS.ADMIN.submitEditedForm}`;
const submitEditedUserDmsFormUrl = `${API_URLS.ADMIN.submitEditedUserDmsForm}`;
const getAllSubmittedFormUrl = `${API_URLS.ADMIN.getAllSubmittedForms}`;
const saveUserDmsFormsUrl = `${API_URLS.ADMIN.saveUserDmsForm}`;

export const uploadDmsForms = createAsyncThunk<IEncryptedApiResponse, IRequestUploadDmsForms>(
  "dmsforms/upload",
  async request => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(uploadDmsFormsUrl, {
      dmsForms: request.forms,
      userId: request.userId,
    });
    return response.data;
  }
);

export const getAllDmsForms = createAsyncThunk<IEncryptedApiResponse, DmsFormPaginationRequest>(
  "dmsforms/getAll",
  async payload => {
    const { userId, ...requestBody } = payload;

    const response = await axiosInstance.post<IEncryptedApiResponse>(`${getAllDmsFormsUrl}=${userId}`, requestBody, {
      headers: { showToast: false },
    });
    return response.data;
  }
);

export const renameDmsForm = createAsyncThunk<IEncryptedApiResponse, RenameDmsFormRequest>(
  "dmsforms/rename",
  async ({ dmsFormId, newFileName, userId }) => {
    const response = await axiosInstance.put<IEncryptedApiResponse>(`${renameDmsFormsUrl}=${userId}`, {
      dmsFormId,
      newFileName,
    });
    return response.data;
  }
);

export const deleteDmsForm = createAsyncThunk<IEncryptedApiResponse, DeleteDmsFormRequest>(
  "dmsforms/delete",
  async payload => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(deleteDmsFormsUrl, payload);
    return response.data;
  }
);

export const getDmsFormById = createAsyncThunk<IEncryptedApiResponse, GetDmsFormByIdRequest>(
  "dmsforms/getById",
  async payload => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(getByIdDmsFormsUrl, payload, {
      headers: { showToast: false },
    });
    return response.data;
  }
);

export const shareDmsForm = createAsyncThunk<IEncryptedApiResponse | undefined, ShareDmsFormArgs>(
  "shareDmsform",
  async ({ formIds, data }) => {
    const res = await axiosInstance.patch<IEncryptedApiResponse>(shareDmsFormsUrl, {
      formIds,
      ...data,
    });
    return res.data;
  }
);

export const saveEditedForm = createAsyncThunk<IEncryptedApiResponse, SaveEditedFormRequest>(
  "dmsforms/saveEditedForm",
  async payload => {
    const url = resolveUrlByRole(String(payload.userRole), saveDmsFormsUrl, saveUserDmsFormsUrl);
    const response = await axiosInstance.post<IEncryptedApiResponse>(url, payload);
    return response.data;
  }
);

export const submitEditedForm = createAsyncThunk<IEncryptedApiResponse, SubmitEditedFormRequest>(
  "dmsforms/submitEditedForm",
  async payload => {
    const url = resolveUrlByRole(String(payload.userRole), submitEditedFormUrl, submitEditedUserDmsFormUrl);
    const response = await axiosInstance.post<IEncryptedApiResponse>(url, payload);
    return response.data;
  }
);

export const getAllSubmittedDmsForms = createAsyncThunk<IEncryptedApiResponse, DmsFormPaginationRequest>(
  "dmsforms/getAllSubmitted",
  async payload => {
    const { userId, ...requestBody } = payload;

    const response = await axiosInstance.post<IEncryptedApiResponse>(
      `${getAllSubmittedFormUrl}=${userId}`,
      requestBody,
      {
        headers: { showToast: false },
      }
    );
    return response.data;
  }
);
