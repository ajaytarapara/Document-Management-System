import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@core/constants";
import { axiosInstance } from "@core/utils";
import { IAPIResponse, IEncryptedApiResponse } from "@core/models";
import { CreateFolderFormValues, ShareFolderArgs, UpdateFolderArgs, VerifyOTPArgs } from "@main/models";

const folderURL = `${API_URLS.USER.FOLDER}`;
const getFolder = `${API_URLS.USER.GET_FOLDER}`;
const deletFolder = `${API_URLS.USER.DELETE_FOLDER}`;
const updateFolderURL = `${API_URLS.USER.UPDATE_FOLDER}`;
const shareFolderURL = `${API_URLS.USER.SHARE_FOLDER}`;
const sendOTPURL = `${API_URLS.USER.SEND_OTP}`;
const verifyOTPURL = `${API_URLS.USER.VERIFY_OTP}`;
const maxtab = `${API_URLS.USER.GET_TAB}`;

/**
 * Creates a new folder.
 * - Sends a POST request with folder form values.
 * - Returns the encrypted API response.
 *
 * @param data - The form values for creating a folder.
 */
const downlaod = `${API_URLS.USER.DOWNLOAD_FOLDER}`;
export const createFolder = createAsyncThunk<IEncryptedApiResponse, CreateFolderFormValues>(
  "createFolder",
  async (data: CreateFolderFormValues) => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(folderURL, data);
    return res.data;
  }
);

/**
 * Fetches all folders with pagination, sorting, and search filters.
 * - Sends a POST request with page, sort, and search parameters.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param pageNumber - The current page number.
 * @param pageSize - The number of items per page.
 * @param sortDirection - Sorting order (ASC/DESC).
 * @param sortBy - Field name to sort by.
 * @param searchTerm - Keyword to filter results.
 */
export const getAllFolder = createAsyncThunk<
  IEncryptedApiResponse,
  { pageNumber: number; pageSize: number; sortDirection: string; sortBy: string; searchTerm: string }
>("getFolder", async ({ pageNumber, pageSize, sortDirection, sortBy, searchTerm }) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    getFolder,
    {
      pageNumber,
      pageSize,
      sortBy,
      sortDirection,
      searchTerm,
    },
    {
      headers: {
        showToast: false,
      },
    }
  );
  return res.data;
});

/**
 * Deletes a folder by its ID.
 * - Sends a DELETE request with the folder ID.
 * - Returns a boolean API response.
 *
 * @param id - The unique identifier of the folder to delete.
 */
export const deleteFolder = createAsyncThunk<IAPIResponse<boolean> | undefined, { id: string }>(
  "deleteFolder",
  async ({ id }) => {
    const res = await axiosInstance.delete<IAPIResponse<boolean>>(`${deletFolder}/${id}`);
    return res.data;
  }
);

/**
 * Thunk to fetch folder details by ID.
 *
 * - Sends a GET request to the backend API with the given folder ID.
 * - Returns an encrypted API response containing the folder data.
 *
 * @param id - The numeric ID of the folder to retrieve.
 *
 * @returns A promise resolving to the encrypted API response.
 */
export const getFolderById = createAsyncThunk<IEncryptedApiResponse, { id: string }>(
  "getFolderById",
  async ({ id }) => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(`${deletFolder}/${id}`);
    return res.data;
  }
);
export const downloadFolder = createAsyncThunk<IEncryptedApiResponse, { id: string }>(
  "downloadFolder",
  async ({ id }) => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(`${downlaod}/${id}`);
    return res.data;
  }
);
/**
 * Updates an existing folder.
 * - Sends a PUT request with folder ID and update data.
 * - Returns the encrypted API response.
 *
 * @param id - The ID of the folder to update.
 * @param data - The updated folder details.
 */
export const updateFolder = createAsyncThunk<IEncryptedApiResponse, UpdateFolderArgs>(
  "updateFolder",
  async ({ id, data }) => {
    const res = await axiosInstance.put<IEncryptedApiResponse>(`${updateFolderURL}/${id}`, data);
    return res.data;
  }
);

/**
 * Shares a folder with specified users or groups.
 * - Sends a PATCH request with folder ID and share details.
 * - Returns the encrypted API response.
 *
 * @param id - The folder ID to share.
 * @param data - The share details (users, permissions, etc.).
 */
export const shareFolder = createAsyncThunk<IEncryptedApiResponse | undefined, ShareFolderArgs>(
  "shareFolder",
  async ({ id, data }) => {
    const res = await axiosInstance.patch<IEncryptedApiResponse>(`${shareFolderURL}/${id}`, data);
    return res.data;
  }
);

/**
 * Sends an OTP (One-Time Password) to the provided email address.
 * - Sends a POST request with email.
 * - Returns the encrypted API response.
 *
 * @param email - The recipient’s email address.
 */
export const sendOTP = createAsyncThunk<IEncryptedApiResponse | undefined, { email: string }>(
  "sendOTP",
  async ({ email }) => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(sendOTPURL, { email });
    return res.data;
  }
);

/**
 * Verifies the OTP for folder sharing.
 * - Sends a POST request with email and OTP code.
 * - Returns the encrypted API response.
 *
 * @param email - The email address used for verification.
 * @param code - The OTP code sent to the user.
 */
export const verifyOTPForShare = createAsyncThunk<IEncryptedApiResponse | undefined, VerifyOTPArgs>(
  "verifyOTP",
  async ({ email, code }) => {
    const res = await axiosInstance.post<IEncryptedApiResponse>(verifyOTPURL, { email, code });
    return res.data;
  }
);

/**
 * Fetches the maximum allowed tab limit for users.
 * - Sends a GET request.
 * - Returns the encrypted API response.
 */
export const getMaxTabLimit = createAsyncThunk<IEncryptedApiResponse>("getMaxtab", async () => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(maxtab);
  return res.data;
});
