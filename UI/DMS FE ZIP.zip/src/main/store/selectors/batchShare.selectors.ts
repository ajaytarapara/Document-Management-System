"use client";

import { useAppSelector } from "@main/hooks";
import { RootState } from "../types";
import { BatchShareState } from "../slices/batchShareSlice";

export const useSelectorBatchShareState = (): BatchShareState => useAppSelector((state: RootState) => state.batchShare);
