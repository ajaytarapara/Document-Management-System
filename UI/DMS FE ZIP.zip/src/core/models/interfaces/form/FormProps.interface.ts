import type { RegisterOptions } from "react-hook-form";
import type { Dayjs } from "dayjs";
import type { ChangeEvent } from "react";
import { IDropdownValue, IRadioButtonOption, FormFieldType, InputType } from "@core/models";

export interface IFormConfig {
  apiRoute: string;
  formElements: IFormElement[];
  isEditMode: boolean;
  pageTitle?: string;
  recordId?: string;
  navigationOnSuccess?: string;
  navigationOnBack?: string;
  snackBarMessage?: string;
  addButtonLabel?: string;
  sections?: ISectionDetail[];
}

export interface ISectionDetail {
  title: string;
  id: string;
}

export interface IFormElement {
  id: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value?: any;
  label: string;
  formFieldType: FormFieldType;
  inputType?: InputType;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  options?: IDropdownValue[] | IRadioButtonOption[] | any[];
  disabled?: boolean;
  tooltip?: string;
  elementCss?: string;
  parentCss?: string;
  minDate?: Dayjs;
  maxDate?: Dayjs;
  sectionId?: string;
  validation?: RegisterOptions;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  errors?: Record<string, any>;
  placeholder?: string;
  onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
}

export interface IUploadedFile {
  name: string;
  type: string;
  content: string;
}
