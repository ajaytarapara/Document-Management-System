import { ReactNode } from "react";

export interface IDialogProps {
  open: boolean;
  onClose: () => void;
  title?: string | ReactNode;
  icon?: React.ReactNode;
  description?: string | ReactNode;
  children?: React.ReactNode;
  showActions?: boolean;
  onSubmit?: () => void;
  submitLabel?: string;
  cancelLabel?: string;
  disableSubmit?: boolean;
  maxWidth?: false | "xs" | "sm" | "md" | "lg" | "xl";
  fullWidth?: boolean;
  customWidth?: string | number;
  buttonType?: "button" | "submit" | "reset" | undefined;
}
