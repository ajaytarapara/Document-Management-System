import type { Control, FieldValues, RegisterOptions } from "react-hook-form";
import type { CSSProperties } from "react";
import { SxProps, Theme } from "@mui/material";

export interface IDropdownValue {
  label: string;
  value: string | number;
}

export interface IRadioButtonOption {
  label: string;
  value: string | number;
}

export interface IControlledSelectProps {
  name: string;
  label: string;
  options?: IDropdownValue[] | IRadioButtonOption[];
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  fullWidth?: boolean;
  customClass?: string;
  style?: CSSProperties;
  control: Control<FieldValues>;
  validations?: RegisterOptions;
  dropdownHeight?: number;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  errors?: Record<string, any>;
  sx?: SxProps<Theme>;
}
