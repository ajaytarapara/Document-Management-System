import type { RegisterOptions, UseFormRegister } from "react-hook-form";
export interface IInputControlProps {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  register?: UseFormRegister<any>;
  name: string;
  validation?: RegisterOptions;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  errors?: Record<string, any>;
}
