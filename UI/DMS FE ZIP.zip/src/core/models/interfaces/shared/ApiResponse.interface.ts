import { FileListDto } from "@main/models";

export interface IAPIResponse<T> {
  isSuccessful: boolean;
  message?: string;
  data?: T;
  statusCode?: number;
}

export interface IPaginatedResponse<T> {
  items: T[];
  pageNumber: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}

export interface IPaginatedRequest {
  pageNumber: number;
  pageSize: number;
  searchTerm?: string;
  sortBy?: string;
  sortDirection?: string;
}
export interface IDownloadFile {
  folderName: string;
  tabListDto: TabListDto[];
}
export interface TabListDto {
  tabName: string;
  fileListDto: FileListDto[];
}

export interface IEncryptedApiResponse {
  data: string;
}

export interface IEncryptedApiRequest {
  data: string;
}
