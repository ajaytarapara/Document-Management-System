export interface ILoaderState {
  isLoading: boolean;
}
