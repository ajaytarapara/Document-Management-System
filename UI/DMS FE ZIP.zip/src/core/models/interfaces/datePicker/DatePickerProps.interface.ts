import type { Dayjs } from "dayjs";
import type { Control, FieldValues } from "react-hook-form";

export interface IDatePickerProps {
  name: string;
  label?: string;
  minDate?: Dayjs;
  maxDate?: Dayjs;
  disabled?: boolean;
  format?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  control: Control<FieldValues, any, FieldValues>;
  views?: Array<"day" | "month" | "year">;
}
