import type { IInputControlProps } from "../inputControl/InputControlProps.interface";

export interface IRadioOption {
  label: string;
  value: string;
}

export interface IRadioGroupProps extends IInputControlProps {
  label?: string;
  options: IRadioOption[];
  value?: string | number;
  row?: boolean;
}
