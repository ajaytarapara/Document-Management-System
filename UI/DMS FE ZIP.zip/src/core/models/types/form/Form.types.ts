export type FormFieldType =
  | "text"
  | "number"
  | "dropdown"
  | "date"
  | "radio"
  | "textarea"
  | "toggle"
  | "datepicker"
  | "checkbox";

export type InputType = "text" | "password" | "email" | "number" | "date" | "datetime-local";
