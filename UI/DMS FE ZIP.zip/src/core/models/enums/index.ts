export enum Role {
  Admin = "Admin",
  Office_User = "Office_User",
  User = "User",
}

export enum LoginTypeEnum {
  USERNAME = "username",
  SSO = "sso",
  BOTH = "both",
}

export enum FieldType {
  Text = "text",
  Checkbox = "checkbox",
  Radio = "radio",
  Select = "select",
  Highlight = "highlight",
  Signature = "signature",
  Eraser = "eraser",
}

export enum Corner {
  TopLeft = "top-left",
  TopRight = "top-right",
  BottomLeft = "bottom-left",
  BottomRight = "bottom-right",
}

export const corners: Corner[] = [Corner.TopLeft, Corner.TopRight, Corner.BottomLeft, Corner.BottomRight];

export enum ShareStep {
  Email = "email",
  Otp = "otp",
  Done = "done",
}
