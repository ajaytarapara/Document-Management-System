"use client";

import { Pagination, MenuItem } from "@mui/material";
import { Controller, Control } from "react-hook-form";
import { StyledFormControl, StyledSelect } from "./TablePagination.styled";

interface FormValues {
  pageSize: string;
}

interface TableFooterPaginationProps {
  control: Control<FormValues>;
  totalPage: number;
  pageIndex: number;
  onPageChange?: (pageIndex: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
}

const pageSizeOptions = [
  { value: "5", label: "5" },
  { value: "10", label: "10" },
  { value: "20", label: "20" },
  { value: "50", label: "50" },
  { value: "100", label: "100" },
];

export const TableFooterPagination = ({
  control,
  totalPage,
  pageIndex,
  onPageChange,
  onPageSizeChange,
}: TableFooterPaginationProps) => {
  if (totalPage <= 0) return null;

  return (
    <div className="mt-4 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-2">
        <p className="text-sm">Rows per page:</p>
        <StyledFormControl className="min-w-[120px]">
          <Controller
            name="pageSize"
            control={control}
            rules={{ required: "Page size is required" }}
            render={({ field }) => (
              <StyledSelect
                {...field}
                displayEmpty
                size="small"
                value={field.value}
                onChange={e => {
                  const newSize = Number(e.target.value);
                  field.onChange(e);
                  onPageSizeChange?.(newSize);
                }}
                MenuProps={{
                  PaperProps: {
                    style: { maxHeight: 150 },
                  },
                }}
              >
                <MenuItem value="" disabled>
                  Rows Per Page
                </MenuItem>
                {pageSizeOptions.map(option => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </StyledSelect>
            )}
          />
        </StyledFormControl>
      </div>

      <div className="flex justify-center md:justify-end">
        <Pagination
          count={totalPage}
          page={pageIndex}
          onChange={(_, page) => onPageChange?.(page)}
          color="primary"
          variant="outlined"
          shape="rounded"
        />
      </div>
    </div>
  );
};
