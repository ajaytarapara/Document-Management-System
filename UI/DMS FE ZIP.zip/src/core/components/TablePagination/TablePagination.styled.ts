import emotionStyled from "@emotion/styled";
import { FormControl, Select } from "@mui/material";

export const StyledFormControl = emotionStyled(FormControl)({
  minWidth: 80,
  height: 32,
  margin: 0,
});

export const StyledSelect = emotionStyled(Select)({
  height: 32,
  "& .MuiSelect-select": {
    padding: "8px 12px",
    fontSize: "14px",
  },
});
