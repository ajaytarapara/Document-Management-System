"use client";

import React, { useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  ColumnDef,
  SortingState,
} from "@tanstack/react-table";
import { ArrowDown, ArrowUp, ArrowUpDown } from "lucide-react";
import { TableFooterPagination } from "../TablePagination/CustomPagination";
import { useForm } from "react-hook-form";

export interface GeneralTableProps<TData extends object, TValue = unknown> {
  data: TData[];
  columns: ColumnDef<TData, TValue>[];
  pageSize?: number;
  pageIndex?: number;
  onPaginationChange?: (pageIndex: number, pageSize: number) => void;
  enablePagination?: boolean;
  className?: string;
  emptyMessage?: string;
  totalCount?: number;
  onSortingChange?: (sorting: SortingState) => void;
}

export const GeneralTable = <TData extends object, TValue = unknown>({
  data,
  columns,
  enablePagination = true,
  pageIndex = 1,
  pageSize = 10,
  className = "",
  emptyMessage = "",
  onPaginationChange,
  totalCount,
  onSortingChange,
}: GeneralTableProps<TData, TValue>) => {
  const { control } = useForm({
    defaultValues: {
      pageSize: pageSize.toString(),
    },
  });
  const [sorting, setSorting] = useState<SortingState>([]);
  const pageCount = totalCount ? Math.ceil(totalCount / (pageSize ?? 10)) : -1;
  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    pageCount,
    getPaginationRowModel: enablePagination ? getPaginationRowModel() : undefined,
    state: {
      sorting,
      pagination: {
        pageIndex: pageIndex ?? 0,
        pageSize: pageSize ?? 10,
      },
    },
    manualPagination: true,
    onPaginationChange: updater => {
      const newState =
        typeof updater === "function" ? updater({ pageIndex: pageIndex ?? 0, pageSize: pageSize ?? 10 }) : updater;
      onPaginationChange?.(newState.pageIndex, newState.pageSize);
    },
    onSortingChange: updater => {
      const newSorting = typeof updater === "function" ? updater(sorting) : updater;
      setSorting(newSorting);
      onSortingChange?.(newSorting);
    },
    manualSorting: true,
  });

  return (
    <div className={`p-4 bg-white rounded-lg shadow-md ${className}`}>
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th
                    key={header.id}
                    onClick={header.column.getToggleSortingHandler()}
                    className={`px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] uppercase tracking-wider ${
                      header.column.getCanSort() ? "cursor-pointer hover:bg-[#e1dcef]" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 whitespace-nowrap">
                      {flexRender(header.column.columnDef.header, header.getContext())}
                      {header.column.getCanSort() && (
                        <>
                          {header.column.getIsSorted() === "asc" && <ArrowUp className="w-4 h-4 text-[#7E57C2]" />}
                          {header.column.getIsSorted() === "desc" && <ArrowDown className="w-4 h-4 text-[#7E57C2]" />}
                          {!header.column.getIsSorted() && <ArrowUpDown className="w-4 h-4 text-[#7a7b7b]" />}
                        </>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="text-center px-4 py-6 text-sm text-gray-500">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map(row => (
                <tr key={row.id} className="hover:bg-gray-50 transition-colors duration-150">
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id} className="px-4 py-3 text-sm text-gray-700">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {enablePagination && (
        <TableFooterPagination
          control={control}
          totalPage={pageCount}
          pageIndex={table.getState().pagination.pageIndex + 1}
          onPageChange={newPage => {
            onPaginationChange?.(newPage - 1, table.getState().pagination.pageSize);
          }}
          onPageSizeChange={newPageSize => {
            onPaginationChange?.(0, newPageSize);
          }}
        />
      )}
    </div>
  );
};
