"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ChevronDown, ChevronUp, Folder, LogOutIcon, Menu, UserRound, X } from "lucide-react";
import { impersonateStopUser, logout, logoutApi, setCurrentUser, useSelectorAuthState } from "@main/store";
import { useAppDispatch } from "@main/hooks";
import Cookie from "js-cookie";
import { usePathname } from "next/navigation";
import { ROUTES } from "@core/constants/PAGE_URLS";
import { Constant } from "@core/constants/Constant";
import { decryptObject, handleThunkWithDecrypt, useNavigate } from "@core/utils";
import { IImpersonate, ILoginResponse, ISubUser } from "@main/models";
import { IAPIResponse, Role } from "@core/models";
import Cookies from "js-cookie";
import { SubUserBoxHeader } from "@main/components";

export const Header = () => {
  const [open, setOpen] = useState<boolean>(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const { loggedInUser, subUsers, currentUser, originalUser } = useSelectorAuthState();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const pathname = usePathname();
  const decryptedLoggedUser = loggedInUser ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser) : null;

  const handleToggle = () => setOpen(prev => !prev);
  const handleClickOutside = (event: MouseEvent) => {
    if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
      setOpen(false);
    }
  };

  const handleLogout = async () => {
    const resultAction = await dispatch(logoutApi());
    if (logoutApi.fulfilled.match(resultAction)) {
      dispatch(logout());
      Cookie.remove("token");
      navigate(ROUTES.LOGIN);
    }
  };

  const isActive = (path: string) => pathname === path;

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleAccountPageNavigation = () => {
    const role = decryptedLoggedUser?.data?.role;
    switch (role) {
      case Role.Admin:
        navigate(ROUTES.ADMIN.ACCOUNT);
        break;
      case Role.Office_User:
        navigate(ROUTES.OFFICE_USER.ACCOUNT);
        break;
      case Role.User:
        navigate(ROUTES.USER.ACCOUNT);
        break;
      default:
        navigate(ROUTES.HOME);
    }
  };

  const ImpersonateStop = async (user: ISubUser) => {
    const decryptedResponse = await handleThunkWithDecrypt<IImpersonate, number>(
      dispatch,
      impersonateStopUser,
      user.id
    );
    Cookies.set("token", decryptedResponse?.data?.token || "");
    dispatch(setCurrentUser(user));
    window.location.reload();
  };

  return (
    <header className="w-full bg-white shadow-sm fixed z-50 pl-[14px]">
      <div className="w-full lg:px-[10px]">
        <div className="flex flex-wrap items-center justify-between">
          <div className="flex items-center space-x-2">
            <button onClick={() => setMobileMenuOpen(true)} className="lg:hidden mr-2">
              <Menu className="h-6 w-6 text-[#7E57C2]" />
            </button>
            <Folder className="text-[#7E57C2] xl:h-[65px] xl:w-[45px] w-[35px] h-[35px] sm:h-[35px] md:h-[47px] lg:h-[50px] sm:w-[35px] md:w-[47px] lg:w-[50px]" />
            <div className="text-3xl font-semibold bg-gradient-to-r from-[#7E57C2] to-[#AB47BC] text-transparent bg-clip-text">
              DMS
            </div>
          </div>
          <nav className="lg:flex hidden text-sm sm:text-base text-[#00092a] leading-7 font-medium">
            {decryptedLoggedUser?.data?.role === Constant.COMMON.ADMIN ? (
              <>
                <Link
                  href={ROUTES.ADMIN.DASHBOARD}
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(ROUTES.ADMIN.DASHBOARD) ? "text-[#7E57C2] border-b" : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  Home
                </Link>
                <Link
                  href={ROUTES.ADMIN.CREATE_USER}
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(ROUTES.ADMIN.CREATE_USER)
                      ? "text-[#7E57C2] border-b"
                      : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  Create User
                </Link>
                <Link
                  href={ROUTES.ADMIN.VIEW_USER}
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(ROUTES.ADMIN.VIEW_USER) ? "text-[#7E57C2] border-b" : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  View Users
                </Link>
                <Link
                  href={ROUTES.ADMIN.DMS_FORMS}
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(ROUTES.ADMIN.DMS_FORMS) ? "text-[#7E57C2] border-b" : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  DMS Forms
                </Link>
              </>
            ) : (
              <>
                <Link
                  href={
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.DASHBOARD
                      : ROUTES.USER.DASHBOARD
                  }
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(
                      decryptedLoggedUser?.data?.role === Role.Office_User
                        ? ROUTES.OFFICE_USER.DASHBOARD
                        : ROUTES.USER.DASHBOARD
                    )
                      ? "text-[#7E57C2] border-b"
                      : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  Home
                </Link>
                <Link
                  href={
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.DMS_FORMS
                      : ROUTES.USER.DMS_FORMS
                  }
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(
                      decryptedLoggedUser?.data?.role === Role.Office_User
                        ? ROUTES.OFFICE_USER.DMS_FORMS
                        : ROUTES.USER.DMS_FORMS
                    )
                      ? "text-[#7E57C2] border-b"
                      : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  DMS Forms
                </Link>
                <Link
                  href={
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.CREATE_FOLDER
                      : ROUTES.USER.CREATE_FOLDER
                  }
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(
                      decryptedLoggedUser?.data?.role === Role.Office_User
                        ? ROUTES.OFFICE_USER.CREATE_FOLDER
                        : ROUTES.USER.CREATE_FOLDER
                    )
                      ? "text-[#7E57C2] border-b"
                      : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  Create New DMSFiles
                </Link>
                <Link
                  href={
                    decryptedLoggedUser?.data?.role == Role.Office_User
                      ? ROUTES.OFFICE_USER.VIEW_FOLDER
                      : ROUTES.USER.VIEW_FOLDER
                  }
                  className={`py-[10px] px-[15px] mx-2 transition-all duration-300 ease-in-out ${
                    isActive(
                      decryptedLoggedUser?.data?.role === Role.Office_User
                        ? ROUTES.OFFICE_USER.VIEW_FOLDER
                        : ROUTES.USER.VIEW_FOLDER
                    )
                      ? "text-[#7E57C2] border-b"
                      : "hover:text-[#7E57C2] hover:border-b"
                  }`}
                >
                  View DMSFiles
                </Link>
              </>
            )}
          </nav>
          <div
            onClick={handleToggle}
            className="min-h-[60px] md:min-h-[69px] flex items-center justify-end gap-2 relative"
            ref={menuRef}
          >
            <div className="h-[38px] w-[38px] bg-[#7E57C2] flex items-center justify-center rounded-full">
              <UserRound className="h-5 w-5 text-white font-bold" />
            </div>
            <div>
              <button className="items-center gap-1 text-[#00092a] font-medium leading-5 text-base cursor-pointer whitespace-nowrap hidden md:flex">
                {currentUser?.username} {open ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              </button>
              {open && (
                <div className="absolute right-2 mt-3 w-56 max-h-[400px] overflow-y-auto rounded-[6px] shadow-[0_4px_20px_rgba(0,0,0,0.1)] p-[25px_15px_18px] bg-white z-50">
                  {subUsers.length > 0 && (
                    <>
                      <div onClick={() => ImpersonateStop(originalUser)}>
                        <SubUserBoxHeader key={originalUser?.id} user={originalUser} currentUser={currentUser} />
                      </div>
                      {subUsers.map(user => (
                        <SubUserBoxHeader key={user.id} user={user} currentUser={currentUser} />
                      ))}
                    </>
                  )}

                  <ul className="py-1">
                    <li
                      onClick={() => handleAccountPageNavigation()}
                      className="cursor-pointer font-medium leading-5 text-center border text-sm border-[#c0c0c0] mb-[15px] rounded-sm text-[#5b5c60] px-4 py-2"
                    >
                      My Account
                    </li>
                    <li
                      onClick={() => handleLogout()}
                      className="flex items-center justify-center gap-2 cursor-pointer font-medium leading-5 text-white rounded-sm text-sm px-4 py-2 bg-[#7E57C2]"
                    >
                      <LogOutIcon size={16} />
                      Logout
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div
        className={`fixed top-0 left-0 h-full w-[250px] bg-white shadow-lg z-[100] transform transition-transform duration-300 ${
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        } lg:hidden`}
      >
        <div className="flex items-center justify-between p-[12px] border-b border-[#7E57C2]">
          <div className="flex">
            <Folder className="text-[#7E57C2] mr-2 xl:h-[65px] xl:w-[65px] w-[35px] h-[35px] sm:h-[35px]" />
            <div className="text-3xl font-semibold text-[#7E57C2]">
              <span className="bg-gradient-to-r from-[#7E57C2] to-[#AB47BC] text-transparent bg-clip-text">DMS</span>
            </div>
          </div>
          <button onClick={() => setMobileMenuOpen(false)}>
            <span className="text-2xl font-bold text-[#7E57C2]">
              <X />
            </span>
          </button>
        </div>
        <hr className="text-[#7E57C2]" />
        <nav className="flex flex-col px-4 py-4 space-y-3 text-[#00092a] font-medium">
          {decryptedLoggedUser?.data?.role === Constant.COMMON.ADMIN ? (
            <>
              <Link
                href={ROUTES.ADMIN.DASHBOARD}
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(ROUTES.ADMIN.DASHBOARD)
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                Home
              </Link>
              <Link
                href={ROUTES.ADMIN.CREATE_USER}
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(ROUTES.ADMIN.CREATE_USER)
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                Create User
              </Link>
              <Link
                href={ROUTES.ADMIN.VIEW_USER}
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(ROUTES.ADMIN.VIEW_USER)
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                View Users
              </Link>
            </>
          ) : (
            <>
              <Link
                href={
                  decryptedLoggedUser?.data?.role === Role.Office_User
                    ? ROUTES.OFFICE_USER.DASHBOARD
                    : ROUTES.USER.DASHBOARD
                }
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.DASHBOARD
                      : ROUTES.USER.DASHBOARD
                  )
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                Home
              </Link>
              <Link
                href={ROUTES.OFFICE_USER.DMS_FORMS}
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(ROUTES.OFFICE_USER.DMS_FORMS)
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                DMS Forms
              </Link>
              <Link
                href={
                  decryptedLoggedUser?.data?.role === Role.Office_User
                    ? ROUTES.OFFICE_USER.CREATE_FOLDER
                    : ROUTES.USER.CREATE_FOLDER
                }
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.CREATE_FOLDER
                      : ROUTES.USER.CREATE_FOLDER
                  )
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                Create New DMSFiles
              </Link>
              <Link
                href={
                  decryptedLoggedUser?.data?.role === Role.Office_User
                    ? ROUTES.OFFICE_USER.VIEW_FOLDER
                    : ROUTES.USER.VIEW_FOLDER
                }
                onClick={() => setMobileMenuOpen(false)}
                className={`p-2 transition-colors duration-200 ${
                  isActive(
                    decryptedLoggedUser?.data?.role === Role.Office_User
                      ? ROUTES.OFFICE_USER.VIEW_FOLDER
                      : ROUTES.USER.VIEW_FOLDER
                  )
                    ? "text-[#7E57C2] font-semibold bg-[#e1dcef] rounded-md"
                    : "hover:text-[#7E57C2]"
                }`}
              >
                View DMSFiles
              </Link>
            </>
          )}
        </nav>
      </div>
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-opacity-30 z-[99] lg:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}
    </header>
  );
};
