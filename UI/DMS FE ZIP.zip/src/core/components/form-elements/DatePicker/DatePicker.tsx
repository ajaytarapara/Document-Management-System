"use client";

import CalendarTodayRoundedIcon from "@mui/icons-material/CalendarTodayRounded";
import { Button } from "@mui/material";
import { useForkRef } from "@mui/material/utils";
import { usePickerContext, useSplitFieldProps } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePicker as MUIDatepicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import * as React from "react";

import { IDatePickerProps } from "@core/models/interfaces";
import { Controller } from "react-hook-form";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function ButtonField(props: any) {
  const { forwardedProps } = useSplitFieldProps(props, "date");
  const pickerContext = usePickerContext();
  const handleRef = useForkRef(pickerContext.triggerRef, pickerContext.rootRef);
  const valueStr = pickerContext.value == null ? "Select date" : pickerContext.value.format(pickerContext.fieldFormat);

  return (
    <Button
      {...forwardedProps}
      ref={handleRef}
      variant="outlined"
      size="small"
      startIcon={<CalendarTodayRoundedIcon fontSize="small" />}
      sx={{ minWidth: "fit-content" }}
      onClick={() => pickerContext.setOpen(prev => !prev)}
    >
      {pickerContext.label ?? valueStr}
    </Button>
  );
}

export const DatePicker: React.FC<IDatePickerProps> = ({
  minDate,
  maxDate,
  name,
  disabled = false,
  views = ["year", "month", "day"],
  format = "MMM DD, YYYY",
  control,
}) => {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Controller
        name={name}
        control={control}
        render={({ field: { value, onChange, ref } }) => (
          <MUIDatepicker
            value={value || null}
            onChange={onChange}
            minDate={minDate}
            maxDate={maxDate}
            format={format}
            disabled={disabled}
            views={views}
            slots={{ field: ButtonField }}
            slotProps={{
              nextIconButton: { size: "small" },
              previousIconButton: { size: "small" },
            }}
            inputRef={ref}
          />
        )}
      />
    </LocalizationProvider>
  );
};
