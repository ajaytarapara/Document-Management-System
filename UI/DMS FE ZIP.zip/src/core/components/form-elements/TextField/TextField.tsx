"use client";

// React
import React from "react";

// MUI components & styling
import { FormControl, FormHelperText, FormLabel, TextField, TextFieldProps } from "@mui/material";
import { styled } from "@mui/material/styles";

// React Hook Form
import { FieldErrors, FieldValues, Path, RegisterOptions, UseFormRegister } from "react-hook-form";

// Styling for the input
const StyledTextField = styled(TextField)(({ theme }) => ({
  "& .MuiOutlinedInput-root": {
    "& fieldset": {
      borderColor: "#ccc",
    },
    "&:hover fieldset": {
      borderColor: theme.palette.primary.main,
    },
    "&.Mui-focused fieldset": {
      borderColor: theme.palette.primary.main,
      borderWidth: "2px",
    },

    "&.Mui-disabled": {
      "& .MuiOutlinedInput-notchedOutline": {
        borderColor: `${theme.palette.action.disabled} !important`,
      },
      "& .MuiInputBase-input": {
        WebkitTextFillColor: `#000000 !important`,
        color: `#000000 !important`,
        backgroundColor: `#f8f5ff !important`,
      },
    },

    "& input": {
      "&:-webkit-autofill": {
        WebkitBoxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
        WebkitTextFillColor: theme.palette.text.primary,
        borderRadius: "inherit",
      },
      "&:-webkit-autofill:hover": {
        WebkitBoxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
      },
      "&:-webkit-autofill:focus": {
        WebkitBoxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
      },
      "&:-moz-autofill": {
        boxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
        textFillColor: theme.palette.text.primary,
      },
      "&:-moz-autofill:hover": {
        boxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
      },
      "&:-moz-autofill:focus": {
        boxShadow: `0 0 0 100px ${theme.palette.background.paper} inset`,
      },
    },
  },
}));

// Styling for helper text and label
export const StyledHelperText = styled(FormHelperText)(() => ({
  margin: "5px 0px 0px 0px",
  padding: 0,
  lineHeight: "1.2rem",
}));

export const StyledFormLabel = styled(FormLabel)(({ theme }) => ({
  lineHeight: "24px",
  color: theme.palette.secondary.main,
  marginBottom: theme.spacing(1),
  fontWeight: 600,
  fontSize: "0.8rem",

  [theme.breakpoints.up("sm")]: {
    fontSize: "1rem",
  },
  [theme.breakpoints.up("md")]: {
    fontSize: "1.1rem",
  },
}));

// Generic props
type CommonTextFieldProps<T extends FieldValues> = TextFieldProps & {
  name: Path<T>;
  label?: string;
  register?: UseFormRegister<T>;
  validation?: RegisterOptions<T, Path<T>>;
  errors?: FieldErrors<T>;
};

// Component
export const CommonTextField = <T extends FieldValues>({
  name,
  label,
  register,
  validation,
  errors,
  ...props
}: CommonTextFieldProps<T>) => {
  const errorMessage = errors?.[name]?.message as string | undefined;
  const registration = register ? register(name, validation) : {};
  const isRequired = props?.required !== undefined;

  return (
    <FormControl fullWidth error={!!errorMessage}>
      {label && (
        <StyledFormLabel htmlFor={name}>
          {label}
          {isRequired && <span style={{ color: "#d32f2f" }}> *</span>}
        </StyledFormLabel>
      )}
      <StyledTextField
        {...props}
        {...registration}
        id={name}
        name={name}
        error={!!errorMessage}
        variant={props.variant}
      />
      {errorMessage && <StyledHelperText>{errorMessage}</StyledHelperText>}
    </FormControl>
  );
};
