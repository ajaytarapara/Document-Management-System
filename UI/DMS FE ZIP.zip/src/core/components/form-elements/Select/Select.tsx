"use client";

// React
import type { FC } from "react";

// MUI components
import { FormControl, MenuItem, Select as MUISelect } from "@mui/material";

// React Hook Form
import { Controller } from "react-hook-form";

// App-specific types
import type { IControlledSelectProps } from "@core/models/interfaces";

// App-specific components
import { StyledFormLabel, StyledHelperText } from "../TextField/TextField";

export const Select: FC<IControlledSelectProps> = ({
  label,
  options,
  placeholder,
  disabled = false,
  required = false,
  fullWidth = false,
  customClass = "",
  style = {},
  errors,
  name,
  sx,
  control,
  validations,
  dropdownHeight,
}) => {
  const hasError = !!(errors && errors[name]);
  const labelId = `${name}-label`;

  return (
    <FormControl disabled={disabled} className={customClass} style={style} fullWidth={fullWidth} error={hasError}>
      {label && (
        <StyledFormLabel htmlFor={name}>
          {label}
          {required && <span style={{ color: "#d32f2f" }}> *</span>}
        </StyledFormLabel>
      )}
      <Controller
        name={name}
        control={control}
        rules={validations}
        render={({ field }) => {
          return (
            <MUISelect
              MenuProps={{
                PaperProps: {
                  style: {
                    maxHeight: dropdownHeight,
                  },
                },
              }}
              sx={sx}
              labelId={labelId}
              displayEmpty
              fullWidth
              {...field}
              value={field.value ?? ""}
            >
              {placeholder && (
                <MenuItem value="" disabled>
                  {placeholder}
                </MenuItem>
              )}
              {options?.map((option, index) => (
                <MenuItem key={`${option.value}-${index}`} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </MUISelect>
          );
        }}
      />
      {hasError && <StyledHelperText>{errors?.[name]?.message}</StyledHelperText>}
    </FormControl>
  );
};
