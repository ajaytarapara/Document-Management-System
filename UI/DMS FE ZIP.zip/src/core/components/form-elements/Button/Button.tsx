"use client";

import React from "react";
import { Button, ButtonProps } from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledButton = styled(Button)<ButtonProps>(({ theme, variant }) => ({
  position: "relative",
  overflow: "hidden",
  textTransform: "none",
  fontWeight: "bold",
  borderRight: 0,
  transition: "color 0.3s, background-color 0.3s",

  ...(variant === "contained" && {
    backgroundColor: theme.palette.primary.main,
    color: "#fff",

    "&.Mui-disabled": {
      backgroundColor: "#ede7f6",
      color: theme.palette.primary.main,
      opacity: "50%",
    },

    "&::before": {
      content: '""',
      position: "absolute",
      inset: 0,
      backgroundColor: theme.palette.custom?.hoverPrimary || "#5E35B1",
      transform: "scaleX(0)",
      transformOrigin: "left",
      transition: "transform 0.3s ease-in-out",
      zIndex: 0,
    },

    "&:hover::before": {
      transform: "scaleX(1)",
    },

    "& .MuiTouchRipple-root, & > *": {
      position: "relative",
      zIndex: 1,
    },
  }),

  ...(variant === "outlined" && {
    backgroundColor: "transparent",
    color: "#000",
    borderColor: "#000",
    borderWidth: 1,
    borderStyle: "solid",

    "&:hover": {
      backgroundColor: "#f5f5f5",
    },

    "&.Mui-disabled": {
      backgroundColor: "#ede7f6",
      color: "#fff",
      borderColor: "#b0a7c7",
      opacity: "50%",
    },
  }),
}));

type CommonButtonProps = ButtonProps & {
  children: React.ReactNode;
};

export const CommonButton: React.FC<CommonButtonProps> = ({ children, ...props }) => {
  return (
    <StyledButton {...props}>
      <span className="button-content">{children}</span>
    </StyledButton>
  );
};
