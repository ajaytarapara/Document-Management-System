import React from "react";
import { TextField, TextFieldProps } from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledTextField = styled(TextField)(({ theme }) => ({
  "& .MuiOutlinedInput-root": {
    "& fieldset": {
      borderColor: "#ccc",
    },
    "&:hover fieldset": {
      borderColor: theme.palette.primary.main,
    },
    "&.Mui-focused fieldset": {
      borderColor: theme.palette.primary.main,
      borderWidth: "2px",
    },
  },
}));

type SimpleTextFieldProps = Omit<TextFieldProps, "name"> & {
  name?: string;
};

export const SimpleTextField: React.FC<SimpleTextFieldProps> = props => {
  return <StyledTextField {...props} />;
};
