"use client";

import React from "react";
import {
  Autocomplete,
  Checkbox,
  Chip,
  FormControl,
  FormHelperText,
  FormLabel,
  Paper,
  TextField,
  Typography,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { styled } from "@mui/material/styles";
import { Controller, Control, FieldValues, Path, RegisterOptions, FieldErrors } from "react-hook-form";

const StyledHelperText = styled(FormHelperText)(() => ({
  margin: "5px 0px 0px 0px",
  padding: 0,
  lineHeight: "1.2rem",
}));

const StyledFormLabel = styled(FormLabel)(({ theme }) => ({
  lineHeight: "24px",
  color: `${theme.palette.secondary.main} !important`,
  marginBottom: 3,
  fontWeight: "600 !important",
}));

export const StyledPlaceHolderText = styled(Typography)(({ theme }) => ({
  color: `${theme.palette.text.disabled} !important`,
  fontStyle: "normal",
}));

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

type Option = {
  id: string | number;
  name: string;
};

type CommonMultiSelectProps<T extends FieldValues> = {
  name: Path<T>;
  label?: string;
  control: Control<T>;
  options: Option[];
  required?: boolean;
  validation?: Omit<RegisterOptions<T, Path<T>>, "disabled" | "setValueAs" | "valueAsNumber" | "valueAsDate">;
  errors?: FieldErrors<T>;
  placeholder?: string;
};

export const CommonMultiSelectAutocomplete = <T extends FieldValues>({
  name,
  label,
  control,
  options,
  required,
  validation,
  errors,
  placeholder,
}: CommonMultiSelectProps<T>) => {
  const errorMessage = errors?.[name]?.message as string | undefined;

  return (
    <FormControl fullWidth error={!!errorMessage}>
      {label && (
        <StyledFormLabel htmlFor={name}>
          {label}
          {required && <span style={{ color: "#d32f2f" }}> *</span>}
        </StyledFormLabel>
      )}

      <Controller
        name={name}
        control={control}
        rules={validation}
        render={({ field }) => {
          const selectedIds: string[] = typeof field.value === "string" ? field.value.split(",") : [];

          const selectedValues = options.filter(opt => selectedIds.includes(String(opt.id)));

          const handleChange = (_event: React.SyntheticEvent, selected: Option[]) => {
            const newValue = selected.map(opt => String(opt.id)).join(",");
            field.onChange(newValue);
          };

          return (
            <Autocomplete
              multiple
              disableCloseOnSelect
              id="tags-outlined"
              options={options}
              slots={{
                paper: props => <Paper {...props} style={{ maxHeight: 200, overflowY: "hidden" }} />,
              }}
              value={selectedValues}
              onChange={handleChange}
              getOptionLabel={option => option.name}
              isOptionEqualToValue={(opt, val) => String(opt.id) === String(val.id)}
              renderOption={(props, option, { selected }) => {
                const { key, ...rest } = props;
                return (
                  <li key={key} {...rest}>
                    <Checkbox icon={icon} checkedIcon={checkedIcon} style={{ marginRight: 8 }} checked={selected} />
                    {option.name}
                  </li>
                );
              }}
              renderInput={params => (
                <TextField
                  {...params}
                  placeholder={selectedValues.length <= 0 ? placeholder : ""}
                  variant="outlined"
                  error={!!errorMessage}
                />
              )}
              renderValue={(tagValue, getTagProps) => {
                if (tagValue.length === 0 && placeholder) {
                  return <StyledPlaceHolderText>{placeholder}</StyledPlaceHolderText>;
                }
                return tagValue.map((option, index) => {
                  const { key, ...rest } = getTagProps({ index });
                  return <Chip key={key} label={option.name} {...rest} />;
                });
              }}
            />
          );
        }}
      />

      {errorMessage && <StyledHelperText>{errorMessage}</StyledHelperText>}
    </FormControl>
  );
};
