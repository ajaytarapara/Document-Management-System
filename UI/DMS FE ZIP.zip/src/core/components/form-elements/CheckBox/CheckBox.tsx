"use client";

import React from "react";
import { Checkbox, FormControlLabel, styled } from "@mui/material";
import { Control, Controller, Path } from "react-hook-form";

export const StyledCheckbox = styled(Checkbox)(({ theme }) => ({
  color: theme.palette.primary.main,
  padding: "3px 5px",
  "&.Mui-checked": {
    color: theme.palette.primary.main,
  },
}));

type CommonCheckboxProps<T extends object> = {
  label: string;
  name: Path<T>;
  control: Control<T>;
};

export const CommonCheckbox = <T extends object>({ label, name, control }: CommonCheckboxProps<T>) => (
  <Controller
    name={name}
    control={control}
    render={({ field }) => (
      <FormControlLabel
        control={<StyledCheckbox checked={!!field.value} onChange={e => field.onChange(e.target.checked)} />}
        label={label}
      />
    )}
  />
);
