"use client";

// MUI components
import { FormControl, FormControlLabel, Radio, RadioGroup as MUIRadioGroup } from "@mui/material";

// App-specific types
import { IRadioGroupProps } from "@core/models/interfaces";

// App-specific components
import { StyledFormLabel, StyledHelperText } from "../TextField/TextField";

export const RadioGroup: React.FC<IRadioGroupProps> = ({
  value,
  label,
  name,
  options,
  row = false,
  register,
  validation,
  errors,
}) => {
  const errorMessage = errors?.[name]?.message;
  const registration = register?.(name, validation);

  return (
    <FormControl component="fieldset" error={!!errorMessage}>
      {label && <StyledFormLabel>{label}</StyledFormLabel>}
      <MUIRadioGroup row={row} name={name} defaultValue={value}>
        {options.map(option => (
          <FormControlLabel
            key={option.value}
            value={option.value}
            label={option.label}
            control={<Radio value={option.value} {...registration} />}
          />
        ))}
      </MUIRadioGroup>
      {errorMessage && <StyledHelperText>{errorMessage}</StyledHelperText>}
    </FormControl>
  );
};
