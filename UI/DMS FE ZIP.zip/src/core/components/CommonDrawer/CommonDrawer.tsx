import React from "react";
import { Drawer, IconButton } from "@mui/material";
import { X } from "lucide-react";

interface CommonDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  lgSize?: string;
}

export const CommonDrawer: React.FC<CommonDrawerProps> = ({
  open,
  onClose,
  title = "Details",
  children,
  lgSize = "60%",
}) => {
  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: { xs: "100%", sm: "90%", md: "70%", lg: lgSize },
          bgcolor: "#faf9ff",
          display: "flex",
          flexDirection: "column",
        },
      }}
    >
      <div className="flex justify-between items-center px-4 py-3 border-b bg-[#7E57C2] text-white">
        <h2 className="text-lg font-semibold">{title}</h2>
        <IconButton onClick={onClose} sx={{ color: "white" }}>
          <X />
        </IconButton>
      </div>
      <div className="px-4 py-4 overflow-auto">{children}</div>
    </Drawer>
  );
};
