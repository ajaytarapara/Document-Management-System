"use client";

import { Facebook, Folder, Linkedin, Twitter, Youtube } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-[#242938] text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-[40px] pb-[20px] border-b border-[#676f87]">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 text-center md:text-left">
          <div className="space-y-4 flex flex-col items-center md:items-start">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <Folder className="w-9 h-9" />
              <div className="text-lg font-semibold">
                <span>DMS</span>
              </div>
            </div>
            <div>
              <p className="font-bold mb-2">FOLLOW US</p>
              <div className="flex justify-center md:justify-start space-x-4 text-xl">
                <Facebook />
                <Linkedin />
                <Twitter />
                <Youtube />
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-bold mb-3">QUICK LINKS</h4>
            <ul className="space-y-2">
              <li className="hover:border-b hover:border-white cursor-pointer">Scanning Calculator</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Records Retention</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3">ABOUT ME</h4>
            <ul className="space-y-2">
              <li className="hover:border-b hover:border-white cursor-pointer">Storage Conversion</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Security</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3">COMMUNITY</h4>
            <ul className="space-y-2">
              <li className="hover:border-b hover:border-white cursor-pointer">Twitter</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Facebook</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Youtube</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3">SUPPORT</h4>
            <ul className="space-y-2">
              <li className="hover:border-b hover:border-white cursor-pointer">Help Center</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Privacy & Terms</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Copyright</li>
              <li className="hover:border-b hover:border-white cursor-pointer">Contact us</li>
            </ul>
          </div>
        </div>
      </div>
      <p className="font-normal text-sm leading-5 text-center pt-[26px] pb-[22px]">Copyright 2025 © DMS.com</p>
    </footer>
  );
};
