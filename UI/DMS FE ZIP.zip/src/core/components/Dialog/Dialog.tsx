"use client";

import {
  Button,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Dialog as MUIDialog,
  IconButton,
  Box,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { IDialogProps } from "@core/models";
import { Constant } from "@core/constants/Constant";
import { CommonButton } from "../form-elements";

export const Dialog = ({
  open,
  onClose,
  title,
  description,
  children,
  icon,
  showActions = true,
  onSubmit,
  submitLabel = `${Constant.COMMON.SUBMIT}`,
  cancelLabel = `${Constant.COMMON.CANCEL}`,
  disableSubmit = false,
  maxWidth,
  customWidth,
  fullWidth,
  buttonType,
}: IDialogProps) => (
  <MUIDialog
    open={open}
    onClose={onClose}
    maxWidth={maxWidth}
    fullWidth={fullWidth}
    sx={customWidth ? { "& .MuiDialog-paper": { width: customWidth } } : {}}
  >
    <DialogTitle sx={{ px: 2, py: 1.5, mb: 0 }}>
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Box display="flex" alignItems="center" gap={1}>
          {icon}
          {title}
        </Box>
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            color: theme => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      </Box>
    </DialogTitle>
    <form onSubmit={onSubmit}>
      <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {typeof description === "string" ? <DialogContentText>{description}</DialogContentText> : description}
        {children}
      </DialogContent>

      {showActions && (
        <DialogActions sx={{ pb: 3, px: 3 }}>
          <Button onClick={onClose} variant="outlined" className="!capitalize !mr-1">
            {cancelLabel}
          </Button>
          <CommonButton
            disabled={disableSubmit}
            type={buttonType}
            variant="contained"
            onClick={buttonType === "button" ? onSubmit : undefined}
            className="!capitalize disabled:!opacity-50 disabled:!text-gray-300 disabled:!bg-[#7e57c2]"
          >
            {submitLabel}
          </CommonButton>
        </DialogActions>
      )}
    </form>
  </MUIDialog>
);
