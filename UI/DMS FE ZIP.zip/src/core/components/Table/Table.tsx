"use client";

import React, { useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  ColumnDef,
  SortingState,
} from "@tanstack/react-table";

import { ArrowDown, ArrowUp, ArrowUpDown } from "src/assets/Icons";
import { useForm } from "react-hook-form";
import { TableFooterPagination } from "../TablePagination/CustomPagination";

export interface CommonTableProps<TData extends object> {
  data: TData[];
  columns: ColumnDef<TData>[];
  pageSize: number;
  pageIndex: number;
  totalPage?: number;
  totalCount?: number;
  className?: string;
  emptyMessage?: string;
  onPageChange?: (pageIndex: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onSortingChange?: (sorting: SortingState) => void;
}

interface FormValues {
  pageSize: string;
}

export const CommonTable = <TData extends object>({
  data,
  columns,
  pageSize,
  pageIndex,
  totalPage,
  emptyMessage = "No data found",
  className = "",
  onSortingChange,
  onPageChange,
  onPageSizeChange,
}: CommonTableProps<TData>) => {
  const [sorting, setSorting] = useState<SortingState>([]);

  const table = useReactTable({
    data,
    columns,
    state: {
      sorting,
      pagination: { pageIndex, pageSize },
    },
    manualPagination: true,
    onSortingChange: updater => {
      const newSort = typeof updater === "function" ? updater(sorting) : updater;
      setSorting(newSort);
      onSortingChange?.(newSort);
    },
    onPaginationChange: updater => {
      const newPage = typeof updater === "function" ? updater({ pageIndex, pageSize }) : updater;
      onPageChange?.(newPage.pageIndex);
      onPageSizeChange?.(newPage.pageSize);
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  const pagination = table.getState().pagination;

  const { control } = useForm<FormValues>({
    defaultValues: {
      pageSize: pagination.pageSize.toString(),
    },
  });

  return (
    <div className={`p-4 bg-white rounded-lg shadow-md ${className}`}>
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th
                    key={header.id}
                    onClick={header.column.getToggleSortingHandler()}
                    className={`px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider ${
                      header.column.getCanSort() ? "cursor-pointer hover:bg-[#e1dcef]" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 whitespace-nowrap">
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                      {header.column.getCanSort() &&
                        (header.column.getIsSorted() === "asc" ? (
                          <ArrowUp />
                        ) : header.column.getIsSorted() === "desc" ? (
                          <ArrowDown />
                        ) : (
                          <ArrowUpDown />
                        ))}
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="text-center px-4 py-6 text-sm text-gray-500">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map(row => (
                <tr key={row.id} className="hover:bg-gray-50 transition-colors duration-150">
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id} className="px-4 py-3 text-sm text-gray-700">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data.length > 0 && (
        <TableFooterPagination
          control={control}
          totalPage={totalPage ?? 0}
          pageIndex={pageIndex}
          onPageChange={onPageChange}
          onPageSizeChange={pageSize => {
            table.options.onPaginationChange?.({
              pageIndex: 0,
              pageSize,
            });
          }}
        />
      )}
    </div>
  );
};
