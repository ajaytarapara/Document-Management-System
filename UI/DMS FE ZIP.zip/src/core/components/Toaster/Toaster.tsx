"use client";

import { Bounce, ToastContainer } from "react-toastify";
import { useColorScheme } from "@mui/material/styles";

export const ToasterContainer = () => {
  const { mode, systemMode } = useColorScheme();
  const resolvedMode = (mode === "system" ? systemMode : mode) ?? "light";

  return (
    <ToastContainer
      position="top-right"
      autoClose={3000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick={false}
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
      theme={resolvedMode as "light" | "dark" | "colored"}
      transition={Bounce}
    />
  );
};
