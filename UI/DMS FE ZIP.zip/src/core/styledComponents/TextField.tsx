"use client";

import { styled, TextField } from "@mui/material";

export const StyledTextField = styled(TextField)({
  display: "flex",
  flexDirection: "column",
  alignSelf: "center",
  width: "100%",
  "& .MuiInputBase-root": {
    height: "48px",
  },
  "& .MuiFormHelperText-root": {
    margin: "5px 0px 0px 0px",
    padding: 0,
    lineHeight: "1.2rem",
  },
});
