import { Role } from "@core/models";
import { DecodedJwtPayload } from "@main/models";

/**
 * Checks whether a JWT token is expired.
 *
 * @param token - JWT token as a string
 * @returns true if token is missing, malformed, or expired; otherwise false
 */
export const isTokenExpired = (token: string): boolean => {
  if (!token) return true;

  try {
    const payload = JSON.parse(atob(token.split(".")[1]));
    const expiry = payload.exp;

    if (!expiry) return true;

    const nowInSeconds = Math.floor(Date.now() / 1000);
    return expiry < nowInSeconds;
  } catch (error) {
    console.error("Invalid token format", error);
    return true;
  }
};

/**
 * Decodes a JWT token and returns its payload as a typed object.
 *
 * @param token - JWT token as a string
 * @returns Decoded payload object, or null if decoding fails
 */
export const decodeJwt = (token: string): DecodedJwtPayload | null => {
  try {
    const base64Url = token.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map(c => `%${("00" + c.charCodeAt(0).toString(16)).slice(-2)}`)
        .join("")
    );
    return JSON.parse(jsonPayload) as DecodedJwtPayload;
  } catch (error) {
    console.error("Failed to decode JWT:", error);
    return null;
  }
};

/**
 * Claim URI used to extract user role from JWT payload.
 * This follows Microsoft's claim naming convention for roles.
 */
export const ROLE_CLAIM_URI = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";

export const mapRoleIdToEnum = (roleId: number | string): Role => {
  switch (roleId.toString()) {
    case "1":
      return Role.Admin;
    case "2":
      return Role.Office_User;
    case "3":
      return Role.User;
    default:
      throw new Error(`Unknown role id: ${roleId}`);
  }
};

export function getRoleNumber(role: Role): number {
  switch (role) {
    case Role.Admin:
      return 1;
    case Role.Office_User:
      return 2;
    case Role.User:
      return 3;
    default:
      throw new Error("Unknown role");
  }
}
