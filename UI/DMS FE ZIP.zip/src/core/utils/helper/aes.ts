import CryptoJS from "crypto-js";
import { Constant } from "@core/constants/Constant";
import { IEncryptedApiRequest } from "@core/models";
import { toast } from "react-toastify";

// Read key/IV from .env
const envKey = process.env.NEXT_PUBLIC_AES_KEY ?? "";
const envIv = process.env.NEXT_PUBLIC_AES_IV ?? "";

if (!envKey || !envIv) {
  toast.error(Constant.MESSAGE.AES_KEY_ENCRYPT_DECRYPT_ERROR);
}

const KEY = CryptoJS.enc.Utf8.parse(envKey); // 32 bytes
const IV = CryptoJS.enc.Utf8.parse(envIv); // 16 bytes

// Convert File -> base64
export const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    if (!(file instanceof Blob)) {
      reject(new Error("Invalid file passed to fileToBase64"));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve((reader.result as string).split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

// AES Encrypt string
export const encryptString = (data: string): string =>
  CryptoJS.AES.encrypt(data, KEY, {
    iv: IV,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  }).toString();

// AES Decrypt string
export const decryptString = (cipherText: string): string =>
  CryptoJS.AES.decrypt(cipherText, KEY, {
    iv: IV,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  }).toString(CryptoJS.enc.Utf8);

//  Decrypt to object
export const decryptObject = <T>(cipherText: string): T => JSON.parse(decryptString(cipherText)) as T;

/**
 *  Define allowed upload file structure
 */
export interface UploadedFile {
  name: string;
  type: string;
  content: string; // base64
}

/**
 * Recursively prepares payload: replaces File/File[] with UploadedFile
 */
const prepareDataForEncryption = async (input: unknown): Promise<unknown> => {
  if (input instanceof File) {
    const fileData: UploadedFile = {
      name: input.name,
      type: input.type,
      content: await fileToBase64(input),
    };
    return fileData;
  }

  if (Array.isArray(input)) {
    return Promise.all(input.map(item => prepareDataForEncryption(item)));
  }

  if (input !== null && typeof input === "object") {
    const output: Record<string, unknown> = {};
    for (const key of Object.keys(input)) {
      output[key] = await prepareDataForEncryption((input as Record<string, unknown>)[key]);
    }
    return output;
  }

  return input;
};

/**
 * Encrypt payload that may include files
 */
export const encryptMixedPayload = async (data: Record<string, unknown>): Promise<IEncryptedApiRequest> => {
  const processed = await prepareDataForEncryption(data);
  const encrypted = encryptString(JSON.stringify(processed));
  return { data: encrypted };
};

/**
 *  Encrypt only JSON objects (no files)
 */
export const encryptPayloadObject = <T extends object>(obj: T): IEncryptedApiRequest => {
  return { data: encryptString(JSON.stringify(obj)) };
};

/**
 * Encrypts a numeric ID using AES encryption (CBC mode with PKCS7 padding).
 *
 * @param {number} id - The numeric ID to encrypt.
 * @returns {string} The encrypted ID encoded in a URL-safe Base64 string.
 */
export const encryptId = (id: number): string => {
  const encrypted = CryptoJS.AES.encrypt(id.toString(), KEY, {
    iv: IV,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  const base64 = encrypted.ciphertext.toString(CryptoJS.enc.Base64);

  // Make Base64 URL-safe by replacing + and /, and trimming padding (=).
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};

/**
 * Decrypts an encrypted ID string back to a numeric ID.
 *
 * @param {string} encryptedId - The encrypted ID string (URL-safe Base64).
 * @returns {number} The decrypted numeric ID.
 */
export const decryptId = (encryptedId: string): number => {
  // Restore standard Base64 format
  let base64 = encryptedId.replace(/-/g, "+").replace(/_/g, "/");

  switch (base64.length % 4) {
    case 2:
      base64 += "==";
      break;
    case 3:
      base64 += "=";
      break;
  }

  const cipherParams = CryptoJS.lib.CipherParams.create({
    ciphertext: CryptoJS.enc.Base64.parse(base64),
  });

  const decrypted = CryptoJS.AES.decrypt(cipherParams, KEY, {
    IV,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });

  const plainText = decrypted.toString(CryptoJS.enc.Utf8);
  return parseInt(plainText, 10);
};
