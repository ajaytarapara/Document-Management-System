import { PayloadAction, UnknownAction } from "@reduxjs/toolkit";
import { IEncryptedApiResponse } from "@core/models";

export const isFulfilledEncryptedAction = (action: UnknownAction): action is PayloadAction<IEncryptedApiResponse> =>
  typeof action === "object" &&
  action !== null &&
  "type" in action &&
  typeof action.type === "string" &&
  action.type.endsWith("/fulfilled") &&
  "payload" in action &&
  typeof action.payload === "object" &&
  action.payload !== null &&
  "data" in action.payload &&
  typeof (action.payload as { data: unknown }).data === "string";
