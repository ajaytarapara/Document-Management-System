/**
 * Generates a random hex color code.
 * - Randomly selects 6 characters from the string "0123456789ABCDEF".
 * - Returns a color string in the format "#RRGGBB".
 *
 * @returns {string} A randomly generated hex color (e.g., "#3FA2C1").
 */
export const getRandomColor = () => {
  const letters = "0123456789ABCDEF";
  return (
    "#" +
    Array.from({ length: 6 })
      .map(() => letters[Math.floor(Math.random() * 16)])
      .join("")
  );
};

/**
 * Determines the appropriate text color (black or white) based on the brightness
 * of a given background color to ensure readability.
 *
 * Uses the YIQ formula for luminance to decide whether the background is
 * light or dark.
 *
 * @param bgColor - A hex color string in the format "#RRGGBB".
 * @returns "#000000" (black) for light backgrounds, "#ffffff" (white) for dark backgrounds.
 */
export const getTextColorForBackground = (bgColor: string): string => {
  const r = parseInt(bgColor.slice(1, 3), 16);
  const g = parseInt(bgColor.slice(3, 5), 16);
  const b = parseInt(bgColor.slice(5, 7), 16);
  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 150 ? "#000000" : "#ffffff";
};

// returns black or white depending on tab bg brightness
export const getReadableBorderColor = (hex: string) => {
  const color = hex.replace("#", "");
  const r = parseInt(color.substr(0, 2), 16);
  const g = parseInt(color.substr(2, 2), 16);
  const b = parseInt(color.substr(4, 2), 16);

  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 150 ? "#000000" : "#ffffff"; // black on light bg, white on dark bg
};
