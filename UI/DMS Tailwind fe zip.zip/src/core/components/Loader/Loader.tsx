"use client";

import { useSelectorLoaderState } from "@/main/store";
import "./Loader.css";

export const Loader = () => {
  const { isLoading } = useSelectorLoaderState();
  return (
    <>
      {isLoading && (
        <div className="loader-overlay">
          <div className="loader-spinner"></div>
        </div>
      )}
    </>
  );
};
