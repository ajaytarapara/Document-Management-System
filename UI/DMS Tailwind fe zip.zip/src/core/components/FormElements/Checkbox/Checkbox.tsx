"use client";

import React from "react";
import { Control, Controller, Path } from "react-hook-form";

type CommonCheckboxProps<T extends object> = {
  label: string;
  name: Path<T>;
  control: Control<T>;
};

export const CommonCheckbox = <T extends object>({
  label,
  name,
  control,
}: CommonCheckboxProps<T>) => {
  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <label className="inline-flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={!!field.value}
            onChange={(e) => field.onChange(e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 cursor-pointer 
                       accent-[#5e35b1]  focus:ring-[#5e35b1]"
          />
          <span className="text-sm text-gray-800">{label}</span>
        </label>
      )}
    />
  );
};
