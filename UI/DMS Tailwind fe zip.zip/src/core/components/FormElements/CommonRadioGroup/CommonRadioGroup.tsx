"use client";

import React from "react";
import { Path, RegisterOptions, FieldErrors } from "react-hook-form";
import { Option } from "@/main/models";

interface CommonRadioGroupProps<T extends object> {
  label?: string;
  name: Path<T>;
  options: Option[];
  row?: boolean;
  value?: string | number;
  register?: any;
  validation?: RegisterOptions<T>;
  errors?: FieldErrors<T>;
}

export const RadioGroup = <T extends object>({
  label,
  name,
  options,
  row = false,
  value,
  register,
  validation,
  errors,
}: CommonRadioGroupProps<T>) => {
  const fieldError = errors?.[name as keyof FieldErrors<T>];
  const errorMessage =
    typeof fieldError?.message === "string" ? fieldError.message : undefined;
  return (
    <div className="flex flex-col w-full">
      {label && (
        <label className="block mb-1 text-sm font-semibold text-gray-700">
          {label}
        </label>
      )}

      <div className={`flex ${row ? "flex-row gap-4" : "flex-col gap-2"}`}>
        {options.map((option) => (
          <label
            key={option.value}
            className="inline-flex items-center cursor-pointer gap-2"
          >
            <input
              type="radio"
              value={option.value}
              defaultChecked={value === option.value}
              {...(register ? register(name, validation) : {})}
              className={`h-4 w-4 border-gray-300 accent-[#5e35b1]  focus:ring-[#5e35b1] text-[#5e35b1]`}
            />
            <span className="text-gray-800 text-sm">{option.label}</span>
          </label>
        ))}
      </div>

      {errorMessage && (
        <p className="mt-1 text-xs text-red-500">{errorMessage}</p>
      )}
    </div>
  );
};
