"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Controller,
  Control,
  Path,
  FieldValues,
  FieldErrors,
  RegisterOptions,
} from "react-hook-form";
import { ChevronDown } from "lucide-react";
import { Option } from "@/main/models";
import { ButtonType } from "@/core/models";

interface CommonSelectProps<T extends FieldValues> {
  label?: string;
  name: Path<T>;
  control: Control<T>;
  options: Option[];
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  fullWidth?: boolean;
  customClass?: string;
  customSelectClass?: string;
  style?: React.CSSProperties;
  errors?: FieldErrors<T>;
  dropdownHeight?: number;
  validations?: Omit<
    RegisterOptions<T, Path<T>>,
    "setValueAs" | "disabled" | "valueAsNumber" | "valueAsDate"
  >;
  onChange?: (value: string) => void;
}

export const CommonSelect = <T extends FieldValues>({
  label,
  name,
  control,
  options,
  placeholder,
  disabled = false,
  required = false,
  fullWidth = false,
  customClass = "",
  style = {},
  errors,
  dropdownHeight = 200,
  validations,
  customSelectClass,
  onChange,
}: CommonSelectProps<T>) => {
  const hasError = !!errors?.[name];
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  /**
   * useEffect:
   * - Adds a global click listener to detect clicks outside the dropdown.
   * - Closes the dropdown if clicked outside.
   * - Cleans up the listener on unmount.
   */
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div
      ref={ref}
      className={`flex flex-col ${
        fullWidth ? "w-full" : "w-auto"
      } ${customClass}`}
      style={style}
    >
      {label && (
        <label className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary dark:text-gray-200">
          {label}
          {required && <span className="text-red-500"> *</span>}
        </label>
      )}

      <Controller
        name={name}
        control={control}
        rules={validations}
        render={({ field }) => {
          const selectedOption = options.find(
            (opt) => opt.value === field.value
          );

          return (
            <div className="relative">
              <button
                type={ButtonType.Button}
                onClick={() => !disabled && setOpen((prev) => !prev)}
                className={`flex w-full items-center justify-between rounded-md border px-3 py-2 text-sm h-[56px]
                ${
                  disabled
                    ? "bg-gray-100 cursor-not-allowed"
                    : "cursor-pointer"
                }
                ${customSelectClass}
                ${
                  hasError
                    ? "border-red-500 focus:ring-red-500 focus:border-red-500 focus:ring-1"
                    : "border-gray-300 focus:border-[#5e35b1] focus:ring-1 focus:ring-[#5e35b1]"
                }`}
              >
                <span
                  className={selectedOption ? "text-gray-900" : "text-gray-400"}
                >
                  {selectedOption
                    ? selectedOption.label
                    : placeholder || "Select..."}
                </span>
                <ChevronDown className="h-4 w-4 text-gray-500" />
              </button>

              {open && (
                <ul
                  className="absolute z-10 mt-1 py-2 w-full rounded-md border border-gray-300 bg-white shadow-lg overflow-auto"
                  style={{ maxHeight: dropdownHeight }}
                >
                  {options.map((option, index) => (
                    <li
                      key={`${option.value}-${index}`}
                      onClick={() => {
                        field.onChange(option.value);
                        onChange?.(option.value as string);
                        setOpen(false);
                      }}
                      className={`px-3 py-2 text-sm hover:bg-purple-100 cursor-pointer
                        ${
                          field.value === option.value
                            ? "bg-purple-50 font-medium"
                            : ""
                        }`}
                    >
                      {option.label}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        }}
      />

      {hasError && (
        <p className="mt-1 text-xs text-red-500">
          {errors?.[name]?.message as string}
        </p>
      )}
    </div>
  );
};
