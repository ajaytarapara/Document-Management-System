"use client";

import React from "react";
import clsx from "clsx";
import {
  FieldErrors,
  FieldValues,
  Path,
  RegisterOptions,
  UseFormRegister,
} from "react-hook-form";

type CommonTextFieldProps<T extends FieldValues> =
  React.InputHTMLAttributes<HTMLInputElement> & {
    name: Path<T>;
    label?: string;
    register?: UseFormRegister<T>;
    validation?: RegisterOptions<T, Path<T>>;
    errors?: FieldErrors<T>;
    errorMessage?: string;
    startAdornment?: React.ReactNode; // custom support
    endAdornment?: React.ReactNode; // custom support
    multiline?: boolean;
    rows?: number;
  };

export const CommonTextField = <T extends FieldValues>({
  name,
  label,
  register,
  validation,
  errors,
  errorMessage: customErrorMessage,
  required,
  disabled,
  className,
  startAdornment,
  endAdornment,
  multiline,
  rows,
  ...props
}: CommonTextFieldProps<T>) => {
  const errorMessage =
    (errors?.[name]?.message as string | undefined) ?? customErrorMessage;
  const registration = register ? register(name, validation) : {};

  return (
    <div className="w-full">
      {label && (
        <label
          htmlFor={name}
          className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary"
        >
          {label}
          {required && <span className="text-red-600"> *</span>}
        </label>
      )}
      <div className="relative flex items-center">
        {startAdornment && (
          <div className="absolute left-3 flex items-center pointer-events-none">
            {startAdornment}
          </div>
        )}
        {multiline ? (
          <textarea
            id={name}
            disabled={disabled}
            rows={rows}
            className={clsx(
              "w-full rounded-md border px-[13px] py-[15px] text-sm sm:text-base resize-none",
              "focus:outline-none focus:ring-1 focus:ring-[#5E35B1] focus:border-[#5E35B1]",
              "transition-colors duration-200",
              "placeholder-gray-400",
              "disabled:border-gray-300 disabled:bg-[#f8f5ff] disabled:text-black",
              errorMessage
                ? "border-red-500 focus:ring-red-500 focus:border-red-500"
                : "border-gray-300 hover:border-[#5E35B1]",
              className
            )}
            {...registration}
            {...(props as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
          />
        ) : (
          <input
            id={name}
            name={name}
            disabled={disabled}
            className={clsx(
              "w-full rounded-md border px-[13px] py-[15px] text-sm sm:text-base",
              startAdornment ? "pl-10" : "pl-3",
              endAdornment ? "pr-10" : "pr-3",
              "focus:outline-none focus:ring-1 focus:ring-[#5E35B1] focus:border-[#5E35B1]",
              "transition-colors duration-200",
              "placeholder-gray-400",
              "disabled:border-gray-300 disabled:bg-[#f8f5ff] disabled:text-black",
              "[&:-webkit-autofill]:shadow-[0_0_0_100px_white_inset]",
              errorMessage
                ? "border-red-500 focus:ring-red-500 focus:border-red-500"
                : "border-gray-300 hover:border-[#5E35B1]",
              className
            )}
            {...props}
            {...registration}
          />
        )}

        {endAdornment && (
          <div className="absolute right-3 flex items-center">
            {endAdornment}
          </div>
        )}
      </div>
      {errorMessage && (
        <p className="mt-1 text-sm text-red-600 leading-5">{errorMessage}</p>
      )}
    </div>
  );
};
