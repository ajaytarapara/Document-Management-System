"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Controller,
  Control,
  FieldValues,
  Path,
  RegisterOptions,
  FieldErrors,
} from "react-hook-form";
import { X, ChevronDown } from "lucide-react";
import { MultiSelectOption } from "@/main/models";
import { ButtonType } from "@/core/models";

type CommonMultiSelectProps<T extends FieldValues> = {
  name: Path<T>;
  label?: string;
  control: Control<T>;
  options: MultiSelectOption[];
  required?: boolean;
  validation?: Omit<
    RegisterOptions<T, Path<T>>,
    "disabled" | "setValueAs" | "valueAsNumber" | "valueAsDate"
  >;
  errors?: FieldErrors<T>;
  placeholder?: string;
  fullWidth?: boolean;
};

export const CommonMultiSelectAutocomplete = <T extends FieldValues>({
  name,
  label,
  control,
  options,
  required,
  validation,
  errors,
  placeholder,
  fullWidth = false,
}: CommonMultiSelectProps<T>) => {
  const errorMessage = errors?.[name]?.message as string | undefined;
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);

  /**
   * useEffect:
   * - Attaches a click listener to detect clicks outside the dropdown.
   * - Closes the dropdown when clicking outside.
   * - Cleans up the listener on component unmount.
   */
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div
      className={`flex flex-col ${fullWidth ? "w-full" : "w-auto"}`}
      ref={dropdownRef}
    >
      {label && (
        <label className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary dark:text-gray-200">
          {label}
          {required && <span className="text-red-500"> *</span>}
        </label>
      )}

      <Controller
        name={name}
        control={control}
        rules={validation}
        render={({ field }) => {
          const selectedIds: string[] =
            typeof field.value === "string" ? field.value.split(",") : [];
          const selectedValues = options.filter((opt) =>
            selectedIds.includes(String(opt.id))
          );

          const toggleOption = (option: MultiSelectOption) => {
            if (selectedIds.includes(String(option.id))) {
              field.onChange(
                selectedIds.filter((id) => id !== String(option.id)).join(",")
              );
            } else {
              field.onChange([...selectedIds, String(option.id)].join(","));
            }
          };

          return (
            <div className="relative">
              <button
                type={ButtonType.Button}
                onClick={() => setOpen(!open)}
                className={`flex w-full items-center justify-between rounded-md border px-3 py-1 text-sm min-h-[46px] ${
                  errorMessage
                    ? "border-red-500 focus:ring-red-500 focus:border-red-500 focus:ring-1"
                    : "border-gray-300 focus:border-[#5e35b1] focus:ring-1 focus:ring-[#5e35b1]"
                } bg-white text-gray-900 cursor-pointer`}
              >
                <div className="flex flex-wrap gap-1">
                  {selectedValues.length === 0 && (
                    <span className="text-gray-400">
                      {placeholder || "Select..."}
                    </span>
                  )}
                  {selectedValues.map((option) => (
                    <span
                      key={option.id}
                      className="flex items-center gap-1 rounded bg-purple-100 px-2 py-1 text-xs text-[#5e35b1]"
                    >
                      {option.name}
                      <X
                        size={14}
                        className="cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleOption(option);
                        }}
                      />
                    </span>
                  ))}
                </div>
                <ChevronDown className="h-4 w-4 text-gray-500" />
              </button>

              {open && (
                <ul className="absolute z-10 mt-1 w-full max-h-60 overflow-auto rounded-md border border-gray-300 bg-white shadow-lg">
                  {options.map((option) => {
                    const selected = selectedIds.includes(String(option.id));
                    return (
                      <li
                        key={option.id}
                        className={`flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-purple-100 ${
                          selected ? "bg-purple-50 font-medium" : ""
                        }`}
                        onClick={() => toggleOption(option)}
                      >
                        <input
                          type="checkbox"
                          checked={selected}
                          readOnly
                          className="h-4 w-4 rounded border-gray-300 cursor-pointer accent-[#5e35b1] focus:ring-[#5e35b1]"
                        />
                        <span>{option.name}</span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          );
        }}
      />

      {errorMessage && (
        <p className="mt-1 text-xs text-red-500">{errorMessage}</p>
      )}
    </div>
  );
};
