"use client";

import React from "react";
import clsx from "clsx";

type Variant = "contained" | "outlined";

type CommonButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  children: React.ReactNode;
  fullWidth?: boolean;
  variant?: Variant;
};

export const CommonButton: React.FC<CommonButtonProps> = ({
  children,
  fullWidth,
  variant = "contained",
  disabled,
  className,
  ...props
}) => {
  return (
    <button
      disabled={disabled}
      className={clsx(
        "font-bold rounded-md max-h-[48px] px-4 py-2 cursor-pointer",
        fullWidth && "w-full",
        variant === "contained" &&
          clsx(
            "bg-[#5E35B1] text-white",
            "hover:bg-[#5E35B1]",
            "disabled:bg-[#ede7f6] disabled:text-[#5E35B1] disabled:opacity-50"
          ),
        variant === "outlined" &&
          clsx(
            "bg-transparent text-[#5E35B1] border border-[#5E35B1]",
            "hover:bg-gray-100",
            "disabled:bg-[#ede7f6] disabled:text-white disabled:border-[#b0a7c7] disabled:opacity-50"
          ),
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};
