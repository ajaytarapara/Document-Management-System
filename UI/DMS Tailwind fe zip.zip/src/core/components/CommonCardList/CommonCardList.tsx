"use client";

import React from "react";
import { Control } from "react-hook-form";
import { TablePagination } from "../TablePagination/TablePagination";
import { Constant } from "@/core/constants/Constant";
import { FormTableValues } from "@/main/models";

interface CommonCardListProps<TData extends object> {
  data: TData[];
  renderCard: (item: TData) => React.ReactNode; 
  pageIndex: number;
  pageSize: number;
  totalPage?: number;
  className?: string;
  emptyMessage?: string;
  control: Control<FormTableValues>;
  onPageChange?: (pageIndex: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
}

export const CommonCardList = <TData extends object>({
  data,
  renderCard,
  pageIndex,
  totalPage,
  control,
  className = "",
  emptyMessage = Constant.MESSAGE.NO_TABLE_DATA_FOUND,
  onPageChange,
  onPageSizeChange,
}: CommonCardListProps<TData>) => {
  return (
    <div className={`p-4 bg-white rounded-lg  ${className}`}>
      {data.length === 0 ? (
        <div className="text-center py-10 text-gray-500">{emptyMessage}</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.map((item, index) => (
            <div key={index}>{renderCard(item)}</div>
          ))}
        </div>
      )}

      {data.length > 0 && (
        <div className="mt-6">
          <TablePagination
            control={control}
            totalPage={totalPage ?? 0}
            pageIndex={pageIndex}
            onPageChange={onPageChange}
            onPageSizeChange={onPageSizeChange}
          />
        </div>
      )}
    </div>
  );
};
