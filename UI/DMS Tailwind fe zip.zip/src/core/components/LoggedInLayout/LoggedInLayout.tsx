"use client";

import { ReactNode } from "react";
import { Header } from "../Header/Header";
import { Footer } from "../Footer/Footer";

interface LayoutProps {
  children: ReactNode;
}

export const LoggedInLayout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow bg-[#e1dcef]">
        <div className="pt-[80px] md:pt-[100px] pb-[80px] mx-4 sm:mx-6 lg:mx-6 xl:mx-auto">{children}</div>
      </main>
      <Footer />
    </div>
  );
};
