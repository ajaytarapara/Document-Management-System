"use client";

import React, { useEffect, useState } from "react";
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  ColumnDef,
  SortingState,
  Row,
} from "@tanstack/react-table";

import { useForm } from "react-hook-form";
import { TablePagination } from "../TablePagination/TablePagination";
import { ArrowDown, ArrowUp, ArrowUpDown } from "@/assets/Icons";
import { Constant } from "@/core/constants/Constant";
import { SortDirection } from "@/core/models";

export interface CommonTableProps<TData extends object> {
  data: TData[];
  columns: ColumnDef<TData>[];
  pageSize: number;
  pageIndex: number;
  totalPage?: number;
  totalCount?: number;
  className?: string;
  emptyMessage?: string;
  onPageChange?: (pageIndex: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onSortDirectionChange?: (sorting: SortingState) => void;
}

interface FormValues {
  pageSize: string;
}

export const CommonTable = <TData extends object>({
  data,
  columns,
  pageSize,
  pageIndex,
  totalPage,
  emptyMessage = Constant.MESSAGE.NO_TABLE_DATA_FOUND,
  className = "",
  onSortDirectionChange,
  onPageChange,
  onPageSizeChange,
}: CommonTableProps<TData>) => {
  const [sorting, setSorting] = useState<SortingState>([]);
  // Initialize the table using TanStack React Table
  const table = useReactTable({
    data,
    columns,
    state: {
      sorting,
      pagination: { pageIndex, pageSize },
    },
    manualPagination: true, // Pagination handled externally
    onSortingChange: (updater) => {
      const newSort =
        typeof updater === "function" ? updater(sorting) : updater;
      setSorting(newSort);
      onSortDirectionChange?.(newSort);
    },
    onPaginationChange: (updater) => {
      const newPage =
        typeof updater === "function"
          ? updater({ pageIndex, pageSize })
          : updater;
      onPageChange?.(newPage.pageIndex); // Notify parent about page change
      onPageSizeChange?.(newPage.pageSize); // Notify parent about page size change
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
  });

  const pagination = table.getState().pagination;

  /**
   * Initialize react-hook-form with default values.
   * control: Used to connect input components to the form state.
   * defaultValues: Sets initial form field values, here setting `pageSize` as a string.
   */
  const { control, setValue } = useForm<FormValues>({
    defaultValues: {
      pageSize: pagination.pageSize.toString(),
    },
  });

  /**
   * Syncs the `pageSize` state with the form field value.
   * Whenever `pageSize` changes, update the form's "pageSize" field.
   * Converted to string since form inputs typically expect string values.
   */
  useEffect(() => {
    setValue("pageSize", pageSize.toString());
  }, [pageSize, setValue]);

  const TableRow = React.memo(
    ({ row, rowIndex }: { row: Row<TData>; rowIndex: number }) => (
      <tr
        className={`hover:bg-gray-50 transition-colors duration-150 ${
          rowIndex !== table.getRowModel().rows.length - 1
            ? "border-b border-gray-200"
            : ""
        }`}
      >
        {row.getVisibleCells().map((cell) => (
          <td key={cell.id} className="px-4 py-3 text-sm text-gray-700">
            {flexRender(cell.column.columnDef.cell, cell.getContext())}
          </td>
        ))}
      </tr>
    )
  );

  return (
    <div className={`p-4 bg-white rounded-lg shadow-md ${className}`}>
      <div className="overflow-x-auto border border-gray-200 rounded-lg">
        <table className="min-w-full border-collapse">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    onClick={
                      table.getRowModel().rows.length > 1
                        ? header.column.getToggleSortingHandler()
                        : undefined
                    }
                    className={`px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider ${
                      header.column.getCanSort()
                        ? "cursor-pointer hover:bg-[#e1dcef]"
                        : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 whitespace-nowrap">
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                      {header.column.getCanSort() &&
                        (header.column.getIsSorted() ===
                        SortDirection.ASC.toLowerCase() ? (
                          <ArrowUp />
                        ) : header.column.getIsSorted() ===
                          SortDirection.DESC.toLowerCase() ? (
                          <ArrowDown />
                        ) : table.getRowModel().rows.length > 1 ? (
                          <ArrowUpDown />
                        ) : null)}
                    </div>
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody className="bg-white">
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length}
                  className="text-center px-4 py-6 text-sm text-gray-500"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              table
                .getRowModel()
                .rows.map((row, rowIndex) => (
                  <TableRow key={row.id} row={row} rowIndex={rowIndex} />
                ))
            )}
          </tbody>
        </table>
      </div>

      {data.length > 0 && (
        <TablePagination
          control={control}
          totalPage={totalPage ?? 0}
          pageIndex={pageIndex}
          onPageChange={onPageChange}
          onPageSizeChange={(pageSize) => {
            table.options.onPaginationChange?.({
              pageIndex: 0,
              pageSize,
            });
          }}
        />
      )}
    </div>
  );
};
