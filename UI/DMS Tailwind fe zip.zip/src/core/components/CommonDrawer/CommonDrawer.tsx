"use client";

import React, { useEffect, useState } from "react";
import { X } from "lucide-react";

interface CommonDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string | React.ReactNode;
  children: React.ReactNode;
  lgSize?: string | number;
}

export const CommonDrawer: React.FC<CommonDrawerProps> = ({
  open,
  onClose,
  title = "Details",
  children,
  lgSize = "60%",
}) => {
  const [drawerWidth, setDrawerWidth] = useState(lgSize);

  /**
   * Update drawer width based on screen size
   */
  useEffect(() => {
    const updateWidth = () => {
      if (window.innerWidth < 768) {
        setDrawerWidth("80%");
      } else {
        setDrawerWidth(lgSize);
      }
    };

    updateWidth(); 
    window.addEventListener("resize", updateWidth);

    return () => window.removeEventListener("resize", updateWidth);
  }, [lgSize]);

  /**
   * useEffect Hook:
   * - Disables body scrolling when the drawer is open.
   * - Restores scrolling when closed or on component unmount.
   */
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    // Cleanup: restore scroll when component unmounts
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/40 z-40" onClick={onClose} />
      )}

      <div
        className={`fixed top-0 right-0 h-full bg-[#faf9ff] shadow-xl transform transition-transform duration-300 z-50 flex flex-col`}
        style={{
          width: drawerWidth,
          transform: open ? "translateX(0)" : "translateX(100%)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center px-4 py-3 border-b bg-[#5e35b1] text-white">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/20 cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        <div className="px-4 py-4 overflow-auto flex-1">{children}</div>
      </div>
    </>
  );
};
