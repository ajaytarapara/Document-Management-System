"use client";

import React, { useState, useRef, useEffect, useMemo } from "react";
import { Controller, Control, FieldValues, Path } from "react-hook-form";
import { ChevronDown, ChevronUp } from "lucide-react";
import { ButtonType, PointerEvents } from "@/core/models";

type PageSizeOption = { value: string; label: string };

interface PageSizeSelectProps<T extends FieldValues> {
  control: Control<T>;
  name: Path<T>;
  onPageSizeChange?: (pageSize: number) => void;
  options?: PageSizeOption[];
  placeholder?: string;
}

const defaultPageSizeOptions: PageSizeOption[] = [
  { value: "5", label: "5" },
  { value: "10", label: "10" },
  { value: "20", label: "20" },
  { value: "50", label: "50" },
  { value: "100", label: "100" },
];

export const PageSizeSelect = <T extends FieldValues>({
  control,
  name,
  onPageSizeChange,
  options = defaultPageSizeOptions,
  placeholder = "Select paze size",
}: PageSizeSelectProps<T>) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  /**
   * Effect to close dropdown when clicking outside
   */
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener(PointerEvents.POINTER_DOWN, handleClickOutside);
    return () =>
      document.removeEventListener(
        PointerEvents.POINTER_DOWN,
        handleClickOutside
      );
  }, []);

  return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        const selectedOption = useMemo(
          () => options.find((opt) => opt.value === String(field.value)),
          [field.value, options]
        );

        return (
          <div ref={ref} className="relative min-w-[120px]">
            <button
              type={ButtonType.Button}
              onClick={() => setOpen((prev) => !prev)}
              className="flex cursor-pointer w-full h-[30px] items-center justify-between rounded-md border px-3 py-2 text-sm bg-white text-gray-900 border-gray-300 focus:outline-none focus:ring-1 focus:ring-[#5e35b1] focus:border-[#5e35b1]"
            >
              <span
                className={selectedOption ? "text-gray-900" : "text-gray-400"}
              >
                {selectedOption ? selectedOption.label : placeholder}
              </span>
              {open ? (
                <ChevronUp className="h-4 w-4 text-gray-400" size={20} />
              ) : (
                <ChevronDown className="h-4 w-4 text-gray-400" size={20} />
              )}
            </button>

            {/* Dropdown menu */}
            {open && (
              <div className="absolute z-10 mt-1 w-full rounded-md border border-gray-300 bg-white shadow-lg overflow-auto max-h-40">
                {options.map((option) => (
                  <div
                    key={option.value}
                    onClick={() => {
                      field.onChange(option.value);
                      onPageSizeChange?.(Number(option.value));
                      setOpen(false);
                    }}
                    className={`px-3 py-2 text-sm cursor-pointer hover:bg-purple-50 ${
                      field.value === option.value
                        ? "bg-[#ede7f6] text-[#5E35B1] font-medium"
                        : ""
                    }`}
                  >
                    {option.label}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      }}
    />
  );
};
