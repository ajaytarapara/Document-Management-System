"use client";

import { FormTableValues } from "@/main/models";
import { Control } from "react-hook-form";
import { PageSizeSelect } from "./PageSizeSelect ";
import { CustomPagination } from "./CustomPagination";

interface TablePaginationProps {
  control: Control<FormTableValues>;
  totalPage: number;
  pageIndex: number;
  onPageChange?: (pageIndex: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
}

export const TablePagination = ({
  control,
  totalPage,
  pageIndex,
  onPageChange,
  onPageSizeChange,
}: TablePaginationProps) => {
  // If no pages exist, hide the pagination footer
  if (totalPage <= 0) return null;

  return (
    <div className="mt-4 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-2">
        <p className="text-sm">Rows per page:</p>
        <PageSizeSelect
          name="pageSize"
          control={control}
          onPageSizeChange={onPageSizeChange}
        />
      </div>

      <div className="flex justify-center md:justify-end items-center gap-2">
        <CustomPagination
          count={totalPage}
          page={pageIndex}
          onChange={(newPage) => {
            if (onPageChange) onPageChange(newPage);
          }}
        />
      </div>
    </div>
  );
};
