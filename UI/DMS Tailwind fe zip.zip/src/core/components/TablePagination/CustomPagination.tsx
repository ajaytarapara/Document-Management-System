import { ChevronLeft, ChevronRight } from "lucide-react";
import React from "react";
import { CommonButton } from "../FormElements/Button/Button";

interface PaginationProps {
  count: number; // total pages
  page: number; // current page (1-based)
  onChange: (page: number) => void;
}

export const CustomPagination: React.FC<PaginationProps> = ({
  count,
  page,
  onChange,
}) => {
  // If there is only one page or no pages, don't render pagination
  if (count <= 1) return null;

  /**
   * Handles page click event
   * Ensures new page number is within valid range
   */
  const handlePageClick = (p: number) => {
    if (p >= 1 && p <= count) {
      onChange(p);
    }
  };

  /**
   * Generate page numbers dynamically
   * - Always show first & last page
   * - Show current ±2 pages
   * - Insert "..." where pages are skipped
   */
  const renderPageNumbers = () => {
    const pages: (number | "...")[] = [];

    if (count <= 4) {
      // Case 1: total pages ≤ 4 → show all
      for (let i = 1; i <= count; i++) {
        pages.push(i);
      }
    } else if (page <= 2) {
      // Case 2: near start
      pages.push(1, 2, 3, 4, "...", count);
    } else if (page >= count - 1) {
      // Case 3: near end
      pages.push(1, "...", count - 2, count - 1, count);
    } else {
      // Case 4: middle
      pages.push(1, "...", page - 1, page, page + 1, "...", count);
    }

    return pages.map((p, idx) =>
      p === "..." ? (
        <span key={`ellipsis-${idx}`} className="px-2 text-gray-500">
          ...
        </span>
      ) : (
        <button
          key={`page-${p}`}
          onClick={() => handlePageClick(p)}
          className={`w-8 h-8 rounded-md border text-sm font-medium transition-colors cursor-pointer
          ${
            p === page
              ? "bg-[#ede7f6] border-[#5e35b1] text-[#5E35B1]"
              : "bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
          }`}
        >
          {p}
        </button>
      )
    );
  };

  return (
    <div className="flex justify-center md:justify-end items-center gap-1 sm:gap-2">
      <CommonButton
        onClick={() => handlePageClick(page - 1)}
        disabled={page <= 1}
        variant="contained"
        className="flex items-center px-2 sm:px-3 py-2 rounded-md text-xs sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <ChevronLeft className="h-4 w-4" />
        <span className="hidden sm:inline ml-1">Prev</span>
      </CommonButton>

      <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm">
        {renderPageNumbers()}
      </div>

      <CommonButton
        onClick={() => handlePageClick(page + 1)}
        disabled={page >= count}
        variant="contained"
        className="flex items-center px-2 sm:px-3 py-2 rounded-md text-xs sm:text-sm disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <span className="hidden sm:inline mr-1">Next</span>
        <ChevronRight className="h-4 w-4" />
      </CommonButton>
    </div>
  );
};
