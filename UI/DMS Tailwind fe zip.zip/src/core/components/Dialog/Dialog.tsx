"use client";

import { X } from "lucide-react";
import { Constant } from "@/core/constants/Constant";
import { ButtonType, IDialogProps } from "@/core/models";
import clsx from "clsx";
import { CommonButton } from "..";

export const Dialog = ({
  open,
  onClose,
  title,
  description,
  children,
  icon,
  showActions = true,
  onSubmit,
  submitLabel = `${Constant.COMMON.SUBMIT}`,
  cancelLabel = `${Constant.COMMON.CANCEL}`,
  disableSubmit = false,
  maxWidth = "sm",
  customWidth,
  fullWidth,
  buttonType,
}: IDialogProps) => {
  if (!open) return null;

  // Map of maxWidth keys to their pixel values
  const maxWidthValues: Record<string, string> = {
    xs: "360px",
    sm: "700px",
    md: "960px",
    lg: "1280px",
    xl: "1536px",
    xxl: "1820px",
  };

  /** Determine the appropriate max-width class for the dialog */
  const dialogMaxWidthStyle: React.CSSProperties = customWidth
    ? { width: customWidth, maxWidth: customWidth }
    : typeof maxWidth === "string" && maxWidthValues[maxWidth]
    ? { maxWidth: maxWidthValues[maxWidth] }
    : {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/40" onClick={onClose}></div>

      {/* Dialog container */}
      <div
        className={clsx(
          "relative bg-white rounded-xl shadow-lg flex flex-col w-full mx-8",
          fullWidth ? "w-full" : "w-auto"
        )}
        style={dialogMaxWidthStyle}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#5e35b1] px-4 py-3">
          <div className="flex items-center gap-2">
            {icon}
            <h2 className="text-lg font-semibold">{title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 p-2 rounded-full hover:bg-gray-100 hover:text-gray-700 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={onSubmit}>
          <div className="p-4 space-y-3">
            {typeof description === "string" ? (
              <p className="text-gray-600">{description}</p>
            ) : (
              description
            )}
            {children}
          </div>

          {/* Footer / Actions */}
          {showActions && (
            <div className="flex justify-end gap-2 px-4 py-3">
              <CommonButton type={ButtonType.Button} variant="outlined" onClick={onClose}>
                {cancelLabel}
              </CommonButton>

              <CommonButton
                disabled={disableSubmit}
                type={buttonType}
                variant="contained"
                onClick={
                  buttonType === ButtonType.Button ? onSubmit : undefined
                }
                className="!capitalize disabled:!opacity-50 disabled:!text-gray-300 disabled:!bg-[#5e35b1]"
              >
                {submitLabel}
              </CommonButton>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
