export interface IFormState {
  message: string;
  isSuccessful: boolean;
}
