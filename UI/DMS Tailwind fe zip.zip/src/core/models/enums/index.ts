export enum Role {
  Admin = "Admin",
  Office_User = "Office_User",
  User = "User",
}

export enum LoginTypeEnum {
  USERNAME = "username",
  SSO = "sso",
  BOTH = "both",
}

export enum FieldType {
  Text = "text",
  Checkbox = "checkbox",
  Radio = "radio",
  Select = "select",
  Highlight = "highlight",
  Signature = "signature",
  Eraser = "eraser",
}

export enum Corner {
  TopLeft = "top-left",
  TopRight = "top-right",
  BottomLeft = "bottom-left",
  BottomRight = "bottom-right",
}

export const corners: Corner[] = [
  Corner.TopLeft,
  Corner.TopRight,
  Corner.BottomLeft,
  Corner.BottomRight,
];

export enum ShareStep {
  Email = "email",
  Otp = "otp",
  Done = "done",
}

export enum SortDirection {
  ASC = "Asc",
  DESC = "Desc",
  NONE = "none",
}

export enum PointerEvents {
  POINTER_DOWN = "mousedown",
  SCROLL = "scroll",
}

export enum KeyEvents {
  ESCAPE = "Escape",
  KEYDOWN = "keydown",
}

export enum BooleanValue {
  TRUE = "true",
  FALSE = "false",
}

export enum ButtonType {
  Button = "button",
  Submit = "submit",
  Reset = "reset",
}

export enum Anchor {
  Left = "left",
  Right = "right",
  Top = "top",
  Bottom = "bottom",
}
