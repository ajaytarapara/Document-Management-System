import { LoginTypeEnum } from "@/core/models";

// Centralized constants for validation patterns and user-facing messages
export const Constant = {
  REGEX: {
    PASSWORD_COMPLEXITY:
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
    EMAIL_REGEX: /\S+@\S+\.\S+/,
    USERNAME_REGEX: /^[a-zA-Z0-9_]{3,}$/,
    PHONE_REGEX: /^[6-9]\d{9}$/,
    POSTAL_CODE_REGEX: /^(?!0{6})\d{6}$/,
    ALLOW_ONLY_TEXT_REGEX: /^[A-Za-z\s]+$/,
    MULTIPLE_EMAIL_WITH_COMMA_SEPRATED_VALUE: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  },
  MESSAGE: {
    USER_NAME_MAX_LIMIT: "Maximum 50 characters allowed",
    ADDRESS_MAX_LIMIT: "Maximum 200 characters allowed",
    PASSWORD_INVALID_FORMAT:
      "Password must be at least 8 characters, include uppercase, lowercase, number, and special character",
    AES_KEY_ENCRYPT_DECRYPT_ERROR:
      "AES KEY and IV must be defined in environment variables",
    UNAUTHORIZED: "Unauthorized access. Please login again.",
    EMAILNOTFOUND: "Email not found in OAuth provider.",
    USERNOTFOUND: "No user found with the given email.",
    ACESSDENIED: "Access denied. You did not grant permission.",
    UNKNOWNERROR: "An unknown error occurred during OAuth.",
    SOME_THING_WENT_TO_WRONG: "Something went wrong",
    MAX_LENGTH: (field: string, max: number) =>
      `${field} must be at most ${max} characters.`,
    INVALID_EMAIL: "Invalid email format.",
    INVALID_USERNAME: "Invalid username format.",
    INVALID_PHONE: "Invalid Indian phone number.",
    INVALID_POSTAL_CODE:
      "Postal Code must be a 6-digit number between 100000 and 999999.",
    FOLDER_REQUIRED: "Folder name is required",
    FILE_NAME_REQ: "File Name is required",
    FILENUMBER_REQ: "File number is required",
    FIRSTNAME_REQ: "First name is required",
    TAB_NAME_REQ: "Tab name is required",
    LOGIN_TYPE_REQUIRED: "Login type is required",
    NO_USERS_FOUND_MESSAGE: "No users have been added yet.",
    NO_USERS_FOUND_FOR_SELECTED_FILTER_MESSAGE:
      "No record found for selected filters.",
    DELETE_USER_CONFIRMATION_MESSAGE:
      "Are you sure you want to delete this user?",
    INSTRUCTION_FOR_UPDATE_USER:
      "Please update the fields below to edit the user.",
    INSTRUCTION_FOR_CREATE_USER:
      "Please input the fields below to create a new user.",
    NO_FILES_UPLOADED: "No files uploaded yet.",
    LETEERS_ONLY: (field: string) => `${field} should only contain letters`,
    EMAIL_CANNOT_BE_SAME: "From Email and To Email cannot be the same",
    MIN_EXPIRATION: "Must be at least 1 hour",
    NOT_ALLOWED_METHOD:
      "This account is not configured for SSO. Please login using your username and password.",
    NO_FILES_UPLOADED_FOR_USER: "No files uploaded yet for selected user.",
    NO_USER_SELECTED: "Please select office user to upload files",
    FILE_NOT_FOUND: "File not found",
    FOLDER_SELECTION_REQUIRED: "Folder selection is required",
    TAB_SELECTION_REQUIRED: "Tab selection is required",
    FILE_REQUIRED: "File name is required",
    FIELD_VALIDATION_MESSAGE_ON_PDF_INPUTS:
      "Please fix the highlighted errors before saving.",
    FIELD_REQUIRED: "This field is required",
    MIN_LENGTH: (field: string, min: number) =>
      `${field} must be at least ${min} characters.`,
    INVALID_SELECTION: "Invalid selection",
    SIGNATURE_REQUIRED: "Signature is required",
    NO_FILES_SUBMITTED: "No dms forms submitted yet.",
    EMAIL_NOT_VARIFY: "Email doesn't match the token.",
    NO_TABLE_DATA_FOUND: "No data found",
  },
  COMMON: {
    GOOGLE: "google",
    MICROSOFT: "microsoft",
    ADMIN: "Admin",
    OFFICEUSER: "Office_User",
    USER: "User",
    EMAIL_INVALID_FORMAT:
      "Please provide valid email format. eg. dms11@yopmail.com",
    USERNAME_INVALID_FORMAT:
      "Username must start with a letter and can contain letters, digits, _",
    PHONE_NUMBER_INVALID_FORMAT:
      "Must be a valid Indian number with optional +91",
    MAX_TAB_LIMIT: "You can add a maximum of 12 tabs.",
    MIN_TAB_LIMIT: "At least 1 tab is required.",
    DELETE: "Delete",
    CANCEL: "Cancel",
    BACK: "Back",
    SAVE: "Save",
    SUBMIT: "Submit",
    UPDATE: "Update",
    CREATE: "Create",
    SEARCH: "Search",
    CLEAR: "Clear",
    OFFICE_USER: "Office User",
    UPLOAD: "Upload",
    CLOSE: "Close",
    SHARE: "Share",
    ANALYTICDATE: "Analytic Date",
    WEEK: "Week",
    MONTH: "Month",
    YEAR: "Year",
    OKAY: "Okay",
  },
  LENGTH: {
    FIRST_NAME_MAX: 50,
    LAST_NAME_MAX: 50,
    EMAIL_MAX: 200,
    USER_NAME_MAX: 50,
    ADDRESS_MAX: 200,
    CITY_MAX: 100,
  },
};

export const loginTypeOptions = [
  { label: "Username & Password", value: LoginTypeEnum.USERNAME },
  { label: "Single Sign-On (SSO)", value: LoginTypeEnum.SSO },
  { label: "Both", value: LoginTypeEnum.BOTH },
];

export const DATE_RANGE_TYPES = {
  CURRENT_WEEK: "current_week",
  CURRENT_MONTH: "current_month",
  CURRENT_YEAR: "current_year",
  LAST_WEEK: "last_week",
  LAST_MONTH: "last_month",
  LAST_YEAR: "last_year",
  CUSTOM: "custom",
  ALL_TIME: "all_time",
} as const;
export type DateRangeType =
  (typeof DATE_RANGE_TYPES)[keyof typeof DATE_RANGE_TYPES];

export const DATE_RANGE_TYPES_KEYS = {
  CURRENT_WEEK: "Current Week",
  CURRENT_MONTH: "Current Month",
  CURRENT_YEAR: "Current Year",
  LAST_WEEK: "Last Week",
  LAST_MONTH: "Last Month",
  LAST_YEAR: "Last Year",
  CUSTOM: "Custom",
  ALL_TIME: "All Time",
} as const;

export const SHARE_TYPE = {
  MOVE_TAB: "moveTab",
  MOVE_FOLDER: "moveFolder",
  FOLDER: "Folder",
  TAB: "Tab",
  FILE: "File",
} as const;

export const INPUT_TAGS = ["BUTTON", "INPUT", "SELECT", "TEXTAREA"];
