"use client";

import React from "react";
import clsx from "clsx";

type CardVariant = "default" | "outlined";

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: CardVariant;
}

export const Card: React.FC<CardProps> = ({
  children,
  className,
  variant = "default",
  ...props
}) => {
  return (
    <div
      className={clsx(
        "flex flex-col self-center w-full p-8 gap-4 mx-auto transition duration-200 bg-white",
        "sm:w-[450px]",
        variant === "default" &&
          "shadow-[hsla(220,30%,5%,0.05)_0px_5px_15px_0px,hsla(220,25%,10%,0.05)_0px_15px_35px_-5px] dark:shadow-[hsla(220,30%,5%,0.5)_0px_5px_15px_0px,hsla(220,25%,10%,0.08)_0px_15px_35px_-5px]",
        variant === "outlined" &&
          "border border-[rgba(0,0,0,0.12)] shadow-[hsla(220,30%,5%,0.05)_0px_5px_15px_0px,hsla(220,25%,10%,0.05)_0px_15px_35px_-5px] dark:shadow-[hsla(220,30%,5%,0.5)_0px_5px_15px_0px,hsla(220,25%,10%,0.08)_0px_15px_35px_-5px]",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
