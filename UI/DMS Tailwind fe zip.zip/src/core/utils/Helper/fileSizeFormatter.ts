/**
 * Converts a file size in bytes into a human-readable format (KB or MB).
 *
 * @param size - The file size in bytes.
 * @returns A formatted string with the size in KB or MB (rounded to 2 decimal places).
 */
export const formatFileSizeInKbMb = (size: number) => {
  if (size >= 1024 * 1024) {
    // If size is 1 MB or more, convert to MB
    return (size / (1024 * 1024)).toFixed(2) + " MB";
  } else {
    // Otherwise, convert to KB
    return (size / 1024).toFixed(2) + " KB";
  }
};

/**
 * Extracts the file extension from a given file name.
 *
 * @param fileName - The name of the file (e.g., "document.pdf").
 * @returns The file extension (e.g., ".pdf") or "unknown" if none exists.
 */
export const getFileExtension = (fileName: string) => {
  const parts = fileName.split(".");
  // If the file has an extension, return it with a dot prefix
  return parts.length > 1 ? "." + parts.pop() : "unknown";
};
