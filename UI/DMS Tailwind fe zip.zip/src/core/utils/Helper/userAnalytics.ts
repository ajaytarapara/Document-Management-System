import {
  Constant,
  DATE_RANGE_TYPES,
  DATE_RANGE_TYPES_KEYS,
  DateRangeType,
} from "@/core/constants/Constant";

/**
 * Converts bytes into a formatted string showing both GB and MB.
 * Example: 3221225472 bytes → "3.00 GB (3072.00 MB)"
 *
 * @param bytes - The file size in bytes.
 * @returns Formatted string as "X.XX GB (Y.YY MB)".
 */
export const formatFileSizeInGbMbFormat = (bytes: number): string => {
  const gb = bytes / 1024 ** 3;
  const mb = bytes / 1024 ** 2;
  return `${gb.toFixed(2)} GB (${mb.toFixed(2)} MB)`;
};

/**
 * Returns a label string based on the provided date range type.
 *
 * Mapping:
 * - "current_week" / "last_week" → "Analytic Date"
 * - "current_month" / "last_month" → "Week"
 * - "current_year" / "last_year" → "Month"
 * - "all_time" → "Year"
 * - Default (any other value) → "Analytic Date"
 *
 * @param value - The date range type to determine the label for.
 * @returns The corresponding label as a string.
 */
export const getDateLabel = (
  value: string,
  startDateStr?: string,
  endDateStr?: string
) => {
  if (value === DATE_RANGE_TYPES.CUSTOM && startDateStr && endDateStr) {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);

    const diffInDays =
      Math.floor(
        (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
      ) + 1;

    if (diffInDays <= 7) return Constant.COMMON.ANALYTICDATE;
    if (diffInDays <= 30) return Constant.COMMON.WEEK;
    if (diffInDays <= 365) return Constant.COMMON.MONTH;
    return Constant.COMMON.YEAR;
  }

  switch (value) {
    case DATE_RANGE_TYPES.CURRENT_WEEK:
    case DATE_RANGE_TYPES.LAST_WEEK:
      return Constant.COMMON.ANALYTICDATE;
    case DATE_RANGE_TYPES.CURRENT_MONTH:
    case DATE_RANGE_TYPES.LAST_MONTH:
      return Constant.COMMON.WEEK;
    case DATE_RANGE_TYPES.CURRENT_YEAR:
    case DATE_RANGE_TYPES.LAST_YEAR:
      return Constant.COMMON.MONTH;
    case DATE_RANGE_TYPES.ALL_TIME:
      return Constant.COMMON.YEAR;
    default:
      return Constant.COMMON.ANALYTICDATE;
  }
};

export const dateRangeTypeOptions: { label: string; value: DateRangeType }[] = [
  {
    label: DATE_RANGE_TYPES_KEYS.CURRENT_WEEK,
    value: DATE_RANGE_TYPES.CURRENT_WEEK,
  },
  {
    label: DATE_RANGE_TYPES_KEYS.CURRENT_MONTH,
    value: DATE_RANGE_TYPES.CURRENT_MONTH,
  },
  {
    label: DATE_RANGE_TYPES_KEYS.CURRENT_YEAR,
    value: DATE_RANGE_TYPES.CURRENT_YEAR,
  },
  { label: DATE_RANGE_TYPES_KEYS.LAST_WEEK, value: DATE_RANGE_TYPES.LAST_WEEK },
  {
    label: DATE_RANGE_TYPES_KEYS.LAST_MONTH,
    value: DATE_RANGE_TYPES.LAST_MONTH,
  },
  { label: DATE_RANGE_TYPES_KEYS.LAST_YEAR, value: DATE_RANGE_TYPES.LAST_YEAR },
  { label: DATE_RANGE_TYPES_KEYS.CUSTOM, value: DATE_RANGE_TYPES.CUSTOM },
  { label: DATE_RANGE_TYPES_KEYS.ALL_TIME, value: DATE_RANGE_TYPES.ALL_TIME },
];
