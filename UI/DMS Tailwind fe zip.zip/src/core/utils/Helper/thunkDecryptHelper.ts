import { AsyncThunk } from "@reduxjs/toolkit";
import { IAPIResponse, IEncryptedApiResponse } from "@/core/models";
import { DefaultThunkConfig } from "@/main/models/types";
import { decryptObject } from "./aes";
import { AppDispatch } from "@/main/store";

/**
 * Dispatches a Redux async thunk that returns an encrypted API response,
 * then decrypts the `data` field and returns the decrypted result.
 *
 * @template TDecrypted - The expected shape of the decrypted `data`.
 * @template TPayload - The type of the thunk's payload argument.
 *
 * @param dispatch - The Redux `dispatch` function.
 * @param thunk - The async thunk to be dispatched, which must return an `IEncryptedApiResponse`.
 * @param payload - Optional payload to pass to the thunk. Required if the thunk expects arguments.
 *
 * @returns A Promise resolving to the decrypted API response of type `IAPIResponse<TDecrypted>`.
 *
 * @example
 * const decryptedUser = await handleThunkWithDecrypt<IUser>(dispatch, getUserById, 5);
 */
export async function handleThunkWithDecrypt<TDecrypted, TPayload>(
  dispatch: AppDispatch,
  thunk: AsyncThunk<IEncryptedApiResponse, TPayload, DefaultThunkConfig>,
  payload: TPayload
): Promise<IAPIResponse<TDecrypted>>;

export async function handleThunkWithDecrypt<TDecrypted>(
  dispatch: AppDispatch,
  thunk: AsyncThunk<IEncryptedApiResponse, void, DefaultThunkConfig>
): Promise<IAPIResponse<TDecrypted>>;

export async function handleThunkWithDecrypt<TDecrypted, TPayload>(
  dispatch: AppDispatch,
  thunk: AsyncThunk<IEncryptedApiResponse, TPayload, DefaultThunkConfig>,
  payload?: TPayload
): Promise<IAPIResponse<TDecrypted>> {
  // @ts-expect-error: payload is optional depending on thunk
  const response = await dispatch(thunk(payload)).unwrap();
  return decryptObject<IAPIResponse<TDecrypted>>(response.data);
}
