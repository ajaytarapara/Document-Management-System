"use client";

import { useRouter } from "next/navigation";

/**
 * Custom hook for navigation using Next.js router.
 * @returns {function(string): void} - Function to navigate to a given path.
 */
export const useNavigate = () => {
  const router = useRouter();

  const handleNavigate = (path: string) => {
    router.push(path);
  };

  return handleNavigate;
};

/**
 * Formats a file size from bytes into a human-readable string (B, KB, MB).
 * @param {number} bytes - The size in bytes.
 * @returns {string} Formatted file size.
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  } else if (bytes >= 1024) {
    return `${(bytes / 1024).toFixed(2)} KB`;
  } else {
    return `${bytes} B`;
  }
};
