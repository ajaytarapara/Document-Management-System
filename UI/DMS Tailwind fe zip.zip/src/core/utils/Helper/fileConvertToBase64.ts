/**
 * Converts a File object into a base64-encoded string.
 *
 * @param file - The File object to convert.
 * @returns A promise that resolves with the base64 string of the file content.
 */
export const convertFileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
  });
};
