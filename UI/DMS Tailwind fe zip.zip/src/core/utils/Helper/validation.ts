// Utility function to generate a required field message for form validation
// Example: "firstName" → "First Name is required"
export const getRequiredMessage = (fieldName: string): string => {
  const formattedName = fieldName
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (s) => s.toUpperCase());
  return `${formattedName} is required`;
};
