import { ROUTES } from "@/core/constants/PAGE_URLS";
import axios, { AxiosInstance, AxiosRequestConfig, AxiosHeaders } from "axios";
import { toast } from "react-toastify";
import Cookie from "js-cookie";
import { triggerLoader } from "./axiosLoaderManager";
import { IAPIResponse } from "@/core/models";
import { Constant } from "@/core/constants/Constant";
import { decryptObject, encryptMixedPayload } from "./Helper/aes";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL;

let activeRequestsCount = 0;
export const axiosInstance: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
});

function getCookie(name: string) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop()?.split(";").shift();
}

axiosInstance.interceptors.request.use((config) => {
  const token = getCookie("token");
  if (!config.headers || !(config.headers instanceof AxiosHeaders)) {
    config.headers = new AxiosHeaders(config.headers);
  }

  if (token) {
    config.headers.set("Authorization", `Bearer ${token}`);
  }

  if (!config.params?.noLoader) {
    activeRequestsCount++;
    triggerLoader(true);
  }

  if (token && config.headers?.set) {
    config.headers.set("Authorization", `Bearer ${token}`);
  }
  if (config.data && !config.headers?.skipEncryption) {
    return encryptMixedPayload(config.data as Record<string, unknown>)
      .then((encryptedPayload) => {
        config.data = encryptedPayload;
        return config;
      })
      .catch((err) => {
        return Promise.reject(err);
      });
  }
  return config;
});

axiosInstance.interceptors.response.use(
  (response) => {
    handleRequestEnd(response.config);
    const showToast = response.config.headers?.showToast !== false;
    const decrypted = decryptObject<IAPIResponse<unknown>>(response.data.data);
    if (typeof decrypted.message === "string" && showToast) {
      toast.success(decrypted.message);
    }
    return response;
  },
  async (error) => {
    handleRequestEnd(error.config);
    const { response } = error;
    const message =
      response?.data?.Message ??
      response?.data?.message ??
      Constant.MESSAGE.SOME_THING_WENT_TO_WRONG;
    const showToast = error.config?.headers?.showToast !== false;
    if (showToast) {
      toast.error(message);
    }
    if (response && response.status === 401) {
      Cookie.remove("token");
      window.location.href = ROUTES.LOGIN;
    }
    return Promise.reject(error);
  }
);

function handleRequestEnd(config: AxiosRequestConfig) {
  if (!config.params?.noLoader) {
    activeRequestsCount = Math.max(0, activeRequestsCount - 1);
  }

  if (activeRequestsCount === 0) {
    triggerLoader(false);
  }

  if (config.params) {
    delete config.params.noLoader;
  }
}
