type LoaderDispatchFn = (show: boolean) => void;

let loaderDispatcher: LoaderDispatchFn | null = null;

export const setLoaderDispatcher = (fn: LoaderDispatchFn) => {
  loaderDispatcher = fn;
};

export const triggerLoader = (show: boolean) => {
  if (loaderDispatcher) loaderDispatcher(show);
};
