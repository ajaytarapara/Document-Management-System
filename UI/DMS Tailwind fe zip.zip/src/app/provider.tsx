"use client";

import { Suspense, useEffect } from "react";
import { PersistGate } from "redux-persist/integration/react";
import { Provider } from "react-redux";
import { Loader, ToasterContainer } from "@/core/components";
import { setLoaderDispatcher } from "@/core/utils/axiosLoaderManager";
import { useAppDispatch } from "@/main/hooks";
import { hideLoader, persistor, showLoader, store } from "@/main/store";

const App = ({ children }: { children: React.ReactNode }) => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    setLoaderDispatcher((show) => {
      dispatch(show ? showLoader() : hideLoader());
    });
  }, [dispatch]);

  return (
    <div className="h-[100vh]">
      <Loader />
      <Suspense fallback={<Loader />}>
        {children}
        <ToasterContainer />
      </Suspense>
    </div>
  );
};

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <Provider store={store}>
      <PersistGate loading={<Loader />} persistor={persistor}>
        <App>{children}</App>
      </PersistGate>
    </Provider>
  );
}
