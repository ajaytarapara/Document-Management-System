import React, { FC } from "react";
import "./globals.css";
import { Jost } from "next/font/google";
import "./toast.css";
import { Providers } from "./provider";

interface IRootLayoutProps {
  children: React.ReactNode;
}

const jost = Jost({
  subsets: ["latin"],
  variable: "--font-jost",
});

export const metadata = {
  title: "DMS",
  description: "Document Management System",
  icons: {
    icon: "/dms_favicon.svg",
  },
};

const RootLayout: FC<Readonly<IRootLayoutProps>> = ({ children }) => (
  <html lang="en" suppressHydrationWarning className={jost.variable}>
    <body suppressHydrationWarning>
      <Providers>{children}</Providers>
    </body>
  </html>
);

export default RootLayout;
