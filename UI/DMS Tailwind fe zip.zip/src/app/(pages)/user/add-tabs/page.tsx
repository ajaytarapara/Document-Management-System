"use client";

import { LoggedInLayout } from "@/core/components";
import { AddTemplateTabForm } from "@/main/components";
import React from "react";

const AddTabs = () => {
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 bg-background p-6">
        <AddTemplateTabForm />
      </div>
    </LoggedInLayout>
  );
};

export default AddTabs;
