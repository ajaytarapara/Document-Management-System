"use client";

import { useEffect, useState } from "react";
import { SortingState } from "@tanstack/react-table";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { useNavigate, handleThunkWithDecrypt } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import {
  IUserDetail,
  PaginationResponse,
  PaginationRequest,
} from "@/main/models";
import { getUsers, deleteUser } from "@/main/store";
import { SortDirection } from "@/core/models";

/**
 * Custom hook to manage the logic and state for the "View Users" page.
 * Handles fetching paginated user data, sorting, delete operations, and navigation.
 */
export const useViewUserForm = () => {
  const [userData, setUserData] = useState<IUserDetail[]>([]);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState<number>(0);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isCreateClick, setIsCreateClick] = useState<boolean>(false);
  const [isEditDrawerOpen, setIsEditDrawerOpen] = useState<boolean>(false);
  const [isSaveClick, setIsSaveClick] = useState<boolean>(false);
  const [selectedEditUserId, setSelectedEditUserId] = useState<string | null>(
    null
  );
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  /**
   * Fetches paginated and sorted user data.
   * @param page - The page number to fetch.
   * @param currentSorting - The current sorting state.
   */
  const getUsersData = async (page = pageIndex, currentSorting = sorting) => {
    const sort = currentSorting[0];

    const decryptedResponse = await handleThunkWithDecrypt<
      PaginationResponse<IUserDetail>,
      PaginationRequest
    >(dispatch, getUsers, {
      pageNumber: page,
      pageSize,
      sortBy: sort?.id,
      sortOrder: sort?.desc ? SortDirection.DESC : SortDirection.ASC,
    });

    const items = decryptedResponse?.data?.items ?? [];
    const total = decryptedResponse?.data?.totalCount ?? 0;
    const totalPg =
      decryptedResponse?.data?.totalPages ?? Math.ceil(total / pageSize);

    setUserData(items);
    setTotalPages(totalPg);
  };

  /**
   * Deletes a selected user by their ID.
   * If successful, refetches the user list and navigates to the same page.
   */
  const handleDeleteUser = async () => {
    if (selectedUserId !== null) {
      const result = await dispatch(deleteUser(selectedUserId));
      if (deleteUser.fulfilled.match(result)) {
        setOpenDeleteDialog(false);
        setSelectedUserId(null);
        setTimeout(() => {
          navigate(ROUTES.OFFICE_USER.VIEW_USER);
        }, 1500);
        getUsersData();
      }
    }
  };

  /**
   * Opens the delete confirmation dialog and sets selected user ID.
   * @param userId - The ID of the user to be deleted.
   */
  const handleOpenDeleteDialog = (userId: string) => {
    setSelectedUserId(userId);
    setOpenDeleteDialog(true);
  };

  /**
   * Closes the delete confirmation dialog and clears selected user ID.
   */
  const handleCloseDeleteDialog = () => {
    setSelectedUserId(null);
    setOpenDeleteDialog(false);
  };

  /**
   * Navigates back to the dashboard page.
   */
  const backToDashboard = () => {
    navigate(ROUTES.OFFICE_USER.DASHBOARD);
  };

  /**
   * Opens the create user drawer.
   */
  const openDrawer = () => setIsDrawerOpen(true);

  /**
   * Closes the create user drawer.
   */
  const closeDrawer = () => setIsDrawerOpen(false);

  /**
   * Handles editing a user by setting the selected user ID
   * and opening the edit drawer.
   *
   * @param userId - The ID of the user to edit.
   */
  const handleEditUser = (userId: string) => {
    setSelectedEditUserId(userId);
    openEditDrawer();
  };

  /**
   * Opens the edit user drawer.
   */
  const openEditDrawer = () => setIsEditDrawerOpen(true);

  /**
   * Closes the edit user drawer.
   */
  const closeEditDrawer = () => setIsEditDrawerOpen(false);

  /**
   * Fetches user data whenever page index, sorting, page size,
   * or create/save actions change.
   */
  useEffect(() => {
    getUsersData(pageIndex, sorting);
    setIsSaveClick(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, sorting, pageSize, isCreateClick, isSaveClick]);

  return {
    userData,
    openDeleteDialog,
    pageIndex,
    totalPages,
    pageSize,
    isDrawerOpen,
    isEditDrawerOpen,
    selectedEditUserId,
    setIsSaveClick,
    closeEditDrawer,
    openDrawer,
    closeDrawer,
    setPageSize,
    setPageIndex,
    backToDashboard,
    handleCloseDeleteDialog,
    handleDeleteUser,
    handleOpenDeleteDialog,
    handleEditUser,
    setIsCreateClick,
  };
};
