"use client";

import {
  ArrowBigLeft,
  Trash2,
  UserRoundPlus,
  UserRoundSearch,
} from "lucide-react";
import {
  LoggedInLayout,
  Dialog,
  CommonDrawer,
  CommonCardList,
} from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { useViewUserForm } from "./ViewUser.hook";
import { StyledButton, StyledUserIconButton } from "./ViewUser.styled";
import { CreateUserForm, UpdateUserForm, UserCard } from "@/main/components";
import { useForm } from "react-hook-form";
import { ButtonType } from "@/core/models/enums";

const ViewUserPage = () => {
  const {
    userData,
    openDeleteDialog,
    pageIndex,
    totalPages,
    pageSize,
    isDrawerOpen,
    isEditDrawerOpen,
    selectedEditUserId,
    setIsSaveClick,
    closeEditDrawer,
    openDrawer,
    closeDrawer,
    setPageSize,
    setPageIndex,
    backToDashboard,
    handleCloseDeleteDialog,
    handleDeleteUser,
    handleOpenDeleteDialog,
    handleEditUser,
    setIsCreateClick,
  } = useViewUserForm();

  /**
   * Initialize react-hook-form with default values.
   * control: Used to connect input components to the form state.
   * defaultValues: Sets initial form field values, here setting `pageSize` as a string.
   */
  const { control } = useForm({
    defaultValues: { pageSize: pageSize.toString() },
  });

  return (
    <LoggedInLayout>
      <div className="container rounded sm:xs-6 mx-auto">
        <div className="flex flex-col gap-3 rounded-lg bg-white sm:flex-row justify-between py-6 px-6 mb-3 xs:py-3 xs:px-2">
          <div className="flex items-center gap-2 w-full flex-wrap xs:flex-col xs:items-start md:flex-row md:items-center">
            <UserRoundSearch
              strokeWidth={2.3}
              color="#00092A"
              className="w-6 h-6 md:w-7 md:h-7"
            />
            <h2 className="text-[#00092A] font-semibold text-lg lg:text-2xl ml-3 xs:ml-0 xs:mt-2 xs:text-lg md:ml-0 md:mt-2">
              View Users
            </h2>
          </div>
          <div className="flex gap-4 w-full justify-end items-center">
            <StyledButton onClick={backToDashboard}>
              <ArrowBigLeft className="h-5 w-5" />
              <span>{Constant.COMMON.BACK}</span>
            </StyledButton>
            <div className="min-w-[100px]">
              <StyledUserIconButton title="Add User" onClick={openDrawer}>
                <UserRoundPlus className="h-5 w-5 z-10" />
                <span>Add User</span>
              </StyledUserIconButton>
            </div>
          </div>
        </div>

        <div>
          <CommonCardList
            data={userData}
            renderCard={(user) => (
              <UserCard
                key={"office-user-cards"}
                onDelete={handleOpenDeleteDialog}
                onEdit={handleEditUser}
                role="Office User"
                user={user}
              />
            )}
            pageSize={pageSize}
            pageIndex={pageIndex}
            totalPage={totalPages}
            control={control}
            onPageChange={(page) => setPageIndex(page)}
            onPageSizeChange={(size) => {
              setPageSize(size);
              setPageIndex(1);
            }}
          />
        </div>
      </div>

      <Dialog
        open={openDeleteDialog}
        onClose={handleCloseDeleteDialog}
        title="Delete User"
        description={Constant.MESSAGE.DELETE_USER_CONFIRMATION_MESSAGE}
        onSubmit={handleDeleteUser}
        icon={<Trash2 color="#e71d1d" />}
        submitLabel={Constant.COMMON.DELETE}
        cancelLabel={Constant.COMMON.CANCEL}
        buttonType={ButtonType.Button}
        maxWidth="xs"
        fullWidth
      />

      {isDrawerOpen && (
        <CommonDrawer
          open={isDrawerOpen}
          onClose={closeDrawer}
          title="Create User"
          lgSize="50%"
        >
          <CreateUserForm
            onClose={closeDrawer}
            setIsCreateClick={setIsCreateClick}
          />
        </CommonDrawer>
      )}

      {isEditDrawerOpen && (
        <CommonDrawer
          open={isEditDrawerOpen}
          onClose={closeEditDrawer}
          title="Update Office User"
          lgSize="50%"
        >
          <UpdateUserForm
            onClose={closeEditDrawer}
            userId={String(selectedEditUserId)}
            setIsSaveClick={setIsSaveClick}
          />
        </CommonDrawer>
      )}
    </LoggedInLayout>
  );
};
export default ViewUserPage;
