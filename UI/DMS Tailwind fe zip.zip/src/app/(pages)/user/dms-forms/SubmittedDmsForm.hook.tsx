import { useEffect, useState } from "react";
import { ColumnDef, SortingState } from "@tanstack/react-table";
import {
  IAPIResponse,
  IDmsForm,
  DmsFormPaginationRequest,
  SortDirection,
} from "@/core/models";
import { decryptObject, encryptId, handleThunkWithDecrypt } from "@/core/utils";
import { FieldBase, previewWithFields } from "@/main/components";
import { useAppDispatch } from "@/main/hooks";
import { ILoginResponse, PaginationResponse } from "@/main/models";
import { useSelectorAuthState, getAllSubmittedDmsForms } from "@/main/store";

export const useSubmittedDmsForm = () => {
  const dispatch = useAppDispatch();
  const { loggedInUser } = useSelectorAuthState();

  /**
   * Decrypts the logged-in user data and generates an encrypted user ID.
   */
  const decryptedLoggedUser = loggedInUser
    ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser)
    : null;

  const selectedUserId: string = encryptId(
    Number(decryptedLoggedUser?.data?.userId)
  );

  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [submittedForms, setSubmittedForms] = useState<IDmsForm[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [totalPage, setTotalPage] = useState<number>(0);
  const [openPreviewModal, setOpenPreviewModal] = useState<boolean>(false);
  const [fileUrl, setFileUrl] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");

  /**
   * Table column definitions for submitted forms.
   * Includes click handler to preview form with fields.
   */
  const submittedColumns: ColumnDef<IDmsForm>[] = [
    {
      accessorKey: "name",
      header: "Submitted Form Name",
      cell: ({ row }) => {
        const name = row.original.name;
        const file = row.original.url;
        const fields = row.original.fields as FieldBase[];
        return (
          <span
            onClick={() => handleOpenPreviewModal(file, name, fields)}
            className="text-[#7E57C2] hover:underline cursor-pointer"
          >
            {name}
          </span>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Created Date",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "submittedAt",
      header: "Submitted Date",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "submittedBy",
      header: "Submitted By",
      cell: (info) => info.getValue(),
    },
  ];

  /**
   * Opens the preview modal for a given file with its associated fields.
   *
   * @param {string} url - The file URL to preview
   * @param {string} fileName - The name of the file
   * @param {FieldBase[]} fields - The form fields to overlay on the preview
   */
  const handleOpenPreviewModal = async (
    url: string,
    fileName: string,
    fields: FieldBase[]
  ) => {
    const previewUrl = await previewWithFields(url, fields);
    setFileUrl(previewUrl);
    setFileName(fileName);
    setOpenPreviewModal(true);
  };

  /**
   * Closes the preview modal and resets file-related state.
   */
  const handleClosePreviewModel = () => {
    setFileName("");
    setFileUrl("");
    setOpenPreviewModal(false);
  };

  /**
   * Fetches submitted forms from the server with pagination and sorting.
   * Updates the submitted forms state and metadata.
   *
   * @param {number} page - Page index (default: current pageIndex state)
   * @param {number} size - Page size (default: current pageSize state)
   * @param {SortingState} currentSorting - Sorting configuration (default: current sorting state)
   * @param {string} userId - Encrypted user ID for filtering forms (default: selectedUserId)
   */
  const getSubmittedForms = async (
    page = pageIndex,
    size = pageSize,
    currentSorting = sorting,
    userId = selectedUserId
  ) => {
    const sort = currentSorting[0];
    const response = await handleThunkWithDecrypt<
      PaginationResponse<IDmsForm>,
      DmsFormPaginationRequest
    >(dispatch, getAllSubmittedDmsForms, {
      pageNumber: page,
      pageSize: size,
      sortBy: sort?.id,
      sortOrder: sort?.desc ? SortDirection.DESC : SortDirection.ASC,
      userId,
      token: decryptedLoggedUser?.data?.token,
    });

    setSubmittedForms(response?.data?.items ?? []);
    setTotalCount(response?.data?.totalCount ?? 0);
    setTotalPage(response?.data?.totalPages ?? 0);
  };

  /**
   * Updates the sorting state and fetches the DMS forms
   * based on the new sorting direction and current filters.
   *
   * @param newSorting - The updated sorting configuration.
   */
  const handleSortDirectionChange = (newSorting: SortingState) => {
    setSorting(newSorting);
    getSubmittedForms(pageIndex, pageSize, newSorting, selectedUserId);
  };

  /**
   * Effect: Fetch submitted forms whenever pageIndex, pageSize, or sorting changes.
   */
  useEffect(() => {
    getSubmittedForms();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sorting]);

  /**
   * Fetches submitted forms when the component mounts.
   */
  useEffect(() => {
    getSubmittedForms();
  }, []);

  return {
    submittedForms,
    submittedColumns,
    pageIndex,
    pageSize,
    totalCount,
    totalPage,
    openPreviewModal,
    fileName,
    fileUrl,
    setPageIndex,
    setPageSize,
    handleSortDirectionChange,
    handleClosePreviewModel,
  };
};
