import { useEffect, useRef, useState } from "react";
import { ColumnDef, SortingState } from "@tanstack/react-table";
import { Download, Edit, Share2, Trash2 } from "lucide-react";
import { Constant } from "@/core/constants/Constant";
import {
  IAPIResponse,
  IDmsForm,
  DeleteFormValues,
  EditFormValues,
  IRequestUploadDmsForms,
  DmsFormPaginationRequest,
  RenameDmsFormRequest,
  SortDirection,
} from "@/core/models";
import { decryptObject, encryptId, handleThunkWithDecrypt } from "@/core/utils";
import {
  downloadWithFields,
  FieldBase,
  SimpleCheckbox,
} from "@/main/components";
import { useAppDispatch } from "@/main/hooks";
import { ILoginResponse, PaginationResponse } from "@/main/models";
import {
  useSelectorAuthState,
  uploadDmsForms,
  getAllDmsForms,
  getDmsFormById,
  deleteDmsForm,
  renameDmsForm,
} from "@/main/store";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import Link from "next/link";
import { ROUTES } from "@/core/constants/PAGE_URLS";

/**
 * Hook to manage DMS form actions like fetch, upload, rename, delete, download, and share.
 *
 * Handles pagination, sorting, form dialogs, file inputs, and selection.
 *
 * @returns Hook state and handlers for DMS form operations.
 */

export const useDmsForm = () => {
  const dispatch = useAppDispatch();
  const { loggedInUser } = useSelectorAuthState();

  /** Decrypts stored logged-in user data */
  const decryptedLoggedUser = loggedInUser
    ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser)
    : null;

  /** Encrypted user ID derived from decrypted user data */
  const selectedUserId: string = encryptId(
    Number(decryptedLoggedUser?.data?.userId)
  );

  const [pageIndex, setPageIndex] = useState<number>(0);
  const [pageSize, setPageSize] = useState<number>(10);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [openEditDialog, setOpenEditDialog] = useState<boolean>(false);
  const [deleteFileId, setDeleteFileId] = useState<string | null>(null);
  const [openShareModal, setOpenShareModal] = useState<boolean>(false);
  const [shareFormId, setShareFormId] = useState<string | null>(null);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [totalPage, SetTotalPage] = useState<number>(0);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [dmsFormsData, setDmsFormsData] = useState<IDmsForm[]>([]);
  const [fileName, setFileName] = useState<string>("");

  const [downloadSuccessDialog, setDownloadSuccessDialog] =
    useState<boolean>(false);

  // Form hook for delete form
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<DeleteFormValues>();

  // Form hook for edit form
  const {
    register: editRegister,
    handleSubmit: handleEditSubmit,
    formState: { errors: editErrors },
    reset: editReset,
  } = useForm<EditFormValues>();

  const isAllSelected = selectedRowIds.length === dmsFormsData.length;

  /**
   * Toggles selection of all rows in the DMS table.
   * If all rows are selected, it clears the selection.
   * Otherwise, it selects all available rows.
   */
  const handleToggleAll = () => {
    if (isAllSelected) {
      setSelectedRowIds([]);
    } else {
      setSelectedRowIds(dmsFormsData.map((row) => row.id));
    }
  };

  /**
   * Toggles selection state of a single row in the DMS table.
   *
   * @param id - The ID of the row to toggle.
   */
  const handleToggleRow = (id: string) => {
    setSelectedRowIds((prev) =>
      prev.includes(id) ? prev.filter((rowId) => rowId !== id) : [...prev, id]
    );
  };

  /**
   * Checkbox column for selecting rows in the DMS Form table.
   * - Header: "Select All" checkbox
   * - Cell: Row-level checkbox
   */
  const checkboxColumn: ColumnDef<IDmsForm> = {
    id: "select",
    header: () => (
      <SimpleCheckbox checked={isAllSelected} onChange={handleToggleAll} />
    ),
    cell: (info) => {
      const row = info.row.original;
      return (
        <SimpleCheckbox
          checked={selectedRowIds.includes(row.id)}
          onChange={() => handleToggleRow(row.id)}
        />
      );
    },
    enableSorting: false,
    enableColumnFilter: false,
  };

  /**
   * Columns used in the DMD forms table.
   */
  const dmsFormColumns: ColumnDef<IDmsForm>[] = [
    checkboxColumn,
    {
      accessorKey: "name",
      header: "Available Fillable DMS form Name",
      cell: ({ row }) => {
        const id = row.original.id;
        const name = row.original.name;
        return (
          <Link
            href={`${ROUTES.OFFICE_USER.DMS_FORMS}/${id}`}
            className="text-[#7E57C2] hover:underline cursor-pointer"
          >
            {name}
          </Link>
        );
      },
    },
    {
      accessorKey: "size",
      header: "Size(Mb)",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "createdAt",
      header: "Created Date",
      cell: (info) => info.getValue(),
    },
    {
      accessorKey: "Action",
      header: "Actions",
      enableSorting: false,
      enableColumnFilter: false,
      cell: ({ row }) => {
        const id = row.original.id;
        const name = row.original.name;
        const fields = row.original.fields;
        return (
          <div className="flex gap-2">
            <button
              onClick={() => handleOpenEditDialog(id)}
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Edit size={18} />
            </button>
            <button
              onClick={() => handleToggleDeleteDialog(id)}
              className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Trash2 size={18} />
            </button>
            <button
              onClick={() =>
                downloadWithFields(row.original.url, fields as FieldBase[])
              }
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Download size={18} />
            </button>
            <button
              onClick={() => handleOpenShareModal(name, id)}
              className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
            >
              <Share2 size={18} />
            </button>
          </div>
        );
      },
    },
  ];

  /**
   * Uploads selected DMS files.
   * - Validates if user ID is available.
   * - Submits files to the backend.
   * - Clears form and resets dialog on success.
   */
  const onSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (selectedUserId == "") {
      toast.error(Constant.MESSAGE.NO_USER_SELECTED);
      setIsDialogOpen(false);
      return;
    }
    if (selectedFiles.length === 0) return;

    const result = await handleThunkWithDecrypt<string, IRequestUploadDmsForms>(
      dispatch,
      uploadDmsForms,
      {
        forms: selectedFiles,
        userId: selectedUserId,
      }
    );

    if (result.isSuccessful && result.data) {
      setSelectedFiles([]);
      setIsDialogOpen(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      getDmsForms(pageIndex, pageSize, sorting, result.data);
    }
  };

  /**
   * Handles file input click by triggering hidden input element.
   */
  const handleFileButtonClick = () => {
    fileInputRef.current?.click();
  };

  /**
   * Handles file input change and sets selected files to be uploaded.
   *
   * @param e - File input change event.
   */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setSelectedFiles(Array.from(files));
      setIsDialogOpen(true);
    }
  };

  /**
   * Closes the file upload dialog and resets selected files.
   */
  const handleDialogClose = () => {
    setIsDialogOpen(false);
    setSelectedFiles([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  /**
   * Opens or closes the delete confirmation dialog and sets the file ID for deletion.
   *
   * @param id - The ID of the file to delete.
   */
  const handleToggleDeleteDialog = (id?: string) => {
    if (id !== undefined) {
      setDeleteFileId(id);
    }
    setOpenDeleteDialog((prev) => !prev);
    reset();
  };

  /**
   * Fetches the DMS form data for the current user with sorting and pagination.
   *
   * @param page - Current page index.
   * @param size - Number of items per page.
   * @param currentSorting - Active sorting configuration.
   * @param selectedUserId - Logged-in user ID to fetch forms for.
   */
  const getDmsForms = async (
    page = pageIndex,
    size = pageSize,
    currentSorting = sorting,
    selectedUserId: string
  ) => {
    const sort = currentSorting[0];

    const decryptedResponse = await handleThunkWithDecrypt<
      PaginationResponse<IDmsForm>,
      DmsFormPaginationRequest
    >(dispatch, getAllDmsForms, {
      pageNumber: page,
      pageSize: size,
      sortBy: sort?.id,
      sortOrder: sort?.desc ? SortDirection.DESC : SortDirection.ASC,
      userId: selectedUserId,
    });

    const items = decryptedResponse?.data?.items ?? [];
    const total = decryptedResponse?.data?.totalCount ?? 0;
    const totalPages = decryptedResponse?.data?.totalPages ?? 0;

    SetTotalPage(totalPages);
    setDmsFormsData(items);
    setPageIndex(1);
    setTotalCount(total);
  };

  /**
   * Opens the edit dialog and pre-fills the form with the selected file's name.
   *
   * @param id - The ID of the file to edit.
   */
  const handleOpenEditDialog = async (id?: number | string) => {
    if (id !== undefined) {
      setOpenEditDialog((prev) => !prev);
      const result = await handleThunkWithDecrypt<
        IDmsForm,
        { formId: string; userId: string }
      >(dispatch, getDmsFormById, {
        formId: String(id),
        userId: String(selectedUserId),
      });
      if (result?.data?.name) {
        editReset({ name: result.data.name });
        setDeleteFileId(String(id));
      }
    }
  };

  /**
   * Closes the edit dialog and resets the form.
   */
  const handleCloseEditDialog = () => {
    setOpenEditDialog(false);
    editReset();
  };

  /**
   * Submits the file deletion form.
   * - Validates password.
   * - Dispatches delete request.
   * - Refreshes the list on success.
   */
  const handleDeleteFile = handleSubmit(async (data) => {
    if (deleteFileId !== null) {
      const result = await dispatch(
        deleteDmsForm({
          dmsFormId: deleteFileId,
          userId: selectedUserId as string,
          password: data.password,
        })
      );

      if (deleteDmsForm.fulfilled.match(result)) {
        getDmsForms(pageIndex, pageSize, sorting, selectedUserId as string);
      }
    }

    setOpenDeleteDialog(false);
    reset();
  });

  /**
   * Opens the Share Modal dialog with file name and ID.
   * If multiple rows are selected, aggregates their names for display.
   *
   * @param fileName - The name of the selected file.
   * @param id - Optional single file ID.
   */
  const handleOpenShareModal = (fileName: string, id?: string) => {
    const selectedNames = dmsFormsData
      .filter((form) => selectedRowIds.includes(form.id))
      .map((form) => form.name)
      .join(", ");
    if (id) {
      setShareFormId(id);
    }
    setFileName(selectedNames);
    setFileName(fileName);
    setOpenShareModal(true);
  };

  /**
   * Closes the Share Modal and clears selected state.
   */
  const closeShareModal = () => {
    setShareFormId(null);
    setSelectedRowIds([]);
    setOpenShareModal(false);
  };

  /**
   * Submits the edit form to rename a DMS file.
   * - Dispatches rename request.
   * - Refreshes data and closes dialog on success.
   */
  const handleEditFile = handleEditSubmit(async (data) => {
    if (deleteFileId !== null) {
      const result = await handleThunkWithDecrypt<string, RenameDmsFormRequest>(
        dispatch,
        renameDmsForm,
        {
          dmsFormId: deleteFileId,
          newFileName: data.name,
          userId: selectedUserId as string,
        }
      );
      if (result.isSuccessful) {
        getDmsForms(pageIndex, pageSize, sorting, selectedUserId as string);
        setOpenEditDialog(false);
        editReset();
      }
    }
  });

  /**
   * Closes the download success dialog.
   */
  const handleDownloadDialogClose = () => {
    setDownloadSuccessDialog(false);
  };

  /**
   * Updates the sorting state and fetches the DMS forms
   * based on the new sorting direction and current filters.
   *
   * @param newSorting - The updated sorting configuration.
   */
  const handleSortDirectionChange = (newSorting: SortingState) => {
    setSorting(newSorting);
    getDmsForms(pageIndex, pageSize, newSorting, selectedUserId);
  };

  /**
   * Fetches DMS forms whenever pagination or sorting state changes.
   */
  useEffect(() => {
    getDmsForms(pageIndex, pageSize, sorting, selectedUserId as string);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, sorting]);

  return {
    dmsFormColumns,
    pageIndex,
    fileName,
    errors,
    selectedRowIds,
    register,
    dispatch,
    pageSize,
    openShareModal,
    fileInputRef,
    isDialogOpen,
    selectedFiles,
    openDeleteDialog,
    openEditDialog,
    shareFormId,
    dmsFormsData,
    totalCount,
    editErrors,
    totalPage,
    downloadSuccessDialog,
    editRegister,
    handleEditFile,
    setSelectedFiles,
    handleToggleDeleteDialog,
    handleCloseEditDialog,
    setPageIndex,
    handleFileButtonClick,
    handleFileChange,
    setPageSize,
    handleDialogClose,
    onSubmit,
    closeShareModal,
    handleDeleteFile,
    handleOpenShareModal,
    handleDownloadDialogClose,
    handleSortDirectionChange,
  };
};
