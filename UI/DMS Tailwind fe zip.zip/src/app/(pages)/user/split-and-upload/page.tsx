"use client";

import { LoggedInLayout } from "@/core/components";
import { SplitAndUpload } from "@/main/components";

const SplitAndUploadPdfUser = () => {
  return (
    <LoggedInLayout>
      <SplitAndUpload />
    </LoggedInLayout>
  );
};

export default SplitAndUploadPdfUser;
