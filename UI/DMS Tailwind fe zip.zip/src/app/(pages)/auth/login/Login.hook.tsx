import { useState } from "react";
import Cookie from "js-cookie";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { ILogin, ILoginResponse, ISubUser } from "@/main/models";
import { Role } from "@/core/models";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import {
  getSubUser,
  login,
  setUserName,
  setSubUser,
  setCurrentUser,
  setOriginalUser,
} from "@/main/store";
import { handleThunkWithDecrypt, triggerLoader } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";

export const useLoginForm = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ILogin>();

  const onSubmit = async (formData: ILogin) => {
    triggerLoader(true);
    const response = await handleThunkWithDecrypt<ILoginResponse, ILogin>(
      dispatch,
      login,
      formData
    );
    if (response?.data) {
      const { token, role, username, isFirstTimeLogin } = response.data;
      Cookie.set("token", token, { expires: 1 });
      Cookie.set("isFirstTimeLogin", isFirstTimeLogin.toString());
      if (!isFirstTimeLogin) {
        if (role === Role.Admin) {
          router.push(ROUTES.ADMIN.DASHBOARD);
        } else if (role === Role.Office_User) {
          router.push(ROUTES.OFFICE_USER.DASHBOARD);
        } else if (role === Role.User) {
          router.push(ROUTES.USER.DASHBOARD);
        }
      } else {
        router.push(ROUTES.ADMIN.CHANGE_PASSWORD);
      }
      dispatch(setUserName(username));
      const decryptedResponse = await handleThunkWithDecrypt<ISubUser[], null>(
        dispatch,
        getSubUser,
        null
      );
      const apiSubUsers = decryptedResponse?.data || [];
      dispatch(setSubUser(apiSubUsers));
      const staticUser: ISubUser = {
        id: Number(response?.data?.userId),
        username: response?.data?.username ?? "",
      };
      dispatch(setCurrentUser(staticUser));
      dispatch(setOriginalUser(staticUser));
    }
    triggerLoader(false);
  };

  const [showPassword, setShowPassword] = useState(false);
  const togglePasswordVisibility = () => setShowPassword((prev) => !prev);

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    showPassword,
    togglePasswordVisibility,
  };
};
