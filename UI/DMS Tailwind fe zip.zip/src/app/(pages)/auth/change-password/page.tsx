"use client";

import { LoggedInLayout } from "@/core/components";
import { ChangePassForm } from "@/main/components";

const ChangePassword = () => {
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 bg-background p-6">
        <ChangePassForm />
      </div>
    </LoggedInLayout>
  );
};

export default ChangePassword;
