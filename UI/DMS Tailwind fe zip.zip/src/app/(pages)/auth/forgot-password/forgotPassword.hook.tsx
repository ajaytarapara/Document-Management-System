import Cookie from "js-cookie";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { IForgotPassword } from "@/main/models";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { handleThunkWithDecrypt, triggerLoader } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import { forgotPass } from "@/main/store";

export const UseForgotPasswordForm = () => {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IForgotPassword>();
  const dispatch = useAppDispatch();
  const onSubmit = async (formData: IForgotPassword) => {
    triggerLoader(true);
    const response = await handleThunkWithDecrypt<string, IForgotPassword>(
      dispatch,
      forgotPass,
      formData
    );
    if (response.isSuccessful) {
      router.push(ROUTES.VERIFY_OTP);
      Cookie.set("userName", formData.userName);
    }
    triggerLoader(false);
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
  };
};
