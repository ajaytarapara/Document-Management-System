"use client";

import Image from "next/image";
import { User } from "lucide-react";
import { UseForgotPasswordForm } from "./forgotPassword.hook";
import { Constant } from "@/core/constants/Constant";
import { getRequiredMessage } from "@/core/utils";
import { CommonButton, CommonTextField } from "@/core/components";
import { Banner } from "@/assets";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import Link from "next/link";
import { Card } from "@/core/StyledComponents";

const ForgotPasswordForm = () => {
  const { register, handleSubmit, errors, onSubmit } = UseForgotPasswordForm();

  return (
    <div className="flex flex-wrap justify-center items-center h-full">
      <div className="hidden lg:block h-full w-full md:w-1/2">
        <Image
          src={Banner}
          alt="Banner"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="w-full md:w-1/2 flex justify-center items-center p-6">
        <Card
          className="w-1/2 transition duration-200 hover:shadow-xl"
          variant="outlined"
        >
          <div>
            <p className="text-[#00092a] text-[24px] flex justify-center items-center  font-semibold transition-transform duration-200 hover:scale-105 gap-3 mb-4">
              Forgot Password
            </p>
            <p className="text-[#00092a] text-[12px] text-center font-semibold mb-4">
              Enter your registered username and we&apos;ll send a one-time
              password (OTP) to your email.
            </p>
          </div>
          <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col w-full gap-2"
          >
            <div className="space-y-4">
              <div>
                <CommonTextField
                  name="userName"
                  placeholder="Username"
                  type="text"
                  className="transition-all duration-200 !mb-0.5"
                  register={register}
                  errors={errors}
                  validation={{
                    required: getRequiredMessage("Username"),
                    maxLength: {
                      value: 50,
                      message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
                    },
                  }}
                  startAdornment={
                    <User
                      size={24}
                      className="text-bolder text-black transition-transform duration-200 hover:scale-110 hover:text-[#7E57C2]"
                    />
                  }
                />
              </div>
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className="!max-h-[48px] h-full !text-[18px] font-bold"
              >
                Submit
              </CommonButton>
              <Link
                href={ROUTES.LOGIN}
                className="text-[#00092a] flex justify-end"
              >
                <span className="relative group text-lg">
                  Back to login
                  <span className="absolute left-0 -bottom-1.5 h-[2px] w-0 bg-[#00092a] transition-all duration-300 group-hover:w-full"></span>
                </span>
              </Link>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default ForgotPasswordForm;
