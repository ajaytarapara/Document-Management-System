import Cookie from "js-cookie";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { IResetPassword } from "@/main/models";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { handleThunkWithDecrypt, triggerLoader } from "@/core/utils";
import { useEffect, useState } from "react";
import { useAppDispatch } from "@/main/hooks";
import { resetPass } from "@/main/store";

export const UseResetPasswordForm = () => {
  const [isShowNewPass, setIsShowNewPass] = useState(false);
  const [isShowConfirmNewPass, setIsShowConfirmNewPass] = useState(false);
  const router = useRouter();
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm<IResetPassword>();
  const dispatch = useAppDispatch();

  const onSubmit = async (formData: IResetPassword) => {
    triggerLoader(true);
    const userName = Cookie.get("userName");
    const finalFormData: IResetPassword = {
      ...formData,
      userName: userName ?? "",
    };
    const response = await handleThunkWithDecrypt<boolean, IResetPassword>(
      dispatch,
      resetPass,
      finalFormData
    );
    if (response.isSuccessful) {
      router.push(ROUTES.LOGIN);
      Cookie.remove("userName");
    }
    triggerLoader(false);
  };

  useEffect(() => {
    const userName = Cookie.get("userName");
    if (!userName) {
      router.push(ROUTES.LOGIN);
    }
  }, [router]);

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  };
};
