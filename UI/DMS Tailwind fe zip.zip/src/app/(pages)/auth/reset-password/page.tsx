"use client";

import Image from "next/image";
import { EyeOff, Eye } from "lucide-react";
import { UseResetPasswordForm } from "./resetPassword.hook";
import { Constant } from "@/core/constants/Constant";
import { getRequiredMessage } from "@/core/utils";
import { CommonButton, CommonTextField } from "@/core/components";
import { Banner } from "@/assets";
import { Card } from "@/core/StyledComponents";

const ResetPasswordForm = () => {
  const {
    register,
    handleSubmit,
    errors,
    onSubmit,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  } = UseResetPasswordForm();

  return (
    <div className="flex flex-wrap justify-center items-center h-full">
      <div className="hidden lg:block h-full w-full md:w-1/2">
        <Image
          src={Banner}
          alt="Banner"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex justify-center items-center p-6 w-full md:w-1/2">
        <Card
          className="w-1/2 transition duration-200 hover:shadow-xl"
          variant="outlined"
        >
          <div>
            <p className="text-[#00092a] text-[24px] flex justify-center items-center  font-semibold transition-transform duration-200 hover:scale-105 gap-3 mb-4">
              Reset Password
            </p>
          </div>
          <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col w-full gap-2"
          >
            <div className="space-y-4">
              <CommonTextField
                label="New Password"
                {...register("newPassword", {
                  required: getRequiredMessage("New Password"),
                  pattern: {
                    value: Constant.REGEX.PASSWORD_COMPLEXITY,
                    message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                  },
                })}
                type={isShowNewPass ? "text" : "password"}
                errors={errors}
                required
                endAdornment={
                  <button
                    type="button"
                    onClick={() => setIsShowNewPass(!isShowNewPass)}
                    className="cursor-pointer transition-transform duration-200 hover:scale-110"
                  >
                    {isShowNewPass ? (
                      <EyeOff
                        size={20}
                        className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    ) : (
                      <Eye
                        size={20}
                        className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    )}
                  </button>
                }
              />
              <CommonTextField
                label="Confirm Password"
                {...register("confirmPassword", {
                  required: getRequiredMessage("Confirm Password"),
                  validate: (value) =>
                    value === getValues("newPassword") ||
                    "Confirm Password must match New Password",
                  pattern: {
                    value: Constant.REGEX.PASSWORD_COMPLEXITY,
                    message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                  },
                })}
                errors={errors}
                required
                type={isShowConfirmNewPass ? "text" : "password"}
                endAdornment={
                  <button
                    type="button"
                    onClick={() =>
                      setIsShowConfirmNewPass(!isShowConfirmNewPass)
                    }
                    className="cursor-pointer transition-transform duration-200 hover:scale-110"
                  >
                    {isShowConfirmNewPass ? (
                      <EyeOff
                        size={20}
                        className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    ) : (
                      <Eye
                        size={20}
                        className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                      />
                    )}
                  </button>
                }
              />
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className="!max-h-[48px] h-full !text-[18px] font-bold"
              >
                Submit
              </CommonButton>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default ResetPasswordForm;
