"use client";

import Image from "next/image";
import { UseVerifyOTPForm } from "./verify-otp.hook";
import { CommonButton } from "@/core/components";
import { Banner } from "@/assets";
import OTPInput from "react-otp-input";
import { Card } from "@/core/StyledComponents";

const VerifyOTPForm = () => {
  const { register, handleSubmit, errors, onSubmit, setValue, watch } =
    UseVerifyOTPForm();
  const otp = watch("otp") || "";
  const isOtpComplete = otp.length === 4;

  return (
    <div className="flex flex-wrap justify-center items-center h-full">
      <div className="hidden lg:block h-full w-full md:w-1/2">
        <Image
          src={Banner}
          alt="Banner"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="flex justify-center items-center p-6 w-full md:w-1/2">
        <Card
          className="w-1/2 transition duration-200 hover:shadow-xl"
          variant="outlined"
        >
          <div>
            <p className="text-[#00092a] text-[24px] text-center font-semibold mb-4">
              Verify OTP
            </p>
          </div>
          <p className="text-[#00092a] text-[12px] text-center font-semibold mb-4">
            Please enter the OTP sent to your registered email address
            associated with your username.
          </p>
          <form
            onSubmit={handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col w-full gap-2"
          >
            <div className="space-y-4">
              <input
                type="hidden"
                {...register("otp", { required: "OTP is required" })}
              />
              <OTPInput
                value={watch("otp") || ""}
                onChange={(val) => setValue("otp", val)}
                numInputs={4}
                shouldAutoFocus
                inputType="number"
                renderInput={(props) => (
                  <input
                    {...props}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="one-time-code"
                    className="!w-[56px] !h-[56px] text-[20px] font-bold rounded-full border-2 border-[#00092a] text-center focus:border-[#7E57C2] focus:outline-none"
                  />
                )}
                containerStyle="flex justify-center gap-3"
              />
              {errors.otp && (
                <span className="text-sm text-red-500 text-center">
                  {errors.otp.message as string}
                </span>
              )}
              <CommonButton
                type="submit"
                fullWidth
                variant="contained"
                className={`!max-h-[48px] h-full !text-[18px] font-bold ${
                  !isOtpComplete ? "opacity-50 cursor-not-allowed" : ""
                }`}
                disabled={!isOtpComplete}
              >
                Submit
              </CommonButton>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default VerifyOTPForm;
