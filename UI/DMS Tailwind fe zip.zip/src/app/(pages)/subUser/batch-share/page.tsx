"use client";

import { LoggedInLayout } from "@/core/components";
import { BatchShare } from "@/main/components";

const BatchShareUser = () => {
  return (
    <LoggedInLayout>
      <BatchShare />
    </LoggedInLayout>
  );
};

export default BatchShareUser;
