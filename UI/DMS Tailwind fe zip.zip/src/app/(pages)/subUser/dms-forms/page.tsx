"use client";

import {
  LoggedInLayout,
  CommonTable,
  Dialog,
  CommonButton,
} from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import {
  CommonDMSDrawer,
  DeleteFile,
  DownloadFile,
  EditFile,
  PdfPreview,
  ShareDmsFileModal,
  UploadDocumentsTable,
} from "@/main/components";
import { shareUserDmsForm } from "@/main/store";
import { FileUp, Share2 } from "lucide-react";
import { useDmsForm } from "./DmsForm.hook";
import { ButtonType } from "@/core/models";
import { useSubmittedDmsForm } from "./SubmittedDmsForm.hook";

const DmsForms = () => {
  const {
    dmsFormColumns,
    pageIndex,
    fileName,
    errors,
    pageSize,
    openShareModal,
    fileInputRef,
    isDialogOpen,
    selectedRowIds,
    selectedFiles,
    openDeleteDialog,
    openEditDialog,
    shareFormId,
    dmsFormsData,
    totalCount,
    editErrors,
    totalPage,
    downloadSuccessDialog,
    register,
    dispatch,
    handleSortDirectionChange,
    editRegister,
    handleEditFile,
    setSelectedFiles,
    handleToggleDeleteDialog,
    handleCloseEditDialog,
    setPageIndex,
    handleFileButtonClick,
    handleFileChange,
    setPageSize,
    handleDialogClose,
    onSubmit,
    closeShareModal,
    handleDeleteFile,
    handleOpenShareModal,
    handleDownloadDialogClose,
  } = useDmsForm();
  const submitted = useSubmittedDmsForm();
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center pb-4 md:pb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">
            DMS Forms
          </h4>
        </div>
        <div className="my-4 bg-white">
          <div className="p-4 pb-0">
            <h5 className="font-semibold text-lg text-[#00092a]">
              Submitted Forms
            </h5>
          </div>
          <CommonTable
            data={submitted.submittedForms}
            columns={submitted.submittedColumns}
            pageIndex={submitted.pageIndex}
            pageSize={submitted.pageSize}
            totalPage={submitted.totalPage}
            totalCount={submitted.totalCount}
            onPageChange={submitted.setPageIndex}
            onPageSizeChange={submitted.setPageSize}
            onSortDirectionChange={submitted.handleSortDirectionChange}
            emptyMessage={Constant.MESSAGE.NO_FILES_SUBMITTED}
          />
        </div>
        <div className="p-4 bg-white rounded-lg">
          <div className="border border-dashed border-gray-300 rounded-md min-h-[130px] h-full flex justify-center items-center">
            <div className="flex flex-col justify-center items-center p-2">
              <FileUp
                strokeWidth={1}
                className="h-10 w-10 text-[#7E57C2] z-10"
              />
              <p className="text-[#b0c0d4] text-[16px] mt-2 text-center">
                Add additional Pdf Fillable Form(s) here
              </p>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <input
              type="file"
              ref={fileInputRef}
              accept="application/pdf"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />

            <button
              type={ButtonType.Button}
              onClick={handleFileButtonClick}
              className="w-full sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3] cursor-pointer"
            >
              Select File
            </button>
          </div>
        </div>
        <div className="mt-4 bg-white">
          <div className="flex justify-end p-4 pb-0">
            <CommonButton
              type={ButtonType.Button}
              variant="contained"
              disabled={!selectedRowIds.length}
              onClick={() => handleOpenShareModal("Multiple Forms")}
              className="hover:bg-[#6C4FB3] cursor-pointer flex items-center"
            >
              <Share2 size={18} /> <span className="ml-2">Multiple Share</span>
            </CommonButton>
          </div>

          <CommonTable
            data={dmsFormsData}
            columns={dmsFormColumns}
            pageIndex={pageIndex}
            pageSize={pageSize}
            totalPage={totalPage}
            totalCount={totalCount}
            onPageChange={setPageIndex}
            onPageSizeChange={setPageSize}
            onSortDirectionChange={handleSortDirectionChange}
            emptyMessage={Constant.MESSAGE.NO_FILES_UPLOADED}
          />
        </div>

        <CommonDMSDrawer
          open={openEditDialog}
          onClose={handleCloseEditDialog}
          title="Edit File Name"
          description={
            <EditFile editErrors={editErrors} editRegister={editRegister} />
          }
          onSubmit={handleEditFile}
          submitLabel={Constant.COMMON.SAVE}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType={ButtonType.Button}
          customWidth={500}
        />

        <Dialog
          open={openDeleteDialog}
          onClose={handleToggleDeleteDialog}
          title="Delete File"
          description={<DeleteFile errors={errors} register={register} />}
          onSubmit={handleDeleteFile}
          maxWidth={"sm"}
          fullWidth
          submitLabel={Constant.COMMON.SUBMIT}
          buttonType={ButtonType.Submit}
          cancelLabel={Constant.COMMON.CANCEL}
        />

        <CommonDMSDrawer
          open={isDialogOpen}
          onClose={handleDialogClose}
          title="Upload Documents"
          description={
            <UploadDocumentsTable
              selectedFiles={selectedFiles}
              setSelectedFiles={setSelectedFiles}
            />
          }
          onSubmit={onSubmit}
          disableSubmit={!selectedFiles.length}
          submitLabel={Constant.COMMON.UPLOAD}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType={ButtonType.Button}
          customWidth={700}
        />

        <ShareDmsFileModal
          open={openShareModal}
          folderId={shareFormId}
          onClose={closeShareModal}
          onShare={async (formId, formData) => {
            return await dispatch(
              shareUserDmsForm({
                formIds: selectedRowIds.length ? selectedRowIds : [formId],
                data: formData,
              })
            ).unwrap();
          }}
          fileName={fileName}
        />

        <CommonDMSDrawer
          open={downloadSuccessDialog}
          onClose={handleDownloadDialogClose}
          title={`Download File - ${fileName}`}
          description={<DownloadFile />}
          submitLabel={Constant.COMMON.OKAY}
          onSubmit={handleDownloadDialogClose}
          buttonType={ButtonType.Button}
        />

        <PdfPreview
          open={submitted.openPreviewModal}
          onClose={submitted.handleClosePreviewModel}
          fileName={submitted.fileName}
          fileUrl={submitted.fileUrl}
        />
      </div>
    </LoggedInLayout>
  );
};

export default DmsForms;
