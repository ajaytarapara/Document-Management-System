"use client";

import { LoggedInLayout } from "@/core/components";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { IPaginatedRequest, IPaginatedResponse } from "@/core/models";
import { handleThunkWithDecrypt } from "@/core/utils";
import { ConfirmDeleteModal, FolderTemplatesTable } from "@/main/components";
import { useAppDispatch } from "@/main/hooks";
import {
  IUsersResponse,
  IUserTemplateRequestVM,
  IUserTemplateResponse,
} from "@/main/models";
import {
  deleteFolderTemplate,
  getAllActiveOfficeUsers,
  getUserTemplatesByUserIdAsync,
} from "@/main/store";
import { Plus } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

const AdminFolderTemplates = () => {
  const [activeUsers, setActiveUsers] = useState<IUsersResponse[]>([]);
  const [folderTemplates, setFolderTemplates] = useState<
    IUserTemplateResponse[]
  >([]);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [search, setSearch] = useState<string>("");
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [selectedDeleteId, setSelectedDeleteId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [filter, setFilter] = useState<IPaginatedRequest>({
    pageNumber: 1,
    pageSize: 10,
    searchTerm: "",
    sortBy: "",
    sortDirection: "",
  });
  const [totalCount, setTotalCount] = useState<number>(0);
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const dispatch = useAppDispatch();
  const router = useRouter();
  const searchParams = useSearchParams();
  const userIdParam = searchParams.get("uid");

  useEffect(() => {
    if (userIdParam) {
      setSelectedUserId(userIdParam);
      handleSearchClick(userIdParam);
      window.history.replaceState(null, "", window.location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userIdParam]);

  /**
   * Fetches all active office users from the server.
   * - Dispatches the `getAllActiveOfficeUsers` async action.
   * - Checks if the response is fulfilled.
   * - Decrypts the encrypted response payload.
   * - If valid user data is present, updates the state with the list of active users.
   */
  const getAllUsers = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IUsersResponse[]>(
      dispatch,
      getAllActiveOfficeUsers
    );
    if (response?.data) {
      setActiveUsers(response.data);
    }
  }, [dispatch]);

  /**
   * Handles the search action to fetch folder templates for a specific user.
   * - Uses the provided `id` if available, otherwise defaults to `selectedUserId`.
   * - Ensures a valid user ID is present.
   * - Constructs a request object with user ID, current filters, and resets pagination to page 1.
   * - Calls `fetchTemplatesDataByUserId` to retrieve the paginated templates.
   *
   * @param id Optional user ID to override the currently selected one.
   */
  const handleSearchClick = (id?: string) => {
    const userIdToUse = id ?? selectedUserId;
    if (userIdToUse !== "") {
      const request: IUserTemplateRequestVM = {
        userId: userIdToUse,
        pageNumber: 1,
        pageSize: filter.pageSize,
        sortBy: filter.sortBy,
        sortDirection: filter.sortDirection,
      };
      setFilter((prev) => ({ ...prev, pageNumber: 1 }));
      fetchTemplatesDataByUserId(request);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  /**
   * Fetches paginated folder templates for a specific user.
   * - Dispatches the `getUserTemplatesByUserIdAsync` async action with the given request.
   * - Checks if the response is fulfilled.
   * - Decrypts the encrypted response payload.
   * - If valid data is present:
   *    - Updates the state with the list of templates (`items`).
   *    - Sets the total count of templates for pagination.
   */
  const fetchTemplatesDataByUserId = async (
    request: IUserTemplateRequestVM
  ) => {
    const response = await handleThunkWithDecrypt<
      IPaginatedResponse<IUserTemplateResponse>,
      IUserTemplateRequestVM
    >(dispatch, getUserTemplatesByUserIdAsync, request);
    if (response?.data) {
      setFolderTemplates(response.data.items);
      setTotalCount(response.data.totalCount);
      setHasSearched(true);
    }
  };

  /**
   * Handles pagination when the user navigates to a different page.
   * - Ensures a user is selected (`selectedUserId` is not empty).
   * - Constructs a request object using the selected page number and current filter values.
   * - Updates the filter state with the new page number.
   * - Calls `fetchTemplatesDataByUserId` to fetch the templates for the selected page.
   */
  const handlePageChange = (page: number) => {
    if (selectedUserId !== "") {
      const request: IUserTemplateRequestVM = {
        pageNumber: page,
        pageSize: filter.pageSize,
        userId: selectedUserId,
        sortBy: filter.sortBy,
        sortDirection: filter.sortDirection,
      };
      setFilter((prev) => ({
        ...prev,
        pageNumber: page,
      }));
      fetchTemplatesDataByUserId(request);
    }
  };

  const handleConfirmDelete = async () => {
    if (selectedDeleteId !== null) {
      const resultAction = await dispatch(
        deleteFolderTemplate(selectedDeleteId)
      );
      setShowModal(false);
      setSelectedDeleteId(null);

      if (
        deleteFolderTemplate.fulfilled.match(resultAction) &&
        selectedUserId !== ""
      ) {
        const request: IUserTemplateRequestVM = {
          pageNumber: filter.pageNumber,
          pageSize: filter.pageSize,
          userId: selectedUserId,
          sortBy: filter.sortBy,
          sortDirection: filter.sortDirection,
        };
        fetchTemplatesDataByUserId(request);
      }
    }
  };

  const handleOpenModal = (id: string) => {
    setSelectedDeleteId(id);
    setShowModal(true);
  };

  const handleAddClick = () => {
    router.push(
      `${ROUTES.ADMIN.ADD_EDIT_FOLDER_TEMPLATES}?uid=${selectedUserId}`
    );
  };

  const handleEditClick = (id: string) => {
    router.push(
      `${ROUTES.ADMIN.ADD_EDIT_FOLDER_TEMPLATES}?uid=${selectedUserId}&templateid=${id}`
    );
  };

  useEffect(() => {
    getAllUsers();
  }, [getAllUsers]);
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">
            Folder Templates
          </h4>
        </div>
        <div className="p-4 md:p-8 bg-white rounded-lg">
          <h6 className="font-semibold text-sm text-[#00092a] tracking-wide mb-2">
            Select User to see Templates:
          </h6>
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4 gap-2 w-full">
            <div className="w-full sm:w-[400px] relative" ref={dropdownRef}>
              <input
                type="text"
                className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-[#7E57C2] border-gray-300 hover:border-[#7E57C2]"
                placeholder="Search Users..."
                value={
                  isOpen
                    ? search
                    : activeUsers.find((u) => u.id === selectedUserId)
                        ?.userName || ""
                }
                onFocus={() => setIsOpen(true)}
                onChange={(e) => setSearch(e.target.value)}
                readOnly={!isOpen}
              />
              {isOpen && (
                <ul className="absolute z-10 mt-1 w-full max-h-48 overflow-y-scroll scrollbar-none bg-white border border-gray-300 rounded-md shadow-lg">
                  {activeUsers.filter((u) =>
                    u.userName.toLowerCase().includes(search.toLowerCase())
                  ).length > 0 ? (
                    activeUsers
                      .filter((u) =>
                        u.userName.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((user) => (
                        <li
                          key={user.id}
                          className="px-3 py-2 hover:bg-blue-100 cursor-pointer"
                          onClick={() => {
                            setSelectedUserId(user.id);
                            setIsOpen(false);
                            setSearch("");
                          }}
                        >
                          {user.userName}
                        </li>
                      ))
                  ) : (
                    <li className="px-3 py-2 text-gray-500">No users found</li>
                  )}
                </ul>
              )}
            </div>
            <button
              type="button"
              onClick={() => handleSearchClick()}
              className="w-full sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3]"
            >
              Search
            </button>
          </div>
        </div>
        {hasSearched && (
          <div className="p-4 md:p-8 bg-white rounded-lg mt-4">
            <div className="mb-4 w-full flex flex-col sm:flex-row sm:justify-end sm:items-center gap-2 sm:gap-4">
              <button
                type="button"
                onClick={handleAddClick}
                className="w-full flex items-center justify-center gap-2 sm:w-auto px-4 py-[9px] text-sm font-medium bg-[#7E57C2] text-white rounded-md shadow hover:bg-[#6C4FB3]"
              >
                <Plus className="h-5 w-5" />
                <span>Add</span>
              </button>
            </div>
            <FolderTemplatesTable
              data={folderTemplates}
              currentPage={filter.pageNumber}
              pageSize={filter.pageSize}
              totalCount={totalCount}
              onPageChange={handlePageChange}
              onDelete={handleOpenModal}
              onEdit={handleEditClick}
            />
            <ConfirmDeleteModal
              open={showModal}
              onClose={() => setShowModal(false)}
              onConfirm={handleConfirmDelete}
              title="Delete Folder Template?"
              message="This action cannot be undone. Are you sure you want to delete this folder template?"
            />
          </div>
        )}
      </div>
    </LoggedInLayout>
  );
};

export default AdminFolderTemplates;
