"use client";

import {
  LoggedInLayout,
  CommonTable,
  Dialog,
  CommonButton,
} from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { ButtonType, PointerEvents, User } from "@/core/models";
import {
  CommonDMSDrawer,
  DeleteFile,
  EditFile,
  PdfPreview,
  UploadDocumentsTable,
} from "@/main/components";
import { FileUp, ChevronDown, ChevronUp } from "lucide-react";
import { useEffect, useRef } from "react";
import { useDmsForm } from "./DmsForm.hook";

interface UserDropdownProps {
  filteredUsers: User[];
  searchText: string;
  setSearchText: (value: string) => void;
  setSelectedUserId: (id: string) => void;
  dropdownOpen: boolean;
  setDropdownOpen: (open: boolean) => void;
}

const DmsForms = () => {
  const {
    dmsFormColumns,
    pageIndex,
    pageSize,
    selectedUserId,
    fileInputRef,
    isDialogOpen,
    selectedFiles,
    totalPage,
    dmsFormsData,
    totalCount,
    openEditDialog,
    handleCloseEditDialog,
    editErrors,
    editRegister,
    handleEditFile,
    openDeleteDialog,
    handleToggleDeleteDialog,
    errors,
    handleDeleteFile,
    register,
    setSelectedFiles,
    handleSearchClick,
    handleFileButtonClick,
    handleFileChange,
    setSelectedUserId,
    handleDialogClose,
    onSubmit,
    handlePageChange,
    handlePageSizeChange,
    handleClosePreviewModel,
    openPreviewModal,
    fileUrl,
    fileName,
    filteredUsers,
    setSearchText,
    dropdownOpen,
    searchText,
    setDropdownOpen,
    handleRemoveSearchText,
    handleSortDirectionChange,
  } = useDmsForm();
  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-6">
          <h4 className="font-semibold text-xl md:text-2xl text-[#00092a] tracking-wide">
            DMS Forms
          </h4>
        </div>

        <div className="p-4 md:p-6 bg-white rounded-lg">
          <label className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary dark:text-gray-200">
            Select office user to see DMS forms:
          </label>
          <div className="flex flex-col sm:flex-row sm:items-center sm:gap-4 gap-2 w-full">
            <div className="w-full sm:w-[400px]">
              <UserDropdown
                filteredUsers={filteredUsers}
                searchText={searchText}
                setSearchText={setSearchText}
                setSelectedUserId={setSelectedUserId}
                dropdownOpen={dropdownOpen}
                setDropdownOpen={setDropdownOpen}
              />
            </div>
            <CommonButton
              type={ButtonType.Button}
              variant="contained"
              disabled={!selectedUserId}
              onClick={() => handleSearchClick(selectedUserId)}
              className="w-fullhover:bg-[#6C4FB3] cursor-pointer"
            >
              Search
            </CommonButton>
            <CommonButton
              type={ButtonType.Button}
              variant="contained"
              disabled={!searchText}
              onClick={() => handleRemoveSearchText()}
              className="w-fullhover:bg-[#6C4FB3] cursor-pointer"
            >
              Clear
            </CommonButton>
          </div>
        </div>
        <div className="p-4 bg-white rounded-lg mt-4">
          <div className="border border-dashed border-gray-300 rounded-md min-h-[130px] h-full flex justify-center items-center">
            <div className="flex flex-col justify-center items-center p-2">
              <FileUp
                strokeWidth={1}
                className="h-10 w-10 text-[#7E57C2] z-10"
              />
              <p className="text-[#b0c0d4] text-[16px] mt-2 text-center">
                Add additional Pdf Fillable Form(s) here
              </p>
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <input
              type="file"
              ref={fileInputRef}
              accept="application/pdf"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />

            <CommonButton
              type={ButtonType.Button}
              variant="contained"
              onClick={handleFileButtonClick}
              className="w-full max-w-[120px] justify-end hover:bg-[#6C4FB3] cursor-pointer"
            >
              Select File
            </CommonButton>
          </div>
        </div>
        <div className="mt-4">
          <CommonTable
            data={dmsFormsData}
            columns={dmsFormColumns}
            pageSize={pageSize}
            pageIndex={pageIndex}
            totalPage={totalPage}
            totalCount={totalCount}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onSortDirectionChange={handleSortDirectionChange}
            emptyMessage={Constant.MESSAGE.NO_FILES_UPLOADED_FOR_USER}
          />
        </div>

        <CommonDMSDrawer
          open={isDialogOpen}
          onClose={handleDialogClose}
          title="Upload Documents"
          description={
            <UploadDocumentsTable
              selectedFiles={selectedFiles}
              setSelectedFiles={setSelectedFiles}
            />
          }
          onSubmit={onSubmit}
          disableSubmit={!selectedFiles.length}
          submitLabel={Constant.COMMON.UPLOAD}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType={ButtonType.Button}
          customWidth={700}
        />

        <CommonDMSDrawer
          open={openEditDialog}
          onClose={handleCloseEditDialog}
          title="Edit File Name"
          description={
            <EditFile editErrors={editErrors} editRegister={editRegister} />
          }
          onSubmit={handleEditFile}
          submitLabel={Constant.COMMON.SAVE}
          cancelLabel={Constant.COMMON.CLOSE}
          buttonType={ButtonType.Button}
          customWidth={500}
        />

        <Dialog
          open={openDeleteDialog}
          onClose={handleToggleDeleteDialog}
          title="Delete File"
          description={<DeleteFile errors={errors} register={register} />}
          onSubmit={handleDeleteFile}
          maxWidth={"xs"}
          fullWidth
          submitLabel={Constant.COMMON.SUBMIT}
          cancelLabel={Constant.COMMON.CANCEL}
          buttonType={ButtonType.Submit}
        />

        <PdfPreview
          open={openPreviewModal}
          onClose={handleClosePreviewModel}
          fileName={fileName}
          fileUrl={fileUrl}
        />
      </div>
    </LoggedInLayout>
  );
};

const UserDropdown: React.FC<UserDropdownProps> = ({
  filteredUsers,
  searchText,
  setSearchText,
  setSelectedUserId,
  dropdownOpen,
  setDropdownOpen,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  /**
   * Closes the dropdown when clicking outside the container.
   */
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener(PointerEvents.POINTER_DOWN, handleClickOutside);
    return () => {
      document.removeEventListener(
        PointerEvents.POINTER_DOWN,
        handleClickOutside
      );
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full sm:w-[400px] relative">
      <input
        type="text"
        placeholder="Search Office User"
        value={searchText}
        onChange={(e) => {
          setSearchText(e.target.value);
          setDropdownOpen(true);
        }}
        onFocus={() => setDropdownOpen(true)}
        className="w-full border cursor-pointer border-gray-300 rounded px-3 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-[#7E57C2]"
      />

      {dropdownOpen ? (
        <ChevronUp
          className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400"
          size={20}
        />
      ) : (
        <ChevronDown
          className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400"
          size={20}
        />
      )}

      {dropdownOpen && (
        <ul className="absolute z-10 bg-white w-full border border-gray-300 rounded mt-1 max-h-40 overflow-y-auto">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <li
                key={user.id}
                className="px-3 py-2 hover:bg-[#f1e9fc] cursor-pointer"
                onClick={() => {
                  setSelectedUserId(user.id.toString());
                  setSearchText(user.userName);
                  setDropdownOpen(false);
                }}
              >
                {user.userName}
              </li>
            ))
          ) : (
            <li className="px-3 py-2 text-gray-400">No users found</li>
          )}
        </ul>
      )}
    </div>
  );
};

export default DmsForms;
