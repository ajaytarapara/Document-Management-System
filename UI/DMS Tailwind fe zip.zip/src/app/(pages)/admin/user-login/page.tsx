"use client";

import { CommonDrawer, CommonSelect, LoggedInLayout } from "@/core/components";
import { IPaginatedRequest, IPaginatedResponse } from "@/core/models";
import { handleThunkWithDecrypt } from "@/core/utils";
import { LoginDetailTable, LoginTable } from "@/main/components";
import { useAppDispatch } from "@/main/hooks";
import {
  IUserLoginDetailRequestVM,
  IUserLoginDetailResponseVM,
  IUserLoginSummaryResponseVM,
  IUserLoginSummaryVM,
  IUsersResponse,
} from "@/main/models";
import {
  getAllActiveUsers,
  getLast7DaysLogins,
  getUserLoginDetailsByDate,
} from "@/main/store";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Option } from "@/main/models";
import { useForm } from "react-hook-form";

const UserLoginRecords = () => {
  const dispatch = useAppDispatch();
  const [data, setData] = useState<IUserLoginSummaryVM[]>([]);
  const [activeUsers, setActiveUsers] = useState<IUsersResponse[]>([]);
  const [clickedButtonData, setClickedButtonData] =
    useState<IUserLoginSummaryVM | null>(null);
  const [filter, setFilter] = useState<IPaginatedRequest>({
    pageNumber: 1,
    pageSize: 10,
    searchTerm: "",
    sortBy: "loginDate",
    sortDirection: "desc",
  });
  const router = useRouter();
  const [dataByDate, setDataByDate] = useState<IUserLoginDetailResponseVM[]>(
    []
  );
  const [totalCount, setTotalCount] = useState<number>(0);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [date, setDate] = useState<string>("");
  /**
   * Fetches login summary data for the last 7 days.
   * - Dispatches the `getLast7DaysLogins` async action.
   * - Checks if the response is successful.
   * - Decrypts the encrypted payload.
   * - If valid data is present, sets the decrypted login summary data in state.
   */
  const fetchData = async () => {
    const response = await handleThunkWithDecrypt<IUserLoginSummaryResponseVM>(
      dispatch,
      getLast7DaysLogins
    );
    if (response?.data) {
      setData(response.data.userLoginSummaryVMs);
    }
  };

  /**
   * Fetches all active users from the server.
   * - Dispatches the `getAllActiveUsers` async action.
   * - Verifies if the response is successful.
   * - Decrypts the encrypted payload received from the API.
   * - If valid user data is present, updates the state with the list of active users.
   */
  const getAllUsers = async () => {
    const response = await handleThunkWithDecrypt<IUsersResponse[]>(
      dispatch,
      getAllActiveUsers
    );
    if (response?.data) {
      setActiveUsers(response.data);
    }
  };

  /**
   * Handles the click event for a specific user's login summary.
   * - Resets the selected user ID.
   * - Converts the clicked data's date to a formatted string: 'YYYY-MM-DDT00:00:00'.
   * - Updates the clicked data with the formatted date and sets it in state.
   * - Constructs a request object using the formatted date and current filter parameters.
   * - Triggers a fetch call to retrieve login details for the selected date.
   */
  const handleActionButtonClick = (clickedData: IUserLoginSummaryVM) => {
    setSelectedUserId("");
    const dateObj = new Date(clickedData.date);
    const year = dateObj.getFullYear();
    const month = String(dateObj.getMonth() + 1).padStart(2, "0");
    const day = String(dateObj.getDate()).padStart(2, "0");
    const formattedDate = `${year}-${month}-${day}T00:00:00`;
    setDate(`${day}-${month}-${year}`);
    const updatedClickedData: IUserLoginSummaryVM = {
      ...clickedData,
      date: formattedDate,
    };

    setClickedButtonData(updatedClickedData);

    const request: IUserLoginDetailRequestVM = {
      date: formattedDate,
      pageNumber: 1,
      pageSize: 10,
      sortBy: "loginDate",
      sortDirection: "desc",
    };
    setFilter((prev) => ({
      ...prev,
      pageNumber: 1,
    }));
    fetchDataByDate(request);
    setDrawerOpen(true);
  };

  /**
   * Fetches detailed login data for a specific date.
   * - Dispatches the `getUserLoginDetailsByDate` async action with the given request payload.
   * - Checks if the response is successful.
   * - Decrypts the encrypted payload which contains paginated login detail data.
   * - If valid data is found:
   *    - Sets the login detail items in state.
   *    - Updates the total count of records.
   */
  const fetchDataByDate = async (request: IUserLoginDetailRequestVM) => {
    const response = await handleThunkWithDecrypt<
      IPaginatedResponse<IUserLoginDetailResponseVM>,
      IUserLoginDetailRequestVM
    >(dispatch, getUserLoginDetailsByDate, request);
    if (response?.data) {
      setDataByDate(response.data.items);
      setTotalCount(response.data.totalCount);
    }
  };

  /**
   * Handles pagination when a new page is selected.
   * - Constructs a request object using the selected page number, current filter values, and clicked date.
   * - Includes `userId` only if a user is selected.
   * - Updates the filter state with the new page number.
   * - Calls `fetchDataByDate` to fetch the login details for the selected page.
   */
  const handlePageChange = (page: number) => {
    if (clickedButtonData) {
      const request: IUserLoginDetailRequestVM = {
        date: clickedButtonData.date,
        pageNumber: page,
        pageSize: filter.pageSize,
        userId: selectedUserId !== "" ? selectedUserId : undefined,
        sortBy: filter.sortBy,
        sortDirection: filter.sortDirection,
      };
      setFilter((prev) => ({
        ...prev,
        pageNumber: page,
      }));
      fetchDataByDate(request);
    }
  };

  /**
   * Handles the search/filter action based on the selected user.
   * - Builds a request object using the current filter and selected user ID.
   * - Resets pagination to the first page.
   * - Invokes `fetchDataByDate` to fetch login details for the selected user and date.
   */
  const onChangeSelect = (id: string) => {
    debugger;
    setSelectedUserId(id);
    if (clickedButtonData) {
      const request: IUserLoginDetailRequestVM = {
        date: clickedButtonData.date,
        userId: id !== "" ? id : undefined,
        pageNumber: 1,
        pageSize: filter.pageSize,
        sortBy: filter.sortBy,
        sortDirection: filter.sortDirection,
      };

      setFilter((prev) => ({ ...prev, pageNumber: 1 }));
      fetchDataByDate(request);
    }
  };

  useEffect(() => {
    fetchData();
    getAllUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Options for User Select Dropdown
   *
   * `options` is an array of objects that will populate the CommonSelect dropdown.
   * The first option is always "All Users" with an empty string value.
   * Then we map over `activeUsers` to create an option for each active user,
   * using their `id` as the value and `userName` as the display label.
   */
  const options: Option[] = [
    { value: "", label: "All Users" },
    ...activeUsers.map((u) => ({ value: u.id, label: u.userName })),
  ];

  /**
   * React Hook Form Control
   *
   * Using `useForm` from react-hook-form to manage form state for the CommonSelect.
   * The form state only tracks `userId` here, with an initial default value of "" (All Users).
   */
  const { control } = useForm<{ userId: string }>({
    defaultValues: { userId: "" },
  });

  return (
    <LoggedInLayout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white rounded-md text-[#212529] p-4">
          <div className="mb-4 flex items-center justify-between">
            <span className="text-base sm:text-lg md:text-xl font-semibold">
              User Login Records
            </span>
            <button
              onClick={() => router.back()}
              className="px-3 py-1.5 sm:px-4 sm:py-2 text-xs sm:text-sm md:text-base font-medium text-white bg-[#7E57C2] hover:bg-[#6C4FB3] rounded-md shadow"
            >
              Back
            </button>
          </div>
          <LoginTable
            data={data}
            handleActionButtonClick={handleActionButtonClick}
          />
        </div>
        <CommonDrawer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          title={`Login Details (${date})`}
          lgSize="60%"
        >
          <div className="w-full sm:w-[250px]">
            <CommonSelect<{ userId: string }>
              name="userId"
              control={control}
              options={options}
              placeholder="All Users"
              fullWidth
              dropdownHeight={188}
              onChange={(val: string) => onChangeSelect(val)}
            />
          </div>
          <div className="mt-4">
            <LoginDetailTable
              data={dataByDate}
              currentPage={filter.pageNumber}
              pageSize={filter.pageSize}
              totalCount={totalCount}
              onPageChange={handlePageChange}
            />
          </div>
        </CommonDrawer>
      </div>
    </LoggedInLayout>
  );
};

export default UserLoginRecords;
