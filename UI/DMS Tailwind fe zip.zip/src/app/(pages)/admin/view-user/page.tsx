"use client";

import {
  ArrowBigLeft,
  Trash2,
  UserRoundPlus,
  UserRoundSearch,
} from "lucide-react";
import { Control, FieldValues, useForm } from "react-hook-form";

import { useViewUserForm } from "./ViewUser.hook";
import {
  StyledButton,
  StyledCancelButton,
  StyledUserIconButton,
} from "./ViewUser.styled";
import {
  LoggedInLayout,
  CommonTextField,
  Dialog,
  CommonSelect,
  CommonDrawer,
  CommonCardList,
} from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { IUserFilter, IUserDetail, FormTableValues } from "@/main/models";
import {
  CreateUserForm,
  UpdateOfficeUserForm,
  UserCard,
} from "@/main/components";
import { ButtonType } from "@/core/models";

const ViewUserPage = () => {
  const {
    userData,
    openDeleteDialog,
    pageSize,
    pageIndex,
    totalPage,
    officeUserOptions,
    isFilterEmpty,
    isDrawerOpen,
    isEditDrawerOpen,
    selectedEditUserId,
    setIsSaveClick,
    closeEditDrawer,
    openDrawer,
    closeDrawer,
    setPageIndex,
    setPageSize,
    backToDashboard,
    onSubmit,
    handleSubmit,
    register,
    handleCloseDeleteDialog,
    handleDeleteUser,
    handleClearFilters,
    handleEditUser,
    handleOpenDeleteDialog,
    setIsCreateClick,
  } = useViewUserForm();

  /**
   * Initialize react-hook-form with default values.
   * control: Used to connect input components to the form state.
   * defaultValues: Sets initial form field values, here setting `pageSize` as a string.
   */
  const { control } = useForm({
    defaultValues: { pageSize: pageSize.toString() },
  });

  return (
    <LoggedInLayout>
      <div className="container bg-white rounded shadow-md mx-auto mb-6">
        <div className="flex flex-col justify-between py-6 sm:py-4 xs:py-3">
          <div className="flex flex-col gap-3 sm:flex-row justify-between pb-4 px-6 border-b border-[#7E57C2] xs:pb-2 xs:px-2">
            <div className="flex items-center gap-2 w-full flex-wrap xs:flex-col xs:items-start md:flex-row md:items-center">
              <UserRoundSearch
                strokeWidth={2.3}
                color="#00092A"
                className="w-6 h-6 md:w-7 md:h-7"
              />
              <h2 className="text-[#00092A] font-semibold text-lg lg:text-2xl ml-3 xs:ml-0 xs:mt-2 xs:text-lg md:ml-0 md:mt-2">
                View Users
              </h2>
            </div>
            <div className="flex gap-4 w-full justify-end items-center">
              <StyledButton onClick={backToDashboard}>
                <ArrowBigLeft className="h-5 w-5" />
                <span>{Constant.COMMON.BACK}</span>
              </StyledButton>
              <div className="min-w-[100px]">
                <StyledUserIconButton title="Add User" onClick={openDrawer}>
                  <UserRoundPlus className="h-5 w-5 z-10" />
                  <span>Add User</span>
                </StyledUserIconButton>
              </div>
            </div>
          </div>

          <div className="pt-4 px-6 sm:px-5 xs:px-2">
            <form
              id="filter-user-form"
              onSubmit={handleSubmit(onSubmit)}
              noValidate
              className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end"
            >
              <CommonTextField<IUserFilter>
                name="userName"
                placeholder="User Name"
                label="User Name"
                register={register}
              />

              <CommonSelect
                name="officeUser"
                label="Office User"
                placeholder="Office User"
                control={control as unknown as Control<FieldValues>}
                options={officeUserOptions}
                dropdownHeight={190}
              />

              <div className="flex gap-4">
                <StyledCancelButton
                  type={ButtonType.Button}
                  disabled={isFilterEmpty}
                  onClick={handleClearFilters}
                  className="w-full sm:w-auto h-11"
                >
                  {Constant.COMMON.CLEAR}
                </StyledCancelButton>
                <StyledButton
                  disabled={isFilterEmpty}
                  type={ButtonType.Submit}
                  className="w-full sm:w-auto"
                >
                  {Constant.COMMON.SEARCH}
                </StyledButton>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div className="container rounded shadow-md mx-auto">
        <CommonCardList<IUserDetail>
          data={userData}
          renderCard={(user) => (
            <UserCard
              onDelete={handleOpenDeleteDialog}
              onEdit={handleEditUser}
              role="Admin"
              user={user}
              key={"admin-user-cards"}
            />
          )}
          pageIndex={pageIndex}
          pageSize={pageSize}
          totalPage={totalPage}
          control={control as unknown as Control<FormTableValues>}
          emptyMessage={
            isFilterEmpty
              ? Constant.MESSAGE.NO_USERS_FOUND_MESSAGE
              : Constant.MESSAGE.NO_USERS_FOUND_FOR_SELECTED_FILTER_MESSAGE
          }
          onPageChange={setPageIndex}
          onPageSizeChange={(size) => {
            setPageSize(size);
            setPageIndex(1);
          }}
        />
      </div>

      <Dialog
        open={openDeleteDialog}
        icon={<Trash2 color="#e71d1d" />}
        onClose={handleCloseDeleteDialog}
        title="Delete User"
        description={Constant.MESSAGE.DELETE_USER_CONFIRMATION_MESSAGE}
        onSubmit={handleDeleteUser}
        submitLabel={Constant.COMMON.DELETE}
        cancelLabel={Constant.COMMON.CANCEL}
        buttonType={ButtonType.Button}
        maxWidth="xs"
        fullWidth
      />

      {isDrawerOpen && (
        <CommonDrawer
          open={isDrawerOpen}
          onClose={closeDrawer}
          title="Create User"
          lgSize="50%"
        >
          <CreateUserForm
            onClose={closeDrawer}
            setIsCreateClick={setIsCreateClick}
          />
        </CommonDrawer>
      )}

      {isEditDrawerOpen && (
        <CommonDrawer
          open={isEditDrawerOpen}
          onClose={closeEditDrawer}
          title="Update Office User"
          lgSize="50%"
        >
          <UpdateOfficeUserForm
            onClose={() => closeEditDrawer()}
            userId={String(selectedEditUserId)}
            setIsSaveClick={setIsSaveClick}
          />
        </CommonDrawer>
      )}
    </LoggedInLayout>
  );
};

export default ViewUserPage;
