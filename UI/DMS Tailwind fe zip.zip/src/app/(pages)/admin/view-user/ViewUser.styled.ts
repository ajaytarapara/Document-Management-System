import emotionStyled from "@emotion/styled";

export const StyledButton = emotionStyled("button")`
  background-color: #5e35b1;
  color: white;
  max-width: 100px;
  width: 100%;
  display:flex;
  gap: 10px;
  align-items:center;
  justify-content: center;
  text-transform: capitalize;
  transition: background-color 0.3s ease;
  padding: 5px 10px;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #6a45b3;
  }

  &:disabled {
    background-color: #e1dcef;
    color: #9e9e9e;
    cursor: not-allowed !important;
  }
  
  @media (max-width: 640px) {
    max-width: 95px;
  }
`;

export const StyledUserIconButton = emotionStyled("button")`
  background-color: #5e35b1;
  color: white;
  gap: 10px;
  max-width: 150px;
  width: 100%;
  display:flex;
  align-items:center;
  justify-content: center;
  text-transform: capitalize;
  transition: background-color 0.3s ease;
  padding: 5px 10px;
  border-radius: 5px;
  cursor: pointer;
  &:hover {
    background-color: #6a45b3;
  }

  &:disabled {
    background-color: #e1dcef;
    color: #9e9e9e;
    cursor: not-allowed !important;
  }

  @media (max-width: 640px) {
    max-width: 125px;
  }
`;

export const StyledCancelButton = emotionStyled("button")`
  max-width: 100px;
  width: 100%;
  cursor: pointer;
  border-radius: 3px;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #5e35b1;
  &:hover {
    background-color: #e1dcef;
  }
`;
