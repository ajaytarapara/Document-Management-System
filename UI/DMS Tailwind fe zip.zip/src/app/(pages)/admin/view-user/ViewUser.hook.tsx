"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { useNavigate, handleThunkWithDecrypt } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import {
  IUserDetail,
  OfficeUser,
  IUserFilter,
  PaginationResponse,
  UserFilterRequest,
} from "@/main/models";
import { getUsers, getAllOfficeUsers, deleteUser } from "@/main/store";
import { SortDirection } from "@/core/models";

/**
 * Custom hook to manage the View Users page.
 * Handles data fetching, filtering, pagination, sorting, user deletion, and navigation.
 *
 * @returns {object} Hook state and handlers for the View Users page
 */
export const useViewUserForm = () => {
  const [userData, setUserData] = useState<IUserDetail[]>([]);
  const [officeUsers, setOfficeUsers] = useState<OfficeUser[]>([]);
  const [pageIndex, setPageIndex] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [totalPage, SetTotalPage] = useState<number>(0);
  const [openDeleteDialog, setOpenDeleteDialog] = useState<boolean>(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isEditDrawerOpen, setIsEditDrawerOpen] = useState<boolean>(false);
  const [isSaveClick, setIsSaveClick] = useState<boolean>(false);
  const [isCreateClick, setIsCreateClick] = useState<boolean>(false);
  const [selectedEditUserId, setSelectedEditUserId] = useState<string | null>(
    null
  );
  const [filters, setFilters] = useState<IUserFilter>({
    officeUser: "",
    roleType: "",
    userName: "",
  });

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { register, handleSubmit, reset, watch } = useForm<IUserFilter>({
    defaultValues: {
      userName: "",
      officeUser: "",
      roleType: "",
    },
  });

  /**
   * Watch form fields for live updates using react-hook-form.
   */
  const watchedUserName = watch("userName");
  const watchedOfficeUser = watch("officeUser");
  const watchedRoleType = watch("roleType");

  /**
   * Determines whether all filters are empty.
   * Used to disable or enable "Clear Filters" or "Apply" actions.
   */
  const isFilterEmpty =
    !watchedUserName?.trim() && !watchedOfficeUser && !watchedRoleType;

  /**
   * Options for the "Office User" dropdown.
   * Includes an "All" option, followed by mapped office users.
   */
  const officeUserOptions = [
    { label: "All", value: "" },
    ...officeUsers.map((user) => ({
      label: `${user.name} (${user.userName})`,
      value: user.name,
    })),
  ];

  /**
   * Fetches paginated user data based on the provided page, size, sorting, and filters.
   *
   * @param {number} [page=pageIndex] - Current page number.
   * @param {number} [size=pageSize] - Number of users per page.
   * @param {SortingState} [currentSorting=sorting] - Current table sorting state.
   * @param {IUserFilter} [currentFilters=filters] - Current applied filters.
   */
  const getUsersData = async (
    page = pageIndex,
    size = pageSize,
    currentFilters = filters
  ) => {
    const searchKey = JSON.stringify(currentFilters);
    const decryptedResponse = await handleThunkWithDecrypt<
      PaginationResponse<IUserDetail>,
      UserFilterRequest
    >(dispatch, getUsers, {
      pageNumber: page,
      pageSize: size,
      sortOrder: SortDirection.DESC,
      searchKey: searchKey,
    });

    const items = decryptedResponse?.data?.items ?? [];
    const totalPages = decryptedResponse?.data?.totalPages ?? 0;
    SetTotalPage(totalPages);
    setUserData(items ?? []);
  };

  /**
   * Fetches all office users and sets them in local state for dropdown filtering.
   */
  const getAllUsers = useCallback(async () => {
    const decryptedResponse = await handleThunkWithDecrypt(
      dispatch,
      getAllOfficeUsers,
      null
    );
    const items = decryptedResponse?.data ?? [];
    setOfficeUsers(items as OfficeUser[]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Deletes the currently selected user (by ID) and refreshes the user list.
   * Also closes the delete confirmation dialog.
   */
  const handleDeleteUser = async () => {
    if (selectedUserId !== null) {
      const result = await dispatch(deleteUser(selectedUserId));
      if (deleteUser.fulfilled.match(result)) {
        setOpenDeleteDialog(false);
        setSelectedUserId(null);
        setTimeout(() => {
          navigate(ROUTES.ADMIN.VIEW_USER);
        }, 1500);
        getUsersData();
      }
    }
  };

  /**
   * Opens the delete confirmation dialog for the selected user ID.
   *
   * @param {number} userId - ID of the user to be deleted.
   */
  const handleOpenDeleteDialog = (userId: string) => {
    setSelectedUserId(userId);
    setOpenDeleteDialog(true);
  };

  /**
   * Closes the delete confirmation dialog and resets selected user ID.
   */
  const handleCloseDeleteDialog = () => {
    setSelectedUserId(null);
    setOpenDeleteDialog(false);
  };

  /**
   * Form submit handler for applying user filters.
   *
   * @param {IUserFilter} data - Filter values submitted from the form.
   */
  const onSubmit = (data: IUserFilter) => {
    setFilters(data);
    setPageIndex(1);
  };

  /**
   * Navigates back to the admin dashboard.
   */
  const backToDashboard = () => {
    navigate(ROUTES.ADMIN.DASHBOARD);
  };

  /**
   * Clears all applied filters and resets the filter form to default values.
   */
  const handleClearFilters = () => {
    const defaultValues: IUserFilter = {
      officeUser: "",
      roleType: "",
      userName: "",
    };
    setFilters(defaultValues);
    reset(defaultValues);
    setPageIndex(1);
  };

  /**
   * Opens the create-user drawer.
   */
  const openDrawer = () => setIsDrawerOpen(true);

  /**
   * Closes the create-user drawer.
   */
  const closeDrawer = () => setIsDrawerOpen(false);

  /**
   * Opens the edit-user drawer for a specific user.
   * @param userId - The ID of the user to be edited.
   */
  const handleEditUser = (userId: string) => {
    setSelectedEditUserId(userId);
    openEditDrawer();
  };

  /**
   * Opens the edit-user drawer.
   */
  const openEditDrawer = () => setIsEditDrawerOpen(true);

  /**
   * Closes the edit-user drawer.
   */
  const closeEditDrawer = () => setIsEditDrawerOpen(false);

  /**
   * Fetches the user data whenever pagination, sorting, or filters change.
   * Also resets create and save click states.
   */
  useEffect(() => {
    getUsersData(pageIndex, pageSize, filters);
    setIsCreateClick(false);
    setIsSaveClick(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pageIndex, pageSize, filters, isSaveClick, isCreateClick]);

  /**
   * Fetches all users when the component mounts or when
   * create/save click states change.
   */
  useEffect(() => {
    getAllUsers();
    setIsCreateClick(false);
    setIsSaveClick(false);
  }, [getAllUsers, isSaveClick, isCreateClick]);

  return {
    userData,
    openDeleteDialog,
    pageSize,
    pageIndex,
    totalPage,
    officeUserOptions,
    isFilterEmpty,
    isDrawerOpen,
    isEditDrawerOpen,
    selectedEditUserId,
    setIsSaveClick,
    closeEditDrawer,
    openDrawer,
    closeDrawer,
    setPageIndex,
    setPageSize,
    backToDashboard,
    onSubmit,
    handleSubmit,
    register,
    handleCloseDeleteDialog,
    handleDeleteUser,
    handleClearFilters,
    handleEditUser,
    handleOpenDeleteDialog,
    setIsCreateClick,
  };
};
