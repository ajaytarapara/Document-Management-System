import Banner from "./Images/Banner.svg";
import Error from "./Images/Error.svg";
import Success from "./Images/success.png";
export { Banner, Error, Success };
