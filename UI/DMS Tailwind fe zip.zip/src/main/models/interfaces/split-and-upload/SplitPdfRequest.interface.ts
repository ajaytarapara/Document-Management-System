export interface ISplitPdfRequest {
  originalFileNameFromUrl: string;
  originalFileName: string;
  selectedPages: number[];
  newSplitPdfFileName: string;
  folderId: string;
  tabId: string;
}

export interface ISplitPdfFormValues {
  newSplitPdfFileName: string;
  folderId: string;
  tabId: string;
}
