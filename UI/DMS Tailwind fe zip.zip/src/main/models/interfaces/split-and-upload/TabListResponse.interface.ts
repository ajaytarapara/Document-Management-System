export interface IFolderTabListResponse {
  id: string;
  tabName: string;
  tabColor: string;
}
