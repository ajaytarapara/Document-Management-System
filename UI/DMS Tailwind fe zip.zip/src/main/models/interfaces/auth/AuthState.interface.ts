import { ROLE_CLAIM_URI } from "@/core/utils";

export interface IAuthState {
  loggedInUser: string;
  userName: string;
  subUsers: ISubUser[];
  currentUser: ISubUser;
  originalUser: ISubUser;
}

export interface DecodedJwtPayload {
  email: string;
  userId: string;
  userName: string;
  exp: number;
  iss?: string;
  aud?: string;
  [ROLE_CLAIM_URI]?: string;
}

export interface IAccountForm {
  firstName: string;
  lastName: string;
  role: string;
  email: string;
  userName: string;
  phoneNumber: string;
  postalCode: string;
  address: string;
  city: string;
  id: number;
  loginType: string;
}

export interface IAccountUser {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  userName: string;
  address: string;
  postalCode: string;
  phoneNumber: string;
  city?: string;
  loginType: string;
}

export interface IChangePassword {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface IForgotPassword {
  userName: string;
}

export interface IVerifyOTP {
  userName: string;
  otp: string;
}

export interface IResetPassword {
  userName: string;
  confirmPassword: string;
  newPassword: string;
}

export interface ISubUser {
  id: number;
  username: string;
}

export interface IImpersonate {
  token: string;
}

export interface ISetupPassword {
  confirmPassword: string;
  newPassword: string;
}
