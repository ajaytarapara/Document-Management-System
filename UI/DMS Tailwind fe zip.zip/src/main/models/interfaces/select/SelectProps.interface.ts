import type { Control, FieldValues, RegisterOptions } from "react-hook-form";
import type { CSSProperties } from "react";

export interface IDropdownValue {
  label: string;
  value: string | number;
}

export interface IRadioButtonOption {
  label: string;
  value: string | number;
}