import { IPaginatedRequest } from "@/core/models";

export interface IUserLoginDetailRequestVM extends IPaginatedRequest {
  date: string;
  userId?: string;
}

export interface IUserLoginDetailResponseVM {
  name: string;
  firstName: string;
  lastName: string;
  email: string;
  loginDate: string;
  logoutDate?: string;
}
