import { IPaginatedRequest } from "@/core/models";

export interface IBatchShareFileRequest extends IPaginatedRequest {
  tabId: string;
}
