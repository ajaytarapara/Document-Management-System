export interface ILoginResponse {
  userId: string;
  email: string;
  username: string;
  fullName: string;
  role: string;
  token: string;
  isFirstTimeLogin: boolean;
}
