export interface IForgotPasswordForm {
  email: string;
}
