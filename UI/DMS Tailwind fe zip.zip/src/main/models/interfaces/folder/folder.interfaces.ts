export interface ShareFolderForm {
  type: string;
  fromEmail: string;
  toEmail: string;
  toName: string;
  subject: string;
  message?: string;
  linkExpiration: number;
  viewOnly: boolean;
  EntityIds?: string[];
}

export interface EditFolderFormValues {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
}

export interface ICreateFolder {
  firstName: string;
  lastName: string;
}
export interface IPaginatedFolderResponse {
  items: FolderDto[];
  totalCount: number;
}
export interface IPermissionResponse {
  items: FolderDto[];
  totalCount: number;
  permissions: Permissions;
}
export interface Permissions {
  privilegeDelete: boolean;
  privilegeDownload: boolean;
  privilegeView: boolean;
  hideLockTabs: boolean;
}
export interface FolderDto {
  id: string;
  folderName: string;
  tabCount: number;
  userId: string;
  firstName: string;
  lastName: string;
  fileNumber: string;
  comment?: string;
  createdAt: string;
  tabs: TabResponse[];
}
export interface FolderListDto {
  id: string;
  folderName: string;
}
export interface TabResponse {
  id: string;
  color: string;
  tabName: string;
  isLock: boolean;
}
export interface UpdateFolderArgs {
  id: string;
  data: EditFolderFormValues;
}
export interface ShareFolderArgs {
  id: string;
  data: ShareFolderForm;
}
export interface VerifyOTPArgs {
  email: string;
  code: string;
}

export interface IEditFolderRequest {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
}

export interface CreateFolderFormValues {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
  comment?: string;
  tabCount?: number;
  templateId?: string;
  tabs: {
    tabName: string;
    color: string;
    isLock: boolean;
  }[];
}
export interface EditFolderFormValues {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
}

export interface ICreateFolder {
  firstName: string;
  lastName: string;
}

export interface IPaginatedFolderResponse {
  items: FolderDto[];
  totalCount: number;
}

export interface IPermissionResponse {
  items: FolderDto[];
  totalCount: number;
  permissions: Permissions;
}

export interface Permissions {
  privilegeDelete: boolean;
  privilegeDownload: boolean;
  privilegeView: boolean;
  hideLockTabs: boolean;
}

export interface FolderDto {
  id: string;
  folderName: string;
  tabCount: number;
  userId: string;
  firstName: string;
  lastName: string;
  fileNumber: string;
  comment?: string;
  createdAt: string;
  tabs: TabResponse[];
}

export interface FolderListDto {
  id: string;
  folderName: string;
}

export interface TabResponse {
  id: string;
  color: string;
  tabName: string;
  isLock: boolean;
}

export interface UpdateFolderArgs {
  id: string;
  data: EditFolderFormValues;
}

export interface ShareFolderArgs {
  id: string;
  data: ShareFolderForm;
}

export interface VerifyOTPArgs {
  email: string;
  code: string;
}

export interface IEditFolderRequest {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
}

export interface CreateFolderFormValues {
  firstName: string;
  folderName: string;
  lastName?: string;
  fileNumber: string;
  comment?: string;
  tabCount?: number;
  templateId?: string;
  tabs: {
    tabName: string;
    color: string;
    isLock: boolean;
  }[];
}

export interface ShareFolderForm {
  type: string;
  fromEmail: string;
  toEmail: string;
  toName: string;
  subject: string;
  message?: string;
  linkExpiration: number;
  viewOnly: boolean;
  EntityIds?: string[];
}
