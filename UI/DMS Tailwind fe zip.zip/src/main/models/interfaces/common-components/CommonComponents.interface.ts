export interface Option {
  label: string;
  value: string | number;
}

export interface MultiSelectOption {
  id: string | number;
  name: string;
}

export interface FormTableValues {
  pageSize: string;
}
