import { PointerEvents } from "@/core/models";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useState, useRef, useEffect } from "react";

interface SelectFieldProps {
  field: {
    id: string;
    value?: string;
    options?: string[];
    placeholder?: string;
  };
  hasError?: boolean;
  onChangeValue?: (id: string, value: string) => void;
  onSelect?: (id: string) => void;
}

export const CustomSelect = ({
  field,
  hasError,
  onChangeValue,
  onSelect,
}: SelectFieldProps) => {
  const selectOptions = field.options ?? ["Option 1", "Option 2"];
  const placeholderText = field.placeholder ?? "Select an option";

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener(PointerEvents.POINTER_DOWN, handleClickOutside);
    return () =>
      document.removeEventListener(
        PointerEvents.POINTER_DOWN,
        handleClickOutside
      );
  }, []);

  /**
   * Handles selecting an option from the dropdown.
   * @param {string} option - The selected option value.
   */
  const handleSelect = (option: string) => {
    if (onChangeValue) onChangeValue(field.id, option);
    setIsOpen(false);
  };

  return (
    <div
      ref={dropdownRef}
      className={`relative w-52 text-sm`}
      onMouseDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      <div
        className={`h-12 px-3 flex items-center justify-between border rounded ${
          hasError ? "border-red-500" : "border-gray-300"
        } bg-[#f4eeff] cursor-pointer`}
        onClick={() => setIsOpen((prev) => !prev)}
        onDoubleClick={(e) => {
          e.stopPropagation();
          onSelect?.(field.id);
        }}
      >
        <span className={`${field.value ? "text-black" : "text-gray-400"}`}>
          {field.value || placeholderText}
        </span>
        {isOpen ? (
          <ChevronUp
            className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400"
            size={20}
          />
        ) : (
          <ChevronDown
            className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none text-gray-400"
            size={20}
          />
        )}
      </div>

      {/* Dropdown */}
      {isOpen && (
        <ul
          className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded shadow max-h-60 overflow-y-auto"
          onMouseDown={(e) => e.stopPropagation()}
        >
          {selectOptions.map((option) => (
            <li
              key={option}
              className="px-3 py-2 hover:bg-[#eae6f7] cursor-pointer"
              onClick={(e) => {
                e.stopPropagation();
                handleSelect(option);
              }}
            >
              {option}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
