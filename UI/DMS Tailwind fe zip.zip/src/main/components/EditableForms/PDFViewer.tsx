// PDFViewer.tsx
"use client";

import React from "react";
import { Viewer, Worker, RenderPageProps } from "@react-pdf-viewer/core";
import "@react-pdf-viewer/core/lib/styles/index.css";
import { zoomPlugin } from "@react-pdf-viewer/zoom";
import "@react-pdf-viewer/zoom/lib/styles/index.css";

import { FieldBase, FieldType } from "./types";
import PageLayer from "./PageLayer";

interface PDFViewerProps {
  pdfData: string | null;
  fields: FieldBase[];
  activeType: FieldType | null;
  addField: (
    pageIndex: number,
    xPct: number,
    yPct: number,
    type: FieldType
  ) => void;
  moveField: (id: string, xPct: number, yPct: number) => void;
  changeFieldValue: (id: string, value: string | boolean) => void;
  resizeField: (id: string, wPct: number, hPct: number) => void;
  selectedFieldId: string | null;
  onSelectField: (id: string | null) => void;
  zoomPluginInstance: ReturnType<typeof zoomPlugin>; // pass zoomPlugin instance from parent
  readonly?: boolean;
}

const PDFViewer: React.FC<PDFViewerProps> = ({
  pdfData,
  fields,
  activeType,
  addField,
  moveField,
  changeFieldValue,
  resizeField,
  selectedFieldId,
  onSelectField,
  zoomPluginInstance,
  readonly,
}) => {
  /**
   * Custom render function for each PDF page.
   * Adds a PageLayer above the PDF canvas to manage interactive fields.
   */
  const renderPage = React.useCallback(
    (props: RenderPageProps) => {
      const { canvasLayer, annotationLayer, textLayer, pageIndex } = props;
      return (
        <div className="relative w-full h-full">
          <div className="w-full h-full">{canvasLayer.children}</div>
          <div className="absolute inset-0">{textLayer.children}</div>
          <div className="absolute inset-0">{annotationLayer.children}</div>

          <PageLayer
            pageIndex={pageIndex}
            fields={fields}
            onAdd={readonly ? undefined : addField}
            onMove={readonly ? undefined : moveField}
            onChangeValue={changeFieldValue}
            activeType={readonly ? null : activeType}
            onResize={readonly ? undefined : resizeField}
            selectedFieldId={readonly ? null : selectedFieldId}
            onSelectField={readonly ? undefined : onSelectField}
            readonly={readonly}
          />
        </div>
      );
    },
    [
      fields,
      activeType,
      addField,
      moveField,
      changeFieldValue,
      resizeField,
      selectedFieldId,
      onSelectField,
      readonly,
    ]
  );

  /**
   * Show placeholder if no PDF is selected.
   */
  if (!pdfData) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        <div className="text-center">
          <div className="text-2xl text-purple-400 mb-2">📄</div>
          <div className="text-[#7e57c2] font-medium">
            Please select a PDF file
          </div>
        </div>
      </div>
    );
  }

  return (
    <Worker workerUrl={String(process.env.NEXT_PUBLIC_WORKER_URL)}>
      <Viewer
        defaultScale={1.5}
        fileUrl={pdfData}
        renderPage={renderPage}
        plugins={[zoomPluginInstance]}
      />
    </Worker>
  );
};

export default PDFViewer;
