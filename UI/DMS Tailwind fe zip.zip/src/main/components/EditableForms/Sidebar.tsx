"use client";

import React from "react";

import { StyledCancelButton } from "../CreateUser/CreateUserForm.styled";
import { Trash2 } from "lucide-react";
import { CommonTextField } from "@/core/components";
import PaletteButton from "./PaletteButton";
import { FieldType, FieldBase } from "./types";
import { ButtonType } from "@/core/models";

interface SidebarProps {
  activeType: FieldType | null;
  setActiveType: (type: FieldType | null) => void;
  fields: FieldBase[];
  clearAll: () => void;
  changeFieldName: (id: string, name: string) => void;
  deleteField: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  activeType,
  setActiveType,
  fields,
  clearAll,
  changeFieldName,
  deleteField,
}) => {
  return (
    <aside className="w-full md:w-[260px] shrink-0 border-r border-purple-200 bg-gradient-to-b from-purple-50 to-white p-4 overflow-y-auto shadow-lg">
      <div className="mb-4 font-semibold text-md text-[#7e57c2] border-b border-purple-200 pb-2">
        Fields (click to place)
      </div>
      <PaletteButton type="text" label="Text Field" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="checkbox" label="Checkbox" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="radio" label="Radio" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="select" label="Select" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="signature" label="Signature" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="highlight" label="Highlighter" activeType={activeType} onSelect={setActiveType} />
      <PaletteButton type="eraser" label="Eraser" activeType={activeType} onSelect={setActiveType} />

      <div className="h-px bg-purple-200 my-4" />
      <div className="mt-6 p-3 bg-white rounded-lg border border-purple-200 shadow-sm">
        <div className="text-sm font-medium text-[#7e57c2] mb-2">Fields ({fields.length})</div>
        <div className="space-y-2 text-xs max-h-[300px] overflow-y-auto">
          {fields.map(f => (
            <div
              key={f.id}
              className="grid grid-cols-[1fr_auto] items-center border border-purple-200 rounded-lg px-3 py-2 bg-purple-50 hover:bg-purple-100 transition-colors gap-2"
            >
              <CommonTextField
                name={`name_${f.id}`}
                className="w-full"
                value={f.name ?? ""}
                onChange={e => changeFieldName(f.id, e.target.value)}
                placeholder="Field name"
              />
              <button
                onClick={() => deleteField(f.id)}
                title="Remove Field"
                type={ButtonType.Button}
                className="text-red-600 p-1 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded"
              >
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>
      </div>
      <div className="flex gap-3 justify-end mt-4">
        <StyledCancelButton
          disabled={!fields.length}
          className="text-[#263238] !w-full sm:!w-auto font !min-w-[100px] !max-w-[150px]"
          onClick={clearAll}
        >
          Delete All Fields
        </StyledCancelButton>
      </div>
      {activeType && (
        <div className="mt-4 p-3 bg-purple-100 border border-purple-300 rounded-lg text-sm text-[#7e57c2]">
          Placing: <b>{activeType}</b> — click on a page to drop. Press Esc to cancel.
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
