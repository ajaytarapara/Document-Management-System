"use client";

import React, { useRef, useState, useEffect, useCallback } from "react";
import { PageLayerProps } from "./types";
import { clamp } from "./utils";
import { FieldType, PointerEvents } from "@/core/models";
import DraggableField from "./DraggableField";

const PageLayer: React.FC<PageLayerProps> = ({
  pageIndex,
  fields,
  onAdd,
  onMove,
  onChangeValue,
  activeType,
  onResize,
  onSelectField,
  readonly,
}) => {
  const ref = useRef<HTMLDivElement | null>(null);
  const [rect, setRect] = useState<DOMRect | null>(null);

  /**
   * Measure the container's bounding rectangle
   * and store it in state for field positioning.
   */
  const measure = useCallback(() => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) setRect(r);
  }, []);

  /**
   * Run measurement on mount and whenever the
   * container is resized (via ResizeObserver).
   */
  useEffect(() => {
    measure();
    const ro = new ResizeObserver(measure);
    if (ref.current) ro.observe(ref.current);
    return () => ro.disconnect();
  }, [measure]);

  /**
   * Extra delayed measure (covers cases where the
   * page is not fully ready on first render).
   */
  useEffect(() => {
    const t = setTimeout(measure, 100);
    return () => clearTimeout(t);
  }, [measure]);

  /**
   * Recalculate position when scrolling,
   * since bounding rect can shift.
   */
  useEffect(() => {
    const onScroll = () => measure();
    window.addEventListener(PointerEvents.SCROLL, onScroll, true);
    return () => window.removeEventListener(PointerEvents.SCROLL, onScroll, true);
  }, [measure]);

  /**
   * Handle clicks inside the page:
   * - If a field type is active, place a new field
   *   at the clicked position (with default size).
   * - If no type is active, clicking empty space
   *   clears the current selection.
   */
  const onClick = (e: React.MouseEvent) => {
    if (activeType) {
      // Ensure click is only on the empty page area
      if (e.target !== e.currentTarget) return;

      const r = ref.current?.getBoundingClientRect();
      if (!r) return;

      // Convert click position to percentage
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      const xPct = clamp((x / r.width) * 100, 0, 100);
      const yPct = clamp((y / r.height) * 100, 0, 100);

      // Default sizes by field type
      const defaults =
        activeType === FieldType.Text || activeType === FieldType.Select
          ? { w: 18, h: 3.5 }
          : activeType === FieldType.Highlight
            ? { w: 20, h: 3 }
            : activeType === FieldType.Signature
              ? { w: 25, h: 6 }
              : { w: 0, h: 0 };

      // Adjust so field is centered at click
      const adjX = clamp(xPct - defaults.w / 2, 0, 100 - defaults.w);
      const adjY = clamp(yPct - defaults.h / 2, 0, 100 - defaults.h);

      if (onAdd) onAdd(pageIndex, adjX, adjY, activeType);
      return;
    }

    // If no active type, clicking empty page clears selection
    if (e.target === e.currentTarget) {
      if (onSelectField) onSelectField(null);
    }
  };

  return (
    <div ref={ref} onClick={onClick} className="absolute inset-0 z-[60] pointer-events-auto">
      {rect &&
        fields
          .filter(f => f.pageIndex === pageIndex)
          .map(f => (
            <DraggableField
              key={f.id}
              field={f}
              pageRect={rect}
              onMove={onMove}
              onChangeValue={onChangeValue}
              onResize={onResize}
              onSelect={onSelectField}
              readonly={readonly}
            />
          ))}
    </div>
  );
};

export default PageLayer;
