"use client";

import React from "react";
import Sidebar from "./Sidebar";
import PDFViewer from "./PDFViewer";
import FieldPropertiesDrawer from "./FieldPropertiesDrawer";
import RightDrawer from "./RightDrawer";
import { Save, Share2 } from "lucide-react";
import { useEditableForm } from "./EditableForms.hook";
import { ShareDmsFileModal } from "../DmsForms/ShareDmsFormsModal";
import { CommonButton } from "@/core/components";
import { shareDmsForm } from "@/main/store";
import { ButtonType } from "@/core/models";

export default function EditableForms() {
  const {
    fields,
    fileName,
    activeType,
    fileUrl,
    setActiveType,
    addField,
    moveField,
    resizeField,
    deleteField,
    clearAll,
    changeFieldValue,
    changeFieldName,
    updateField,
    handleSave,
    selectedFieldId,
    setSelectedFieldId,
    selectedField,
    zoomPluginInstance,
    ZoomInButton,
    ZoomOutButton,
    ZoomPopover,
    handleOpenShareModal,
    openShareModal,
    closeShareModal,
    shareFormId,
    dispatch,
  } = useEditableForm();
  return (
    <div>
      <div className="bg-gray-50 p-4">
        <p className="font-semibold text-lg text-[#00092a]">
          File name : {fileName}
        </p>
      </div>
      <div className="bg-white flex flex-wrap md:flex-nowrap justify-center md:justify-between items-center gap-2 py-2 border-b border-t border-[#7E57C2]">
        <div className="flex items-center gap-2 px-2 py-1 flex-shrink-0">
          <ZoomOutButton />
          <ZoomPopover />
          <ZoomInButton />
        </div>

        <div className="flex justify-center md:justify-end gap-2 sm:gap-3 items-center px-2 sm:pr-3 w-full md:w-auto">
          <CommonButton
            type={ButtonType.Button}
            variant="contained"
            title="Share DMS Form"
            onClick={() => handleOpenShareModal(fileName)}
            className="!max-h-[36px] h-full !text-xs sm:!text-sm md:!text-[16px] font-bold px-2 sm:px-4 md:px-6"
          >
            <span className="flex items-center gap-2">
              <Share2 size={18} />
              <span className="hidden sm:inline">Share DMS Form</span>
            </span>
          </CommonButton>

          <CommonButton
            className="!max-h-[36px] h-full !text-xs sm:!text-sm md:!text-[16px] font-bold px-2 sm:px-4 md:px-6"
            variant="contained"
            title="Save DMS Form"
            onClick={handleSave}
          >
            <span className="flex items-center gap-2">
              <Save size={18} />
              <span className="hidden sm:inline">Save DMS Form</span>
            </span>
          </CommonButton>
        </div>
      </div>

      <div className="flex h-full bg-gray-50 flex-col md:flex-row">
        <Sidebar
          activeType={activeType}
          setActiveType={setActiveType}
          fields={fields}
          clearAll={clearAll}
          changeFieldName={changeFieldName}
          deleteField={deleteField}
        />

        <main className="flex-1 overflow-y-auto">
          <div className="min-h-[calc(100dvh-56px)] md:min-h-full bg-white py-4 px-2">
            <PDFViewer
              pdfData={fileUrl}
              fields={fields}
              activeType={activeType}
              addField={addField}
              moveField={moveField}
              changeFieldValue={changeFieldValue}
              resizeField={resizeField}
              selectedFieldId={selectedFieldId}
              onSelectField={setSelectedFieldId}
              zoomPluginInstance={zoomPluginInstance}
              readonly={false}
            />
          </div>
        </main>

        <RightDrawer
          open={!!selectedField}
          onClose={() => setSelectedFieldId(null)}
          title="Field Properties"
        >
          {selectedField && (
            <FieldPropertiesDrawer
              field={selectedField}
              onUpdate={(patch) => updateField(selectedField.id, patch)}
              onUpdateFields={(updater) => {
                const updatedFields = updater(fields);
                updatedFields.forEach((f) => updateField(f.id, f));
              }}
              onRemoveOption={(idx) => {
                const opts = [...(selectedField.options ?? [])];
                opts.splice(idx, 1);
                updateField(selectedField.id, { options: opts });
              }}
              onAddOption={() => {
                const opts = [...(selectedField.options ?? [])];
                opts.push(`Option ${opts.length + 1}`);
                updateField(selectedField.id, { options: opts });
              }}
              onChangeOption={(idx, val) => {
                const opts = [...(selectedField.options ?? [])];
                opts[idx] = val;
                updateField(selectedField.id, { options: opts });
              }}
            />
          )}
        </RightDrawer>

        <ShareDmsFileModal
          open={openShareModal}
          folderId={shareFormId}
          onClose={closeShareModal}
          onShare={async (formId, formData) => {
            return await dispatch(
              shareDmsForm({
                formIds: [formId],
                data: formData,
              })
            ).unwrap();
          }}
          fileName={fileName}
        />
      </div>
    </div>
  );
}
