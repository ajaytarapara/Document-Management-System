"use client";

import { Constant } from "@/core/constants/Constant";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import {
  FieldType as FieldTypeEnum,
  IAPIResponse,
  SaveEditedFormRequest,
  IDmsForm,
  KeyEvents,
  BooleanValue,
} from "@/core/models";
import {
  useNavigate,
  decryptObject,
  encryptId,
  handleThunkWithDecrypt,
} from "@/core/utils";
import { ILoginResponse } from "@/main/models";
import {
  AppDispatch,
  useSelectorAuthState,
  saveEditedForm,
  getDmsFormById,
  getUserDmsFormById,
} from "@/main/store";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useDispatch } from "react-redux";
import { v4 as uuidv4 } from "uuid";
import { FieldBase, FieldType } from "./types";
import { validateField, blobToBase64, mapResultToFileData } from "./utils";
import { zoomPlugin } from "@react-pdf-viewer/zoom";
import "@react-pdf-viewer/zoom/lib/styles/index.css";

/**
 * Custom hook to manage Editable DMS Forms.
 * Handles PDF loading, dynamic field CRUD, validation, and save functionality.
 */
export const useEditableForm = () => {
  const [fields, setFields] = useState<FieldBase[]>([]);
  const [activeType, setActiveType] = useState<FieldType | null>(null);
  const [selectedFieldId, setSelectedFieldId] = useState<string | null>(null);
  const [fileUrl, setFileUrl] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [shareFormId, setShareFormId] = useState<string | null>(null);
  const [openShareModal, setOpenShareModal] = useState<boolean>(false);

  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const params = useParams();

  const id = params.id;

  const { loggedInUser } = useSelectorAuthState();

  /**
   * Decrypts logged-in user data, extracts selected user ID,
   * and initializes PDF zoom plugin with controls.
   */
  const decryptedLoggedUser = loggedInUser
    ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser)
    : null;

  const selectedUserId = decryptedLoggedUser?.data?.userId;

  const zoomPluginInstance = zoomPlugin();
  const { ZoomInButton, ZoomOutButton, ZoomPopover } = zoomPluginInstance;

  /**
   * Adds a new form field to the PDF document.
   * @param pageIndex - The page index where the field is placed.
   * @param xPct - The X position as a percentage of page width.
   * @param yPct - The Y position as a percentage of page height.
   * @param type - The type of field (e.g., text, select, signature).
   */
  const addField = useCallback(
    (pageIndex: number, xPct: number, yPct: number, type: FieldType) => {
      const id = uuidv4();
      setFields((prev) => [
        ...prev,
        {
          id,
          type,
          pageIndex,
          xPct,
          yPct,
          wPct:
            type === FieldTypeEnum.Text || type === FieldTypeEnum.Select
              ? 18
              : type === FieldTypeEnum.Highlight
              ? 20
              : type === FieldTypeEnum.Signature
              ? 25
              : undefined,
          hPct:
            type === FieldTypeEnum.Text || type === FieldTypeEnum.Select
              ? 3.5
              : type === FieldTypeEnum.Highlight
              ? 3
              : type === FieldTypeEnum.Signature
              ? 6
              : undefined,
          name: `${type}_${Date.now()}`,
          label:
            type === FieldTypeEnum.Text
              ? "Text"
              : type === FieldTypeEnum.Select
              ? "Select"
              : type[0].toUpperCase() + type.slice(1),
          placeholder:
            type === FieldTypeEnum.Text
              ? "Enter text..."
              : type === FieldTypeEnum.Select
              ? "Select an option"
              : undefined,
          options:
            type === FieldTypeEnum.Select
              ? ["Option 1", "Option 2"]
              : undefined,
        },
      ]);
      setSelectedFieldId(id);
      setActiveType(null);
    },
    []
  );

  /**
   * Updates the position of an existing field.
   * @param id - The ID of the field.
   * @param xPct - New X position (percentage).
   * @param yPct - New Y position (percentage).
   */
  const moveField = useCallback((id: string, xPct: number, yPct: number) => {
    setFields((prev) =>
      prev.map((f) => (f.id === id ? { ...f, xPct, yPct } : f))
    );
  }, []);

  /**
   * Resizes an existing field.
   * @param id - The ID of the field.
   * @param wPct - New width percentage.
   * @param hPct - New height percentage.
   */
  const resizeField = useCallback((id: string, wPct: number, hPct: number) => {
    setFields((prev) =>
      prev.map((f) => (f.id === id ? { ...f, wPct, hPct } : f))
    );
  }, []);

  /**
   * Deletes a field from the form by its ID.
   * @param id - The field ID to delete.
   */
  const deleteField = useCallback((id: string) => {
    setFields((prev) => prev.filter((f) => f.id !== id));
    setSelectedFieldId((prev) => (prev === id ? null : prev));
  }, []);

  /**
   * Clears all fields from the form.
   */
  const clearAll = useCallback(() => {
    setFields([]);
    setSelectedFieldId(null);
  }, []);

  /**
   * Updates the value of a field and validates it.
   * @param id - The field ID.
   * @param value - The new field value.
   */
  const changeFieldValue = (id: string, value: string | boolean) => {
    setFields((prev) =>
      prev.map((f) => {
        // For radio buttons, check if they belong to the same group
        const clickedField = prev.find((field) => field.id === id);

        if (
          clickedField?.type === FieldTypeEnum.Radio &&
          clickedField.groupId
        ) {
          // Deselect all radios in the same group, select only the clicked one
          if (f.groupId === clickedField.groupId) {
            return {
              ...f,
              value: f.id === id ? BooleanValue.TRUE : BooleanValue.FALSE,
            };
          }
          return f;
        }

        // Normal field or radio without group
        if (f.id === id) return { ...f, value };
        return f;
      })
    );
  };
  /**
   * Updates the name (identifier) of a field.
   * @param id - The field ID.
   * @param name - The new field name.
   */
  const changeFieldName = useCallback((id: string, name: string) => {
    setFields((prev) => prev.map((f) => (f.id === id ? { ...f, name } : f)));
  }, []);

  /**
   * Applies a patch update to a field (partial updates).
   * Automatically revalidates the field after patching.
   * @param id - The field ID.
   * @param patch - The partial update to apply.
   */
  const updateField = useCallback((id: string, patch: Partial<FieldBase>) => {
    setFields((prev) =>
      prev.map((f) => {
        if (f.id !== id) return f;
        const next = { ...f, ...patch };
        return { ...next, error: validateField(next) };
      })
    );
  }, []);

  /**
   * Validates all fields and saves the form to the backend.
   * If validation fails, prevents save and shows a toast error.
   */
  const handleSave = useCallback(async () => {
    let base64File = "";
    if (fileUrl) {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      base64File = await blobToBase64(blob);
    }
    const payload: SaveEditedFormRequest = {
      formId: String(id),
      userId: encryptId(Number(selectedUserId)),
      file: base64File,
      fields: fields.map(({ ...rest }) => rest),
      userRole: decryptedLoggedUser?.data?.role,
      token: decryptedLoggedUser?.data?.token,
    };

    const result = await dispatch(saveEditedForm(payload));

    if (saveEditedForm.fulfilled.match(result)) {
      navigate(
        decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER
          ? ROUTES.OFFICE_USER.DMS_FORMS
          : ROUTES.USER.DMS_FORMS
      );
    }
  }, [
    fields,
    fileUrl,
    dispatch,
    id,
    navigate,
    selectedUserId,
    decryptedLoggedUser?.data?.token,
    decryptedLoggedUser?.data?.role,
  ]);

  /**
   * Fetches the PDF data and associated form fields from the backend.
   * Converts base64 to Uint8Array for PDF rendering.
   */
  const getPdfData = async () => {
    const result = await handleThunkWithDecrypt<
      IDmsForm,
      { formId: string; userId: string }
    >(
      dispatch,
      decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER
        ? getDmsFormById
        : getUserDmsFormById,
      {
        formId: String(id),
        userId: encryptId(Number(selectedUserId)),
      }
    );

    const mappedData = mapResultToFileData(
      result,
      decryptedLoggedUser?.data?.role
    );
    if (mappedData) {
      setFileUrl(mappedData.fileUrl);
      setFileName(mappedData.fileName);
      setFields(mappedData.fields);
    }
  };

  const validated = fields.map((f) => ({ ...f, error: validateField(f) }));

  /** Currently selected field (if any) */
  const selectedField = useMemo(
    () => fields.find((f) => f.id === selectedFieldId) ?? null,
    [fields, selectedFieldId]
  );

  /**
   * Opens the Share Modal dialog with file name and ID.
   * If multiple rows are selected, aggregates their names for display.
   *
   * @param fileName - The name of the selected file.
   * @param id - Optional single file ID.
   */
  const handleOpenShareModal = (fileName: string) => {
    if (id) {
      setShareFormId(id as string);
    }
    setFileName(fileName);
    setOpenShareModal(true);
  };

  /**
   * Closes the Share Modal and clears selected state.
   */
  const closeShareModal = () => {
    setShareFormId(null);
    setOpenShareModal(false);
  };

  /**
   * Fetches PDF data on mount and closes the active modal/type when Escape is pressed.
   */
  useEffect(() => {
    getPdfData();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === KeyEvents.ESCAPE) setActiveType(null);
    };
    window.addEventListener(KeyEvents.KEYDOWN, onKey);
    return () => window.removeEventListener(KeyEvents.KEYDOWN, onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    id,
    fields,
    fileName,
    activeType,
    fileUrl,
    setActiveType,
    addField,
    moveField,
    resizeField,
    deleteField,
    clearAll,
    changeFieldValue,
    changeFieldName,
    updateField,
    handleSave,
    validated,
    selectedFieldId,
    setSelectedFieldId,
    selectedField,
    zoomPluginInstance,
    ZoomInButton,
    ZoomOutButton,
    ZoomPopover,
    handleOpenShareModal,
    closeShareModal,
    openShareModal,
    shareFormId,
    dispatch,
  };
};
