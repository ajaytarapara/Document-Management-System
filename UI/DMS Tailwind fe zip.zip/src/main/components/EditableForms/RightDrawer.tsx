"use client";

import { CommonDrawer } from "@/core/components";
import React from "react";

interface RightDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
}

const RightDrawer: React.FC<RightDrawerProps> = ({
  open,
  onClose,
  title = "Details",
  children,
}) => {
  return (
    <CommonDrawer open={open} onClose={onClose} title={title} lgSize="30%">
      {children}
    </CommonDrawer>
  );
};

export default RightDrawer;
