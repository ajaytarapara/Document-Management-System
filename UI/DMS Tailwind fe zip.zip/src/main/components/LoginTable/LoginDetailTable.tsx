"use client";

import { CustomPagination } from "@/core/components";
import { IUserLoginDetailResponseVM } from "@/main/models";
import moment from "moment-timezone";

type Props = {
  data: IUserLoginDetailResponseVM[];
  currentPage: number;
  pageSize: number;
  totalCount: number;
  onPageChange: (page: number) => void;
};

export const LoginDetailTable = ({
  data,
  currentPage,
  pageSize,
  totalCount,
  onPageChange,
}: Props) => {
  const totalPages = Math.ceil(totalCount / pageSize);
  return (
    <>
      <div className="shadow-sm overflow-x-auto">
        <table className="min-w-full table-auto border-collapse">
          <thead className="bg-[#e1dcef]">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">
                Username
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">
                Email
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">
                Login Time
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tr-md">
                Logout Time
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.map((item, index) => (
              <tr key={index} className="hover:bg-gray-50 transition">
                <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                  {item.name}
                </td>
                <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                  {item.email}
                </td>
                <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                  {moment
                    .utc(item.loginDate)
                    .tz("Asia/Kolkata")
                    .format("hh:mm:ss A")}
                </td>
                <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                  {item.logoutDate
                    ? moment
                        .utc(item.logoutDate)
                        .tz("Asia/Kolkata")
                        .format("hh:mm:ss A")
                    : " - "}
                </td>
              </tr>
            ))}
            {data.length === 0 && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-6 text-center text-sm text-gray-500"
                >
                  No login records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <div className="mt-4 flex justify-end">
          <CustomPagination
            count={totalPages}
            page={currentPage}
            onChange={onPageChange}
          />
        </div>
      )}
    </>
  );
};
