"use client";

import { IUserDetail } from "@/main/models";
import { Edit, Trash2, User2 } from "lucide-react";
import { Constant } from "@/core/constants/Constant";

interface UserCardProps {
  user: IUserDetail;
  role?: string;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export const UserCard = ({ user, role, onEdit, onDelete }: UserCardProps) => {
  return (
    <div className="border border-[#b7a3e1] rounded-xl shadow-sm p-4 hover:shadow-md transition bg-[#f7f2ff]">
      <div className="flex items-center gap-3 mb-3">
        <div className="border border-[#5e35b1] rounded-[50%] p-2">
          <User2 className="h-6 w-6 text-[#5e35b1]" />
        </div>
        <div>
          <h3 className="font-semibold text-lg text-[#00092A] truncate max-w-[174px] sm:max-w-[250px]">
            {user.name}
          </h3>
          <p className="text-sm text-gray-500 truncate max-w-[174px] sm:max-w-[250px]">
            {user.email}
          </p>
        </div>
      </div>

      <div className="text-sm text-gray-700 space-y-1">
        <div className="truncate max-w-[174px] sm:max-w-[250px]">
          <p>
            <b>Username:</b> {user.userName}
          </p>
        </div>
        <p className="truncate max-w-[220px]">
          <b>Contact No.:</b> {user.phoneNumber ?? "-"}
        </p>

        {role === Constant.COMMON.OFFICE_USER && (
          <>
            <p>
              <b>Has Privilege Delete:</b> {user.privilegeDelete ? "Yes" : "No"}
            </p>
            <p>
              <b>Has Privilege Download:</b>{" "}
              {user.privilegeDownload ? "Yes" : "No"}
            </p>
          </>
        )}

        <p>
          <b>Status:</b>{" "}
          <span
            className={`px-2 py-1 rounded-md text-xs font-semibold ${
              user.isActive
                ? "bg-green-100 text-green-700 border border-green-400"
                : "bg-red-100 text-red-700 border border-red-400"
            }`}
          >
            {user.isActive ? "Active" : "Inactive"}
          </span>
        </p>
      </div>

      <div className="flex gap-2 mt-4">
        <button
          onClick={() => onEdit(user.id)}
          className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
        >
          <Edit size={18} />
        </button>
        <button
          onClick={() => onDelete(user.id)}
          className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
};
