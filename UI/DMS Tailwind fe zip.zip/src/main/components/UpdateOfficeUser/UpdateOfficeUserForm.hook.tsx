import { useForm } from "react-hook-form";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { IAPIResponse, LoginTypeEnum } from "@/core/models";
import { decryptObject, handleThunkWithDecrypt } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import { IUpdateUserForm, OfficeUser, IUsersResponse } from "@/main/models";
import { getAllOfficeUsers, getUserById, updateUser } from "@/main/store";
/**
 * Custom hook to manage the update user form logic.
 * Handles fetching user data, managing form state, and submitting updated user info.
 *
 * @returns Object containing form handlers, user data, office options, and navigation utilities.
 */
interface UseUpdateUserFormProps {
  userId: string;
  onClose: () => void;
  setIsSaveClick: Dispatch<SetStateAction<boolean>>;
}

export const useUpdateOfficeUserForm = ({
  userId,
  setIsSaveClick,
  onClose,
}: UseUpdateUserFormProps) => {
  const dispatch = useAppDispatch();

  const [user, setUser] = useState<IUpdateUserForm | null>(null);
  const [officeUsers, setOfficeUsers] = useState<OfficeUser[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    control,
  } = useForm<IUpdateUserForm>({
    defaultValues: {
      userName: "",
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      address: "",
      city: "",
      assignedOffices: "",
      postalCode: 0,
      maxTabLimit: 1,
      isActive: false,
    },
  });

  const loginType = watch("loginType");

  /**
   * Options list derived from fetched office users for dropdown/select input.
   */
  const officeUserOptions = [
    ...officeUsers.map((user) => ({
      id: user.id,
      name: user.userName,
    })),
  ];

  /**
   * Fetches all office users from the server and updates state.
   */
  const getUsersData = async () => {
    const decryptedResponse = await handleThunkWithDecrypt(
      dispatch,
      getAllOfficeUsers,
      null
    );
    const items = decryptedResponse?.data ?? [];
    setOfficeUsers(items as OfficeUser[]);
  };

  /**
   * Fetches a specific user's data by ID and sets it in the form.
   *
   * @param userId - The ID of the user to fetch.
   */
  const fetchUserData = async (userId: string) => {
    const decryptedResponse = await handleThunkWithDecrypt<
      IAPIResponse<IUpdateUserForm>,
      string
    >(dispatch, getUserById, userId);

    if (decryptedResponse?.data) {
      const userData = decryptedResponse.data as unknown as IUpdateUserForm;
      setUser(userData);
      reset(userData);
    }
  };

  /**
   * Handles form submission for updating a user.
   *
   * @param data - Form values containing updated user information.
   */
  const onSubmit = async (data: IUpdateUserForm) => {
    const result = await dispatch(
      updateUser({
        id: userId as string,
        address: data.address,
        city: data.city,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        phoneNumber: data.phoneNumber,
        userName: data.userName,
        postalCode: Number(data.postalCode),
        isActive: data.isActive,
        assignedOffices: data.assignedOffices ?? "",
        privilegeView: data.privilegeView ?? false,
        privilegeDownload: data.privilegeDownload ?? false,
        privilegeDelete: data.privilegeDelete ?? false,
        hideLockTabs: data.hideLockTabs ?? false,
        maxTabLimit: data.maxTabLimit ?? 1,
        loginType: data.loginType ?? LoginTypeEnum.USERNAME,
      })
    );
    if (updateUser.fulfilled.match(result)) {
      const encryptedString = result.payload?.data;
      const decrypted: IAPIResponse<IUsersResponse> = decryptObject<
        IAPIResponse<IUsersResponse>
      >(encryptedString as unknown as string);
      if (decrypted?.data) {
        setIsSaveClick(true);
        onClose();
      }
    }
  };

  /**
   * Effect to initialize user data on component mount or when `userId` changes.
   * Always fetches the list of users.
   * If a `userId` is available, also fetches the details of that specific user.
   */
  useEffect(() => {
    const init = async () => {
      await getUsersData();
      if (userId) {
        await fetchUserData(userId as string);
      }
    };
    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  /**
   * Effect to reset the form with the fetched user data.
   * Runs when either `officeUsers` list is populated or `user` data changes.
   * Ensures the form is pre-filled once both user details and office users are ready.
   */
  useEffect(() => {
    if (user && officeUsers.length > 0) {
      reset(user);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [officeUsers, user]);

  return {
    user,
    errors,
    control,
    officeUserOptions,
    loginType,
    handleSubmit,
    onSubmit,
    register,
  };
};
