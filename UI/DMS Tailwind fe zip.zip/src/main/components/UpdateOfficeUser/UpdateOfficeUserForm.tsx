"use client";

import { Control, FieldValues } from "react-hook-form";

import {
  CommonTextField,
  CommonCheckbox,
  CommonMultiSelectAutocomplete,
  CommonButton,
  CommonSelect,
} from "@/core/components";
import { Constant, loginTypeOptions } from "@/core/constants/Constant";
import { ButtonType, LoginTypeEnum } from "@/core/models";
import { getRequiredMessage } from "@/core/utils";
import { IUpdateUserForm } from "@/main/models";
import { StyledCancelButton } from "./UpdateOfficeUserForm.styled";
import { useUpdateOfficeUserForm } from "./UpdateOfficeUserForm.hook";
import { Dispatch, SetStateAction } from "react";

interface UpdateOfficeUserFormProps {
  userId: string;
  onClose: () => void;
  setIsSaveClick: Dispatch<SetStateAction<boolean>>;
}

export const UpdateOfficeUserForm: React.FC<UpdateOfficeUserFormProps> = ({
  userId,
  onClose,
  setIsSaveClick,
}) => {
  const {
    user,
    errors,
    control,
    officeUserOptions,
    loginType,
    handleSubmit,
    onSubmit,
    register,
  } = useUpdateOfficeUserForm({ userId, setIsSaveClick, onClose });

  if (!user) return null;

  return (
    <div>
      <div className="py-2 px-4 border-b border-[#5e35b1]">
        <h4 className="text-[#727272] font-normal text-xs sm:text-sm">
          {Constant.MESSAGE.INSTRUCTION_FOR_UPDATE_USER}
        </h4>
      </div>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 grid gap-4 grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
        noValidate
      >
        <CommonTextField<IUpdateUserForm>
          name="userName"
          placeholder="Username"
          label="Username"
          disabled
          register={register}
          validation={{
            required: getRequiredMessage("Username"),
            pattern: {
              value: Constant.REGEX.USERNAME_REGEX,
              message: Constant.MESSAGE.INVALID_USERNAME,
            },
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="firstName"
          placeholder="First Name"
          label="First Name"
          required
          register={register}
          validation={{
            required: getRequiredMessage("First Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="lastName"
          placeholder="Last Name"
          label="Last Name"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Last Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="email"
          placeholder="Email"
          label="Email"
          required
          register={register}
          disabled={
            loginType == LoginTypeEnum.SSO || loginType == LoginTypeEnum.BOTH
          }
          validation={{
            required: getRequiredMessage("Email"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.EMAIL_REGEX,
              message: Constant.MESSAGE.INVALID_EMAIL,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="phoneNumber"
          placeholder="Phone Number"
          label="Phone Number"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Phone Number"),
            pattern: {
              value: Constant.REGEX.PHONE_REGEX,
              message: Constant.MESSAGE.INVALID_PHONE,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="address"
          placeholder="Address"
          label="Address"
          register={register}
          validation={{
            maxLength: {
              value: 200,
              message: Constant.MESSAGE.ADDRESS_MAX_LIMIT,
            },
          }}
        />

        <CommonTextField<IUpdateUserForm>
          name="city"
          placeholder="City"
          label="City"
          register={register}
          validation={{
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
        />

        <CommonTextField<IUpdateUserForm>
          name="postalCode"
          placeholder="Postal Code"
          label="Postal Code"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Postal Code"),
            pattern: {
              value: Constant.REGEX.POSTAL_CODE_REGEX,
              message: Constant.MESSAGE.INVALID_POSTAL_CODE,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="maxTabLimit"
          placeholder="Maximum Tabs Limit"
          label="Maximum Tabs Limit"
          type="number"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Max Tab Limit"),
            max: { value: 12, message: Constant.COMMON.MAX_TAB_LIMIT },
            min: { value: 1, message: Constant.COMMON.MIN_TAB_LIMIT },
          }}
          errors={errors}
        />

        <CommonSelect
          name="loginType"
          label="Login Type"
          required
          placeholder="Select login type"
          errors={errors}
          fullWidth
          validations={{ required: Constant.MESSAGE.LOGIN_TYPE_REQUIRED }}
          control={control as unknown as Control<FieldValues>}
          options={loginTypeOptions}
        />

        <div className="col-span-1">
          <label className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary dark:text-gray-200">
            Is Active
          </label>
          <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
            <CommonCheckbox<IUpdateUserForm>
              name="isActive"
              label="Is Active"
              control={control}
            />
          </div>
        </div>

        <CommonMultiSelectAutocomplete
          name="assignedOffices"
          control={control}
          label="Assign Offices"
          options={officeUserOptions}
          placeholder="Select Office"
          errors={errors}
        />

        <div className="col-span-full flex flex-col sm:flex-row justify-end gap-2 mt-6">
          <StyledCancelButton
            onClick={onClose}
            className="text-[#263238] w-full sm:w-auto"
          >
            {Constant.COMMON.CANCEL}
          </StyledCancelButton>

          <CommonButton type={ButtonType.Submit} variant="contained" className="w-full sm:w-auto">
            {Constant.COMMON.SAVE}
          </CommonButton>
        </div>
      </form>
    </div>
  );
};
