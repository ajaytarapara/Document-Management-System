"use client";

import React from "react";
import { X } from "lucide-react";
import { Viewer, Worker } from "@react-pdf-viewer/core";
import { defaultLayoutPlugin } from "@react-pdf-viewer/default-layout";

import "@react-pdf-viewer/core/lib/styles/index.css";
import "@react-pdf-viewer/default-layout/lib/styles/index.css";

interface PdfPreviewProps {
  open: boolean;
  onClose: () => void;
  fileUrl: string;
  fileName: string;
}

export const PdfPreview: React.FC<PdfPreviewProps> = ({
  open,
  onClose,
  fileUrl,
  fileName,
}) => {
  const defaultLayoutPluginInstance = defaultLayoutPlugin();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative z-10 w-full max-w-6xl bg-white rounded-md shadow-lg flex flex-col mx-5">
        <div className="flex justify-between items-center pt-[10px] pr-[10px] pb-[10px] pl-[16px] mb-[24px] border-b border-[#9e9e9e]">
          <span className="font-semibold">{fileName}</span>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-200 transition"
          >
            <X className="h-5 w-5 text-gray-600" />
          </button>
        </div>
        <div
          style={{
            height: "80vh",
            position: "relative",
            padding: "0px 20px 24px",
          }}
        >
          {fileUrl && (
            <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
              <Viewer
                fileUrl={fileUrl}
                plugins={[defaultLayoutPluginInstance]}
              />
            </Worker>
          )}
        </div>
      </div>
    </div>
  );
};
