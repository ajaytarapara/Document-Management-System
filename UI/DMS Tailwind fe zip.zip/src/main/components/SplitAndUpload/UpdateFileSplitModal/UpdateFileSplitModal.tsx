import React from "react";
import { IFileUploadResponseForSplitVM } from "@/main/models";
import { useFileForSplitUpdateForm } from "./UpdateFileSplit.hook";
import { CommonDrawer, CommonTextField } from "@/core/components";
import { Constant } from "@/core/constants/Constant";

interface UploadFileSplitDrawerProps {
  open: boolean;
  onClose: () => void;
  fileForEdit: IFileUploadResponseForSplitVM | null;
  handleSuccess: () => void;
}

export const UploadFileSplitDrawer: React.FC<UploadFileSplitDrawerProps> = ({
  open,
  onClose,
  fileForEdit,
  handleSuccess,
}) => {
  const { register, errors, handleSubmit, onSubmit } =
    useFileForSplitUpdateForm(fileForEdit, onClose, handleSuccess);
  return (
    <CommonDrawer
      open={open}
      onClose={onClose}
      title="Edit file split"
      lgSize="40%"
    >
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              File Name
            </span>
            <CommonTextField
              name="name"
              register={register}
              validation={{ required: Constant.MESSAGE.FILE_NAME_REQ }}
              errors={errors}
              className="h-10"
            />
          </div>
        </div>
        <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-1 mt-4">
          <button
            onClick={onClose}
            type="button"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
          >
            Close
          </button>
          <button
            type="submit"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
          >
            Save
          </button>
        </div>
      </form>
    </CommonDrawer>
  );
};
