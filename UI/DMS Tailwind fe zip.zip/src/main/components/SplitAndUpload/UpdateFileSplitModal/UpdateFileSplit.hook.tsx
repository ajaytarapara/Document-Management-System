import { useEffect } from "react";
import { useForm } from "react-hook-form";
import {
  IFileUploadResponseForSplitVM,
  IUpdateFileNameForSplitForm,
  IUpdateFileNameForSplitRequest,
} from "@/main/models";
import { useAppDispatch } from "@/main/hooks";
import { updateUploadedFileForSplit } from "@/main/store";

export const useFileForSplitUpdateForm = (
  fileForEdit: IFileUploadResponseForSplitVM | null,
  onClose: () => void,
  handleSuccess: () => void
) => {
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<IUpdateFileNameForSplitForm>({
    defaultValues: {
      name: fileForEdit?.name || "",
    },
  });

  /**
   * Effect that resets the form values when a file is selected for editing.
   *
   * - If `fileForEdit` is set, it pre-fills the form with the file’s current name.
   */
  useEffect(() => {
    if (fileForEdit) {
      reset({ name: fileForEdit.name });
    }
  }, [fileForEdit, reset]);

  /**
   * Handles form submission for updating an uploaded file’s name.
   *
   * - Validates that a file is selected for editing.
   * - Constructs the update request payload.
   * - Dispatches the `updateUploadedFileForSplit` thunk to update the file name.
   * - Closes the edit modal on successful update.
   *
   * @param data - The form data containing the updated file name.
   */
  const onSubmit = async (data: IUpdateFileNameForSplitForm) => {
    if (!fileForEdit?.id) return;
    const request: IUpdateFileNameForSplitRequest = {
      id: fileForEdit.id,
      name: data.name,
    };
    await dispatch(updateUploadedFileForSplit(request));
    handleSuccess();
    onClose();
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
  };
};
