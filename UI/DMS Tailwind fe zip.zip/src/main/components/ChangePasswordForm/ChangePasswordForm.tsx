import { CommonButton, CommonTextField } from "@/core/components";
import { UseChangePasswordForm } from "./ChangePasswordForm.hook";
import { getRequiredMessage } from "@/core/utils";
import { Constant } from "@/core/constants/Constant";
import { Eye, EyeOff } from "lucide-react";

export const ChangePassForm = () => {
  const {
    handleSubmit,
    onSubmit,
    register,
    errors,
    isShowOldPass,
    setIsShowOldPass,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  } = UseChangePasswordForm();

  return (
    <div className="w-full">
      <h1 className="text-xl sm:text-2xl md:text-3xl font-semibold text-foreground mb-4">
        Change password
      </h1>
      <form noValidate onSubmit={handleSubmit(onSubmit)}>
        <div className="bg-white rounded-md shadow-md mb-8 p-4">
          <div className="flex flex-col gap-4">
            <CommonTextField
              label="Current Password"
              required
              name="currentPassword"
              placeholder="Current Password"
              type={isShowOldPass ? "text" : "password"}
              className="transition-all duration-200 text-sm sm:text-base md:text-lg"
              register={register}
              errors={errors}
              validation={{
                required: getRequiredMessage("Current Password"),
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              }}
              endAdornment={
                <button
                  type="button"
                  onClick={() => setIsShowOldPass(!isShowOldPass)}
                  className="cursor-pointer transition-transform duration-200 hover:scale-110"
                >
                  {isShowOldPass ? (
                    <EyeOff
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  ) : (
                    <Eye
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  )}
                </button>
              }
            />
            <CommonTextField
              name="newPassword"
              label="New Password"
              required
              placeholder="New Password"
              type={isShowNewPass ? "text" : "password"}
              className="transition-all duration-200 text-sm sm:text-base md:text-lg"
              register={register}
              errors={errors}
              validation={{
                required: getRequiredMessage("New Password"),
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              }}
              endAdornment={
                <button
                  type="button"
                  onClick={() => setIsShowNewPass(!isShowNewPass)}
                  className="cursor-pointer transition-transform duration-200 hover:scale-110"
                >
                  {isShowNewPass ? (
                    <EyeOff
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  ) : (
                    <Eye
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  )}
                </button>
              }
            />
            <CommonTextField
              name="confirmPassword"
              label="Confirm Password"
              required
              placeholder="Confirm Password"
              type={isShowConfirmNewPass ? "text" : "password"}
              className="transition-all duration-200 text-sm sm:text-base md:text-lg"
              register={register}
              errors={errors}
              validation={{
                required: getRequiredMessage("Confirm Password"),
                validate: (value) =>
                  value === getValues("newPassword") ||
                  "Confirm Password must match New Password",
                pattern: {
                  value: Constant.REGEX.PASSWORD_COMPLEXITY,
                  message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                },
              }}
              endAdornment={
                <button
                  type="button"
                  onClick={() => setIsShowConfirmNewPass(!isShowConfirmNewPass)}
                  className="cursor-pointer transition-transform duration-200 hover:scale-110"
                >
                  {isShowConfirmNewPass ? (
                    <EyeOff
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  ) : (
                    <Eye
                      size={20}
                      className="text-gray-600 hover:text-[#5e35b1]"
                    />
                  )}
                </button>
              }
            />
            <CommonButton
              type="submit"
              className="!max-h-[48px] !text-sm sm:!text-md md:!text-lg !max-w-md !font-semibold justify-end !ml-auto"
              variant="contained"
            >
              Change password
            </CommonButton>
          </div>
        </div>
      </form>
    </div>
  );
};
