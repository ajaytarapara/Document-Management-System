import { useForm } from "react-hook-form";
import { useState } from "react";
import { IChangePassword } from "@/main/models";
import { handleThunkWithDecrypt } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import { updateAccountPass } from "@/main/store";
import { useRouter } from "next/navigation";

export const UseChangePasswordForm = () => {
  const [isShowOldPass, setIsShowOldPass] = useState(false);
  const [isShowNewPass, setIsShowNewPass] = useState(false);
  const [isShowConfirmNewPass, setIsShowConfirmNewPass] = useState(false);
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm<IChangePassword>();
  const router = useRouter();

  const onSubmit = async (data: IChangePassword) => {
    const response = await handleThunkWithDecrypt(
      dispatch,
      updateAccountPass,
      data
    );
    if (response.isSuccessful) {
      router.back();
    }
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    getValues,
    isShowOldPass,
    setIsShowOldPass,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
  };
};
