export const StyledButton: React.FC<
  React.ButtonHTMLAttributes<HTMLButtonElement>
> = ({ children, className = "", ...props }) => {
  return (
    <button
      {...props}
      className={`bg-[#7E57C2] text-white max-w-[100px] w-full capitalize px-4 py-2 rounded-md transition-colors duration-200 hover:bg-[#6a45b3] ${className}`}
    >
      {children}
    </button>
  );
};
