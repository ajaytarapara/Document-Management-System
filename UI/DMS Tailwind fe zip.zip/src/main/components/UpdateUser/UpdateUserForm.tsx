"use client";

import {
  CommonTextField,
  CommonCheckbox,
  CommonSelect,
  CommonButton,
} from "@/core/components";
import { Constant, loginTypeOptions } from "@/core/constants/Constant";
import { IUpdateUserForm } from "@/main/models";
import { Control, FieldValues } from "react-hook-form";
import { useUpdateUserForm } from "./UpdateUserForm.hook";
import { Dispatch, SetStateAction } from "react";
import { StyledCancelButton } from "./UpdateUserForm.styled";
import { getRequiredMessage } from "@/core/utils";
import { ButtonType, LoginTypeEnum } from "@/core/models";

interface UpdateUserFormProps {
  userId: string;
  onClose: () => void;
  setIsSaveClick: Dispatch<SetStateAction<boolean>>;
}

export const UpdateUserForm: React.FC<UpdateUserFormProps> = ({
  onClose,
  setIsSaveClick,
  userId,
}) => {
  const { user, handleSubmit, onSubmit, register, errors, control, loginType } =
    useUpdateUserForm({ onClose, setIsSaveClick, userId });

  if (!user) return null;

  return (
    <div>
      <div className="py-2 px-4 border-b border-[#5e35b1]">
        <h4 className="text-[#727272] font-normal text-xs sm:text-sm">
          {Constant.MESSAGE.INSTRUCTION_FOR_UPDATE_USER}
        </h4>
      </div>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 grid gap-4 grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
        noValidate
      >
        <CommonTextField<IUpdateUserForm>
          name="userName"
          placeholder="Username"
          label="Username"
          required
          register={register}
          disabled
          validation={{
            required: getRequiredMessage("Username"),
            pattern: {
              value: Constant.REGEX.USERNAME_REGEX,
              message: Constant.MESSAGE.INVALID_USERNAME,
            },
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="firstName"
          placeholder="First Name"
          label="First Name"
          required
          register={register}
          validation={{
            required: getRequiredMessage("First Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="lastName"
          placeholder="Last Name"
          label="Last Name"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Last Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="email"
          placeholder="Email"
          label="Email"
          required
          register={register}
          disabled={
            loginType == LoginTypeEnum.SSO || loginType == LoginTypeEnum.BOTH
          }
          validation={{
            required: getRequiredMessage("Email"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.EMAIL_REGEX,
              message: Constant.MESSAGE.INVALID_EMAIL,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="phoneNumber"
          placeholder="Phone Number"
          label="Phone Number"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Phone Number"),
            pattern: {
              value: Constant.REGEX.PHONE_REGEX,
              message: Constant.MESSAGE.INVALID_PHONE,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="address"
          placeholder="Address"
          label="Address"
          register={register}
          validation={{
            maxLength: {
              value: 200,
              message: Constant.MESSAGE.ADDRESS_MAX_LIMIT,
            },
          }}
        />

        <CommonTextField<IUpdateUserForm>
          name="city"
          placeholder="City"
          label="City"
          register={register}
          validation={{
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
        />

        <CommonTextField<IUpdateUserForm>
          name="postalCode"
          placeholder="Postal Code"
          label="Postal Code"
          required
          register={register}
          validation={{
            required: getRequiredMessage("Postal Code"),
            pattern: {
              value: Constant.REGEX.POSTAL_CODE_REGEX,
              message: Constant.MESSAGE.INVALID_POSTAL_CODE,
            },
          }}
          errors={errors}
        />

        <CommonTextField<IUpdateUserForm>
          name="roleName"
          placeholder="Role Name"
          label="Role Name"
          value={"Users"}
          disabled
        />

        <CommonSelect
          name="loginType"
          label="Login Type"
          required
          placeholder="Select login type"
          errors={errors}
          fullWidth
          validations={{ required: Constant.MESSAGE.LOGIN_TYPE_REQUIRED }}
          control={control as unknown as Control<FieldValues>}
          options={loginTypeOptions}
        />

        <div className="col-span-full grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
            <CommonCheckbox<IUpdateUserForm>
              name="isActive"
              label="Is Active"
              control={control}
            />
          </div>
          <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
            <CommonCheckbox<IUpdateUserForm>
              name="privilegeDownload"
              label="Has Privilege To Download"
              control={control}
            />
          </div>
          <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
            <CommonCheckbox<IUpdateUserForm>
              name="privilegeDelete"
              label="Has Privilege To Delete"
              control={control}
            />
          </div>
          <div className="w-full border border-gray-300 rounded px-3 py-2 sm:px-4 sm:py-3 flex items-center">
            <CommonCheckbox<IUpdateUserForm>
              name="privilegeView"
              label="View Privilege"
              control={control}
            />
          </div>
        </div>

        <div className="col-span-full flex flex-col sm:flex-row justify-end gap-2 mt-6">
          <StyledCancelButton
            onClick={onClose}
            className="text-[#263238] w-full sm:w-auto"
          >
            {Constant.COMMON.CANCEL}
          </StyledCancelButton>
          <CommonButton type={ButtonType.Submit} variant="contained" className="w-full sm:w-auto">
            {Constant.COMMON.SAVE}
          </CommonButton>
        </div>
      </form>
    </div>
  );
};
