import emotionStyled from "@emotion/styled";

export const StyledCancelButton = emotionStyled("button")`
  max-width: 100px;
  width: 100%;
  cursor: pointer;
  border-radius: 3px;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #5e35b1;
  &:hover {
    background-color: #e1dcef;
  }
`;

