"use client";

import React, { Dispatch, SetStateAction } from "react";

import { StyledCancelButton } from "./CreateUserForm.styled";
import { Control, FieldValues } from "react-hook-form";
import { useCreateUserForm } from "./CreateUserForm.hook";
import {
  CommonButton,
  CommonCheckbox,
  CommonSelect,
  CommonTextField,
} from "@/core/components";
import { Constant, loginTypeOptions } from "@/core/constants/Constant";
import { getRequiredMessage } from "@/core/utils";
import { ICreateUserForm } from "@/main/models";
import { ButtonType } from "@/core/models";

interface CreateUserFormProps {
  onClose: () => void;
  setIsCreateClick: Dispatch<SetStateAction<boolean>>;
}

export const CreateUserForm: React.FC<CreateUserFormProps> = ({
  onClose,
  setIsCreateClick,
}) => {
  const {
    register,
    handleSubmit,
    control,
    errors,
    decryptedLoggedUser,
    onSubmit,
    backToViewUsers,
  } = useCreateUserForm({ onClose, setIsCreateClick });

  return (
    <div>
      <div className="py-2 px-4 border-b border-[#5e35b1]">
        <h4 className="text-[#727272] font-normal text-xs sm:text-sm">
          {Constant.MESSAGE.INSTRUCTION_FOR_CREATE_USER}
        </h4>
      </div>

      <form
        id="create-user-form"
        onSubmit={handleSubmit(onSubmit)}
        noValidate
        className="p-4 grid gap-4 grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2"
      >
        <CommonTextField<ICreateUserForm>
          name="firstName"
          placeholder="First Name"
          label="First Name"
          register={register}
          validation={{
            required: getRequiredMessage("First Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.ALLOW_ONLY_TEXT_REGEX,
              message: Constant.MESSAGE.LETEERS_ONLY("First Name"),
            },
          }}
          required
          errors={errors}
        />

        <CommonTextField<ICreateUserForm>
          name="lastName"
          placeholder="Last Name"
          label="Last Name"
          register={register}
          validation={{
            required: getRequiredMessage("Last Name"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.ALLOW_ONLY_TEXT_REGEX,
              message: Constant.MESSAGE.LETEERS_ONLY("Last Name"),
            },
          }}
          required
          errors={errors}
        />

        <CommonTextField<ICreateUserForm>
          name="email"
          placeholder="Email"
          label="Email"
          register={register}
          validation={{
            required: getRequiredMessage("Email"),
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.EMAIL_REGEX,
              message: Constant.MESSAGE.INVALID_EMAIL,
            },
          }}
          required
          errors={errors}
        />

        <CommonTextField<ICreateUserForm>
          name="userName"
          placeholder="Username"
          label="Username"
          register={register}
          validation={{
            required: getRequiredMessage("Username"),
            pattern: {
              value: Constant.REGEX.USERNAME_REGEX,
              message: Constant.MESSAGE.INVALID_USERNAME,
            },
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
          }}
          required
          errors={errors}
        />

        <CommonTextField<ICreateUserForm>
          name="phoneNumber"
          placeholder="Phone Number"
          label="Phone Number"
          register={register}
          validation={{
            required: getRequiredMessage("Phone Number"),
            pattern: {
              value: Constant.REGEX.PHONE_REGEX,
              message: Constant.MESSAGE.INVALID_PHONE,
            },
          }}
          required
          errors={errors}
        />

        <CommonSelect
          name="loginType"
          label="Login Type"
          placeholder="Select Login Type"
          required
          errors={errors}
          fullWidth
          validations={{ required: Constant.MESSAGE.LOGIN_TYPE_REQUIRED }}
          control={control as unknown as Control<FieldValues>}
          options={loginTypeOptions}
        />

        <CommonTextField<ICreateUserForm>
          name="postalCode"
          placeholder="Postal Code"
          label="Postal Code"
          register={register}
          validation={{
            required: getRequiredMessage("Postal Code"),
            pattern: {
              value: Constant.REGEX.POSTAL_CODE_REGEX,
              message: Constant.MESSAGE.INVALID_POSTAL_CODE,
            },
          }}
          required
          errors={errors}
        />

        <CommonTextField<ICreateUserForm>
          name="address"
          placeholder="Address"
          label="Address"
          register={register}
          validation={{
            maxLength: {
              value: 200,
              message: Constant.MESSAGE.ADDRESS_MAX_LIMIT,
            },
          }}
        />

        <CommonTextField<ICreateUserForm>
          name="city"
          placeholder="City"
          label="City"
          register={register}
          validation={{
            maxLength: {
              value: 50,
              message: Constant.MESSAGE.USER_NAME_MAX_LIMIT,
            },
            pattern: {
              value: Constant.REGEX.ALLOW_ONLY_TEXT_REGEX,
              message: Constant.MESSAGE.LETEERS_ONLY("City"),
            },
          }}
          errors={errors}
        />

        {decryptedLoggedUser?.data?.role === Constant.COMMON.ADMIN && (
          <CommonTextField<ICreateUserForm>
            name="maxTabLimit"
            placeholder="Maximum Tabs Limit"
            label="Maximum Tabs Limit"
            type="number"
            register={register}
            validation={{
              required: getRequiredMessage("Max Tab Limit"),
              max: { value: 12, message: Constant.COMMON.MAX_TAB_LIMIT },
              min: { value: 1, message: Constant.COMMON.MIN_TAB_LIMIT },
            }}
            errors={errors}
          />
        )}

        {decryptedLoggedUser?.data?.role === Constant.COMMON.OFFICEUSER && (
          <>
            <div className="col-span-full">
              <label className="block mb-2 font-semibold text-sm sm:text-base md:text-lg text-secondary dark:text-gray-200">
                Privilege
              </label>
              <div className="col-span-full grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="w-full border border-gray-300 rounded px-3 py-2 flex items-center">
                  <CommonCheckbox<ICreateUserForm>
                    name="privilegeView"
                    label="View"
                    control={control}
                  />
                </div>
                <div className="w-full border border-gray-300 rounded px-3 py-2 flex items-center">
                  <CommonCheckbox<ICreateUserForm>
                    name="privilegeDownload"
                    label="Download"
                    control={control}
                  />
                </div>
                <div className="w-full border border-gray-300 rounded px-3 py-2 flex items-center">
                  <CommonCheckbox<ICreateUserForm>
                    name="privilegeDelete"
                    label="Delete"
                    control={control}
                  />
                </div>
                <div className="w-full border border-gray-300 rounded px-3 py-2 flex items-center">
                  <CommonCheckbox<ICreateUserForm>
                    name="hideLockTabs"
                    label="Hide Lock Tabs"
                    control={control}
                  />
                </div>
                <div className="w-full border border-gray-300 rounded px-3 py-2 flex items-center">
                  <CommonCheckbox<ICreateUserForm>
                    name="isActive"
                    label="Is Active"
                    control={control}
                  />
                </div>
              </div>
            </div>
          </>
        )}

        <div className="col-span-full flex justify-end gap-2 mt-6">
          <StyledCancelButton
            onClick={() => backToViewUsers(onClose)}
            className="text-[#263238] w-full sm:w-auto"
          >
            {Constant.COMMON.CANCEL}
          </StyledCancelButton>
          <CommonButton
            variant="contained"
            type={ButtonType.Submit}
            className="w-full sm:w-auto"
          >
            {Constant.COMMON.CREATE}
          </CommonButton>
        </div>
      </form>
    </div>
  );
};
