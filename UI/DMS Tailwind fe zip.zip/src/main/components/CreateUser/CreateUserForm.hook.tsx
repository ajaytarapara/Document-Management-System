import { IAPIResponse } from "@/core/models";
import { decryptObject } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import { ILoginResponse, ICreateUserForm, IUsersResponse } from "@/main/models";
import { createUser, useSelectorAuthState } from "@/main/store";
import { Dispatch, SetStateAction } from "react";
import { useForm } from "react-hook-form";

interface UseCreateUserFormProps {
  onClose: () => void;
  setIsCreateClick: Dispatch<SetStateAction<boolean>>;
}

/**
 * Custom hook for handling the "Create User" form logic.
 * - Handles form state and validation with react-hook-form.
 * - Manages user creation API call and response decryption.
 * - Provides helper methods for submission and resetting the form.
 */
export const useCreateUserForm = ({
  onClose,
  setIsCreateClick,
}: UseCreateUserFormProps) => {
  const dispatch = useAppDispatch();
  const { loggedInUser } = useSelectorAuthState();
  const decryptedLoggedUser = loggedInUser
    ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser)
    : null;

  /** Setup react-hook-form for managing the "Create User" form */
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
  } = useForm<ICreateUserForm>();

  /**
   * Handles form submission for creating a new user.
   * - Dispatches the `createUser` thunk.
   * - Decrypts the API response.
   * - Resets the form and closes the drawer on success.
   */
  const onSubmit = async (data: ICreateUserForm) => {
    const result = await dispatch(createUser(data));

    if (createUser.fulfilled.match(result)) {
      const encryptedString = result.payload?.data;

      // Decrypt API response
      const decrypted: IAPIResponse<IUsersResponse> = decryptObject<
        IAPIResponse<IUsersResponse>
      >(encryptedString as unknown as string);

      if (decrypted?.data) {
        reset();
        setTimeout(() => {
          onClose();
          setIsCreateClick(true);
        }, 1500);
      }
    }
  };

  /**
   * Resets the form and navigates back to the "View Users" screen.
   * @param onClose - Optional callback to close the modal/drawer.
   */
  const backToViewUsers = (onClose?: () => void) => {
    reset({}, { keepErrors: false, keepDirty: false });
    if (onClose) onClose();
  };

  return {
    errors,
    control,
    decryptedLoggedUser,
    register,
    handleSubmit,
    backToViewUsers,
    onSubmit,
  };
};
