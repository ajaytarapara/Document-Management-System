import emotionStyled from "@emotion/styled";

export const StyledCancelButton = emotionStyled("button")`
  max-width: 100px;
  width: 100%;
  background-color: #f5f3fa;
  text-transform: capitalize;
  color: #5e35b1;
  border: none;
  border-radius: 0.375rem; /* match Tailwind rounded-md */
  padding: 0.5rem 1rem;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover {
    background-color: #e1dcef;
  }
`;

export const StyledFormControl = emotionStyled("div")`
  min-width: 100px;
  height: 28px;
  margin: 0;
`;

export const StyledSelect = emotionStyled("select")`
  height: 28px;
  padding: 0 0.75rem; /* 12px left/right */
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 0.375rem; /* rounded-md */
  background-color: white;
  cursor: pointer;

  &:focus {
    outline: none;
    border-color: #5e35b1;
  }
`;
