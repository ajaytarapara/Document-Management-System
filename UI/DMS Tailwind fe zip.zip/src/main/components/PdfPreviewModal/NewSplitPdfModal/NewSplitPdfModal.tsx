"use client";
import React, { useCallback, useEffect, useState } from "react";
import { handleThunkWithDecrypt } from "@/core/utils";
import { IFolderListResponse, IFolderTabListResponse } from "@/main/models";
import { getAllFolderList, getAllFolderTabList } from "@/main/store";
import { useAppDispatch } from "@/main/hooks";
import { useSplitPdf } from "./NewSplitPdfModal.hook";
import { CommonDrawer, CommonSelect, CommonTextField } from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { Option } from "@/main/models";

interface NewSplitPdfModalProps {
  open: boolean;
  onClose: () => void;
  handleSuccess: () => void;
  splitFileNameFromUrl: string;
  splitFileName: string;
  selectedPages: number[];
}

const NewSplitPdfModal: React.FC<NewSplitPdfModalProps> = ({
  open,
  onClose,
  handleSuccess,
  splitFileNameFromUrl,
  splitFileName,
  selectedPages,
}) => {
  const [folderList, setFolderList] = useState<IFolderListResponse[]>([]);
  const [folderTabList, setFolderTabList] = useState<IFolderTabListResponse[]>(
    []
  );
  const dispatch = useAppDispatch();
  const { register, errors, control, handleSubmit, onSubmit, setValue } =
    useSplitPdf(
      splitFileNameFromUrl,
      splitFileName,
      onClose,
      handleSuccess,
      selectedPages,
      open
    );

  /**
   * Fetches the list of all active folders.
   *
   * - Dispatches the `getAllFolderList` thunk through `handleThunkWithDecrypt`.
   * - Decrypts the API response into a list of `IFolderListResponse` objects.
   * - Updates the local `folderList` state if data is returned.
   */
  const getAllActiveFolderList = useCallback(async () => {
    const response = await handleThunkWithDecrypt<IFolderListResponse[]>(
      dispatch,
      getAllFolderList
    );
    if (response?.data) {
      setFolderList(response.data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Handles the folder selection change event.
   *
   * - If a valid folder ID is selected, fetches the list of tabs for that folder.
   * - Updates the `folderTabList` state with the response data.
   * - Clears the `folderTabList` if no folder is selected.
   * - Resets the `tabId` form value to ensure a fresh selection.
   *
   * @param folderId - The selected folder ID, or an empty string if no folder is selected.
   */
  const handleFolderChange = async (folderId: string | "") => {
    if (folderId !== "") {
      const response = await handleThunkWithDecrypt<
        IFolderTabListResponse[],
        string
      >(dispatch, getAllFolderTabList, folderId);
      if (response?.data) {
        setFolderTabList(response.data);
      }
    } else {
      setFolderTabList([]);
    }
    setValue("tabId", "");
  };

  useEffect(() => {
    getAllActiveFolderList();
  }, [getAllActiveFolderList]);

  const folderOptions: Option[] = [
    { value: "", label: "Select Folder" },
    ...folderList.map((folder) => ({
      value: folder.id,
      label: folder.folderName,
    })),
  ];

  const tabOptions: Option[] = [
    { value: "", label: "Select Tab" },
    ...folderTabList.map((folderTab) => ({
      value: folderTab.id,
      label: folderTab.tabName,
    })),
  ];
  return (
    <CommonDrawer open={open} onClose={onClose} title="Tab" lgSize="40%">
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <div className="!space-y-4">
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              New Split Pdf Name <span className="text-red-500">*</span>
            </span>
            <CommonTextField
              name="newSplitPdfFileName"
              placeholder="Enter new pdf name"
              register={register}
              validation={{ required: Constant.MESSAGE.FILE_NAME_REQ }}
              errors={errors}
              className="h-10"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              Select Folder <span className="text-red-500">*</span>
            </span>
            <CommonSelect
              name="folderId"
              control={control}
              options={folderOptions}
              placeholder="Select Folder"
              fullWidth
              required
              errors={errors}
              customSelectClass="h-10"
              dropdownHeight={188}
              onChange={(value) => {
                handleFolderChange(value);
              }}
            />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-[#00092a] mb-1">
              Select Tab <span className="text-red-500">*</span>
            </span>
            <CommonSelect
              name="tabId"
              control={control}
              options={tabOptions}
              placeholder="Select Tab"
              fullWidth
              required
              errors={errors}
              customSelectClass="h-10"
              dropdownHeight={188}
            />
          </div>
        </div>
        <div className="flex flex-col sm:flex-row justify-end gap-2 p-4">
          <button
            onClick={onClose}
            type="button"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
          >
            Close
          </button>
          <button
            type="submit"
            className="w-full sm:w-auto !rounded-md !px-6 !py-2 bg-[#7E57C2] text-white hover:bg-[#6C4FB3] transition"
          >
            Save
          </button>
        </div>
      </form>
    </CommonDrawer>
  );
};

export default NewSplitPdfModal;
