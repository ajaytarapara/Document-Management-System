"use client";
import React, { useState } from "react";
import { X } from "lucide-react";
import { Viewer, Worker } from "@react-pdf-viewer/core";
import { defaultLayoutPlugin } from "@react-pdf-viewer/default-layout";

import "@react-pdf-viewer/core/lib/styles/index.css";
import "@react-pdf-viewer/default-layout/lib/styles/index.css";
import { CommonButton } from "@/core/components";

interface PdfPreviewModalProps {
  open: boolean;
  onClose: () => void;
  fileUrl: string;
  fileName: string;
  handleClickSplitPdfButton: (
    pages: number[],
    fileUrl: string,
    fileName: string
  ) => void;
}

const PdfPreviewModal: React.FC<PdfPreviewModalProps> = ({
  open,
  onClose,
  fileUrl,
  fileName,
  handleClickSplitPdfButton,
}) => {
  const defaultLayoutPluginInstance = defaultLayoutPlugin();
  const [selectedPages, setSelectedPages] = useState<number[]>([]);
  const [totalPages, setTotalPages] = useState<number>(0);

  /**
   * Toggles the selection state of a specific page.
   *
   * - If the page is already selected, it is removed from the selection.
   * - Otherwise, it is added to the selection.
   *
   * @param page - The page number to toggle.
   */
  const togglePageSelection = (page: number) => {
    setSelectedPages((prev) =>
      prev.includes(page) ? prev.filter((p) => p !== page) : [...prev, page]
    );
  };

  /**
   * Clears all selected pages.
   */
  const clearAll = () => {
    setSelectedPages([]);
  };

  /**
   * Handles the PDF split action.
   *
   * - Calls the split handler with the selected pages and file url.
   * - Resets selected pages and total page count after the split action.
   */
  const handleSplit = () => {
    handleClickSplitPdfButton(selectedPages, fileUrl, fileName);
    setSelectedPages([]);
    setTotalPages(0);
  };

  /**
   * Handles closing the current modal or component.
   *
   * - Resets selected pages and total page count.
   * - Invokes the provided `onClose` callback to close the modal.
   */
  const handleClose = () => {
    setSelectedPages([]);
    setTotalPages(0);
    onClose();
  };
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="absolute inset-0" onClick={handleClose} />
      <div className="relative z-10 w-full max-w-6xl bg-white rounded-lg shadow-lg flex flex-col">
        <div className="flex justify-between items-center pt-[10px] pr-[10px] pb-[10px] pl-[16px] mb-[24px] border-b border-[#9e9e9e]">
          <span className="font-semibold text-gray-800">{fileName}</span>
          <button
            onClick={handleClose}
            className="p-1 rounded-full hover:bg-gray-200 transition"
          >
            <X className="h-5 w-5 text-gray-600" />
          </button>
        </div>
        <div
          style={{
            height: "80vh",
            position: "relative",
            padding: "0px 20px 24px",
            overflowY: "auto",
          }}
        >
          {fileUrl && (
            <>
              <div className="flex items-center justify-between mb-3 border-b border-gray-300 pb-2">
                <div className="flex items-center gap-2 overflow-x-auto whitespace-nowrap max-h-[50px] pr-4">
                  <p className="font-medium mr-2 shrink-0">Select Pages:</p>
                  {[...Array(totalPages)].map((_, index) => {
                    const pageNum = index;
                    const isSelected = selectedPages.includes(pageNum);
                    return (
                      <button
                        key={pageNum}
                        onClick={() => togglePageSelection(pageNum)}
                        className={`px-2 py-1 rounded border text-sm font-medium shrink-0
                        ${
                          isSelected
                            ? "border-[#7E57C2] bg-[#ede7f6]"
                            : "border-gray-400 bg-white"
                        }
                      `}
                      >
                        {pageNum + 1}
                      </button>
                    );
                  })}
                </div>
                <div className="flex items-center gap-2 shrink-0 pl-4">
                  <CommonButton
                    variant="outlined"
                    onClick={clearAll}
                    className="!min-w-fit !py-[3px] !px-[9px] !text-[.8152rem] !font-medium !rounded-[4px]"
                  >
                    Clear All
                  </CommonButton>
                  <CommonButton
                    variant="contained"
                    disabled={selectedPages.length === 0 || totalPages === 1}
                    onClick={handleSplit}
                    className="!min-w-fit !py-[3px] !px-[9px] !text-[.8152rem] !font-medium !rounded-[4px]"
                  >
                    Split Selected Pages
                  </CommonButton>
                </div>
              </div>
              <Worker workerUrl="https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js">
                <Viewer
                  fileUrl={fileUrl}
                  plugins={[defaultLayoutPluginInstance]}
                  onDocumentLoad={(e) => setTotalPages(e.doc.numPages)}
                />
              </Worker>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PdfPreviewModal;
