import { UserRound } from "lucide-react";
import { UseSubUserBoxHeader } from "./SubUserBoxHeader.hook";
import { ISubUser } from "@/main/models";

type Props = {
  user: ISubUser;
  currentUser: ISubUser;
};

export const SubUserBoxHeader = ({ user, currentUser }: Props) => {
  const { ImpersonateUser } = UseSubUserBoxHeader();
  const isActive = user.id === currentUser?.id;

  return (
    <button
      className={`!flex p-2 !w-full !item-center ${isActive ? "!bg-gray-300 !cursor-no-drop" : "!cursor-pointer"} hover:!bg-gray-300`}
      onClick={() => {
        ImpersonateUser(user);
      }}
      disabled={isActive}
    >
      <div className="h-[38px] w-[38px] bg-[#5e35b1] flex items-center justify-center rounded-full">
        <UserRound className="h-5 w-5 text-white font-bold" />
      </div>
      <div
        className="items-center gap-1 text-[#00092a] ml-4 font-semibold !mt-auto !mb-auto !mr-auto
                      "
      >
        {user?.username}
      </div>
    </button>
  );
};
