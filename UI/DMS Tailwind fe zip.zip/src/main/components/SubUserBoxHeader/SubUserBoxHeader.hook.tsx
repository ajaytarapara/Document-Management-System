import { handleThunkWithDecrypt } from "@/core/utils";
import { useAppDispatch } from "@/main/hooks";
import { ISubUser, IImpersonate } from "@/main/models";
import {
  useSelectorAuthState,
  impersonateUser,
  setCurrentUser,
} from "@/main/store";
import Cookies from "js-cookie";

export const UseSubUserBoxHeader = () => {
  const dispatch = useAppDispatch();
  const { currentUser } = useSelectorAuthState();

  /**
   * Impersonates a sub-user by calling the impersonation API,
   * updating the token cookie, setting the current user in state,
   * and reloading the page.
   * @param {ISubUser} user - The sub-user to impersonate.
   */
  const ImpersonateUser = async (user: ISubUser) => {
    const decryptedResponse = await handleThunkWithDecrypt<
      IImpersonate,
      { subUserId: number }
    >(dispatch, impersonateUser, {
      subUserId: user.id,
    });
    Cookies.set("token", decryptedResponse?.data?.token || "");
    dispatch(setCurrentUser(user));
    window.location.reload();
  };

  return { ImpersonateUser, currentUser };
};
