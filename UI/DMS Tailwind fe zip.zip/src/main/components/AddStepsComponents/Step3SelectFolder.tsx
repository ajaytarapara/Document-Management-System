import { FolderListResponseVM, IUserTemplateTabsUI } from "@/main/models";

type Props = {
  data: FolderListResponseVM[];
  selectedIds: number[];
  isAllSelected: boolean;
  toggleAll: () => void;
  toggleOne: (id: number) => void;
  newTab: IUserTemplateTabsUI[];
  selectedTemplate: string;
};

export const Step3SelectFolder: React.FC<Props> = ({
  data,
  selectedIds,
  isAllSelected,
  toggleAll,
  toggleOne,
  newTab,
  selectedTemplate,
}) => {
  const showCheckbox = data.length > 0;
  const editableTabNames = newTab
    .filter((tab) => !tab.readonly)
    .map((tab) => tab.name);
  const editableTabNamesString = editableTabNames.join(", ");

  return (
    <div className="overflow-x-auto border border-gray-200 rounded-lg">
      <div className="bg-[#7e58c1] text-white rounded-2xl m-2 w-fit p-3">
        <div className="font-bold text-xl ">Template : {selectedTemplate}</div>
        <div className="font-bold text-xl ">
          New Tabs : {editableTabNamesString}
        </div>
      </div>
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider">
              {showCheckbox && (
                <input
                  type="checkbox"
                  checked={isAllSelected}
                  onChange={toggleAll}
                  className="w-5 h-5 accent-[#7E57C2] border-gray-300 rounded focus:ring-1 focus:ring-[#7E57C2]"
                />
              )}
            </th>
            <th className="px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider">
              Name
            </th>
            <th className="px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider">
              File Number
            </th>
            <th className="px-4 bg-[#eeebf8] py-3 text-left text-sm font-bold text-[#00092A] tracking-wider">
              Tabs Count
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.length === 0 ? (
            <tr>
              <td colSpan={4} className="text-center py-6 text-gray-500">
                No folder available
              </td>
            </tr>
          ) : (
            data.map((row) => (
              <tr
                key={row.id}
                className="hover:bg-gray-50 transition-colors duration-150"
              >
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(row.id)}
                    onChange={() => toggleOne(row.id)}
                    className="w-5 h-5 accent-[#7E57C2] border-gray-300 rounded focus:ring-1 focus:ring-[#7E57C2]"
                  />
                </td>
                <td className="px-4 py-3 text-sm text-gray-700">
                  {row.folderName}
                </td>
                <td className="px-4 py-3 text-sm text-gray-700">
                  {row.fileNumber}
                </td>
                <td className="px-4 py-3 text-sm text-gray-700">
                  {row.tabsCount}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};
