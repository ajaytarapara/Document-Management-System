export interface Step {
  id: number;
  title: string;
  description: string;
}

interface StepIndicatorProps {
  steps: Step[];
  currentStep: number;
  completedSteps: number[];
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ steps, currentStep, completedSteps }) => {
  return (
    <div className="flex justify-between items-center gap-4 mb-6 mt-3">
      {steps.map(step => (
        <div
          key={step.id}
          className={`flex-1 text-center p-2 rounded ${
            currentStep === step.id
              ? "bg-[#7e58c1] text-white"
              : completedSteps.includes(step.id)
                ? "bg-[#caabff] text-white"
                : "bg-gray-200 text-gray-600"
          }`}
        >
          <div className="font-semibold">Step {step.id}</div>
          <div className="text-sm  hidden sm:block">{step.description}</div>
        </div>
      ))}
    </div>
  );
};
