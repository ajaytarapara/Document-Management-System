import { IUserTemplate } from "@/main/models";
import { useForm } from "react-hook-form";
import { CommonSelect } from "@/core/components";

type Props = {
  userTemplate: IUserTemplate[];
  selectedTemplate: string;
  setSelectedTemplate: (id: string) => void;
  getTemplateTabs: (id: string) => void;
  setSelectedTemplateName: (name: string) => void;
};

export const Step1TemplateSelection: React.FC<Props> = ({
  userTemplate,
  selectedTemplate,
  setSelectedTemplate,
  getTemplateTabs,
  setSelectedTemplateName,
}) => {
  type FormValues = {
    templateId: string;
  };

  const templateOptions = userTemplate.map((t) => ({
    value: t.id,
    label: t.name,
  }));

  const { control } = useForm<FormValues>({
    defaultValues: { templateId: selectedTemplate },
  });
  return (
    <div className="mb-8 p-2 bg-white rounded-[4px] shadow">
      <div className="space-y-6 p-[16px]">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="flex flex-col">
            <label
              className="
                block font-semibold text-secondary leading-6 mb-1
                text-[0.8rem]
                sm:text-base
                md:text-lg
              "
            >
              Please select template <span className="text-red-600">*</span>
            </label>
            <CommonSelect<FormValues>
              name="templateId"
              control={control}
              options={templateOptions}
              placeholder="Select Template"
              fullWidth
              required
              customSelectClass="h-10"
              onChange={(id) => {
                const template = userTemplate.find((t) => t.id === id);
                setSelectedTemplate(id);
                setSelectedTemplateName(template?.name || "");
                getTemplateTabs(id);
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
