import { EditableTab } from "../AddTemplateTabForm/AddTemplateTabForm";
import { Pencil, Plus, Save, Trash2 } from "lucide-react";

type Props = {
  tabs: EditableTab[];
  onEdit: (id: string) => void;
  onSave: (id: string) => void;
  onChange: <K extends keyof EditableTab>(
    id: string,
    field: K,
    value: EditableTab[K]
  ) => void;
  onDelete: (id: string) => void;
  onAddNew: () => void;
  newTab: Omit<EditableTab, "id">;
  setNewTab: (tab: Omit<EditableTab, "id">) => void;
  maxLimit: number;
  hasDuplicateName: boolean;
  hasDuplicateColor: boolean;
  selectedTemplate?: string;
};

// Separate component for table
const TabDetailsTable: React.FC<
  Omit<Props, "onSubmit" | "isSubmitDisabled">
> = ({
  tabs,
  onEdit,
  onSave,
  onChange,
  onDelete,
  onAddNew,
  newTab,
  setNewTab,
  maxLimit,
  hasDuplicateName,
  hasDuplicateColor,
}) => {
  return (
    <div className="overflow-auto max-h-[400px]">
      <table className="min-w-full text-sm text-center">
        <thead>
          <tr className="border-b-2 border-gray-300 font-semibold text-gray-700">
            <th className="p-2">Action</th>
            <th className="p-2 min-w-[200px]">Name</th>
            <th className="p-2 min-w-[200px]">Color</th>
            <th className="p-2">Locked</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-transparent">
          {tabs.map((tab, index) => (
            <tr
              key={tab.id}
              className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}
            >
              <td className="p-2 space-x-1 min-w-[100px]">
                {!tab.readonly && (
                  <>
                    {tab.editing ? (
                      <button
                        onClick={() => onSave(tab.id)}
                        className={`text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1 ${
                          !tab.name.trim()
                            ? "opacity-50 cursor-not-allowed"
                            : ""
                        }`}
                        title="Save"
                        disabled={!tab.name.trim()}
                      >
                        <Save size={18} />
                      </button>
                    ) : (
                      <button
                        onClick={() => onEdit(tab.id)}
                        className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
                        title="Edit"
                      >
                        <Pencil size={18} />
                      </button>
                    )}
                    <button
                      onClick={() => onDelete(tab.id)}
                      className="text-red-600 hover:bg-red-100 cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1 ml-1"
                      title="Delete"
                    >
                      <Trash2 size={18} />
                    </button>
                  </>
                )}
              </td>
              <td className="p-2">
                {tab.editing ? (
                  <input
                    type="text"
                    value={tab.name}
                    onChange={(e) => onChange(tab.id, "name", e.target.value)}
                    className="border px-2 py-1 w-full text-center rounded"
                  />
                ) : (
                  tab.name
                )}
              </td>
              <td className="p-2">
                <input
                  type="color"
                  value={tab.color}
                  disabled={!tab.editing}
                  onChange={(e) => onChange(tab.id, "color", e.target.value)}
                  className="cursor-pointer mx-auto w-[60%]"
                />
              </td>
              <td className="p-2">
                <input
                  type="checkbox"
                  checked={tab.isLock}
                  disabled={!tab.editing}
                  onChange={(e) => onChange(tab.id, "isLock", e.target.checked)}
                />
              </td>
            </tr>
          ))}

          {/* New Tab Row */}
          {tabs.length < maxLimit && (
            <tr className="bg-gray-100">
              <td className="p-2">
                {newTab.name.trim() &&
                  !hasDuplicateName &&
                  !hasDuplicateColor && (
                    <button
                      onClick={onAddNew}
                      className="text-[#7E57C2] hover:bg-[#f1e9fc] cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 rounded p-1"
                      title="Add"
                    >
                      <Plus size={18} />
                    </button>
                  )}
              </td>
              <td className="p-2">
                <input
                  type="text"
                  placeholder="Tab name"
                  value={newTab.name}
                  onChange={(e) =>
                    setNewTab({ ...newTab, name: e.target.value })
                  }
                  className="border px-2 py-1 w-full text-center rounded"
                />
              </td>
              <td className="p-2">
                <input
                  type="color"
                  value={newTab.color}
                  onChange={(e) =>
                    setNewTab({ ...newTab, color: e.target.value })
                  }
                  className="cursor-pointer mx-auto w-[60%]"
                />
              </td>
              <td className="p-2">
                <input
                  type="checkbox"
                  checked={newTab.isLock}
                  onChange={(e) =>
                    setNewTab({ ...newTab, isLock: e.target.checked })
                  }
                />
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Validation Messages */}
      {(hasDuplicateName || hasDuplicateColor) && (
        <div className="text-red-600 font-medium text-sm mt-2">
          {hasDuplicateName && <div>Tab names must be unique.</div>}
          {hasDuplicateColor && <div>Tab colors must be unique.</div>}
        </div>
      )}
    </div>
  );
};

// Main Component for Step 2
export const Step2AddTabs: React.FC<Props> = ({
  tabs,
  onEdit,
  onSave,
  onChange,
  onDelete,
  onAddNew,
  newTab,
  setNewTab,
  maxLimit,
  hasDuplicateName,
  hasDuplicateColor,
  selectedTemplate,
}) => {
  return (
    <div className="mb-8 p-6 bg-white rounded-[4px] shadow">
      <div className="font-bold text-xl mb-3">
        Selected Template : {selectedTemplate}
      </div>
      <TabDetailsTable
        tabs={tabs}
        onEdit={onEdit}
        onSave={onSave}
        onChange={onChange}
        onDelete={onDelete}
        onAddNew={onAddNew}
        newTab={newTab}
        setNewTab={setNewTab}
        maxLimit={maxLimit}
        hasDuplicateName={hasDuplicateName}
        hasDuplicateColor={hasDuplicateColor}
      />
    </div>
  );
};
