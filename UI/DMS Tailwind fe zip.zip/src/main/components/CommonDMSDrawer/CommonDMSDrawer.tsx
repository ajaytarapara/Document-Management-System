"use client";

import { CommonDrawer, CommonButton } from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { Anchor, ButtonType } from "@/core/models";

interface ICommonDrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  description?: string | React.ReactNode;
  children?: React.ReactNode;
  icon?: React.ReactNode;
  showActions?: boolean;
  onSubmit?: (e?: React.FormEvent) => void;
  submitLabel?: string;
  cancelLabel?: string;
  disableSubmit?: boolean;
  buttonType?: ButtonType.Button | ButtonType.Reset | ButtonType.Submit;
  anchor?: Anchor.Left | Anchor.Right | Anchor.Top | Anchor.Bottom;
  customWidth?: number | string;
}

export const CommonDMSDrawer = ({
  open,
  onClose,
  description,
  children,
  showActions = true,
  onSubmit,
  submitLabel = `${Constant.COMMON.SUBMIT}`,
  cancelLabel = `${Constant.COMMON.CANCEL}`,
  disableSubmit = false,
  buttonType,
  title,
  customWidth,
}: ICommonDrawerProps) => {
  return (
    <CommonDrawer
      open={open}
      onClose={onClose}
      title={title}
      lgSize={customWidth ? customWidth : ""}
    >
      <div className="flex flex-col gap-2 flex-1">
        {description && <div>{description}</div>}
        {children}
      </div>

      {showActions && (
        <div className="flex justify-end gap-2 mt-5">
          <CommonButton
            onClick={onClose}
            variant="outlined"
            className="!capitalize"
          >
            {cancelLabel}
          </CommonButton>

          <CommonButton
            disabled={disableSubmit}
            type={buttonType}
            variant="contained"
            onClick={buttonType === ButtonType.Button ? onSubmit : undefined}
            className="!capitalize disabled:!opacity-50 disabled:!text-gray-300 disabled:!bg-[#7e57c2]"
          >
            {submitLabel}
          </CommonButton>
        </div>
      )}
    </CommonDrawer>
  );
};
