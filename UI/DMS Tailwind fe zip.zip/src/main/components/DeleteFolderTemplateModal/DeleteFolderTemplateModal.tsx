import { X } from "lucide-react";
import React from "react";

interface ConfirmDeleteModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title?: string;
  message?: string;
}

export const ConfirmDeleteModal: React.FC<ConfirmDeleteModalProps> = ({
  open,
  onClose,
  onConfirm,
  title = "Delete Confirmation",
  message = "Are you sure you want to delete this item?",
}) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-2xl w-full max-w-xs mx-4">
        <div className="flex items-center justify-between p-4 border-b border-gray-300">
          <h5 className="text-xl font-medium text-black">{title}</h5>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition"
          >
            <X />
          </button>
        </div>
        <div className="p-4">
          <p className="text-center text-gray-700">{message}</p>
        </div>
        <div className="flex flex-col sm:flex-row justify-center gap-2 sm:gap-1 p-4 border-t border-gray-300">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2 rounded-md bg-gray-100 text-gray-800 hover:bg-gray-200 transition"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className="w-full sm:w-auto px-6 py-2 rounded-md bg-red-600 text-white hover:bg-red-700 transition"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};
