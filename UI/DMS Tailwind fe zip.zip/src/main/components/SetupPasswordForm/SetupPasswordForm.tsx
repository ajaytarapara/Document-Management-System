import { CommonButton, CommonTextField } from "@/core/components";
import { UseSetupPasswordForm } from "./SetupPasswordForm.hook";
import { getRequiredMessage } from "@/core/utils";
import { Constant } from "@/core/constants/Constant";
import { Eye, EyeOff, Lock } from "lucide-react";
import { Card } from "@/core/StyledComponents";

export const SetupPasswordForm = () => {
  const {
    handleSubmit,
    onSubmit,
    register,
    errors,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
    getValues,
  } = UseSetupPasswordForm();

  return (
    <Card className="flex items-center justify-center w-fit m-auto !rounded-2xl !shadow-xl">
      <div className="mx-auto p-[16px]">
        <div className="text-center mb-8">
          <h1 className="!text-2xl !sm:text-3xl !font-bold !text-foreground mb-2 flex items-center justify-center gap-3">
            <Lock
              strokeWidth={2.5}
              strikethroughThickness={3}
              className="text-2xl sm:text-3xl font-bold text-foreground"
            />
            Set Up Your Password
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            You are logging in for the first time. Please create a secure
            password to continue.
          </p>
        </div>

        <form noValidate onSubmit={handleSubmit(onSubmit)}>
          <div className="shadow-lg border-0  bg-white/80 backdrop-blur-sm">
            <div className="p-6 sm:p-8 space-y-6">
              <div className="space-y-2 gap-5">
                <CommonTextField
                  label="New Password"
                  {...register("newPassword", {
                    required: getRequiredMessage("New Password"),
                    pattern: {
                      value: Constant.REGEX.PASSWORD_COMPLEXITY,
                      message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                    },
                  })}
                  errors={errors}
                  required
                  type={isShowNewPass ? "text" : "password"}
                  endAdornment={
                    <button
                      type="button"
                      onClick={() => setIsShowNewPass(!isShowNewPass)}
                      className="cursor-pointer transition-transform duration-200 hover:scale-110"
                    >
                      {isShowNewPass ? (
                        <EyeOff
                          size={20}
                          className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                        />
                      ) : (
                        <Eye
                          size={20}
                          className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                        />
                      )}
                    </button>
                  }
                />
                <CommonTextField
                  label="Confirm Password"
                  {...register("confirmPassword", {
                    required: getRequiredMessage("Confirm Password"),
                    validate: (value) =>
                      value === getValues("newPassword") ||
                      "Confirm Password must match New Password",
                    pattern: {
                      value: Constant.REGEX.PASSWORD_COMPLEXITY,
                      message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
                    },
                  })}
                  type={isShowConfirmNewPass ? "text" : "password"}
                  errors={errors}
                  required
                  endAdornment={
                    <button
                      type="button"
                      onClick={() =>
                        setIsShowConfirmNewPass(!isShowConfirmNewPass)
                      }
                      className="cursor-pointer transition-transform duration-200 hover:scale-110"
                    >
                      {isShowConfirmNewPass ? (
                        <EyeOff
                          size={20}
                          className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                        />
                      ) : (
                        <Eye
                          size={20}
                          className="transition duration-200 hover:scale-110 hover:text-[#7E57C2]"
                        />
                      )}
                    </button>
                  }
                />
              </div>

              <div className="pt-4 flex items-center">
                <CommonButton
                  type="submit"
                  className="!max-h-[48px] !text-lg !max-w-md !font-semibold justify-end !m-auto"
                  variant="contained"
                >
                  Set Password
                </CommonButton>
              </div>
            </div>
          </div>
        </form>

        <div className="mt-6 text-center">
          <p className="text-xs sm:text-sm text-muted-foreground">
            Note : {Constant.MESSAGE.PASSWORD_INVALID_FORMAT}
          </p>
        </div>
      </div>
    </Card>
  );
};
