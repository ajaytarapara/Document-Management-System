import { useForm } from "react-hook-form";
import { useState } from "react";
import { ISetupPassword } from "@/main/models";
import { useAppDispatch } from "@/main/hooks";
import { useRouter } from "next/navigation";
import { handleThunkWithDecrypt } from "@/core/utils";
import { SetUpPassword } from "@/main/store";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import Cookie from "js-cookie";

export const UseSetupPasswordForm = () => {
  const [isShowOldPass, setIsShowOldPass] = useState(false);
  const [isShowNewPass, setIsShowNewPass] = useState(false);
  const [isShowConfirmNewPass, setIsShowConfirmNewPass] = useState(false);
  const dispatch = useAppDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm<ISetupPassword>();
  const router = useRouter();

  const onSubmit = async (data: ISetupPassword) => {
    const response = await handleThunkWithDecrypt(
      dispatch,
      SetUpPassword,
      data
    );
    if (response.isSuccessful) {
      Cookie.remove("token");
      Cookie.remove("isFirstTimeLogin");
      router.push(ROUTES.LOGIN);
    }
  };

  return {
    register,
    handleSubmit,
    errors,
    onSubmit,
    getValues,
    isShowOldPass,
    setIsShowOldPass,
    isShowNewPass,
    setIsShowNewPass,
    isShowConfirmNewPass,
    setIsShowConfirmNewPass,
  };
};
