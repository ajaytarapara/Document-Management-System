"use client";

import { Success } from "@/assets";
import { useState, useEffect } from "react";
import Image from "next/image";

export const DownloadFile: React.FC = () => {
  const [visible, setVisible] = useState(false);

  /**
   * Shows the element after a 100ms delay.
   */
  useEffect(() => {
    const timeout = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <div className="flex items-center space-x-3">
      <Image
        src={Success}
        alt="Success"
        className={`w-8 h-8 transform transition-all duration-700 ease-in-out ${
          visible ? "rotate-0 opacity-100" : "-rotate-45 opacity-0"
        }`}
      />
      <p
        className={`text-green-700 font-semibold transition-opacity duration-[1500ms] ease-in-out delay-150`}
      >
        File downloaded successfully
      </p>
    </div>
  );
};


