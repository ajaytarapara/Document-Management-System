"use client";

import React from "react";

type SimpleCheckboxProps = {
  checked: boolean;
  onChange: () => void;
};

export const SimpleCheckbox: React.FC<SimpleCheckboxProps> = ({
  checked,
  onChange,
}) => {
  return (
    <input
      type="checkbox"
      checked={checked}
      onChange={onChange}
      className="h-4 w-4 rounded border-gray-300 cursor-pointer accent-[#5e35b1] focus:ring-[#5e35b1]"
    />
  );
};
