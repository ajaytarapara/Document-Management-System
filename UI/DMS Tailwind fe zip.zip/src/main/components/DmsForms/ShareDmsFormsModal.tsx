"use client";
import { CommonButton, CommonDrawer, CommonTextField } from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import {
  ButtonType,
  IAPIResponse,
  ShareDmsFileModalProps,
  ShareDmsForms,
} from "@/core/models";
import { decryptObject, getRequiredMessage } from "@/core/utils";
import { ILoginResponse } from "@/main/models";
import { useSelectorAuthState } from "@/main/store";
import React from "react";
import { useForm } from "react-hook-form";

export const ShareDmsFileModal: React.FC<ShareDmsFileModalProps> = ({
  open,
  folderId,
  onClose,
  onShare,
  fileName,
}) => {
  /**
   * Get logged-in user email from Redux state after decrypting stored user object.
   */
  const { loggedInUser } = useSelectorAuthState();

  const decryptedUser = loggedInUser
    ? decryptObject<IAPIResponse<ILoginResponse>>(loggedInUser)
    : null;
  const userEmail = decryptedUser?.data?.email ?? "";

  /**
   * Form handlers and state for Share DMS Form.
   */
  const {
    register,
    reset,
    handleSubmit,
    formState: { errors },
  } = useForm<ShareDmsForms>({
    defaultValues: {
      fromEmail: userEmail,
      toEmail: "",
      toName: "",
      subject: "",
      message: "",
      linkExpiration: 24,
    },
  });

  /**
   * Submits the share folder form.
   */
  const submit = handleSubmit(async (data) => {
    if (!folderId) return;
    const response = await onShare(folderId, data);

    if (response?.data) {
      handleCloseDialog();
    }
  });

  /**
   * Validates email string.
   */
  const isValidEmail = (email: string): boolean => {
    return Constant.REGEX.MULTIPLE_EMAIL_WITH_COMMA_SEPRATED_VALUE.test(
      email.trim()
    );
  };

  /**
   * Handles closing of the dialog.
   */
  const handleCloseDialog = () => {
    onClose();
    reset();
  };

  return (
    <CommonDrawer open={open} onClose={handleCloseDialog} title={fileName}>
      <form onSubmit={submit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <CommonTextField
            name="fromEmail"
            register={register}
            validation={{
              required: getRequiredMessage("From email"),
              pattern: {
                value: Constant.REGEX.MULTIPLE_EMAIL_WITH_COMMA_SEPRATED_VALUE,
                message: Constant.COMMON.EMAIL_INVALID_FORMAT,
              },
            }}
            errors={errors}
            label="From Email"
            disabled
          />

          <CommonTextField
            name="toEmail"
            register={register}
            validation={{
              required: getRequiredMessage("To email"),
              validate: {
                format: (value: string | number | undefined) => {
                  const emails = String(value || "")
                    .split(";")
                    .map((e) => e.trim());
                  const allValid = emails.every((email) => isValidEmail(email));
                  return allValid || Constant.COMMON.EMAIL_INVALID_FORMAT;
                },
                notSelf: (value: string | number | undefined) =>
                  !String(value || "")
                    .split(";")
                    .map((v) => v.trim())
                    .includes(userEmail) ||
                  Constant.MESSAGE.EMAIL_CANNOT_BE_SAME,
              },
            }}
            errors={errors}
            label="To Email (separate multiple with `;`)"
          />

          <CommonTextField
            name="toName"
            register={register}
            validation={{ required: getRequiredMessage("To name") }}
            errors={errors}
            label="To Name (separate multiple with `;`)"
          />

          <CommonTextField
            name="subject"
            register={register}
            validation={{ required: getRequiredMessage("Subject") }}
            errors={errors}
            label="Subject"
          />

          <div className="md:col-span-2">
            <CommonTextField
              name="message"
              register={register}
              errors={errors}
              label="Message"
              multiline
              rows={3}
            />
          </div>

          <div className="md:col-span-2">
            <CommonTextField
              name="linkExpiration"
              register={register}
              validation={{
                required: getRequiredMessage("Expiration"),
                min: { value: 1, message: Constant.MESSAGE.MIN_EXPIRATION },
              }}
              errors={errors}
              label="Link Expiration Time (hrs)"
              type="number"
            />
          </div>
        </div>
      </form>

      <div className="flex gap-3 justify-end mt-4">
        <CommonButton
          type={ButtonType.Button}
          variant="outlined"
          onClick={handleCloseDialog}
          className=" hover:bg-gray-100 transition"
        >
          {Constant.COMMON.CANCEL}
        </CommonButton>
        <CommonButton
          type="submit"
          variant="contained"
          onClick={submit}
          className="hover:bg-[#562da8] transition"
        >
          {Constant.COMMON.SHARE}
        </CommonButton>
      </div>
    </CommonDrawer>
  );
};
