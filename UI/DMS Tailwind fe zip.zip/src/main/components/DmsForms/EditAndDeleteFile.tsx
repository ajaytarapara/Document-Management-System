"use client";

import { CommonTextField } from "@/core/components";
import { Constant } from "@/core/constants/Constant";
import { ButtonType, DeleteFileProps, EditFileProps, EditFormValues } from "@/core/models";
import { getRequiredMessage } from "@/core/utils";
import { EyeOff, Eye } from "lucide-react";
import { useState } from "react";

export const DeleteFile: React.FC<DeleteFileProps> = ({ errors, register }) => {
  const [showPassword, setShowPassword] = useState(false);

  /**
   * Toggles the visibility of the password field.
   * - Switches between showing and hiding the password by updating `showPassword` state.
   */
  const togglePasswordVisibility = () => setShowPassword((prev) => !prev);

  return (
    <div>
      <p className="mb-4 text-sm text-gray-700">
        Caution! Are you sure you want to delete this file?
      </p>

      <div className="relative">
        <CommonTextField
          name="password"
          placeholder="Password"
          type={showPassword ? "text" : "password"}
          className="transition-all duration-200 text-sm sm:text-base md:text-lg"
          register={register}
          errors={errors}
          validation={{
            required: getRequiredMessage("Password"),
            pattern: {
              value: Constant.REGEX.PASSWORD_COMPLEXITY,
              message: Constant.MESSAGE.PASSWORD_INVALID_FORMAT,
            },
          }}
          endAdornment={
            <button
              type={ButtonType.Button}
              onClick={togglePasswordVisibility}
              className="cursor-pointer transition-transform duration-200 hover:scale-110"
            >
              {showPassword ? (
                <EyeOff
                  size={20}
                  className="text-gray-600 hover:text-[#5e35b1]"
                />
              ) : (
                <Eye size={20} className="text-gray-600 hover:text-[#5e35b1]" />
              )}
            </button>
          }
        />
      </div>
    </div>
  );
};

export const EditFile: React.FC<EditFileProps> = ({
  editErrors,
  editRegister,
}) => {
  return (
    <div>
      <CommonTextField<EditFormValues>
        name="name"
        placeholder="Name"
        label="Name"
        register={editRegister}
        validation={{
          required: getRequiredMessage("File Name"),
        }}
        errors={editErrors}
      />
    </div>
  );
};
