"use client";

import { DocumentsTableProps } from "@/core/models";
import { formatFileSize } from "@/core/utils";
import { Trash2 } from "lucide-react";

export const UploadDocumentsTable = ({
  selectedFiles,
  setSelectedFiles,
}: DocumentsTableProps) => {
  /**
   * Removes a selected file from the list based on its index.
   *
   * @param indexToRemove - The index of the file to be removed from the selected files array.
   */
  const handleDelete = (indexToRemove: number) => {
    setSelectedFiles((prev) => prev.filter((_, idx) => idx !== indexToRemove));
  };

  return (
    <div className="shadow-sm overflow-x-auto">
      <table className="min-w-full table-auto border-collapse">
        <thead className="bg-[#e1dcef]">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A] rounded-tl-md">
              File Name
            </th>
            <th className="px-4 py-3 text-left text-sm font-semibold text-[#00092A]">
              Size & Format
            </th>
            <th className="px-4 py-3 text-center text-sm font-semibold text-[#00092A] rounded-tr-md">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {selectedFiles.map((item, index) => (
            <tr key={index} className="hover:bg-gray-50 transition">
              <td className="px-4 py-3 text-sm text-gray-800 whitespace-nowrap">
                {item.name}
              </td>
              <td className="px-4 py-3 text-sm text-gray-800">
                {formatFileSize(item.size)} ({item.type})
              </td>
              <td className="px-4 py-3">
                <div className="flex justify-center items-center gap-3 flex-wrap">
                  <Trash2
                    className="w-5 h-5 text-[#EF5350] cursor-pointer"
                    onClick={() => handleDelete(index)}
                  />
                </div>
              </td>
            </tr>
          ))}
          {selectedFiles.length === 0 && (
            <tr>
              <td
                colSpan={3}
                className="px-4 py-6 text-center text-sm text-gray-500"
              >
                No files uploaded yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};
