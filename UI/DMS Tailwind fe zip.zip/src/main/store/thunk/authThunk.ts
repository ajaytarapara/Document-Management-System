import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import {
  IAccountUser,
  IChangePassword,
  IForgotPassword,
  ILogin,
  IResetPassword,
  ISetupPassword,
  IUserLoginDetailRequestVM,
  IVerifyOTP,
} from "@/main/models";
import { IEncryptedApiResponse, Role } from "@/core/models";
import { axiosInstance, getRoleNumber } from "@/core/utils";

const loginUrl = `${API_URLS.ADMIN.LOGIN}`;
const logoutUrl = `${API_URLS.ADMIN.LOGOUT}`;
const exchangeCodeUrl = `${API_URLS.ADMIN.EXCHANGECODE}`;
const accountDetailUrl = API_URLS.ADMIN.ACCOUNT_DETAIL;
const accountUpdateUrl = API_URLS.ADMIN.UPDATE_ACCOUNT;
const getLast7DaysLoginsUrl = `${API_URLS.ADMIN.GetLast7DaysLogins}`;
const getUserLoginDetailsByDateUrl = `${API_URLS.ADMIN.GetUserLoginDetailsByDAte}`;
const getAllActiveUsersUrl = `${API_URLS.ADMIN.GetAllActiveUsers}`;
const updateAccountPassUrl = API_URLS.ADMIN.UpdateAccountPass;
const getMaxTabLimitApiUrl = `${API_URLS.ADMIN.getMaxTabLimit}`;

// Async thunk action for handling user login, makes POST request to login endpoint

/**
 * Logs in a user.
 * - Sends a POST request with login credentials.
 * - Returns the encrypted API response.
 *
 * @param data - User login credentials.
 */
export const login = createAsyncThunk<IEncryptedApiResponse, ILogin>(
  "auth/login",
  async (data) => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(
      loginUrl,
      data
    );
    return response.data;
  }
);

/**
 * Exchanges an authorization code for an access token.
 * - Sends a POST request with the code as a query parameter.
 * - Returns the encrypted API response.
 *
 * @param code - The authorization code.
 */
export const exchangeCode = createAsyncThunk<
  IEncryptedApiResponse,
  { code: string }
>("exchangeCode", async ({ code }) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    `${exchangeCodeUrl}?code=${code}`
  );
  return res.data;
});

/**
 * Fetches login statistics for the last 7 days.
 * - Sends a GET request with toast notifications disabled.
 * - Returns the encrypted API response.
 */
export const getLast7DaysLogins = createAsyncThunk<IEncryptedApiResponse, void>(
  "getLast7DaysLogins",
  async () => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(
      `${getLast7DaysLoginsUrl}`,
      {
        headers: { showToast: false },
      }
    );
    return res.data;
  }
);

/**
 * Retrieves all currently active users.
 * - Sends a GET request with toast notifications disabled.
 * - Returns the encrypted API response.
 */
export const getAllActiveUsers = createAsyncThunk<IEncryptedApiResponse, void>(
  "getAllActiveUsers",
  async () => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(
      `${getAllActiveUsersUrl}`,
      {
        headers: { showToast: false },
      }
    );
    return res.data;
  }
);

/**
 * Fetches account details for a specific user.
 * - Sends a GET request with userId in the URL.
 * - Returns the encrypted API response.
 *
 * @param userId - The ID of the user whose account details are being retrieved.
 */
export const getAccountDetail = createAsyncThunk<IEncryptedApiResponse, number>(
  "auth/getAccount",
  async (userId) => {
    const response = await axiosInstance.get<IEncryptedApiResponse>(
      accountDetailUrl + `/${userId}`,
      {
        headers: {
          showToast: false,
        },
      }
    );
    return response.data;
  }
);

/**
 * Logs out the currently authenticated user.
 * - Sends a POST request to the logout endpoint.
 * - Returns the encrypted API response.
 */
export const logoutApi = createAsyncThunk<IEncryptedApiResponse>(
  "auth/getAccount",
  async () => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(
      `${logoutUrl}`
    );
    return response.data;
  }
);

/**
 * Updates account details for a user.
 * - Prepares the payload by parsing `postalCode` as an integer and converting the role string to a role number.
 * - Sends a PUT request to the account update endpoint.
 * - Returns the encrypted API response.
 *
 * @param data - Updated account details (`IAccountUser`).
 */
export const updateAccountDetail = createAsyncThunk<
  IEncryptedApiResponse,
  IAccountUser
>("auth/updateAccount", async (data) => {
  const payload = {
    ...data,
    postalCode: parseInt(data.postalCode, 10),
    role: getRoleNumber(data.role as Role),
  };
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    accountUpdateUrl,
    payload
  );
  return response.data;
});

/**
 * Async thunk to fetch user login details for a given date range.
 * - Sends a POST request to `getUserLoginDetailsByDateUrl`.
 * - Passes the payload parameters (date, userId, pagination, and sorting) in the request body.
 * - Suppresses toast notifications via the request headers.
 * - Returns the encrypted API response (`IEncryptedApiResponse`).
 *
 * @param payload - Request parameters including:
 *   - `date`: The specific date or date range filter.
 *   - `userId`: The ID of the user whose login details are being fetched.
 *   - `pageNumber`: The current page number for pagination.
 *   - `pageSize`: The number of records per page.
 *   - `sortBy`: The field to sort by.
 *   - `sortDirection`: The sort order ("asc" or "desc").
 */
export const getUserLoginDetailsByDate = createAsyncThunk<
  IEncryptedApiResponse,
  IUserLoginDetailRequestVM
>("getUserLoginDetailsByDate", async (payload) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    getUserLoginDetailsByDateUrl,
    {
      date: payload.date,
      userId: payload.userId,
      pageNumber: payload.pageNumber,
      pageSize: payload.pageSize,
      sortBy: payload.sortBy,
      sortDirection: payload.sortDirection,
    },
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Updates the account password for the logged-in user.
 * - Sends a PUT request with the new password details.
 * - Returns the encrypted API response.
 *
 * @param data - Change password payload (`IChangePassword`).
 */
export const updateAccountPass = createAsyncThunk<
  IEncryptedApiResponse,
  IChangePassword
>("auth/updatePassAccount", async (data) => {
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    updateAccountPassUrl,
    data
  );
  return response.data;
});

/**
 * Initiates the "forgot password" flow.
 * - Sends a POST request with the user’s email/identifier.
 * - Returns the encrypted API response.
 *
 * @param data - Forgot password payload (`IForgotPassword`).
 */
export const forgotPass = createAsyncThunk<
  IEncryptedApiResponse,
  IForgotPassword
>("auth/forgotpass", async (data) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.ADMIN.ForgotPassword,
    data
  );
  return response.data;
});

/**
 * Verifies the one-time password (OTP) during authentication flows.
 * - Sends a POST request with the OTP and related data.
 * - Returns the encrypted API response.
 *
 * @param data - OTP verification payload (`IVerifyOTP`).
 */
export const verifyOTP = createAsyncThunk<IEncryptedApiResponse, IVerifyOTP>(
  "auth/verifyOTP",
  async (data) => {
    const response = await axiosInstance.post<IEncryptedApiResponse>(
      API_URLS.ADMIN.VerifyOTP,
      data
    );
    return response.data;
  }
);

/**
 * Resets the user’s password after successful OTP verification.
 * - Sends a POST request with reset password data.
 * - Returns the encrypted API response.
 *
 * @param data - Reset password payload (`IResetPassword`).
 */
export const resetPass = createAsyncThunk<
  IEncryptedApiResponse,
  IResetPassword
>("auth/resetPass", async (data) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.ADMIN.ResetPassword,
    data
  );
  return response.data;
});

/**
 * Retrieves the list of sub-users for the current account.
 * - Sends a GET request with toast notifications disabled.
 * - Returns the encrypted API response.
 */
export const getSubUser = createAsyncThunk<IEncryptedApiResponse, null>(
  "auth/sub-users",
  async () => {
    const response = await axiosInstance.get<IEncryptedApiResponse>(
      API_URLS.ADMIN.SubUsers,
      {
        headers: { showToast: false },
      }
    );
    return response.data;
  }
);

/**
 * Starts impersonating a sub-user account.
 * - Sends a POST request with the `subUserId`.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param subUserId - ID of the sub-user to impersonate.
 */
export const impersonateUser = createAsyncThunk<
  IEncryptedApiResponse,
  { subUserId: number }
>("auth/impersonate", async ({ subUserId: number }) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.ADMIN.Impersonate,
    {
      subUserId: number,
    },
    {
      headers: { showToast: false },
    }
  );
  return response.data;
});

/**
 * Stops impersonating a user and reverts back to the original account.
 * - Sends a POST request with the original userId in the URL.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param userId - ID of the original account to switch back to.
 */
export const impersonateStopUser = createAsyncThunk<
  IEncryptedApiResponse,
  number
>("auth/stop-impersonate", async (userId: number) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.ADMIN.stopImpersonate + `/${userId}`,
    {
      headers: { showToast: false },
    }
  );
  return response.data;
});

/**
 * Sets up a new password for a user (e.g., first-time login or invitation).
 * - Sends a POST request with setup password details.
 * - Returns the encrypted API response.
 *
 * @param payload - Setup password data (`ISetupPassword`).
 */
export const SetUpPassword = createAsyncThunk<
  IEncryptedApiResponse,
  ISetupPassword
>("auth/setup-password", async (payload: ISetupPassword) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.ADMIN.setUpPassword,
    payload
  );
  return response.data;
});

/**
 * Fetches the maximum tab limit for a given office user.
 * - Sends a GET request with the officeUserId.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param officeUserId - The office user’s ID.
 */
export const getMaxTabLimitAPI = createAsyncThunk<
  IEncryptedApiResponse,
  { officeUserId: string }
>("getMaxTabLimitAPI", async ({ officeUserId }) => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    `${getMaxTabLimitApiUrl}/${officeUserId}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});
