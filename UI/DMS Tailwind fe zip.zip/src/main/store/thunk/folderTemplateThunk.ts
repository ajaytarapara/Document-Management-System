import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import { axiosInstance } from "@/core/utils";
import { IEncryptedApiResponse } from "@/core/models";
import {
  IAddUserTemplateRequest,
  IUpdateUserTemplateRequest,
  IUserTemplateRequestVM,
} from "@/main/models";

const getAllActiveOfficeUsersUrl = `${API_URLS.ADMIN.GetAllActiveOfficeUsers}`;
const getUserTemplatesByUserIdAsyncUrl = `${API_URLS.ADMIN.GetUserTemplatesByUserIdAsync}`;
const addFolderTemplateUrl = `${API_URLS.ADMIN.AddFolderTemplateUrl}`;
const deleteFolderTemplateUrl = `${API_URLS.ADMIN.DeleteFolderTemplate}`;
const getFolderTemplateByIdUrl = `${API_URLS.ADMIN.GetFolderTemplate}`;
const updateFolderTemplateUrl = `${API_URLS.ADMIN.UpdateFolderTemplateUrl}`;

/**
 * Fetches all active office users.
 * - Sends a GET request to the active office users endpoint.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 */
export const getAllActiveOfficeUsers = createAsyncThunk<
  IEncryptedApiResponse,
  void
>("getAllActiveOfficeUsers", async () => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    `${getAllActiveOfficeUsersUrl}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Fetches user templates for a given user ID with pagination and sorting.
 * - Sends a POST request with userId, pagination, and sorting details.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param payload - User ID and pagination/sorting parameters.
 */
export const getUserTemplatesByUserIdAsync = createAsyncThunk<
  IEncryptedApiResponse,
  IUserTemplateRequestVM
>("getUserTemplatesByUserIdAsync", async (payload) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    getUserTemplatesByUserIdAsyncUrl,
    {
      userId: payload.userId,
      pageNumber: payload.pageNumber,
      pageSize: payload.pageSize,
      sortBy: payload.sortBy,
      sortDirection: payload.sortDirection,
    },
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Adds a new folder template.
 * - Sends a POST request with the template details.
 * - Returns the encrypted API response.
 *
 * @param data - Folder template details.
 */
export const addFolderTemplate = createAsyncThunk<
  IEncryptedApiResponse,
  IAddUserTemplateRequest
>("addFolderTemplate", async (data) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    addFolderTemplateUrl,
    data
  );
  return response.data;
});

/**
 * Deletes a folder template by user ID.
 * - Sends a DELETE request with the userId in the URL.
 * - Returns the encrypted API response.
 *
 * @param userId - The ID of the user whose template should be deleted.
 */
export const deleteFolderTemplate = createAsyncThunk<
  IEncryptedApiResponse,
  string
>("deleteFolderTemplate", async (userId) => {
  const response = await axiosInstance.delete<IEncryptedApiResponse>(
    `${deleteFolderTemplateUrl}/${userId}`
  );
  return response.data;
});

/**
 * Fetches a folder template by ID.
 * - Sends a GET request with the template ID in the URL.
 * - Disables toast notifications.
 * - Returns the encrypted API response.
 *
 * @param id - The folder template ID.
 */
export const getFolderTemplateById = createAsyncThunk<
  IEncryptedApiResponse,
  { id: string }
>("getFolderTemplateById", async ({ id }) => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    `${getFolderTemplateByIdUrl}/${id}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Updates an existing folder template.
 * - Sends a PUT request with updated template details.
 * - Returns the encrypted API response.
 *
 * @param data - Updated folder template details.
 */
export const updateFolderTemplate = createAsyncThunk<
  IEncryptedApiResponse,
  IUpdateUserTemplateRequest
>("updateFolderTemplate", async (data) => {
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    updateFolderTemplateUrl,
    data
  );
  return response.data;
});
