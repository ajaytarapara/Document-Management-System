import { API_URLS } from "@/core/constants";
import {
  IEncryptedApiResponse,
  IRequestUploadDmsForms,
  DmsFormPaginationRequest,
  RenameDmsFormRequest,
  DeleteDmsFormRequest,
  GetDmsFormByIdRequest,
  ShareDmsFormArgs,
} from "@/core/models";
import { axiosInstance } from "@/core/utils";
import { createAsyncThunk } from "@reduxjs/toolkit";

const uploadDmsFormsUrl = `${API_URLS.ADMIN.uploadUserDmsForm}`;
const getAllDmsFormsUrl = `${API_URLS.ADMIN.getUserDmsForm}`;
const renameDmsFormsUrl = `${API_URLS.ADMIN.renameUserDmsForm}`;
const deleteDmsFormsUrl = `${API_URLS.ADMIN.deleteUserDmsForm}`;
const getByIdDmsFormsUrl = `${API_URLS.ADMIN.getByIdUserDmsForm}`;
const shareDmsFormsUrl = `${API_URLS.ADMIN.shareUserDmsForm}`;
const getAllUserSubmittedFormUrl = `${API_URLS.ADMIN.getAllUserSubmittedForms}`;

/**
 * Upload user DMS forms.
 * @param {IRequestUploadDmsForms} request - User ID and forms to upload.
 * @returns {IEncryptedApiResponse} API response.
 */
export const uploadUserDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  IRequestUploadDmsForms
>("userdmsforms/upload", async (request) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    uploadDmsFormsUrl,
    {
      dmsForms: request.forms,
      userId: request.userId,
    }
  );
  return response.data;
});

/**
 * Get all user DMS forms with pagination.
 * @param {DmsFormPaginationRequest} payload - Pagination info and userId.
 * @returns {IEncryptedApiResponse} API response.
 */
export const getAllUserDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  DmsFormPaginationRequest
>("userdmsforms/getAll", async (payload) => {
  const { userId, ...requestBody } = payload;
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    `${getAllDmsFormsUrl}=${userId}`,
    requestBody,
    { headers: { showToast: false } }
  );
  return response.data;
});

/**
 * Rename a user DMS form.
 * @param {RenameDmsFormRequest} param0 - Form ID, new file name, and user ID.
 * @returns {IEncryptedApiResponse} API response.
 */
export const renameUserDmsForm = createAsyncThunk<
  IEncryptedApiResponse,
  RenameDmsFormRequest
>("userdmsforms/rename", async ({ dmsFormId, newFileName, userId }) => {
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    `${renameDmsFormsUrl}=${userId}`,
    { dmsFormId, newFileName }
  );
  return response.data;
});

/**
 * Delete a user DMS form.
 * @param {DeleteDmsFormRequest} payload - Form data to delete.
 * @returns {IEncryptedApiResponse} API response.
 */
export const deleteUserDmsForm = createAsyncThunk<
  IEncryptedApiResponse,
  DeleteDmsFormRequest
>("userdmsforms/delete", async (payload) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    deleteDmsFormsUrl,
    payload
  );
  return response.data;
});

/**
 * Get a user DMS form by ID.
 * @param {GetDmsFormByIdRequest} payload - Form ID and optional filters.
 * @returns {IEncryptedApiResponse} API response with form data.
 */
export const getUserDmsFormById = createAsyncThunk<
  IEncryptedApiResponse,
  GetDmsFormByIdRequest
>("userdmsforms/getById", async (payload) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    getByIdDmsFormsUrl,
    payload,
    { headers: { showToast: false } }
  );
  return response.data;
});

/**
 * Share user DMS forms with provided data.
 * @param {ShareDmsFormArgs} param0 - Form IDs and additional share data.
 * @returns {IEncryptedApiResponse | undefined} API response.
 */
export const shareUserDmsForm = createAsyncThunk<
  IEncryptedApiResponse | undefined,
  ShareDmsFormArgs
>("shareDmsform", async ({ formIds, data }) => {
  const res = await axiosInstance.patch<IEncryptedApiResponse>(
    shareDmsFormsUrl,
    {
      formIds,
      ...data,
    }
  );
  return res.data;
});

/**
 * Get all submitted DMS forms with pagination.
 * @param {DmsFormPaginationRequest} payload - Pagination info + userId.
 * @returns {IEncryptedApiResponse} API response with submitted forms list.
 */
export const getAllSubmittedDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  DmsFormPaginationRequest
>("dmsforms/getAllSubmitted", async (payload) => {
  const { userId } = payload;
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    `${getAllUserSubmittedFormUrl}=${userId}`,
    payload,
    { headers: { showToast: false } }
  );
  return response.data;
});
