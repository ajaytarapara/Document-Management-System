import { API_URLS } from "@/core/constants";
import {
  IEncryptedApiResponse,
  IRequestUploadDmsForms,
  DmsFormPaginationRequest,
  RenameDmsFormRequest,
  DeleteDmsFormRequest,
  GetDmsFormByIdRequest,
  ShareDmsFormArgs,
  SaveEditedFormRequest,
  SubmitEditedFormRequest,
} from "@/core/models";
import { axiosInstance } from "@/core/utils";
import { resolveUrlByRole } from "@/main/components";
import { createAsyncThunk } from "@reduxjs/toolkit";

const uploadDmsFormsUrl = `${API_URLS.ADMIN.uploadDmsForm}`;
const getAllDmsFormsUrl = `${API_URLS.ADMIN.getDmsForm}`;
const renameDmsFormsUrl = `${API_URLS.ADMIN.renameDmsForm}`;
const deleteDmsFormsUrl = `${API_URLS.ADMIN.deleteDmsForm}`;
const getByIdDmsFormsUrl = `${API_URLS.ADMIN.getByIdDmsForm}`;
const shareDmsFormsUrl = `${API_URLS.ADMIN.shareDmsForm}`;
const saveDmsFormsUrl = `${API_URLS.ADMIN.saveDmsForm}`;
const submitEditedFormUrl = `${API_URLS.ADMIN.submitEditedForm}`;
const submitEditedUserDmsFormUrl = `${API_URLS.ADMIN.submitEditedUserDmsForm}`;
const getAllSubmittedFormUrl = `${API_URLS.ADMIN.getAllSubmittedForms}`;
const saveUserDmsFormsUrl = `${API_URLS.ADMIN.saveUserDmsForm}`;

/**
 * Upload DMS forms for a user.
 * @param {IRequestUploadDmsForms} request - Forms and userId to upload.
 * @returns {IEncryptedApiResponse} API response with status/data.
 */
export const uploadDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  IRequestUploadDmsForms
>("dmsforms/upload", async (request) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    uploadDmsFormsUrl,
    {
      dmsForms: request.forms,
      userId: request.userId,
    }
  );
  return response.data;
});

/**
 * Fetch all DMS forms with pagination for a user.
 * @param {DmsFormPaginationRequest} payload - Pagination info + userId.
 * @returns {IEncryptedApiResponse} API response with forms list.
 */
export const getAllDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  DmsFormPaginationRequest
>("dmsforms/getAll", async (payload) => {
  const { userId, ...requestBody } = payload;
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    `${getAllDmsFormsUrl}=${userId}`,
    requestBody,
    { headers: { showToast: false } }
  );
  return response.data;
});

/**
 * Rename a DMS form.
 * @param {RenameDmsFormRequest} param0 - Contains dmsFormId, newFileName, userId.
 * @returns {IEncryptedApiResponse} API response.
 */
export const renameDmsForm = createAsyncThunk<
  IEncryptedApiResponse,
  RenameDmsFormRequest
>("dmsforms/rename", async ({ dmsFormId, newFileName, userId }) => {
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    `${renameDmsFormsUrl}=${userId}`,
    { dmsFormId, newFileName }
  );
  return response.data;
});

/**
 * Delete a DMS form.
 * @param {DeleteDmsFormRequest} payload - DMS form details to delete.
 * @returns {IEncryptedApiResponse} API response.
 */
export const deleteDmsForm = createAsyncThunk<
  IEncryptedApiResponse,
  DeleteDmsFormRequest
>("dmsforms/delete", async (payload) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    deleteDmsFormsUrl,
    payload
  );
  return response.data;
});

/**
 * Get DMS form by ID.
 * @param {GetDmsFormByIdRequest} payload - Form ID and optional filters.
 * @returns {IEncryptedApiResponse} API response with form data.
 */
export const getDmsFormById = createAsyncThunk<
  IEncryptedApiResponse,
  GetDmsFormByIdRequest
>("dmsforms/getById", async (payload) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    getByIdDmsFormsUrl,
    payload,
    { headers: { showToast: false } }
  );
  return response.data;
});

/**
 * Share selected DMS forms with provided data.
 * @param {ShareDmsFormArgs} param0 - Contains formIds and additional data.
 * @returns {IEncryptedApiResponse | undefined} API response.
 */
export const shareDmsForm = createAsyncThunk<
  IEncryptedApiResponse | undefined,
  ShareDmsFormArgs
>("shareDmsform", async ({ formIds, data }) => {
  const res = await axiosInstance.patch<IEncryptedApiResponse>(
    shareDmsFormsUrl,
    { formIds, ...data }
  );
  return res.data;
});

/**
 * Save edited DMS form.
 * @param {SaveEditedFormRequest} payload - Edited form data and userRole.
 * @returns {IEncryptedApiResponse} API response.
 */
export const saveEditedForm = createAsyncThunk<
  IEncryptedApiResponse,
  SaveEditedFormRequest
>("dmsforms/saveEditedForm", async (payload) => {
  const url = resolveUrlByRole(
    String(payload.userRole),
    saveDmsFormsUrl,
    saveUserDmsFormsUrl
  );
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    url,
    payload
  );
  return response.data;
});

/**
 * Submit an edited DMS form.
 * @param {SubmitEditedFormRequest} payload - Edited form data and userRole.
 * @returns {IEncryptedApiResponse} API response.
 */
export const submitEditedForm = createAsyncThunk<
  IEncryptedApiResponse,
  SubmitEditedFormRequest
>("dmsforms/submitEditedForm", async (payload) => {
  const url = resolveUrlByRole(
    String(payload.userRole),
    submitEditedFormUrl,
    submitEditedUserDmsFormUrl
  );
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    url,
    payload
  );
  return response.data;
});

/**
 * Get all submitted DMS forms with pagination.
 * @param {DmsFormPaginationRequest} payload - Pagination info + userId.
 * @returns {IEncryptedApiResponse} API response with submitted forms list.
 */
export const getAllSubmittedDmsForms = createAsyncThunk<
  IEncryptedApiResponse,
  DmsFormPaginationRequest
>("dmsforms/getAllSubmitted", async (payload) => {
  const { userId, ...requestBody } = payload;
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    `${getAllSubmittedFormUrl}=${userId}`,
    requestBody,
    { headers: { showToast: false } }
  );
  return response.data;
});
