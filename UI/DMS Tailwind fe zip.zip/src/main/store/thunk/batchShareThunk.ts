import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import { axiosInstance } from "@/core/utils";
import { IEncryptedApiResponse } from "@/core/models";
import { IBatchShareFileRequest, IBatchShareRequestDto } from "@/main/models";

const getAllActiveFolderListUrl = `${API_URLS.USER.GET_ALL_BATCH_FOLDER_LIST}`;
const getAllActiveFolderTabListUrl = `${API_URLS.USER.GET_ALL_BATCH_FOLDER_TAB_LIST}`;
const getFileByTabIdURL = `${API_URLS.USER.GET_FILE_BY_TAB_ID}`;
const batchShareFilesAPIUrl = `${API_URLS.USER.SHARE_MUL_BATCH_FILE}`;

/**
 * Thunk to retrieve the full list of active folders.
 *
 * - Sends a GET request to the backend API.
 * - Suppresses toast notifications via request headers.
 * - Expects an encrypted API response containing the folder list.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const getAllBatchFolderList = createAsyncThunk<
  IEncryptedApiResponse,
  void
>("getAllFolderList", async () => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    `${getAllActiveFolderListUrl}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Thunk to retrieve the list of tabs for a specific folder.
 *
 * - Sends a GET request to the backend API with the folder ID.
 * - Expects an encrypted API response containing the folder’s tab list.
 *
 * @param folderId - The ID of the folder whose tabs are being requested.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const getAllBatchFolderTabList = createAsyncThunk<
  IEncryptedApiResponse,
  string
>("getAllFolderTabList", async (folderId) => {
  const response = await axiosInstance.get<IEncryptedApiResponse>(
    `${getAllActiveFolderTabListUrl}/${folderId}`,
    {
      headers: { showToast: false },
    }
  );
  return response.data;
});

/**
 * 📂 Retrieves files inside a specific tab.
 * - Supports pagination, sorting, and search.
 * - Disables toast notifications in headers.
 * - Returns the encrypted API response.
 *
 * @param page - Current page number.
 * @param pageSize - Number of items per page.
 * @param sortDirection - Sorting order ("asc" / "desc").
 * @param sortColumn - Column to sort by.
 * @param searchTerm - Search keyword.
 * @param id - Tab ID.
 */
export const getFileByTabId = createAsyncThunk<
  IEncryptedApiResponse,
  IBatchShareFileRequest
>("getFileByTabs", async (payload) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    getFileByTabIdURL,
    payload,
    {
      headers: {
        showToast: false,
      },
    }
  );
  return res.data;
});

/**
 * 🤝📦 Shares multiple files at once.
 * - Sends a POST request with file list and permissions.
 * - Returns the encrypted API response.
 *
 * @param data - Share multiple files payload.
 */
export const batchShareFiles = createAsyncThunk<
  IEncryptedApiResponse,
  IBatchShareRequestDto
>("batchShareFile", async (data) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    batchShareFilesAPIUrl,
    data
  );
  return res.data;
});
