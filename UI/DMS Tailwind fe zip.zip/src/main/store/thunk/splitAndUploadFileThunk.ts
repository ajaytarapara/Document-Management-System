import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import { axiosInstance } from "@/core/utils";
import { IEncryptedApiResponse, IPaginatedRequest } from "@/core/models";
import {
  ISplitPdfRequest,
  IUpdateFileNameForSplitRequest,
  IUploadFileForSplitRequest,
} from "@/main/models";

const uploadFileForSplitUrl = `${API_URLS.USER.UPLOAD_FILE_FOR_SPLIT}`;
const getAllUploadedFileForSplitUrl = `${API_URLS.USER.GET_UPLOADED_FILE_FOR_SPLIT}`;
const deleteUploadedFileUrl = `${API_URLS.USER.DELETE_UPLOADED_FILE_FOR_SPLIT}`;
const updateUploadedFileForSplitUrl = `${API_URLS.USER.UPDATE_UPLOAD_FILE_FOR_SPLIT}`;
const getAllActiveFolderListUrl = `${API_URLS.USER.GET_ALL_FOLDER_LIST}`;
const getAllActiveFolderTabListUrl = `${API_URLS.USER.GET_ALL_FOLDER_TAB_LIST}`;
const splitAndReplaceUrl = `${API_URLS.USER.SPLIT_AND_REPLACE}`;

/**
 * Thunk to upload files for splitting.
 *
 * - Sends a POST request with the given file upload request payload.
 * - Expects an encrypted API response from the server.
 *
 * @param data - The file upload request payload containing files and metadata.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const uploadFileForSplit = createAsyncThunk<
  IEncryptedApiResponse,
  IUploadFileForSplitRequest
>("uploadFileForSplit", async (data) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    uploadFileForSplitUrl,
    data
  );
  return response.data;
});

/**
 * Thunk to fetch all uploaded files for splitting with pagination support.
 *
 * - Sends a GET request to retrieve paginated file records.
 * - Accepts page number, page size, sorting field, and sorting direction as query parameters.
 * - Suppresses toast notifications via the request headers.
 *
 * @param payload - The pagination and sorting parameters.
 *
 * @returns A promise resolving to the encrypted API response containing the files.
 */
export const getAllUploadedFileForSplit = createAsyncThunk<
  IEncryptedApiResponse,
  IPaginatedRequest
>("getAllUploadedFileForSplit", async (payload) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    `${getAllUploadedFileForSplitUrl}`,
    {
      pageNumber: payload.pageNumber,
      pageSize: payload.pageSize,
      sortBy: payload.sortBy,
      sortDirection: payload.sortDirection,
      searchTerm: payload.searchTerm,
    },
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

/**
 * Thunk to delete an uploaded file by its ID.
 *
 * - Sends a DELETE request to the backend API with the given file ID.
 * - Expects an encrypted API response confirming the deletion.
 *
 * @param id - The numeric ID of the file to delete.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const deleteUploadedFile = createAsyncThunk<
  IEncryptedApiResponse,
  string
>("deleteUploadedFile", async (id) => {
  const response = await axiosInstance.delete<IEncryptedApiResponse>(
    `${deleteUploadedFileUrl}/${id}`
  );
  return response.data;
});

/**
 * Thunk to update the name of an uploaded file for splitting.
 *
 * - Sends a PUT request with the updated file name payload.
 * - Expects an encrypted API response from the server.
 *
 * @param data - The request payload containing the file ID and the new name.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const updateUploadedFileForSplit = createAsyncThunk<
  IEncryptedApiResponse,
  IUpdateFileNameForSplitRequest
>("updateUploadedFileForSplit", async (data) => {
  const response = await axiosInstance.put<IEncryptedApiResponse>(
    updateUploadedFileForSplitUrl,
    data
  );
  return response.data;
});

/**
 * Thunk to retrieve the full list of active folders.
 *
 * - Sends a GET request to the backend API.
 * - Suppresses toast notifications via request headers.
 * - Expects an encrypted API response containing the folder list.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const getAllFolderList = createAsyncThunk<IEncryptedApiResponse, void>(
  "getAllFolderList",
  async () => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(
      `${getAllActiveFolderListUrl}`,
      {
        headers: { showToast: false },
      }
    );
    return res.data;
  }
);

/**
 * Thunk to retrieve the list of tabs for a specific folder.
 *
 * - Sends a GET request to the backend API with the folder ID.
 * - Expects an encrypted API response containing the folder’s tab list.
 *
 * @param folderId - The ID of the folder whose tabs are being requested.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const getAllFolderTabList = createAsyncThunk<
  IEncryptedApiResponse,
  string
>("getAllFolderTabList", async (folderId) => {
  const response = await axiosInstance.get<IEncryptedApiResponse>(
    `${getAllActiveFolderTabListUrl}/${folderId}`,
    {
      headers: { showToast: false },
    }
  );
  return response.data;
});

/**
 * Thunk to split a PDF and replace the original file with the split version.
 *
 * - Sends a POST request with the split PDF request payload.
 * - Expects an encrypted API response confirming the operation.
 *
 * @param data - The split PDF request payload, including file ID and page ranges.
 *
 * @returns A promise resolving to the encrypted API response from the server.
 */
export const splitAndReplace = createAsyncThunk<
  IEncryptedApiResponse,
  ISplitPdfRequest
>("splitAndReplace", async (data) => {
  const response = await axiosInstance.post<IEncryptedApiResponse>(
    splitAndReplaceUrl,
    data
  );
  return response.data;
});
