import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import { axiosInstance } from "@/core/utils";
import { IEncryptedApiResponse } from "@/core/models";
import { IFileRecordStatsRequest } from "@/main/models";

const getOfficeUserAnalyticsDataUrl = `${API_URLS.ADMIN.GetOfficeUserAnalyticsData}`;

/**
 * Redux async thunk to fetch office user analytics data from the API.
 *
 * This function sends a POST request with the provided payload
 * (`IFileRecordStatsRequest`) in the request body to the
 * `getOfficeUserAnalyticsDataUrl` endpoint.
 *
 * @param payload - The request data containing date range type, office user ID,
 *                  and optional custom start/end dates.
 * @returns A promise that resolves to `IEncryptedApiResponse` containing
 *          the analytics data.
 */
export const getOfficeUserAnalyticsData = createAsyncThunk<
  IEncryptedApiResponse,
  IFileRecordStatsRequest
>("getOfficeUserAnalyticsData", async (payload) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    getOfficeUserAnalyticsDataUrl,
    payload,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});
