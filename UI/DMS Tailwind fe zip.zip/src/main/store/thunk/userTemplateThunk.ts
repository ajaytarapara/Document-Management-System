import { createAsyncThunk } from "@reduxjs/toolkit";
import { API_URLS } from "@/core/constants";
import { axiosInstance } from "@/core/utils";
import { IEncryptedApiResponse } from "@/core/models";
import {
  IAddFolderTabRequestVM,
  IAddTemplateTabRequestVM,
} from "@/main/models";

export const getAllUserTemplate = createAsyncThunk<IEncryptedApiResponse, null>(
  "get/userTemplate",
  async () => {
    const res = await axiosInstance.get<IEncryptedApiResponse>(
      API_URLS.USER.GET_USER_TEMPLATE,
      {
        headers: { showToast: false },
      }
    );
    return res.data;
  }
);

export const getUserTemplateTabs = createAsyncThunk<
  IEncryptedApiResponse,
  string
>("get/userTemplateTabs", async (tempId: string) => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    API_URLS.USER.GET_USER_TEMPLATE_TABS + `${tempId}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

export const addUserTemplateTabs = createAsyncThunk<
  IEncryptedApiResponse,
  IAddTemplateTabRequestVM
>("get/addUserTemplateTabs", async (tabs: IAddTemplateTabRequestVM) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.USER.ADD_TEMPLATE_TABS,
    tabs
  );
  return res.data;
});

export const getFoldersAvailable = createAsyncThunk<
  IEncryptedApiResponse,
  { templateId: string; newTabCount: number }
>("get/getFoldersAvailable", async ({ templateId, newTabCount }) => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    `${API_URLS.USER.GET_FOLDERS_AVAILABLE_TAB}/${templateId}/${newTabCount}`,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

export const addFolderTabs = createAsyncThunk<
  IEncryptedApiResponse,
  IAddFolderTabRequestVM
>("get/addFolderTemplateTabs", async (tabs: IAddFolderTabRequestVM) => {
  const res = await axiosInstance.post<IEncryptedApiResponse>(
    API_URLS.USER.ADD_FOLDER_TABS,
    tabs,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});

export const getAllUserTemplateAvailableToAdd = createAsyncThunk<
  IEncryptedApiResponse,
  null
>("get/userTemplateAvailableToAdd", async () => {
  const res = await axiosInstance.get<IEncryptedApiResponse>(
    API_URLS.USER.GET_USER_TEMPLATE_AVAILABLE_ADD,
    {
      headers: { showToast: false },
    }
  );
  return res.data;
});
