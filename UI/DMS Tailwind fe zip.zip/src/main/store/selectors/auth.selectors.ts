"use client";

import { useAppSelector } from "@/main/hooks";
import { RootState } from "../types";
import { IAuthState } from "@/main/models";

export const useSelectorAuthState = (): IAuthState =>
  useAppSelector((state: RootState) => state.auth);
