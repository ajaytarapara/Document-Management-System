"use client";

import { useAppSelector } from "@/main/hooks";
import { RootState } from "../types";
import { ILoaderState } from "@/core/models";

export const useSelectorLoaderState = (): ILoaderState =>
  useAppSelector((state: RootState) => state.loader);
