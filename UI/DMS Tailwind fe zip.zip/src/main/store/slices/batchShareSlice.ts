import { IBatchShareTabAndFileResponse } from "@/main/models";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface BatchShareState {
  selectedFilesByFolderAndTab: Record<
    string, // folderId
    Record<string, IBatchShareTabAndFileResponse[]> // tabId -> files
  >;
}

const initialState: BatchShareState = {
  selectedFilesByFolderAndTab: {},
};

interface FileSelectionPayload {
  folderId: string;
  tabId: string;
  files?: IBatchShareTabAndFileResponse[];
  file?: IBatchShareTabAndFileResponse;
}

const batchShareSlice = createSlice({
  name: "batchShare",
  initialState,
  reducers: {
    setSelectedIdsForTab: (
      state,
      action: PayloadAction<FileSelectionPayload>
    ) => {
      const { folderId, tabId, files = [] } = action.payload;
      if (!state.selectedFilesByFolderAndTab[folderId]) {
        state.selectedFilesByFolderAndTab[folderId] = {};
      }
      state.selectedFilesByFolderAndTab[folderId][tabId] = files;
    },
    toggleFileForTab: (state, action: PayloadAction<FileSelectionPayload>) => {
      const { folderId, tabId, file } = action.payload;
      if (!file) return;

      if (!state.selectedFilesByFolderAndTab[folderId]) {
        state.selectedFilesByFolderAndTab[folderId] = {};
      }
      const current = state.selectedFilesByFolderAndTab[folderId][tabId] || [];

      const exists = current.some((f) => f.id === file.id);

      if (exists) {
        state.selectedFilesByFolderAndTab[folderId][tabId] = current.filter(
          (f) => f.id !== file.id
        );
      } else {
        state.selectedFilesByFolderAndTab[folderId][tabId] = [...current, file];
      }
    },
    clearSelectionForTab: (
      state,
      action: PayloadAction<{ folderId: string; tabId: string }>
    ) => {
      if (state.selectedFilesByFolderAndTab[action.payload.folderId]) {
        state.selectedFilesByFolderAndTab[action.payload.folderId][
          action.payload.tabId
        ] = [];
      }
    },
    clearSelectionForFolder: (state, action: PayloadAction<string>) => {
      delete state.selectedFilesByFolderAndTab[action.payload];
    },
    clearAllSelections: (state) => {
      state.selectedFilesByFolderAndTab = {};
    },
  },
});

export const {
  setSelectedIdsForTab,
  toggleFileForTab,
  clearSelectionForTab,
  clearSelectionForFolder,
  clearAllSelections,
} = batchShareSlice.actions;

export const batchShareReducer = batchShareSlice.reducer;
