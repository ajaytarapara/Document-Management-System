import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IAuthState, ISubUser } from "@/main/models";
import { exchangeCode, login } from "../thunk/authThunk";

const initialState: IAuthState = {
  loggedInUser: "",
  userName: "",
  subUsers: [],
  currentUser: {} as ISubUser,
  originalUser: {} as ISubUser,
};

const AuthSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout: (state) => {
      state.loggedInUser = "";
      state.subUsers = [];
      state.currentUser = {} as ISubUser;
      state.originalUser = {} as ISubUser;
    },
    setUserName: (state, action: PayloadAction<string>) => {
      state.userName = action.payload;
    },
    setSubUser: (state, action: PayloadAction<ISubUser[]>) => {
      state.subUsers = action.payload;
    },
    setCurrentUser: (state, action: PayloadAction<ISubUser>) => {
      state.currentUser = action.payload;
    },
    setOriginalUser: (state, action: PayloadAction<ISubUser>) => {
      state.originalUser = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.fulfilled, (state, action) => {
        if (action.payload) {
          state.loggedInUser = action.payload.data;
        }
      })
      .addCase(login.rejected, (_state, action) => {
        console.log(action);
      })
      .addCase(exchangeCode.fulfilled, (state, action) => {
        if (action.payload) {
          state.loggedInUser = action.payload.data;
        }
      })
      .addCase(exchangeCode.rejected, (_state, action) => {
        console.log(action);
      });
  },
});

export const {
  logout,
  setUserName,
  setSubUser,
  setCurrentUser,
  setOriginalUser,
} = AuthSlice.actions;
export const authReducer = AuthSlice.reducer;
