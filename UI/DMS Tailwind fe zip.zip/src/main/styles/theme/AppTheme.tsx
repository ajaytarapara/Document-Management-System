"use client";
import React from "react";
import { ThemeProvider } from "next-themes";
import clsx from "clsx";

interface AppThemeProps {
  children: React.ReactNode;
  disableCustomTheme?: boolean;
}

export const AppTheme: React.FC<AppThemeProps> = ({
  children,
  disableCustomTheme,
}) => {
  return (
    <ThemeProvider attribute="class" disableTransitionOnChange>
      <div className={clsx(disableCustomTheme ? "" : "theme-custom h-[100vh]")}>
        {children}
      </div>
    </ThemeProvider>
  );
};
