import { NextResponse, NextRequest } from "next/server";
import { ROUTES } from "@/core/constants/PAGE_URLS";
import { Role } from "@/core/models";
import { decodeJwt, isTokenExpired, ROLE_CLAIM_URI } from "@/core/utils";

// Define which routes are accessible for each user role
const roleRoutes: Record<string, string[]> = {
  [Role.Admin]: [
    ROUTES.ADMIN.DASHBOARD,
    ROUTES.ADMIN.ACCOUNT,
    ROUTES.ADMIN.VIEW_USER,
    ROUTES.ADMIN.CHANGE_PASSWORD,
    ROUTES.ADMIN.FOLDER_TEMPLATES,
    ROUTES.ADMIN.ADD_EDIT_FOLDER_TEMPLATES,
    ROUTES.ADMIN.USER_LOGIN,
    ROUTES.ADMIN.UPDATE_USER,
    ROUTES.ADMIN.DMS_FORMS,
    ROUTES.SET_UP_PASSWORD,
    ROUTES.ADMIN.OFFICE_USER_ANALYTICS,
    ROUTES.ADMIN.SUB_USER_ANALYTICS,
  ],
  [Role.Office_User]: [
    ROUTES.OFFICE_USER.DASHBOARD,
    ROUTES.OFFICE_USER.ACCOUNT,
    ROUTES.OFFICE_USER.CHANGE_PASSWORD,
    ROUTES.OFFICE_USER.CREATE_FOLDER,
    ROUTES.OFFICE_USER.VIEW_FOLDER,
    ROUTES.OFFICE_USER.VIEW_USER,
    ROUTES.OFFICE_USER.FILE,
    ROUTES.OFFICE_USER.SHARE_FOLDER,
    ROUTES.OFFICE_USER.UPDATE_USER,
    ROUTES.OFFICE_USER.DMS_FORMS,
    ROUTES.OFFICE_USER.ADD_TABS,
    ROUTES.SET_UP_PASSWORD,
    ROUTES.OFFICE_USER.SPLIT_AND_UPLOAD,
    ROUTES.OFFICE_USER.SHARE_DMS_FORM,
    ROUTES.OFFICE_USER.BATCH_SHARE,
    ROUTES.OFFICE_USER.PREVIEW_FOLDER,
    ROUTES.PREVIEW_FILE,
    ROUTES.PREVIEW_TAB,
  ],
  [Role.User]: [
    ROUTES.USER.DASHBOARD,
    ROUTES.USER.CREATE_FOLDER,
    ROUTES.USER.BATCH_SHARE,
    ROUTES.USER.VIEW_FOLDER,
    ROUTES.USER.ACCOUNT,
    ROUTES.USER.SHARE_FOLDER,
    ROUTES.USER.ADD_TABS,
    ROUTES.USER.CHANGE_PASSWORD,
    ROUTES.SET_UP_PASSWORD,
    ROUTES.USER.SPLIT_AND_UPLOAD,
    ROUTES.USER.DMS_FORMS,
    ROUTES.USER.PREVIEW_FOLDER,
    ROUTES.PREVIEW_FILE,
    ROUTES.PREVIEW_TAB,
    ROUTES.USER.SHARE_DMS_FORM,
  ],
};

// Default redirect per role
const defaultRoutes: Record<string, string> = {
  [Role.Admin]: ROUTES.ADMIN.DASHBOARD,
  [Role.Office_User]: ROUTES.OFFICE_USER.DASHBOARD,
  [Role.User]: ROUTES.USER.DASHBOARD,
};

// Public routes (no auth needed)
const publicRoutes = [
  ROUTES.LOGIN,
  ROUTES.HOME,
  ROUTES.SHARE_FOLDER,
  ROUTES.FORGOT_PASSWORD,
  ROUTES.VERIFY_OTP,
  ROUTES.RESET_PASSWORD,
  ROUTES.PREVIEW_FOLDER,
  ROUTES.PREVIEW_FILE,
  ROUTES.PREVIEW_TAB,
  ROUTES.SHARE_DMS_FORM,
];

export async function middleware(request: NextRequest) {
  const currentPath = request.nextUrl.pathname;
  const isPublicRoute = publicRoutes.includes(currentPath);

  const token = request.cookies.get("token")?.value;
  const isFirstTimeLogin =
    request.cookies.get("isFirstTimeLogin")?.value === "true";

  // If not logged in, only allow public routes
  if (!token || isTokenExpired(token)) {
    if (!isPublicRoute) {
      return NextResponse.redirect(new URL(ROUTES.LOGIN, request.url));
    }
    return NextResponse.next();
  }

  const payload = decodeJwt(token);
  const userRole = payload?.[ROLE_CLAIM_URI];

  if (!userRole || !(userRole in roleRoutes)) {
    return NextResponse.redirect(new URL(ROUTES.LOGIN, request.url));
  }

  const defaultRedirect = defaultRoutes[userRole];
  const allowedRoutes = roleRoutes[userRole];

  const changePasswordRoute = {
    [Role.Admin]: ROUTES.SET_UP_PASSWORD,
    [Role.Office_User]: ROUTES.SET_UP_PASSWORD,
    [Role.User]: ROUTES.SET_UP_PASSWORD,
  }[userRole];

  const isOnChangePasswordPage = currentPath === changePasswordRoute;
  // Enforce first-time login: allow ONLY the change-password route
  if (isFirstTimeLogin) {
    if (!isOnChangePasswordPage) {
      return NextResponse.redirect(
        new URL(ROUTES.SET_UP_PASSWORD, request.url)
      );
    }
  } else {
    // Prohibit access to SET_UP_PASSWORD for users who are not first-time login
    if (isOnChangePasswordPage) {
      return NextResponse.redirect(new URL(defaultRedirect, request.url));
    }
  }

  // Allow Share Folder route if unauthenticated or allowed role
  if (
    currentPath === ROUTES.SHARE_FOLDER ||
    currentPath === ROUTES.SHARE_DMS_FORM ||
    currentPath === ROUTES.USER.SHARE_DMS_FORM ||
    currentPath === ROUTES.PREVIEW_FOLDER ||
    currentPath === ROUTES.PREVIEW_FILE ||
    currentPath === ROUTES.PREVIEW_TAB ||
    currentPath === ROUTES.SHARE_DMS_FORM
  ) {
    if (!token || userRole === Role.Office_User || userRole === Role.User) {
      return NextResponse.next();
    }
    return NextResponse.redirect(new URL(defaultRedirect, request.url));
  }

  // Prevent logged-in users from accessing public routes (e.g., login)
  if (isPublicRoute) {
    return NextResponse.redirect(new URL(defaultRedirect, request.url));
  }

  // Prevent user from accessing routes outside their role
  const isAllowed = allowedRoutes.some((route) =>
    currentPath.startsWith(route)
  );
  if (!isAllowed) {
    return NextResponse.redirect(new URL(defaultRedirect, request.url));
  }

  return NextResponse.next(); // Everything valid — allow access
}

// Match routes where middleware runs
export const config = {
  matcher: [
    "/",
    "/auth/:path*",
    "/admin/:path*",
    "/user/:path*",
    "/office-user/:path*",
    "/subUser/:path*",
  ],
};
