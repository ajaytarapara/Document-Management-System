namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel used to update account user details.
    /// </summary>
    public class UpdateAccountUserRequestVM
    {
        /// <summary>
        /// The unique identifier of the user.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The first name of the user.
        /// </summary>
        public string FirstName { get; set; } = null!;

        /// <summary>
        /// The last name of the user.
        /// </summary>
        public string LastName { get; set; } = null!;

        /// <summary>
        /// The email address of the user.
        /// </summary>
        public string Email { get; set; } = null!;

        /// <summary>
        /// The role assigned to the user.
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// The username of the user.
        /// </summary>
        public string UserName { get; set; } = null!;

        /// <summary>
        /// The residential address of the user.
        /// </summary>
        public string Address { get; set; } = null!;

        /// <summary>
        /// The postal code of the user's address.
        /// </summary>
        public int PostalCode { get; set; }

        /// <summary>
        /// The phone number of the user.
        /// </summary>
        public string PhoneNumber { get; set; } = null!;

        /// <summary>
        /// The city of residence for the user.
        /// </summary>
        public string? City { get; set; }

        /// <summary>
        /// The login type used by the user (e.g., local, external).
        /// </summary>
        public string? LoginType { get; set; }
    }
}
