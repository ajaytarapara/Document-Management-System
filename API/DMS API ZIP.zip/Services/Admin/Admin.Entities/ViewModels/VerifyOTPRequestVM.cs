namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel for verifying a user's One-Time Password (OTP)
    /// during password reset or authentication processes.
    /// </summary>
    public class VerifyOTPRequestVM
    {
        /// <summary>
        /// The username of the user attempting to verify the OTP.
        /// </summary>
        public string Username { get; set; } = string.Empty;

        /// <summary>
        /// The one-time password sent to the user for verification.
        /// </summary>
        public string Otp { get; set; } = string.Empty;
    }
}