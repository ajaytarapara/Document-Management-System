namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel for handling password reset requests.
    /// </summary>
    public class ResetPasswordRequestVM
    {
        /// <summary>
        /// The new password to be set by the user.
        /// </summary>
        public string NewPassword { get; set; } = string.Empty;

        /// <summary>
        /// Confirmation of the new password to ensure it matches.
        /// </summary>
        public string ConfirmPassword { get; set; } = string.Empty;

        /// <summary>
        /// The username of the account for which the password is being reset.
        /// </summary>
        public string Username { get; set; } = string.Empty;
    }
}