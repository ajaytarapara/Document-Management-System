namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel representing a request to change a user's password.
    /// </summary>
    public class ChangePasswordRequestVM
    {
        /// <summary>
        /// Gets or sets the user's current password.
        /// </summary>
        public string CurrentPassword { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the new password the user wants to set.
        /// </summary>
        public string NewPassword { get; set; } = string.Empty;
    }
}