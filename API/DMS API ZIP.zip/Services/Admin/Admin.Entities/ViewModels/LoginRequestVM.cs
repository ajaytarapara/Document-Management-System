using Shared.ViewModels.Base;

namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel representing a login request containing username and password.
    /// </summary>

    public class LoginRequestVM
    {
        /// <summary>
        /// The username provided by the user for login.
        /// </summary>
        public string Username { get; set; } = string.Empty;

        /// <summary>
        /// The password provided by the user for authentication.
        /// </summary>
        public string Password { get; set; } = string.Empty;
    }
}