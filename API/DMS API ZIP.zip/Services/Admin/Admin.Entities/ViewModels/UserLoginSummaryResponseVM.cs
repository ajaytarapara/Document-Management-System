namespace Admin.Entities.ViewModels
{
    public class UserLoginSummaryResponseVM
    {
        public List<UserLoginSummaryVM> userLoginSummaryVMs { get; set; } = new();
    }

    public class UserLoginSummaryVM
    {
        public DateTime Date { get; set; }
        public string Day { get; set; }
        public int LoginCount { get; set; }
    }
}