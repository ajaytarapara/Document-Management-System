namespace Admin.Entities.ViewModels.FolderTemplate
{
    public class UserTemplateRequest : PaginatedRequest
    {
        public string userId { get; set; }
    }
}