namespace Admin.Entities.ViewModels.FolderTemplate
{
    public class AddUserTemplateRequest
    {
        public string UserId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string TabsCount { get; set; } = "0";
        public List<UserTemplateTabRequest> Tabs { get; set; } = new();
    }

    public class UserTemplateTabRequest
    {
        public string Name { get; set; } = string.Empty;
        public string Color { get; set; } = string.Empty;
        public bool IsLock { get; set; } = false;
    }
}