namespace Admin.Entities.ViewModels.FolderTemplate
{
    public class UserTemplateResponseWithTabsVM
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string TabsCount { get; set; } = string.Empty;
        public List<UserTemplateTabResponse> Tabs { get; set; } = new();
    }
    public class UserTemplateTabResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Color { get; set; } = string.Empty;
        public bool IsLock { get; set; }
    }
}