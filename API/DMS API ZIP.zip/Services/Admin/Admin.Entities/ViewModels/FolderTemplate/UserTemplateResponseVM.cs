namespace Admin.Entities.ViewModels.FolderTemplate
{
    public class UserTemplateResponseVM
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string TabsCount { get; set; } = string.Empty;
    }

}