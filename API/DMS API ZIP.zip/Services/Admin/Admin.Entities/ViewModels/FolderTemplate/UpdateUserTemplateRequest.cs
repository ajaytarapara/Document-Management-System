namespace Admin.Entities.ViewModels.FolderTemplate
{
    public class UpdateUserTemplateRequest
    {
        public string Id { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string TabsCount { get; set; } = "0";
        public List<UserTemplateTabRequest> Tabs { get; set; } = new();
    }
}