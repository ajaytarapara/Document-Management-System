namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel representing the data required to set up a new password.
    /// </summary>
    public class SetUpPasswordRequestVM
    {
        /// <summary>
        /// The new password the user wants to set.
        /// </summary>
        public string NewPassword { get; set; } = string.Empty;

        /// <summary>
        /// The confirmation of the new password to ensure accuracy.
        /// </summary>
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
