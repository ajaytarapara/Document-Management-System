namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel representing the response returned after a successful login.
    /// </summary>
    public class LoginResponseVM
    {
        /// <summary>
        /// The unique identifier of the user.
        /// </summary>
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// The email address associated with the user.
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// The username used by the user.
        /// </summary>
        public string Username { get; set; } = string.Empty;

        /// <summary>
        /// The authentication token generated after login.
        /// </summary>
        public string Token { get; set; } = string.Empty;

        /// <summary>
        /// The full name of the user.
        /// </summary>
        public string FullName { get; set; } = string.Empty;

        /// <summary>
        /// The role assigned to the user (e.g., Admin, User).
        /// </summary>
        public string Role { get; set; } = string.Empty;

        /// <summary>
        /// Indicates whether the user is logging in for the first time.
        /// Used to determine if password setup is required.
        /// </summary>
        public bool IsFirstTimeLogin { get; set; }

    }
}