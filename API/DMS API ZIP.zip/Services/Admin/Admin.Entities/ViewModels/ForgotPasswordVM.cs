namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel for initiating a forgot password request.
    /// </summary>
    public class ForgotPasswordVM
    {
        /// <summary>
        /// The username of the account for which the password reset process is being initiated.
        /// </summary>
        public string Username { get; set; } = string.Empty;
    }
}