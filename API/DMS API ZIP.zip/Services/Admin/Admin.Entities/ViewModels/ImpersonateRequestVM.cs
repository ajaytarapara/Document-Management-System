namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel used to initiate an impersonation request for a specific sub-user.
    /// </summary>
    public class ImpersonateRequestVM
    {
        /// <summary>
        /// The unique identifier of the sub-user to impersonate.
        /// </summary>
        public int SubUserId { get; set; }
    }
}
