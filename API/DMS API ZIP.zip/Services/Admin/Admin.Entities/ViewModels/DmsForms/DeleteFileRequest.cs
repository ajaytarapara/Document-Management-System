namespace Admin.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// ViewModel representing the request to delete a DMS form file.
    /// </summary>
    public class DeleteFileRequest
    {
        /// <summary>
        /// The unique identifier of the DMS form to be deleted.
        /// </summary>
        public string DmsFormId { get; set; } = string.Empty;

        /// <summary>
        /// The unique identifier of the user requesting the deletion.
        /// </summary>
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// The password provided by the user to authorize the deletion.
        /// </summary>
        public string Password { get; set; } = null!;
    }
}
