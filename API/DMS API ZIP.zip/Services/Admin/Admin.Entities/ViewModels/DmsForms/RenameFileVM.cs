namespace Admin.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// ViewModel representing a request to rename a DMS form file.
    /// </summary>
    public class RenameFileVM
    {
        /// <summary>
        /// The unique identifier of the DMS form file to be renamed.
        /// </summary>
        public string DmsFormId { get; set; } = string.Empty;

        /// <summary>
        /// The new name to assign to the file.
        /// </summary>
        public string NewFileName { get; set; }
    }
}
