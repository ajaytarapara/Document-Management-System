namespace Admin.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// ViewModel representing a paginated response for DMS form files.
    /// </summary>
    public class PaginatedDmsFormResponseVM
    {
        /// <summary>
        /// The list of DMS form files for the current page.
        /// </summary>
        public List<DMSFormFileVM> Items { get; set; } = new();

        /// <summary>
        /// The total number of DMS form files available.
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// The current page index (1-based).
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// The number of items displayed per page.
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// The name of the column used for sorting.
        /// </summary>
        public string SortColumn { get; set; } = string.Empty;

        /// <summary>
        /// The direction of sorting (e.g., ASC or DESC).
        /// </summary>
        public string SortDirection { get; set; } = string.Empty;
    }
}
