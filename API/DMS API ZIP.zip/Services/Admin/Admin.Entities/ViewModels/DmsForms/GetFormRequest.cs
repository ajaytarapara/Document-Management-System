using System;

namespace Admin.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// Represents the request model for retrieving a DMS form
    /// by its encrypted form ID and user ID.
    /// </summary>
    public class GetFormRequest
    {
        /// <summary>
        /// The encrypted identifier of the DMS form to retrieve.
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// The encrypted identifier of the user requesting the form.
        /// </summary>
        public string UserId { get; set; }
    }
}
