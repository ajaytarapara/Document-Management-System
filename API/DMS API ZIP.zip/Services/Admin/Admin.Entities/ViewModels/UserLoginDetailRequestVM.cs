namespace Admin.Entities.ViewModels
{
    public class UserLoginDetailRequestVM : PaginatedRequest
    {
        public DateTime date { get; set; }
        public string? userId { get; set; }
    }
}