using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Entities.ViewModels.User
{
    public class OfficeUserVM
    {
        /// <summary>
        /// Unique identifier for the user
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// UserName name of the user
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Name of the user
        /// </summary>
        public string Name { get; set; }

    }
}