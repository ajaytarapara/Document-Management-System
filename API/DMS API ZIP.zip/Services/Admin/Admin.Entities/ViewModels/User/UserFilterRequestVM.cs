using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shared.ViewModels.Base;

namespace Admin.Entities.ViewModels.User
{
    public class UserFilterRequestVM : PaginationRequestVM
    {
        public string? UserName { get; set; }
        public string? OfficeUser { get; set; }
        public int? RoleType { get; set; }
    }
}