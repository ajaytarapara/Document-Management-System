using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Entities.ViewModels.User
{
    public class UserVM
    {
        /// <summary>
        /// Unique identifier for the user
        /// </summary>
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// Full name of the user
        /// </summary>
        public required string Name { get; set; }

        /// <summary>
        /// Email address of the user
        /// </summary>
        public required string Email { get; set; }

        /// <summary>
        /// Contact number of the user
        /// </summary>
        public string? PhoneNumber { get; set; }

        /// <summary>
        /// Address of the user
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// City of the user
        /// </summary>
        public string? City { get; set; }

        /// <summary>
        /// Postal code
        /// </summary>
        public int PostalCode { get; set; }

        /// <summary>
        /// Username (used for login)
        /// </summary>
        public required string UserName { get; set; }

        /// <summary>
        /// Role ID
        /// </summary>
        public int Role { get; set; }

        /// <summary>
        /// Role name
        /// </summary>
        public string? RoleName { get; set; }

        /// <summary>
        /// Comma-separated list of assigned offices for the user.
        /// </summary>
        public string? AssignedOffices { get; set; }

        /// <summary>
        /// Whether the user has delete privileges
        /// </summary>
        public bool? PrivilegeDelete { get; set; }

        /// <summary>
        /// Whether the user can download files
        /// </summary>
        public bool? PrivilegeDownload { get; set; }

        /// <summary>
        /// Whether the user can view content
        /// </summary>
        public bool? PrivilegeView { get; set; }

        /// <summary>
        /// Whether to hide or lock tabs from the user
        /// </summary>
        public bool? HideLockTabs { get; set; }

        /// <summary>
        /// Whether user is active
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Maximum number of tabs allowed for the user.
        /// </summary>
        public int MaxTabLimit { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}