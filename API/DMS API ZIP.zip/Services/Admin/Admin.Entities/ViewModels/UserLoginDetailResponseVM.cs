namespace Admin.Entities.ViewModels
{
    public class UserLoginDetailResponseVM
    {
        public string Name { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime LoginDate { get; set; }
        public DateTime? LogoutDate { get; set; }
    }
}