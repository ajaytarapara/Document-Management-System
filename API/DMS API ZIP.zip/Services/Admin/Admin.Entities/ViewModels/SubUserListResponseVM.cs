using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Admin.Entities.ViewModels
{
    /// <summary>
    /// ViewModel representing a sub-user in the response.
    /// </summary>
    public class SubUserListResponseVM
    {
        /// <summary>
        /// Unique identifier of the sub-user.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Username of the sub-user used for login.
        /// </summary>
        public string Username { get; set; } = string.Empty;
    }
}