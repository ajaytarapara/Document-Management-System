namespace Admin.Entities.ViewModels.UserAnalytics
{
    public class FileRecordStatsRequest : PaginatedRequest
    {
        public string DateRangeType { get; set; } = "current_week";
        public string? OfficeUserId { get; set; }
        public DateTime? CustomStartDate { get; set; }
        public DateTime? CustomEndDate { get; set; }
        public bool IsForOfficeUser { get; set; } = true;
    }
}