namespace Admin.Entities.ViewModels.UserAnalytics
{
    public class FileRecordStatsResponse
    {
        public int TotalFolderCount { get; set; }
        public long TotalFileSizeBytes { get; set; }
        public List<BreakdownRecord> Breakdown { get; set; } = [];
        public string UserName { get; set; } = string.Empty;
        public string OfficeUserName { get; set; } = string.Empty;
        public string OfficeUserId { get; set; } = string.Empty;
    }

    public class BreakdownRecord
    {
        public string Label { get; set; } = string.Empty;
        public int FolderCount { get; set; }
        public long TotalFileSizeBytes { get; set; }
    }
}