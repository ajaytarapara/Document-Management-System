using System.Text;
using System.Text.Json;
using Admin.Entities.ViewModels.DmsForms;
using AutoMapper;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Microsoft.Extensions.Hosting;
using Shared.ConfigItems;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.Helper;
using Shared.ViewModels.Base;
using Shared.ViewModels.DmsForms;
using static Admin.Services.UserServices.UserServices;
using static Shared.Constant.Enums;

namespace Admin.Services.DmsFormService;

[ScopedDependency(ServiceType = typeof(IDmsFormService))]
public class DmsFormService : IDmsFormService
{
    #region Fields

    private readonly IGenericService<DmsForm, ApplicationDBContext> _genericDmsFormService;
    private readonly IGenericService<User, ApplicationDBContext> _generiUserService;
    private readonly ICurrentUserService _currentUserService;
    private readonly IGenericService<DmsSubmittedForm, ApplicationDBContext> _genericSubmittedFormService;

    private readonly IEmailSender _emailSender;
    private readonly IMapper _mapper;
    private readonly IHostEnvironment _env;
    #endregion

    #region Constructor

    public DmsFormService(
        IGenericService<DmsForm, ApplicationDBContext> genericDmsFormService,
        IGenericService<User, ApplicationDBContext> generiUserService,
        IGenericService<DmsSubmittedForm, ApplicationDBContext> genericSubmittedFormService,
        ICurrentUserService currentUserService,
        IMapper mapper,
        IEmailSender emailSender,
        IHostEnvironment env)
    {
        _genericDmsFormService = genericDmsFormService;
        _generiUserService = generiUserService;
        _currentUserService = currentUserService;
        _genericSubmittedFormService = genericSubmittedFormService;
        _mapper = mapper;
        _emailSender = emailSender;
        _env = env;
    }

    #endregion

    #region Public Methods

    public async Task<string> AddDmsForm(UploadDmsFormsVM dmsForms, string userId, int createdBy)
    {
        int decryptedUserId = AesEncryptionHelper.DecryptId(userId);
        ValidateUploadRequest(dmsForms, decryptedUserId);

        string uploadsFolder = GetUserFolderPath(decryptedUserId);
        EnsureDirectoryExists(uploadsFolder);

        List<DmsForm> formEntities = new List<DmsForm>();

        foreach (UploadedFile file in dmsForms.DmsForms)
        {
            if (string.IsNullOrWhiteSpace(file.Content) || string.IsNullOrWhiteSpace(file.Name))
                continue;

            await EnsureFileNameIsUniqueAsync(decryptedUserId, file.Name);

            string filePath = Path.Combine(uploadsFolder, file.Name);
            await WriteFileAsync(filePath, file.Content);

            CreateDmsFormEntityRequest createRequest = new CreateDmsFormEntityRequest
            {
                File = file,
                FilePath = filePath,
                UserId = decryptedUserId,
                CreatedBy = createdBy
            };

            DmsForm entity = CreateDmsFormEntity(createRequest);
            formEntities.Add(entity);
        }

        if (formEntities.Any())
        {
            await _genericDmsFormService.InsertManyAsync(formEntities);
        }

        return userId;
    }

    public async Task<PaginationResponseVM<DMSFormFileVM>> GetAllDmsFormsAsync(PaginationRequestVM request, int userId, string baseUrl)
    {
        IEnumerable<DmsForm> allForms = await _genericDmsFormService.GetAllAsync(f =>
            f.SelectedUserId == userId && !(f.IsDeleted ?? false));

        IEnumerable<DmsForm> sortDmsForms = SortDmsForms(allForms, request);
        PaginatedDmsFormResponseVM pagedResult = Paginate(sortDmsForms, request);

        List<DMSFormFileVM> items = pagedResult.Items.Select(f => new DMSFormFileVM
        {
            Id = f.Id,
            Name = f.Name,
            Size = f.Size,
            CreatedAt = f.CreatedAt,
            Status = f.Status,
            Url = $"{baseUrl}{f.Url}",
            Fields = f.Fields,
        }).ToList();


        return new PaginationResponseVM<DMSFormFileVM>
        {
            Items = items,
            TotalCount = pagedResult.TotalCount,
            PageIndex = pagedResult.PageIndex,
            PageSize = pagedResult.PageSize,
            SortColumn = pagedResult.SortColumn,
            SortDirection = pagedResult.SortDirection
        };
    }

    public async Task<bool> RenameDmsFormFileAsync(string dmsFormId, string newFileName, int userId)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(dmsFormId);
        if (string.IsNullOrWhiteSpace(newFileName))
            throw new InvalidDataException(Messages.Error.Validation.InvalidFileName);

        DmsForm dmsForm = await GetValidDmsFormAsync(decryptedDmsFormId, userId);
        await EnsureFileNameIsUniqueAsync(userId, newFileName);

        string oldPath = Path.Combine(GetUserFolderPath(userId), dmsForm.Name);
        string newPath = Path.Combine(GetUserFolderPath(userId), newFileName);

        if (!File.Exists(oldPath))
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        File.Move(oldPath, newPath);

        dmsForm.Name = newFileName;
        dmsForm.Url = $"/dmsform/{userId}/{newFileName}";
        dmsForm.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);

        await _genericDmsFormService.UpdateAsync(dmsForm);
        return true;
    }

    public async Task<bool> DeleteDmsFormFileAsync(DeleteFileRequest model)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(model.DmsFormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(model.UserId);
        DmsForm dmsForm = await GetValidDmsFormAsync(decryptedDmsFormId, decryptedUserId);
        int loggedInUserId = _currentUserService.GetUserId();
        User user = await _generiUserService.GetAsync(u => u.Id == loggedInUserId);

        if (!PasswordHelper.ValidatePassword(model.Password, user.PasswordHash))
            throw new DataNotFoundException(Messages.Error.General.InvalidCredentialMessage);

        string filePath = Path.Combine(GetUserFolderPath(decryptedUserId), dmsForm.Name);
        if (File.Exists(filePath))
            File.Delete(filePath);

        await _genericDmsFormService.DeleteAsync(dmsForm);
        return true;
    }

    public async Task<DMSFormFileVM> GetDmsFormByIdAsync(string dmsFormId, string userId)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(dmsFormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(userId);
        DmsForm? dmsForm = await _genericDmsFormService.GetAsync(f => f.Id == decryptedDmsFormId);

        if (dmsForm == null || dmsForm.IsDeleted == true || dmsForm.SelectedUserId != decryptedUserId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        var vm = _mapper.Map<DMSFormFileVM>(dmsForm);

        if (!string.IsNullOrEmpty(dmsForm.FieldsJson))
        {
            try
            {
                vm.Fields = JsonSerializer.Deserialize<List<FieldBaseVM>>(dmsForm.FieldsJson)
                            ?? new List<FieldBaseVM>();
            }
            catch
            {
                vm.Fields = new List<FieldBaseVM>();
            }
        }

        string filePath = Path.Combine(GetUserFolderPath(dmsForm.SelectedUserId), dmsForm.Name);
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);
        }
        return vm;
    }

    public async Task<ShareDmsFormVM> ShareDmsFormAsync(ShareDmsFormVM dmsForm, int userId)
    {
        string[] emails = SplitAndTrim(dmsForm.ToEmail);
        string[] names = SplitAndTrim(dmsForm.ToName);

        if (emails.Length != names.Length)
            throw new InvalidOperationException(Messages.Error.UserMessage.MismatchEmailAndName);

        string baseUrl = ConfigItems.BaseUrl;
        DateTime expiresAt = DateTime.UtcNow.AddHours(dmsForm.LinkExpiration);

        string templatePath = Path.Combine(_env.ContentRootPath, ConfigItems.EmailTemplateShareDmsFormPath);
        if (!File.Exists(templatePath))
            throw new FileNotFoundException(Messages.Error.Validation.EmailTemplateNotFound, templatePath);

        string templateHtml = await File.ReadAllTextAsync(templatePath);

        for (int i = 0; i < emails.Length; i++)
        {
            string email = emails[i];
            string name = names[i];

            string formLinks = BuildFormLinks(new BuildFormLinksRequest
            {
                FormIds = dmsForm.FormIds,
                BaseUrl = baseUrl,
                Email = email,
                ExpiresAt = expiresAt,
                ViewOnly = dmsForm.ViewOnly,
                UserId = userId
            });

            string bodyHtml = templateHtml
                .Replace("{{UserName}}", name)
                .Replace("{{Message}}", dmsForm.Message ?? Messages.Success.DMSForm.FormSharedSuccessMessage)
                .Replace("{{Links}}", formLinks)
                .Replace("{{LinkText}}", "")
                .Replace("{{Expiration}}", $"{expiresAt.ToString(AppConstants.Constants.DateFormate)} UTC");

            await _emailSender.SendEmailAsync(
                from: ConfigItems.FromMail,
                to: email,
                subject: dmsForm.Subject,
                html: bodyHtml
            );
        }

        return dmsForm;
    }

    public async Task<bool> SaveEditedFormAsync(SaveEditedFormVM editedForm)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(editedForm.FormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(editedForm.UserId);
        if (editedForm.IsUser == false)
        {
            editedForm.FilePath = GetUserFolderPath();
        }
        InputType inputType = (InputType)EnumHelper.GetValueFromDescription<InputType>(Messages.Success.DMSForm.InputRadioType);
        DmsForm dmsForm = await _genericDmsFormService.GetAsync(f => f.Id == decryptedDmsFormId);
        if (dmsForm == null || dmsForm.IsDeleted == true || dmsForm.SelectedUserId != decryptedUserId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        var groupedRadios = editedForm.Fields
        .Where(f => f.Type == inputType.ToString() && !string.IsNullOrEmpty(f.GroupId))
        .GroupBy(f => f.GroupId);

        foreach (var group in groupedRadios)
        {
            bool isCheckedSet = false;
            foreach (var radio in group)
            {
                if (radio.Value == "true")
                {
                    if (!isCheckedSet)
                    {
                        isCheckedSet = true;
                    }
                    else
                    {
                        radio.Value = "false";
                    }
                }
            }
        }

        byte[] fileBytes = Convert.FromBase64String(editedForm.File);
        string filePath = Path.Combine(editedForm.FilePath, dmsForm.SelectedUserId.ToString(), dmsForm.Name);
        await File.WriteAllBytesAsync(filePath, fileBytes);

        // Persist fields (serialize to JSON for simplicity)
        dmsForm.FieldsJson = JsonSerializer.Serialize(editedForm.Fields);

        dmsForm.UpdatedAt = DateTime.UtcNow;
        dmsForm.UpdatedBy = decryptedUserId;

        await _genericDmsFormService.UpdateAsync(dmsForm);
        return true;
    }

    public async Task<bool> SubmitEditedFormAsync(SubmittedDmsFromRequest submittedForm)
    {
        if (submittedForm == null || string.IsNullOrEmpty(submittedForm.File))
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        if (submittedForm.IsUser == false)
        {
            submittedForm.FilePath = GetUserFolderPath();
        }

        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(submittedForm.FormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(submittedForm.UserId);

        DmsForm dmsForm = await _genericDmsFormService.GetAsync(f => f.Id == decryptedDmsFormId);
        if (dmsForm == null || dmsForm.IsDeleted == true || dmsForm.SelectedUserId != decryptedUserId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        NormalizeRadioGroups(submittedForm);

        byte[] fileBytes = Convert.FromBase64String(submittedForm.File);
        string userFolderPath = Path.Combine(submittedForm.FilePath, dmsForm.SelectedUserId.ToString());

        DmsSubmittedForm existingSubmission = await _genericSubmittedFormService.GetAsync(s => s.FormId == dmsForm.Id
                 && s.CreatedBy == decryptedUserId
                 && s.SubmittedByEmail == submittedForm.SubmittedBy);

        string fileName;

        if (existingSubmission != null)
        {
            fileName = existingSubmission.Name;
        }
        else
        {
            fileName = GetUniqueFileName(userFolderPath, dmsForm.Name);
        }

        string filePath = Path.Combine(userFolderPath, fileName);
        await File.WriteAllBytesAsync(filePath, fileBytes);

        DateTime now = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
        string fieldsJson = JsonSerializer.Serialize(submittedForm.Fields);
        string url = $"/dmsform/{dmsForm.SelectedUserId}/{fileName}";

        SubmissionStatus submissionStatus = (SubmissionStatus)EnumHelper.GetValueFromDescription<SubmissionStatus>(Messages.Success.DMSForm.SubmittedStatus);

        if (existingSubmission != null)
        {
            existingSubmission.Name = fileName;
            existingSubmission.Size = fileBytes.Length.ToString();
            existingSubmission.Url = url;
            existingSubmission.FieldsJson = fieldsJson;
            existingSubmission.SubmittedByEmail = submittedForm.SubmittedBy;
            existingSubmission.SubmittedAt = now;
            existingSubmission.Status = submissionStatus.ToString();

            await _genericSubmittedFormService.UpdateAsync(existingSubmission);
        }
        else
        {
            DmsSubmittedForm submittedEntity = new DmsSubmittedForm
            {
                FormId = dmsForm.Id,
                Name = fileName,
                Size = fileBytes.Length.ToString(),
                Url = url,
                FieldsJson = fieldsJson,
                SubmittedByEmail = submittedForm.SubmittedBy,
                SubmittedAt = now,
                Status = submissionStatus.ToString(),
                CreatedBy = decryptedUserId,
                CreatedAt = now
            };

            await _genericSubmittedFormService.InsertAsync(submittedEntity);
        }

        return true;
    }
    public async Task<PaginationResponseVM<DMSFormFileVM>> GetAllSubmittedDmsFormsAsync(PaginationRequestVM request, int userId, string baseUrl)
    {
        IEnumerable<DmsSubmittedForm> allSubmittedForms = await _genericSubmittedFormService.GetAllAsync(f =>
            f.CreatedBy == userId);

        IEnumerable<DmsSubmittedForm> sortedForms = SortSubmittedForms(allSubmittedForms, request);
        int totalCount = sortedForms.Count();

        int pageIndex = Math.Max(request.PageNumber, 1);
        int pageSize = Math.Max(request.PageSize, 5);

        List<DMSFormFileVM> items = sortedForms
            .Skip((pageIndex - 1) * pageSize)
            .Take(pageSize)
            .Select(f => new DMSFormFileVM
            {
                Id = AesEncryptionHelper.EncryptId(f.Id),
                Name = f.Name,
                Size = Convert.ToInt64(f.Size),
                Url = request.IsSubUser == true ? ConfigItems.UserServiceBaseUrl + $"{f.Url}" : $"{baseUrl}{f.Url}",
                Status = f.Status,
                SubmittedBy = f.SubmittedByEmail,
                Fields = string.IsNullOrEmpty(f.FieldsJson) ? new List<FieldBaseVM>()
                        : JsonSerializer.Deserialize<List<FieldBaseVM>>(f.FieldsJson) ?? new List<FieldBaseVM>(),
                CreatedAt = f.CreatedAt.ToString(AppConstants.Constants.DateFormate),
                SubmittedAt = f.SubmittedAt?.ToString(AppConstants.Constants.DateFormate)
            })
            .ToList();

        return new PaginationResponseVM<DMSFormFileVM>
        {
            Items = items,
            TotalCount = totalCount,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortColumn = request.SortBy,
            SortDirection = request.SortOrder.ToString()
        };
    }

    #endregion

    #region Private Helper Methods

    private void ValidateUploadRequest(UploadDmsFormsVM dmsForms, int userId)
    {
        if (dmsForms == null || dmsForms.DmsForms == null || !dmsForms.DmsForms.Any())
            throw new InvalidDataException(Messages.Error.Validation.InvalidFileContext);
        if (userId <= 0)
            throw new InvalidDataException(Messages.Error.Validation.InvalidUser);
    }

    private string GetUserFolderPath(int userId)
    {
        return Path.Combine(Directory.GetCurrentDirectory(), AppConstants.Constants.RootPath, AppConstants.Constants.DmsFolderPath, userId.ToString());
    }

    private void EnsureDirectoryExists(string path)
    {
        if (!Directory.Exists(path))
            Directory.CreateDirectory(path);
    }

    private async Task EnsureFileNameIsUniqueAsync(int userId, string fileName)
    {
        DmsForm existing = await _genericDmsFormService.GetAsync(f =>
            f.SelectedUserId == userId &&
            f.Name == fileName &&
            !(f.IsDeleted ?? false));

        if (existing != null)
            throw new DataConflictException(Messages.Error.Exception.RequiredFieldMessage(existing.Name));
    }

    private async Task WriteFileAsync(string path, string base64Content)
    {
        byte[] bytes = Convert.FromBase64String(base64Content);
        await File.WriteAllBytesAsync(path, bytes);
    }

    private DmsForm CreateDmsFormEntity(CreateDmsFormEntityRequest request)
    {
        FileInfo fileInfo = new FileInfo(request.FilePath);
        SubmissionStatus submissionStatus = (SubmissionStatus)EnumHelper.GetValueFromDescription<SubmissionStatus>(Messages.Success.DMSForm.UploadedStatus);
        return new DmsForm
        {
            Name = request.File.Name,
            Size = fileInfo.Length.ToString(),
            Url = $"/dmsform/{request.UserId}/{request.File.Name}",
            Status = submissionStatus.ToString(),
            CreatedBy = request.CreatedBy,
            CreatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc),
            IsActive = true,
            IsDeleted = false,
            SelectedUserId = request.UserId
        };
    }
    private async Task<DmsForm> GetValidDmsFormAsync(int formId, int userId)
    {
        DmsForm form = await _genericDmsFormService.GetAsync(f =>
            f.Id == formId && !(f.IsDeleted ?? false));

        if (form == null || form.SelectedUserId != userId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        return form;
    }

    private PaginatedDmsFormResponseVM Paginate(IEnumerable<DmsForm> forms, PaginationRequestVM request)
    {
        int totalCount = forms.Count();
        int pageIndex = Math.Max(request.PageNumber, 1);
        int pageSize = Math.Max(request.PageSize, 5);

        List<DMSFormFileVM> items = forms
            .Skip((pageIndex - 1) * pageSize)
            .Take(pageSize)
            .Select(f => new DMSFormFileVM
            {
                Id = AesEncryptionHelper.EncryptId(f.Id),
                Name = f.Name,
                Size = Convert.ToInt64(f.Size),
                Url = f.Url,
                Status = f.Status,
                Fields = string.IsNullOrEmpty(f.FieldsJson) ? new List<FieldBaseVM>()
                        : JsonSerializer.Deserialize<List<FieldBaseVM>>(f.FieldsJson) ?? new List<FieldBaseVM>(),
                CreatedAt = f.CreatedAt.ToString(AppConstants.Constants.DateFormate)
            })
            .ToList();

        return new PaginatedDmsFormResponseVM
        {
            Items = items,
            TotalCount = totalCount,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortColumn = request.SortBy,
            SortDirection = request.SortOrder.ToString()
        };
    }

    private IEnumerable<DmsForm> SortDmsForms(IEnumerable<DmsForm> forms, PaginationRequestVM request)
    {
        string sortColumn = string.IsNullOrWhiteSpace(request.SortBy) ? nameof(DMSFormFileVM.Id) : request.SortBy;
        bool isDescending = request.SortOrder.ToString().Equals("Desc", StringComparison.OrdinalIgnoreCase);

        return sortColumn switch
        {
            nameof(DMSFormFileVM.Size) => isDescending
                ? forms.OrderByDescending(f => Convert.ToInt64(f.Size)).ToList()
                : forms.OrderBy(f => Convert.ToInt64(f.Size)).ToList(),

            nameof(DMSFormFileVM.CreatedAt) => isDescending
                ? forms.OrderByDescending(f => f.CreatedAt).ToList()
                : forms.OrderBy(f => f.CreatedAt).ToList(),

            _ => isDescending
                ? forms.OrderByDescending(f => f.Name).ToList()
                : forms.OrderBy(f => f.Name).ToList()
        };
    }

    private string GenerateShareToken(GenerateShareTokenRequest request)
    {
        var tokenPayload = new
        {
            formId = request.FormId,
            email = request.Email,
            request.ViewOnly,
            userId = request.UserId,
            expiresAt = new DateTimeOffset(request.Expires).ToUnixTimeSeconds()
        };

        string json = JsonSerializer.Serialize(tokenPayload);
        string base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        return base64;
    }
    private static string[] SplitAndTrim(string input) =>
       input.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .ToArray();

    private string BuildFormLinks(BuildFormLinksRequest request)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<ul>");

        foreach (string formId in request.FormIds)
        {
            string token = GenerateShareToken(new GenerateShareTokenRequest
            {
                FormId = AesEncryptionHelper.DecryptId(formId),
                Email = request.Email,
                Expires = request.ExpiresAt,
                ViewOnly = request.ViewOnly,
                UserId = request.UserId,
            });

            string url = $"{request.BaseUrl}/user/view-share-dms-form?shareToken={token}";
            string linkText = request.ViewOnly ? "View" : "View/Download";
            sb.Append($"<li><a href='{url}' target='_blank' style='color: #7e57c2; text-decoration: underline;'>{linkText} Form #{formId}</a></li>");
        }

        sb.Append("</ul>");
        return sb.ToString();
    }

    private IEnumerable<DmsSubmittedForm> SortSubmittedForms(IEnumerable<DmsSubmittedForm> forms, PaginationRequestVM request)
    {
        string sortColumn = string.IsNullOrWhiteSpace(request.SortBy) ? nameof(DMSFormFileVM.Id) : request.SortBy;
        bool isDescending = request.SortOrder.ToString().Equals("Desc", StringComparison.OrdinalIgnoreCase);

        return sortColumn switch
        {
            nameof(DMSFormFileVM.Size) => isDescending
                ? forms.OrderByDescending(f => Convert.ToInt64(f.Size)).ToList()
                : forms.OrderBy(f => Convert.ToInt64(f.Size)).ToList(),

            nameof(DMSFormFileVM.CreatedAt) => isDescending
                ? forms.OrderByDescending(f => f.CreatedAt).ToList()
                : forms.OrderBy(f => f.CreatedAt).ToList(),

            _ => isDescending
                ? forms.OrderByDescending(f => f.Name).ToList()
                : forms.OrderBy(f => f.Name).ToList()
        };
    }

    private static void NormalizeRadioGroups(SubmittedDmsFromRequest submittedForm)
    {
        InputType inputType = (InputType)EnumHelper.GetValueFromDescription<InputType>(Messages.Success.DMSForm.InputRadioType);
        var groupedRadios = submittedForm.Fields
            .Where(f => f.Type == inputType.ToString().ToLower() && !string.IsNullOrEmpty(f.GroupId))
            .GroupBy(f => f.GroupId);

        foreach (var group in groupedRadios)
        {
            bool isCheckedSet = false;
            foreach (var radio in group)
            {
                if (radio.Value == "true")
                {
                    if (!isCheckedSet) isCheckedSet = true;
                    else radio.Value = "false";
                }
            }
        }
    }

    private string GetUniqueFileName(string folderPath, string baseFileName)
    {
        string fileNameWithoutExt = Path.GetFileNameWithoutExtension(baseFileName);
        string extension = Path.GetExtension(baseFileName);

        string fileName = baseFileName;
        string filePath = Path.Combine(folderPath, fileName);

        int counter = 1;
        while (File.Exists(filePath))
        {
            fileName = $"{fileNameWithoutExt}_{counter}{extension}";
            filePath = Path.Combine(folderPath, fileName);
            counter++;
        }

        return fileName;
    }

    private string GetUserFolderPath()
    {
        return Path.Combine(Directory.GetCurrentDirectory(), AppConstants.Constants.RootPath, AppConstants.Constants.DmsFolderPath);
    }
    #endregion
}
