using Admin.Entities.ViewModels.DmsForms;
using Shared.ViewModels.Base;
using Shared.ViewModels.DmsForms;

namespace Admin.Services.DmsFormService
{
    public interface IDmsFormService
    {
        Task<string> AddDmsForm(UploadDmsFormsVM dmsForms, string userId, int createdBy);
        Task<PaginationResponseVM<DMSFormFileVM>> GetAllDmsFormsAsync(PaginationRequestVM request, int userId, string baseUrl);
        Task<bool> RenameDmsFormFileAsync(string dmsFormId, string newFileName, int userId);
        Task<bool> DeleteDmsFormFileAsync(DeleteFileRequest request);
        Task<DMSFormFileVM> GetDmsFormByIdAsync(string dmsFormId, string userId);
        Task<ShareDmsFormVM> ShareDmsFormAsync(ShareDmsFormVM dmsForm, int userId);
        Task<bool> SaveEditedFormAsync(SaveEditedFormVM editedForm);
        Task<bool> SubmitEditedFormAsync(SubmittedDmsFromRequest editedForm);
        Task<PaginationResponseVM<DMSFormFileVM>> GetAllSubmittedDmsFormsAsync(PaginationRequestVM request, int userId, string baseUrl);
    }
}