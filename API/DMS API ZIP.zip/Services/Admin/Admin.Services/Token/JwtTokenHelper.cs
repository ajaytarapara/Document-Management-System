using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Shared.ConfigItems;

namespace Admin.Services.Token
{
    public class JwtTokenHelper
    {
        private readonly IConfiguration _configuration;

        public JwtTokenHelper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GenerateJwtToken(string email, int userId, string userName, string role, int? originalUserId = null)
        {
            var jwtSettings = _configuration.GetSection("JwtSettings");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim("email", email),
                new Claim("userId", userId.ToString()),
                new Claim("userName", userName),
                new Claim(ClaimTypes.Role, role)
            };


            if (originalUserId.HasValue)
                claims.Add(new Claim("originalUserId", originalUserId.Value.ToString()));

            var token = new JwtSecurityToken(
                issuer: ConfigItems.JwtIssuer,
                audience: ConfigItems.JwtAudience,
                claims: claims,
                expires: DateTime.UtcNow.AddDays(double.Parse(ConfigItems.JwtExpiryInDays)),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}




