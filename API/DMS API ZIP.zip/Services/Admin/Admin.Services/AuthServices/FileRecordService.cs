using System.Globalization;
using System.Linq.Expressions;
using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.UserAnalytics;
using CoreServices.Generic;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Shared.Helper;
using static Shared.Constant.Enums;

namespace Admin.Services.AuthServices
{
    [ScopedDependency(ServiceType = typeof(IFileRecordService))]
    public class FileRecordService(IGenericService<FileRecord, ApplicationDBContext> fileRecordService, IGenericService<Folder, ApplicationDBContext> folderService, IGenericService<User, ApplicationDBContext> userService) : IFileRecordService
    {
        #region fields
        private readonly IGenericService<FileRecord, ApplicationDBContext> _fileRecordService = fileRecordService;
        private readonly IGenericService<Folder, ApplicationDBContext> _folderService = folderService;
        private readonly IGenericService<User, ApplicationDBContext> _userService = userService;
        #endregion

        #region constructor
        #endregion

        #region methods
        public async Task<PaginatedResponse<FileRecordStatsResponse>> GetFileRecordStats(FileRecordStatsRequest request)
        {
            (DateTime startDate, DateTime endDate) = GetDateRange(request.DateRangeType, request.CustomStartDate, request.CustomEndDate);
            if (request.OfficeUserId != null)
            {
                int officeUserId = AesEncryptionHelper.DecryptId(request.OfficeUserId);
                return await GetStatsForSingleUser(officeUserId, startDate, endDate, request.DateRangeType, request.PageNumber, request.PageSize, request.IsForOfficeUser);
            }
            return await GetStatsForAllUsers(startDate, endDate, request.DateRangeType, request.PageNumber, request.PageSize);
        }

        private async Task<PaginatedResponse<FileRecordStatsResponse>> GetStatsForSingleUser(int officeUserId, DateTime startDate, DateTime endDate, string dateRangeType, int pageNumber, int pageSize, bool IsForOfficeUser)
        {
            if (IsForOfficeUser)
            {
                return await GetStatsForOfficeUser(officeUserId, startDate, endDate, dateRangeType, pageNumber, pageSize);
            }
            else
            {
                return await GetStatsForNonOfficeUser(officeUserId, startDate, endDate, dateRangeType, pageNumber, pageSize);
            }
        }

        private Task<PaginatedResponse<FileRecordStatsResponse>> GetStatsForNonOfficeUser(int officeUserId, DateTime startDate, DateTime endDate, string dateRangeType, int pageNumber, int pageSize)
        {
            return GetStats(
                f => f.IsActive == true && f.IsDeleted == false && f.CreatedBy == officeUserId,
                startDate,
                endDate,
                dateRangeType,
                pageNumber,
                pageSize,
                null,
                async userFileGroup =>
                {
                    User user = await _userService.GetFirstOrDefaultAsync(u => u.Id == userFileGroup.Key);
                    User officeUser = await _userService.GetFirstOrDefaultAsync(u => u.Id == officeUserId);
                    return new FileRecordStatsResponse
                    {
                        UserName = user.UserName,
                        OfficeUserName = officeUser.UserName
                    };
                },
                false
            );
        }

        private Task<PaginatedResponse<FileRecordStatsResponse>> GetStatsForOfficeUser(int officeUserId, DateTime startDate, DateTime endDate, string dateRangeType, int pageNumber, int pageSize)
        {
            return GetStats(
                f => f.IsActive == true && f.User.Role == (int)UserRoles.OfficeUser && f.IsDeleted == false && f.CreatedBy == officeUserId,
                startDate,
                endDate,
                dateRangeType,
                pageNumber,
                pageSize,
                async userGroup =>
                {
                    User user = await _userService.GetFirstOrDefaultAsync(u => u.Id == userGroup.Key);
                    return new FileRecordStatsResponse
                    {
                        OfficeUserName = user.UserName,
                        OfficeUserId = AesEncryptionHelper.EncryptId(user.Id)
                    };
                },
                null
            );
        }

        private Task<PaginatedResponse<FileRecordStatsResponse>> GetStatsForAllUsers(DateTime startDate, DateTime endDate, string dateRangeType, int pageNumber, int pageSize)
        {
            return GetStats(
                f => f.IsActive == true && f.User.Role == (int)UserRoles.OfficeUser && f.IsDeleted == false,
                startDate,
                endDate,
                dateRangeType,
                pageNumber,
                pageSize,
                async userGroup =>
                {
                    User user = await _userService.GetFirstOrDefaultAsync(u => u.Id == userGroup.Key);
                    return new FileRecordStatsResponse
                    {
                        OfficeUserName = user.UserName,
                        OfficeUserId = AesEncryptionHelper.EncryptId(user.Id)
                    };
                },
                null
            );
        }

        private static List<BreakdownRecord> GetBreakdown(IEnumerable<Folder> folders, IEnumerable<FileRecord> fileRecords, string dateRangeType, DateTime? customStartDate = null, DateTime? customEndDate = null)
        {
            return dateRangeType.ToLower() switch
            {
                "current_week" or "last_week" => (List<BreakdownRecord>)[.. folders
                                        .GroupBy(f => f.CreatedAt.Date)
                                        .Select(g => new BreakdownRecord
                                        {
                                            Label = g.Key.ToString("dd-MM-yyyy"),
                                            FolderCount = g.Count(),
                                            TotalFileSizeBytes = fileRecords.Where(fr => g.Select(f => f.Id).Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size))
                                        })
                                        .OrderByDescending(b => b.Label)],

                "current_month" or "last_month" => (List<BreakdownRecord>)[.. folders
                                        .GroupBy(f => GetWeekRange(f.CreatedAt))
                                        .Select(g => new BreakdownRecord
                                        {
                                            Label = $"{g.Key.Start:dd-MM-yyyy} to {g.Key.End:dd-MM-yyyy}",
                                            FolderCount = g.Count(),
                                            TotalFileSizeBytes = fileRecords.Where(fr => g.Select(f => f.Id).Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size))
                                        })
                                        .OrderByDescending(b => b.Label)],

                "current_year" or "last_year" => (List<BreakdownRecord>)[.. folders
                                        .GroupBy(f => new { f.CreatedAt.Year, f.CreatedAt.Month })
                                        .Select(g => new BreakdownRecord
                                        {
                                            Label = $"{CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(g.Key.Month)} {g.Key.Year}",
                                            FolderCount = g.Count(),
                                            TotalFileSizeBytes = fileRecords.Where(fr => g.Select(f => f.Id).Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size))
                                        })
                                        .OrderByDescending(b => b.Label)],

                "all_time" => (List<BreakdownRecord>)[.. folders
                                        .GroupBy(f => f.CreatedAt.Year)
                                        .Select(g => new BreakdownRecord
                                        {
                                            Label = g.Key.ToString(),
                                            FolderCount = g.Count(),
                                            TotalFileSizeBytes = fileRecords.Where(fr => g.Select(f => f.Id).Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size))
                                        })
                                        .OrderByDescending(b => b.Label)],

                "custom" when customStartDate.HasValue && customEndDate.HasValue => GetCustomBreakdown(folders, fileRecords, customStartDate.Value, customEndDate.Value),

                _ => [],
            };
        }

        private static (DateTime start, DateTime end) GetDateRange(string dateRangeType, DateTime? customStart, DateTime? customEnd)
        {
            var today = DateTime.UtcNow.Date;
            DateTime GetMonday(DateTime date) => date.AddDays(-(int)date.DayOfWeek + (date.DayOfWeek == DayOfWeek.Sunday ? -6 : 1));
            DateTime GetSunday(DateTime date) => GetMonday(date).AddDays(7).AddTicks(-1);
            return dateRangeType?.ToLower() switch
            {
                "current_week" => (
                    GetMonday(today),
                    GetSunday(today)
                ),

                "last_week" => (
                    GetMonday(today).AddDays(-7),
                    GetSunday(today).AddDays(-7)
                ),

                "current_month" => (
                    new DateTime(today.Year, today.Month, 1),
                    new DateTime(today.Year, today.Month, DateTime.DaysInMonth(today.Year, today.Month))
                        .AddDays(1).AddTicks(-1)
                ),

                "last_month" => (
                    new DateTime(today.Year, today.Month, 1).AddMonths(-1),
                    new DateTime(today.Year, today.Month, 1).AddTicks(-1)
                ),

                "current_year" => (
                    new DateTime(today.Year, 1, 1),
                    new DateTime(today.Year, 12, 31).AddDays(1).AddTicks(-1)
                ),

                "last_year" => (
                    new DateTime(today.Year - 1, 1, 1),
                    new DateTime(today.Year - 1, 12, 31).AddDays(1).AddTicks(-1)
                ),

                "custom" => (
                    customStart?.Date ?? today,
                    (customEnd?.Date ?? today).AddDays(1).AddTicks(-1)
                ),

                _ => (
                    today,
                    today.AddDays(1).AddTicks(-1)
                )
            };
        }

        private static (DateTime Start, DateTime End) GetWeekRange(DateTime date)
        {
            DateTime GetMonday(DateTime d) =>
                d.AddDays(-(int)d.DayOfWeek + (d.DayOfWeek == DayOfWeek.Sunday ? -6 : 1));

            DateTime GetSunday(DateTime d) =>
                GetMonday(d).AddDays(7).AddTicks(-1);

            var monday = GetMonday(date.Date);
            var sunday = GetSunday(date.Date);

            return (Start: monday, End: sunday);
        }

        private static long ParseFileSizeToBytes(string sizeWithUnit)
        {
            if (string.IsNullOrWhiteSpace(sizeWithUnit))
                return 0;

            var parts = sizeWithUnit.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != 2)
                return 0;

            if (!double.TryParse(parts[0], out double size))
                return 0;

            string unit = parts[1].ToUpper();

            return unit switch
            {
                "B" => (long)size,
                "KB" => (long)(size * 1024),
                "MB" => (long)(size * Math.Pow(1024, 2)),
                "GB" => (long)(size * Math.Pow(1024, 3)),
                _ => 0
            };
        }

        private static List<BreakdownRecord> GetCustomBreakdown(IEnumerable<Folder> folders, IEnumerable<FileRecord> fileRecords, DateTime startDate, DateTime endDate)
        {
            var totalDays = (endDate - startDate).TotalDays;
            if (totalDays <= 7)
            {
                return [.. folders
                            .GroupBy(f => f.CreatedAt.Date)
                            .Select(g => new BreakdownRecord
                            {
                                Label = g.Key.ToString("dd-MM-yyyy"),
                                FolderCount = g.Count(),
                                TotalFileSizeBytes = fileRecords
                                    .Where(fr => g.Select(f => f.Id).Contains(fr.Folder))
                                    .Sum(fr => ParseFileSizeToBytes(fr.Size))
                            })
                            .OrderByDescending(b => b.Label)
                        ];
            }
            else if (totalDays <= 30)
            {
                return [.. folders
                            .GroupBy(f => GetWeekRange(f.CreatedAt))
                            .Select(g => new BreakdownRecord
                            {
                                Label = $"{g.Key.Start:dd-MM-yyyy} to {g.Key.End:dd-MM-yyyy}",
                                FolderCount = g.Count(),
                                TotalFileSizeBytes = fileRecords
                                    .Where(fr => g.Select(f => f.Id).Contains(fr.Folder))
                                    .Sum(fr => ParseFileSizeToBytes(fr.Size))
                            })
                            .OrderByDescending(b => b.Label)
                        ];
            }
            else if (totalDays <= 365)
            {
                return [.. folders
                            .GroupBy(f => new { f.CreatedAt.Year, f.CreatedAt.Month })
                            .Select(g => new BreakdownRecord
                            {
                                Label = $"{CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(g.Key.Month)} {g.Key.Year}",
                                FolderCount = g.Count(),
                                TotalFileSizeBytes = fileRecords
                                    .Where(fr => g.Select(f => f.Id).Contains(fr.Folder))
                                    .Sum(fr => ParseFileSizeToBytes(fr.Size))
                            })
                            .OrderByDescending(b => b.Label)
                        ];
            }
            else
            {
                return [.. folders
                            .GroupBy(f => f.CreatedAt.Year)
                            .Select(g => new BreakdownRecord
                            {
                                Label = g.Key.ToString(),
                                FolderCount = g.Count(),
                                TotalFileSizeBytes = fileRecords
                                    .Where(fr => g.Select(f => f.Id).Contains(fr.Folder))
                                    .Sum(fr => ParseFileSizeToBytes(fr.Size))
                            })
                            .OrderByDescending(b => b.Label)
                        ];
            }
        }

        private async Task<PaginatedResponse<FileRecordStatsResponse>> GetStats(
            Expression<Func<Folder, bool>> folderExpression,
            DateTime startDate,
            DateTime endDate,
            string dateRangeType,
            int pageNumber,
            int pageSize,
            Func<IGrouping<int, Folder>, Task<FileRecordStatsResponse>> buildFolderStatsFunc = null,
            Func<IGrouping<int, FileRecord>, Task<FileRecordStatsResponse>> buildFileStatsFunc = null,
            bool IsForOfficeUser = true)
        {
            Expression<Func<Folder, object>>[] includes = [f => f.User];
            IEnumerable<Folder> folders = await _folderService.GetAllAsync(folderExpression, includes);

            List<int> folderIds = [.. folders.Select(f => f.Id)];

            Expression<Func<FileRecord, bool>> fileExpression = dateRangeType?.ToLower() == "all_time"
                ? fr => fr.IsActive == true && fr.IsDeleted == false && folderIds.Contains(fr.Folder)
                : fr => fr.IsActive == true && fr.IsDeleted == false && fr.CreatedAt >= startDate && fr.CreatedAt <= endDate && folderIds.Contains(fr.Folder);

            IEnumerable<FileRecord> fileRecords = await _fileRecordService.GetAllAsync(fileExpression);

            IEnumerable<IGrouping<int, Folder>> groupedUsers = default;
            if (buildFolderStatsFunc != null)
                groupedUsers = folders.GroupBy(f => f.UserId ?? f.CreatedBy);

            IEnumerable<IGrouping<int, FileRecord>> groupedFileUsers = default;
            if (buildFileStatsFunc != null)
                groupedFileUsers = fileRecords
                    .Where(f => f.CreatedBy.HasValue)
                    .GroupBy(f => f.CreatedBy.Value);

            List<FileRecordStatsResponse> allStats = [];

            if (IsForOfficeUser && groupedUsers != null)
            {
                foreach (IGrouping<int, Folder> userGroup in groupedUsers)
                {
                    List<int> userFolderIds = [.. userGroup.Select(f => f.Id)];
                    IEnumerable<FileRecord> userFiles = fileRecords.Where(fr => userFolderIds.Contains(fr.Folder));

                    if (!userFiles.Any())
                        continue;

                    IEnumerable<Folder> filteredFolders = dateRangeType?.ToLower() == "all_time"
                        ? userGroup
                        : userGroup.Where(f => f.CreatedAt >= startDate && f.CreatedAt <= endDate && userFiles.Any(fr => fr.Folder == f.Id));

                    var stats = await buildFolderStatsFunc(userGroup);
                    var filteredFolderIds = filteredFolders.Select(f => f.Id).ToHashSet();
                    stats.TotalFolderCount = filteredFolders.Count();
                    stats.TotalFileSizeBytes = userFiles.Where(fr => filteredFolderIds.Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size));
                    stats.Breakdown = GetBreakdown(filteredFolders, userFiles, dateRangeType, startDate, endDate);

                    allStats.Add(stats);
                }
            }
            else if (!IsForOfficeUser && groupedFileUsers != null)
            {
                foreach (IGrouping<int, FileRecord> userFileGroup in groupedFileUsers)
                {
                    bool isOfficeUserId = await _userService.AnyAsync(u => u.Role == (int)UserRoles.OfficeUser && u.Id == userFileGroup.Key);
                    if (isOfficeUserId)
                        continue;

                    List<int> userFolderIds = [.. userFileGroup.Select(fr => fr.Folder)];
                    IEnumerable<Folder> userFolders = folders.Where(f => userFolderIds.Contains(f.Id));

                    if (!userFolders.Any())
                        continue;

                    IEnumerable<Folder> filteredFolders = dateRangeType?.ToLower() == "all_time"
                        ? userFolders
                        : userFolders.Where(f =>
                            f.CreatedAt >= startDate && f.CreatedAt <= endDate &&
                            userFileGroup.Any(fr => fr.Folder == f.Id));

                    var stats = await buildFileStatsFunc(userFileGroup);
                    var filteredFolderIds = filteredFolders.Select(f => f.Id).ToHashSet();
                    stats.TotalFolderCount = filteredFolders.Count();
                    stats.TotalFileSizeBytes = userFileGroup.Where(fr => filteredFolderIds.Contains(fr.Folder)).Sum(fr => ParseFileSizeToBytes(fr.Size));
                    stats.Breakdown = GetBreakdown(filteredFolders, userFileGroup, dateRangeType, startDate, endDate);

                    allStats.Add(stats);
                }
            }

            int totalCount = allStats.Count;
            List<FileRecordStatsResponse> pagedItems = [.. allStats
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)];

            return new PaginatedResponse<FileRecordStatsResponse>
            {
                Items = pagedItems,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalCount = totalCount,
                TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize)
            };
        }
        #endregion
    }

}