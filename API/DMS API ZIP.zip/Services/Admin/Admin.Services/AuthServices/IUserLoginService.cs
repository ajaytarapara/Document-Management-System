using Admin.Entities.ViewModels;
using Infrastructure.Entities;

namespace Admin.Services.AuthServices
{
    public interface IUserLoginService
    {
        public Task<UserLoginSummaryResponseVM> GetLast7DaysLogins();
        public Task<UserLogin> AddLogin(UserLogin userLogin);
        public Task<PaginatedResponse<UserLoginDetailResponseVM>> GetLoginDetailsByDate(UserLoginDetailRequestVM userLoginDetailRequestVM);
        public Task Logout();
    }
}