using System.Collections.Concurrent;
using Admin.Entities.ViewModels;
using Infrastructure.DependencyInjection;

namespace Admin.Services.AuthServices;

[SingletonDependency(ServiceType = typeof(IAuthCodeCache))]
public class AuthCodeCache : IAuthCodeCache
{
    private readonly ConcurrentDictionary<string, (LoginResponseVM Data, DateTime Expiry)> _store = new();

    public void Store(string code, LoginResponseVM data, TimeSpan ttl)
    {
        _store[code] = (data, DateTime.UtcNow.Add(ttl));
    }

    public Task<LoginResponseVM?> Retrieve(string code)
    {
        if (_store.TryGetValue(code, out var entry))
        {
            if (entry.Expiry > DateTime.UtcNow)
            {
                return Task.FromResult<LoginResponseVM?>(entry.Data);
            }
            _store.TryRemove(code, out _);
        }
        return Task.FromResult<LoginResponseVM?>(null);
    }

}
