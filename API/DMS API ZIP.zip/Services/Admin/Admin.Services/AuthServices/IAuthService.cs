using Admin.Entities.ViewModels;

namespace Admin.Services.AuthServices
{
    public interface IAuthService
    {
        public Task<LoginResponseVM> Login(LoginRequestVM login);
        public Task<(string authCode, bool isSuccess)> HandleOAuthSuccess(string email);
        public Task<LoginResponseVM>? Retrieve(string code);
        public Task<List<UsersResponse>> GetAllActiveUsersList();
        public Task UpdateAccountUserAsync(UpdateAccountUserRequestVM accountVM);
        public Task<UpdateAccountUserRequestVM> AccountUser(int userId);
        public Task ChangePasswordAsync(ChangePasswordRequestVM model);
        public Task<string> ForgotPasswordAsync(ForgotPasswordVM model);
        public Task<bool> VerifyPasswordAsync(VerifyOTPRequestVM model);
        public Task ResetPasswordAsync(ResetPasswordRequestVM model);
        public Task<string> ImpersonateAsync(int subUserId);
        public Task<string> StopImpersonateAsync(int userId);
        public Task<IEnumerable<SubUserListResponseVM>> GetSubUsers();
        public Task<int> GetMaxTabLimit(int id);
        public Task SetUpPasswordAsync(SetUpPasswordRequestVM model);
    }
}
