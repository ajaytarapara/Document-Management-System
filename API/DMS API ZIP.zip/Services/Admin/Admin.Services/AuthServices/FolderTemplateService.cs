using System.Linq.Expressions;
using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.FolderTemplate;
using AutoMapper;
using CoreServices.Generic;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Shared.ExceptionHandler;
using Shared.Helper;
using static Shared.Constant.Enums;

namespace Admin.Services.AuthServices
{
    [ScopedDependency(ServiceType = typeof(IFolderTemplateService))]
    public class FolderTemplateService(IGenericService<User, ApplicationDBContext> userService, IGenericService<UserTemplate, ApplicationDBContext> userTemplateService, IMapper mapper, IGenericService<UserTemplateTab, ApplicationDBContext> userTemplateTabService) : IFolderTemplateService
    {
        #region fields
        private readonly IGenericService<User, ApplicationDBContext> _userService = userService;
        private readonly IGenericService<UserTemplate, ApplicationDBContext> _userTemplateService = userTemplateService;
        private readonly IGenericService<UserTemplateTab, ApplicationDBContext> _userTemplateTabService = userTemplateTabService;
        private readonly IMapper _mapper = mapper;
        #endregion

        #region constructor
        #endregion

        #region methods
        public async Task<List<UsersResponse>> GetAllActiveOfficeUsersList()
        {
            Expression<Func<User, bool>> predicate = u => u.IsActive && u.IsDeleted == false && u.Role == (int)UserRoles.OfficeUser;
            IEnumerable<UsersResponse> usersResponses = await _userService.GetAllAsync(predicate, u => new UsersResponse
            {
                Id = AesEncryptionHelper.EncryptId(u.Id),
                UserName = u.UserName,
            });
            return [.. usersResponses];
        }

        public async Task<PaginatedResponse<UserTemplateResponseVM>> GetUserTemplatesByUserIdAsync(UserTemplateRequest userTemplateRequest)
        {
            int decrptedUserId = AesEncryptionHelper.DecryptId(userTemplateRequest.userId);
            Expression<Func<UserTemplate, bool>> predicate = t =>
                t.IsActive && t.IsDeleted == false && t.Users == decrptedUserId;

            int totalRecords = await _userTemplateService.CountAsync(predicate);

            IEnumerable<UserTemplateResponseVM> records = await _userTemplateService.GetPaginatedAsync(userTemplateRequest.PageNumber, userTemplateRequest.PageSize, x => new UserTemplateResponseVM
            {
                Id = AesEncryptionHelper.EncryptId(x.Id),
                Name = x.Name,
                TabsCount = x.TabsCount
            }, predicate, userTemplateRequest.SortBy, userTemplateRequest.SortDirection);

            PaginatedResponse<UserTemplateResponseVM> paginatedResponse = new()
            {
                Items = records,
                PageNumber = userTemplateRequest.PageNumber,
                PageSize = userTemplateRequest.PageSize,
                TotalCount = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / userTemplateRequest.PageSize)
            };

            return paginatedResponse;
        }

        public async Task AddFolderTemplateAsync(AddUserTemplateRequest request)
        {
            int decryptedUserId = AesEncryptionHelper.DecryptId(request.UserId);
            bool templateExists = await _userTemplateService.AnyAsync(x => x.Users == decryptedUserId && x.Name.ToLower() == request.Name.ToLower() && x.IsActive && x.IsDeleted == false);
            if (templateExists)
                throw new DataConflictException($"A template with the name '{request.Name}' already exists for this user");

            List<string> duplicateTabNames = [.. request.Tabs.GroupBy(tab => tab.Name.Trim().ToLower())
                                    .Where(g => g.Count() > 1)
                                    .Select(g => g.Key)];
            if (duplicateTabNames.Count != 0)
                throw new DataConflictException($"Duplicate tab name(s) found: {string.Join(", ", duplicateTabNames)}.");

            UserTemplate userTemplate = _mapper.Map<UserTemplate>(request);
            await _userTemplateService.InsertAsync(userTemplate);

            List<UserTemplateTab> userTemplateTabs = _mapper.Map<List<UserTemplateTab>>(request.Tabs);

            foreach (UserTemplateTab tab in userTemplateTabs)
            {
                tab.UserTemplate = userTemplate.Id;
            }

            await _userTemplateTabService.InsertManyAsync(userTemplateTabs);
        }

        public async Task DeleteFolderAsync(int id)
        {
            Expression<Func<UserTemplate, bool>> predicate = t => t.IsActive && t.IsDeleted == false && t.Id == id;
            UserTemplate userTemplate = await _userTemplateService.GetAsync(predicate) ?? throw new DataNotFoundException("Folder template not found");

            userTemplate.IsDeleted = true;
            await _userTemplateService.UpdateAsync(userTemplate);

            Expression<Func<UserTemplateTab, bool>> tabPredicate = tab => tab.UserTemplate == id && tab.IsDeleted == false && tab.IsActive;
            IEnumerable<UserTemplateTab> relatedTabs = await _userTemplateTabService.GetAllAsync(tabPredicate);

            foreach (UserTemplateTab tab in relatedTabs)
            {
                tab.IsDeleted = true;
            }
            await _userTemplateTabService.UpdateManyAsync(relatedTabs);
        }

        public async Task<UserTemplateResponseWithTabsVM> GetFolderTemplateById(int id)
        {
            Expression<Func<UserTemplate, bool>> predicate = t => t.IsActive && t.IsDeleted == false && t.Id == id;
            UserTemplateResponseWithTabsVM userTemplateResponseWithTabsVMuserTemplate = await _userTemplateService.GetFirstOrDefaultAsync(predicate, x => new UserTemplateResponseWithTabsVM
            {
                Id = x.Id,
                Name = x.Name,
                TabsCount = x.TabsCount,
                Tabs = x.UserTemplateTabs
                        .Where(tab => tab.IsActive && tab.IsDeleted == false)
                        .Select(tab => new UserTemplateTabResponse
                        {
                            Id = tab.Id,
                            Name = tab.Name,
                            Color = tab.Color,
                            IsLock = tab.IsLock,
                        }).ToList()
            }) ?? throw new DataNotFoundException("Folder template not found");

            return userTemplateResponseWithTabsVMuserTemplate;
        }

        public async Task UpdateFolderTemplateAsync(UpdateUserTemplateRequest request)
        {
            int decryptedTemplateId = AesEncryptionHelper.DecryptId(request.Id);
            int decryptedUserId = AesEncryptionHelper.DecryptId(request.UserId);
            Expression<Func<UserTemplate, bool>> predicate = t => t.IsActive && t.IsDeleted == false && t.Id == decryptedTemplateId;
            UserTemplate existingTemplate = await _userTemplateService.GetFirstOrDefaultAsync(predicate) ?? throw new DataNotFoundException("Folder template not found");

            bool duplicateNameExists = await _userTemplateService.AnyAsync(
                x => x.Users == decryptedUserId &&
                     x.Id != decryptedTemplateId &&
                     x.Name.ToLower() == request.Name.ToLower() &&
                     x.IsActive && x.IsDeleted == false
            );
            if (duplicateNameExists)
                throw new DataConflictException($"A template with the name '{request.Name}' already exists for this user.");

            List<string> duplicateTabNames = [.. request.Tabs
                .GroupBy(tab => tab.Name.Trim().ToLower())
                .Where(g => g.Count() > 1)
                .Select(g => g.Key)];

            if (duplicateTabNames.Count != 0)
                throw new DataConflictException($"Duplicate tab name(s) found: {string.Join(", ", duplicateTabNames)}.");

            _mapper.Map(request, existingTemplate);

            await _userTemplateService.UpdateAsync(existingTemplate);
            await _userTemplateTabService.DeleteManyAsync(x => x.UserTemplate == decryptedTemplateId);

            List<UserTemplateTab> updatedTabs = _mapper.Map<List<UserTemplateTab>>(request.Tabs);
            foreach (var tab in updatedTabs)
            {
                tab.UserTemplate = decryptedTemplateId;
            }
            await _userTemplateTabService.InsertManyAsync(updatedTabs);
        }
        #endregion
    }
}