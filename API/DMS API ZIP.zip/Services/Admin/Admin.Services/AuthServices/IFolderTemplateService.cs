using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.FolderTemplate;

namespace Admin.Services.AuthServices
{
    public interface IFolderTemplateService
    {
        public Task<List<UsersResponse>> GetAllActiveOfficeUsersList();
        public Task<PaginatedResponse<UserTemplateResponseVM>> GetUserTemplatesByUserIdAsync(UserTemplateRequest userTemplateRequest);
        public Task AddFolderTemplateAsync(AddUserTemplateRequest request);
        public Task DeleteFolderAsync(int id);
        public Task<UserTemplateResponseWithTabsVM> GetFolderTemplateById(int id);
        public Task UpdateFolderTemplateAsync(UpdateUserTemplateRequest request);
    }
}