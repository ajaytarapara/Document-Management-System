using System.Collections.Concurrent;
using System.Linq.Expressions;
using Admin.Entities.ViewModels;
using Admin.Services.Token;
using AutoMapper;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.Helper;
using Microsoft.Extensions.Hosting;
using Shared.ConfigItems;
using static Shared.Constant.Enums;
using static Admin.Services.UserServices.UserServices;

namespace Admin.Services.AuthServices;

[ScopedDependency(ServiceType = typeof(IAuthService))]
public class AuthService(IGenericService<User, ApplicationDBContext> authService, JwtTokenHelper jwtHelper, IMapper mapper, IAuthCodeCache authCodeCache, IUserLoginService userLoginService, ICurrentUserService currentUserService, IEmailSender emailSender, IHostEnvironment env, IGenericService<AssignedOffice, ApplicationDBContext> assignOfficeService) : IAuthService
{
    #region fields
    private readonly IMapper _mapper = mapper;
    private readonly IGenericService<User, ApplicationDBContext> _authService = authService;
    private readonly IUserLoginService _userLoginService = userLoginService;
    private readonly JwtTokenHelper _jwtHelper = jwtHelper;
    private readonly IAuthCodeCache _authCodeCache = authCodeCache;
    private readonly ConcurrentDictionary<string, (LoginResponseVM Data, DateTime Expiry)> _store = new();
    private readonly ICurrentUserService _currentUserService = currentUserService;
    private readonly IEmailSender _emailSender = emailSender;
    private readonly IHostEnvironment _env = env;
    private readonly IGenericService<AssignedOffice, ApplicationDBContext> _assignOfficeService = assignOfficeService;

    #endregion

    #region constructor
    #endregion

    #region methods
    public async Task<LoginResponseVM> Login(LoginRequestVM login)
    {
        User user = await _authService.GetAsync(x => x.UserName == login.Username && (x.IsDeleted ?? false) == false && x.IsActive, U => U.RoleNavigation) ?? throw new DataNotFoundException($"User with this user name {login.Username} not found.");
        LoginTypeEnum loginType = (LoginTypeEnum)EnumHelper.GetValueFromDescription<LoginTypeEnum>(user.LoginType);

        if (loginType == LoginTypeEnum.SSO)
            throw new InvalidOperationException(Messages.Error.Exception.NotAllowedWithUsernameException);

        bool decryptedPass = PasswordHelper.ValidatePassword(login.Password, user.PasswordHash);
        if (!decryptedPass)
            throw new DataNotFoundException(Messages.Error.General.InvalidCredentialMessage);

        string token = _jwtHelper.GenerateJwtToken(user.Email, user.Id, user.UserName, user.RoleNavigation.Name.ToString(), user.Id);

        LoginResponseVM response = _mapper.Map<LoginResponseVM>(user);
        response.Token = token;
        if (!user.IsFirstTimeLogin)
        {
            UserLogin userLogin = _mapper.Map<UserLogin>(user);
            await _userLoginService.AddLogin(userLogin);
        }
        return response;
    }

    public async Task<(string, bool)> HandleOAuthSuccess(string email)
    {
        User user = await _authService.GetAsync(u => u.Email == email && u.IsActive, u => u.RoleNavigation);
        if (user == null)
            return (Messages.Error.UserMessage.UserNotFoundMessage, false);

        LoginTypeEnum loginType = (LoginTypeEnum)EnumHelper.GetValueFromDescription<LoginTypeEnum>(user.LoginType);

        if (loginType == LoginTypeEnum.USERNAME)
            return (Messages.Error.UserMessage.NotAllowedWithSsoException, false);

        string token = _jwtHelper.GenerateJwtToken(user.Email, user.Id, user.UserName, user.RoleNavigation.Name.ToString(), user.Id);
        LoginResponseVM loginResponse = _mapper.Map<LoginResponseVM>(user);
        loginResponse.Token = token;

        UserLogin userLogin = _mapper.Map<UserLogin>(user);
        await _userLoginService.AddLogin(userLogin);

        var authCode = Guid.NewGuid().ToString("N");
        _authCodeCache.Store(authCode, loginResponse, TimeSpan.FromMinutes(1));

        return (authCode, true);
    }

    public Task<LoginResponseVM?> Retrieve(string code)
    {
        return _authCodeCache.Retrieve(code);
    }

    public async Task<List<UsersResponse>> GetAllActiveUsersList()
    {
        Expression<Func<User, bool>> predicate = u => u.IsActive && u.IsDeleted == false && u.Role != (int)UserRoles.Admin;
        IEnumerable<UsersResponse> usersResponses = await _authService.GetAllAsync(predicate, u => new UsersResponse
        {
            Id = AesEncryptionHelper.EncryptId(u.Id),
            UserName = u.UserName,
        });
        return usersResponses.ToList();
    }

    public async Task UpdateAccountUserAsync(UpdateAccountUserRequestVM accountVM)
    {
        User existingUser = await _authService.GetAsync(x => x.Id == accountVM.Id && (x.IsDeleted ?? false) == false) ?? throw new DataNotFoundException($"User with this user id is {accountVM.Id} not found.");

        bool emailExists = await _authService.AnyAsync(x =>
            x.Email == accountVM.Email && x.Id != accountVM.Id && (x.IsDeleted ?? false) == false);
        if (emailExists)
            throw new DataConflictException($"Email '{accountVM.Email}' is already associated with another user.");

        bool userNameExists = await _authService.AnyAsync(x =>
            x.UserName == accountVM.UserName && x.Id != accountVM.Id && (x.IsDeleted ?? false) == false);

        if (userNameExists)
            throw new DataConflictException($"Username '{accountVM.UserName}' is already taken.");

        _mapper.Map(accountVM, existingUser);
        await _authService.UpdateAsync(existingUser);
    }

    public async Task<UpdateAccountUserRequestVM> AccountUser(int userId)
    {
        User existingUser = await _authService.GetAsync(x => x.Id == userId && (x.IsDeleted ?? false) == false) ?? throw new DataNotFoundException($"User with this user id is {userId} not found.");
        UpdateAccountUserRequestVM mappedUser = _mapper.Map<UpdateAccountUserRequestVM>(existingUser);
        return mappedUser;
    }

    public async Task ChangePasswordAsync(ChangePasswordRequestVM model)
    {
        User? user = await GetUserAsync();

        if (!PasswordHelper.ValidatePassword(model.CurrentPassword, user.PasswordHash))
            throw new InvalidOperationException(Messages.Error.General.CurrentPwdIncorrect);

        if (PasswordHelper.ValidatePassword(model.NewPassword, user.PasswordHash))
            throw new InvalidOperationException(Messages.Error.General.NewPwdSameAsCurrentPwd);

        user.PasswordHash = PasswordHelper.CreateHash(model.NewPassword);

        await _authService.UpdateAsync(user);
    }

    private async Task<User?> GetUserAsync()
    {
        int userId = _currentUserService.GetUserId();
        return await GetUserById(userId);
    }

    private async Task<User?> GetUserById(int id) => await _authService.GetAsync(u =>
            u.Id == id && (u.IsDeleted ?? false) == false) ?? throw new DataNotFoundException($"User with this user id {id} not found.");

    public async Task<string> ForgotPasswordAsync(ForgotPasswordVM model)
    {
        User user = await _authService.GetAsync(u =>
             u.UserName == model.Username && (u.IsDeleted ?? false) == false) ?? throw new DataNotFoundException($"User with this user name {model.Username} not found.");
        string OTP = OtpGenerator.GenerateNumericOTP(4);
        user.OtpCode = OTP;
        string email = user.Email;
        string name = user.UserName;
        string relativePath = ConfigItems.EmailTemplateOtpPath;
        string templatePath = Path.Combine(_env.ContentRootPath, relativePath);
        string htmlBody = await File.ReadAllTextAsync(templatePath);
        htmlBody = htmlBody.Replace("{{UserName}}", user.UserName)
                           .Replace("{{OTP}}", OTP);
        _emailSender.SendEmailAsync(from: ConfigItems.FromMail,
            to: user.Email,
            subject: AppConstants.Constants.OtpCode,
            html: htmlBody);
        await _authService.UpdateAsync(user);
        return OTP;
    }

    public async Task<bool> VerifyPasswordAsync(VerifyOTPRequestVM model)
    {
        User user = await _authService.GetAsync(u =>
            u.UserName == model.Username && (u.IsDeleted ?? false) == false)
            ?? throw new DataNotFoundException($"User with username '{model.Username}' was not found.");

        if (user.OtpCode != model.Otp)
            throw new DataConflictException(Messages.Error.General.OtpIncorrect);

        user.OtpCode = null;
        user.IsOtpVerified = true;
        await _authService.UpdateAsync(user);

        return true;
    }


    public async Task ResetPasswordAsync(ResetPasswordRequestVM model)
    {
        User user = await _authService.GetAsync(u =>
           u.UserName == model.Username && (u.IsDeleted ?? false) == false)
           ?? throw new DataNotFoundException($"User with this user name {model.Username} not found.");

        if ((bool)!user.IsOtpVerified)
            throw new InvalidOperationException(Messages.Error.General.OtpNotVerified);

        if (PasswordHelper.ValidatePassword(model.NewPassword, user.PasswordHash))
            throw new InvalidOperationException(Messages.Error.General.NewPwdSameAsOldPwd);

        user.IsOtpVerified = false;
        user.PasswordHash = PasswordHelper.CreateHash(model.NewPassword);
        await _authService.UpdateAsync(user);
    }

    public async Task<string> ImpersonateAsync(int subUserId)
    {
        int userId = _currentUserService.GetUserId();

        User user = await _authService.GetAsync(x => x.Id == subUserId && (x.IsDeleted ?? false) == false, x => x.RoleNavigation);

        return _jwtHelper.GenerateJwtToken(user.Email, user.Id, user.UserName, user.RoleNavigation.Name.ToString(), userId);
    }

    public async Task<string> StopImpersonateAsync(int userId)
    {
        if (userId == null)
            throw new DataConflictException(Messages.Error.Exception.NotAbleToPersonateMessage);

        User user = await _authService.GetAsync(u => u.Id == userId, T => T.RoleNavigation);

        return _jwtHelper.GenerateJwtToken(
            user.Email,
            user.Id,
            user.UserName,
            user.RoleNavigation.Name,
            user.Id
        );
    }

    public async Task<IEnumerable<SubUserListResponseVM>> GetSubUsers()
    {
        int originalUserId = _currentUserService.GetOriginalUserId();
        AssignedOffice assignedOffice = await _assignOfficeService.GetAsync(x =>
        x.UserId == originalUserId &&
        (x.IsDeleted ?? false) == false);

        if (assignedOffice?.AssignedUser == null)
            return Enumerable.Empty<SubUserListResponseVM>();

        List<int> subUserIds = assignedOffice.AssignedUser.ToIntList();

        if (!subUserIds.Any())
            return Enumerable.Empty<SubUserListResponseVM>();

        IEnumerable<User> users = await _authService.GetAllAsync(u =>
            subUserIds.Contains(u.Id) &&
            (u.IsDeleted ?? false) == false);

        return users.Select(u => new SubUserListResponseVM
        {
            Id = u.Id,
            Username = u.UserName
        });

    }

    public async Task<int> GetMaxTabLimit(int id)
    {
        int maxTabLimit = await _authService.GetFirstOrDefaultAsync(
                            u => u.Id == id,
                            u => u.MaxTabLimit
                        );
        return maxTabLimit;
    }

    public async Task SetUpPasswordAsync(SetUpPasswordRequestVM model)
    {
        int userId = _currentUserService.GetUserId();
        User user = await _authService.GetAsync(u =>
           u.Id == userId && (u.IsDeleted ?? false) == false)
           ?? throw new DataNotFoundException($"User with this user userId {userId} not found.");

        if (!user.IsFirstTimeLogin)
            throw new InvalidOperationException(Messages.Error.General.FirstTimeLoginUserError);

        if (PasswordHelper.ValidatePassword(model.NewPassword, user.PasswordHash))
            throw new InvalidOperationException(Messages.Error.General.NewPwdSameAsTempPwd);

        user.PasswordHash = PasswordHelper.CreateHash(model.NewPassword);
        user.IsFirstTimeLogin = false;
        await _authService.UpdateAsync(user);
    }

    #endregion

}