using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.UserAnalytics;

namespace Admin.Services.AuthServices
{
    public interface IFileRecordService
    {
        public Task<PaginatedResponse<FileRecordStatsResponse>> GetFileRecordStats(FileRecordStatsRequest request);
    }
}