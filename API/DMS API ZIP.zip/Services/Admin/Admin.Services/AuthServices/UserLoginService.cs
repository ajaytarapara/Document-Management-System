using System.Linq.Expressions;
using Admin.Entities.ViewModels;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using LinqKit;
using Microsoft.EntityFrameworkCore;
using Shared.ExceptionHandler;
using Shared.Helper;

namespace Admin.Services.AuthServices
{
    [ScopedDependency(ServiceType = typeof(IUserLoginService))]
    public class UserLoginService(IGenericService<UserLogin, ApplicationDBContext> userLoginService, ICurrentUserService currentUserService) : IUserLoginService
    {
        #region fields
        private readonly IGenericService<UserLogin, ApplicationDBContext> _userLoginService = userLoginService;
        private readonly ICurrentUserService _currentUserService = currentUserService;
        #endregion

        #region constructor
        #endregion

        #region methods
        public Task<UserLogin> AddLogin(UserLogin userLogin)
        {
            return _userLoginService.InsertAsync(userLogin);
        }

        public async Task Logout()
        {
            int id = _currentUserService.GetOriginalUserId();
            DateTime today = DateTime.UtcNow.Date;
            DateTime tomorrow = today.AddDays(2);

            Expression<Func<UserLogin, bool>> predicate = ul =>
                ul.IsActive == true &&
                ul.Users == id &&
                (ul.IsDeleted == null || ul.IsDeleted == false) &&
                ul.LoginAt >= today && ul.LoginAt < tomorrow;

            IEnumerable<UserLogin> todayLogins = await _userLoginService.GetAllAsync(predicate);
            UserLogin userLogin = todayLogins
                .OrderByDescending(ul => ul.LoginAt)
                .FirstOrDefault();

            if (userLogin == null)
                return;

            userLogin.LogoutAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
            await _userLoginService.UpdateAsync(userLogin);
        }

        public async Task<UserLoginSummaryResponseVM> GetLast7DaysLogins()
        {
            DateTime today = DateTime.Today;
            DateTime startDate = today.AddDays(-6);

            List<UserLoginSummaryVM> loginData = await _userLoginService.GetQueryable()
                                        .Where(x => x.LoginAt.Date >= startDate &&
                                                    x.LoginAt.Date <= today &&
                                                    x.IsActive == true &&
                                                    (x.IsDeleted == null || x.IsDeleted == false))
                                        .GroupBy(x => x.LoginAt.Date)
                                        .Select(g => new UserLoginSummaryVM
                                        {
                                            Date = g.Key,
                                            Day = ((DayOfWeek)g.Key.DayOfWeek).ToString(),
                                            LoginCount = g.Select(x => x.Users).Distinct().Count()
                                        })
                                        .ToListAsync();

            List<UserLoginSummaryVM> summary = [.. Enumerable.Range(0, 7)
                        .Select(i =>
                        {
                            DateTime date = startDate.AddDays(i);
                            UserLoginSummaryVM existing = loginData.FirstOrDefault(x => x.Date.Date == date.Date);
                            return existing ?? new UserLoginSummaryVM
                            {
                                Date = date,
                                Day = date.DayOfWeek.ToString(),
                                LoginCount = 0
                            };
                        })
                        .OrderByDescending(x => x.Date)];

            return new UserLoginSummaryResponseVM
            {
                userLoginSummaryVMs = summary
            };
        }

        public async Task<PaginatedResponse<UserLoginDetailResponseVM>> GetLoginDetailsByDate(UserLoginDetailRequestVM userLoginDetailRequestVM)
        {

            Expression<Func<UserLogin, bool>> predicate = ul =>
                ul.LoginAt.Date == userLoginDetailRequestVM.date.Date &&
                ul.IsActive == true &&
                (ul.IsDeleted == null || ul.IsDeleted == false);

            if (!string.IsNullOrEmpty(userLoginDetailRequestVM.userId))
            {
                int decryptedUserId = AesEncryptionHelper.DecryptId(userLoginDetailRequestVM.userId);
                predicate = predicate.And(ul => ul.Users == decryptedUserId);
            }

            int totalRecords = await _userLoginService.CountAsync(predicate);

            IEnumerable<UserLoginDetailResponseVM> records = await _userLoginService.GetPaginatedAsync(userLoginDetailRequestVM.PageNumber, userLoginDetailRequestVM.PageSize, x => new UserLoginDetailResponseVM
            {
                Name = x.UsersNavigation.UserName,
                Email = x.UsersNavigation.Email,
                FirstName = x.UsersNavigation.FirstName,
                LastName = x.UsersNavigation.LastName,
                LoginDate = x.LoginAt,
                LogoutDate = x.LogoutAt,
            }, predicate, userLoginDetailRequestVM.SortBy, userLoginDetailRequestVM.SortDirection);

            PaginatedResponse<UserLoginDetailResponseVM> paginatedResponse = new()
            {
                Items = records,
                PageNumber = userLoginDetailRequestVM.PageNumber,
                PageSize = userLoginDetailRequestVM.PageSize,
                TotalCount = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / userLoginDetailRequestVM.PageSize)
            };

            return paginatedResponse;
        }
        #endregion

    }
}