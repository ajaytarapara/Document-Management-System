using Admin.Entities.ViewModels;

namespace Admin.Services.AuthServices
{
    public interface IAuthCodeCache
    {
        void Store(string code, LoginResponseVM data, TimeSpan ttl);
        Task<LoginResponseVM?> Retrieve(string code);
    }

}