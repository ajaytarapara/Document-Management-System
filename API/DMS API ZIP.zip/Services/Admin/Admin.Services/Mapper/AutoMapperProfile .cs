using Admin.Entities.ViewModels;
using Infrastructure.Entities;
using Admin.Entities.ViewModels.User;
using Admin.Entities.ViewModels.FolderTemplate;
using Shared.ViewModels.Base;
using Admin.Entities.ViewModels.DmsForms;
using Shared.Constant;
using Shared.Helper;

namespace Admin.Services.Mapper
{
    public class AutoMapperProfile : AutoMapper.Profile
    {
        /// <summary>
        /// AutoMapper Profile
        /// </summary>
        public AutoMapperProfile()
        {
            /// <summary>
            /// Map from User to LoginResponseVM, automatically mapping matching properties.
            /// </summary>
            CreateMap<User, LoginResponseVM>()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.Id.ToString()))
                .ForMember(dest => dest.Username, opt => opt.MapFrom(src => src.UserName))
                .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"))
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => src.RoleNavigation.Name))
                .ForMember(dest => dest.Token, opt => opt.Ignore());

            /// <summary>
            /// Map from User to UserLogin, automatically mapping matching properties.
            /// </summary>    
            CreateMap<User, UserLogin>()
               .ForMember(dest => dest.Users, opt => opt.MapFrom(src => src.Id))
               .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.Id))
               .ForMember(dest => dest.LoginAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
               .ForMember(dest => dest.Id, opt => opt.Ignore())
               .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)));

            CreateMap<AddUserTemplateRequest, UserTemplate>()
                .ForMember(dest => dest.TabsCount, opt => opt.MapFrom(src => src.Tabs.Count.ToString()))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(_ => 1))
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(_ => true))
                .ForMember(dest => dest.Users, opt => opt.MapFrom(src => AesEncryptionHelper.DecryptId(src.UserId)));

            CreateMap<UserTemplateTabRequest, UserTemplateTab>()
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(_ => true))
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(_ => 1));

            // Mapping configuration between UpdateAccountUserRequestVM and User.
            // - Automatically maps matching properties.
            // - Sets UpdatedAt to current UTC time during mapping from VM to User.
            // - Sets UpdatedBy using the Id from the source VM.
            // - ReverseMap enables reverse mapping from User back to UpdateAccountUserRequestVM.
            CreateMap<UpdateAccountUserRequestVM, User>()
               .ForMember(dest => dest.UpdatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
               .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.Id)).ReverseMap();


            /// <summary>
            /// Map from User entity to UserVM
            /// </summary>
            CreateMap<User, UserVM>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"))
                .ForMember(dest => dest.PhoneNumber, opt => opt.MapFrom(src => src.PhoneNumber.ToString()))
                .ForMember(dest => dest.PrivilegeDelete, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDelete))
                .ForMember(dest => dest.PrivilegeDownload, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDownload))
                .ForMember(dest => dest.PrivilegeView, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeView))
                .ForMember(dest => dest.HideLockTabs, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.HideLockTabs))
                .ForMember(dest => dest.MaxTabLimit, opt => opt.MapFrom(src => src.MaxTabLimit))
                .ForMember(dest => dest.AssignedOffices, opt => opt.MapFrom(src =>
                    src.AssignedOfficeUsers != null ? string.Join(",", src.AssignedOfficeUsers.Where(x => !string.IsNullOrWhiteSpace(x.AssignedUser))
                    .Select(x => x.AssignedUser)) : null))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.RoleName, opt => opt.MapFrom(src => src.RoleNavigation.Name.ToString())).ReverseMap();

            /// <summary>
            /// Map from CreateUserVM to User entity
            /// </summary>
            CreateMap<User, CreateUserVM>()
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.PrivilegeDelete, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDelete))
                .ForMember(dest => dest.PrivilegeDownload, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDownload))
                .ForMember(dest => dest.PrivilegeView, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeView))
                .ForMember(dest => dest.HideLockTabs, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.HideLockTabs))
                .ForMember(dest => dest.AssignedOffices, opt => opt.MapFrom(src =>
                    src.AssignedOfficeUsers != null ? string.Join(",", src.AssignedOfficeUsers.Where(x => !string.IsNullOrWhiteSpace(x.AssignedUser))
                    .Select(x => x.AssignedUser)) : null)).ReverseMap();

            /// <summary>
            // Map from CreateUserVM to UserRolePermission entity
            /// </summary>
            CreateMap<CreateUserVM, UserRolePermission>()
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc))).ReverseMap();

            CreateMap<UpdateUserTemplateRequest, UserTemplate>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.DecryptId(src.Id)))
                .ForMember(dest => dest.Users, opt => opt.MapFrom(src => AesEncryptionHelper.DecryptId(src.UserId)))
                .ForMember(dest => dest.UpdatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(_ => 1));

            /// <summary>
            /// Map from UpdateUserVM to User entity
            /// </summary>
            CreateMap<User, UpdateUserVM>()
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.PrivilegeDelete, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDelete))
                .ForMember(dest => dest.PrivilegeDownload, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeDownload))
                .ForMember(dest => dest.PrivilegeView, opt => opt.MapFrom(src =>
                    src.UserRolePermissionUsersNavigations.FirstOrDefault()!.PrivilegeView))
                .ForMember(dest => dest.HideLockTabs, opt => opt.MapFrom(src =>
               src.UserRolePermissionUsersNavigations.FirstOrDefault()!.HideLockTabs))
               .ForMember(dest => dest.AssignedOffices, opt => opt.MapFrom(src =>
                    src.AssignedOfficeUsers != null ? string.Join(",", src.AssignedOfficeUsers.Where(x => !string.IsNullOrWhiteSpace(x.AssignedUser))
                    .Select(x => x.AssignedUser)) : null)).ReverseMap()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.DecryptId(src.Id)));

            /// <summary>
            // Map from UpdateUserVM to UserRolePermission entity
            /// </summary>
            CreateMap<UpdateUserVM, UserRolePermission>()
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ReverseMap();

            /// <summary>
            // Map from DmsForm to DMSFormFileVM entity
            /// </summary>
            CreateMap<DmsForm, DMSFormFileVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)))
                .ForMember(dest => dest.Size, opt => opt.MapFrom(src => Convert.ToInt64(src.Size)))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt.ToString(AppConstants.Constants.DateFormate))).ReverseMap();
        }
    }
}
