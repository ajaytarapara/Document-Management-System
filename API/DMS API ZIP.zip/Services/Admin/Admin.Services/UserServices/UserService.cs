using Newtonsoft.Json;
using Admin.Entities.ViewModels.User;
using AutoMapper;
using Infrastructure.Context;
using Infrastructure.Entities;
using Infrastructure.DependencyInjection;
using CoreServices.Generic;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using static Shared.Constant.Enums;
using Shared.ExceptionHandler;
using Shared.ViewModels.Base;
using Shared.Helper;
using System.ComponentModel;
using System.Linq.Expressions;
using Shared.Constant;
using Shared.ConfigItems;
using Microsoft.Extensions.Hosting;

namespace Admin.Services.UserServices
{
    [ScopedDependency(ServiceType = typeof(IUserService))]
    public class UserServices : IUserService
    {
        #region fields
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IGenericService<User, ApplicationDBContext> _userService;
        private readonly IGenericService<UserRolePermission, ApplicationDBContext> _permissionService;
        private readonly IGenericService<AssignedOffice, ApplicationDBContext> _assignedOfficeService;

        private readonly IMapper _mapper;
        private readonly IEmailSender _emailSender;

        private readonly IHostEnvironment _env;

        #endregion

        #region constructor

        public UserServices(
            IGenericService<User, ApplicationDBContext> userService,
            IGenericService<UserRolePermission, ApplicationDBContext> permissionService,
            IGenericService<AssignedOffice, ApplicationDBContext> assignedOfficeService,
            IMapper mapper,
            IHttpContextAccessor httpContextAccessor,
            IEmailSender emailSender,
            IHostEnvironment env)
        {
            _userService = userService;
            _permissionService = permissionService;
            _assignedOfficeService = assignedOfficeService;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            _emailSender = emailSender;
            _env = env;
        }

        #endregion

        #region methods
        public async Task<PaginationResponseVM<UserVM>> GetAllUsersAsync(int userId, PaginationRequestVM request)
        {
            UserRoles currentUserRole = GetCurrentUserRole();
            UserRoles targetRole = GetTargetRole(currentUserRole);
            UserFilterRequestVM filters = ParseSearchFilters(request.SearchKey);

            Expression<Func<User, bool>> filter = BuildFilterPredicate(userId, targetRole, filters);

            int pageIndex = Math.Max(request.PageNumber, 1);
            int pageSize = Math.Max(request.PageSize, 5);
            string sortColumn = string.IsNullOrWhiteSpace(request.SortBy) ? nameof(User.Id) : request.SortBy;
            string sortDirection = request.SortOrder.ToString().ToLower();

            int totalRecords = await _userService.CountAsync(filter);

            IEnumerable<UserVM> records = await _userService.GetPaginatedAsync(
                pageNumber: pageIndex,
                pageSize: pageSize,
                select: ProjectToUserVM(),
                predicate: filter,
                sortBy: sortColumn,
                sortDirection: sortDirection
            );

            records = [.. records.Select(u =>
            {
                u.Id = AesEncryptionHelper.EncryptId(int.Parse(u.Id));
                return u;
            })];

            return new PaginationResponseVM<UserVM>
            {
                Items = records,
                TotalCount = totalRecords,
                PageIndex = pageIndex,
                PageSize = pageSize,
                SortColumn = sortColumn,
                SortDirection = sortDirection
            };
        }
        public async Task<UserVM> CreateAsync(CreateUserVM model, int userId)
        {
            string roleClaim = GetUserRoleFromClaims();

            UserRoles? parsedRole = EnumHelper.GetValueFromDescription<UserRoles>(roleClaim);
            int userRole = parsedRole.HasValue ? (int)parsedRole.Value : (int)UserRoles.User;

            User? userExists = await _userService.GetAsync(u => (u.UserName == model.UserName.Trim() || u.Email == model.Email) && u.IsDeleted == false);

            if (userExists != null)
            {
                throw new DataConflictException(Messages.Error.UserMessage.UserAlreadyExists);
            }

            User user = _mapper.Map<User>(model);

            user.CreatedBy = userId;
            user.Role = userRole == (int)UserRoles.Admin ? (int)UserRoles.OfficeUser : (int)UserRoles.User;

            string password = GeneratePassword();
            user.PasswordHash = PasswordHelper.CreateHash(password);

            await _userService.InsertAsync(user);

            if (userRole == (int)UserRoles.OfficeUser)
            {
                UserRolePermission permission = _mapper.Map<UserRolePermission>(model);
                permission.Users = user.Id;
                permission.CreatedBy = userId;

                await _permissionService.InsertAsync(permission);
            }

            User? createdUser = await _userService.GetAsync(u => u.Id == user.Id && u.IsDeleted != true, u => u.RoleNavigation, u => u.AssignedOfficeUsers);

            await SendUserCredentialsAsync(model, password);

            return _mapper.Map<UserVM>(createdUser);
        }

        public async Task<UserVM> UpdateAsync(UpdateUserVM model, int updatedBy)
        {
            int decryptedUserId = AesEncryptionHelper.DecryptId(model.Id);
            string roleClaim = GetUserRoleFromClaims();

            UserRoles? parsedRole = EnumHelper.GetValueFromDescription<UserRoles>(roleClaim);
            int userRole = parsedRole.HasValue ? (int)parsedRole.Value : (int)UserRoles.User;

            User existingUser = await GetExistingUserAsync(decryptedUserId);

            ValidateRoleUpdateAuthorization((UserRoles)existingUser.Role);

            await EnsureNoDuplicateUser(model, decryptedUserId);

            LoginTypeEnum? loginType = EnumHelper.GetValueFromDescription<LoginTypeEnum>(model.LoginType);

            if (existingUser.Email != model.Email && (loginType.Value == LoginTypeEnum.SSO || loginType.Value == LoginTypeEnum.BOTH))
            {
                throw new DataConflictException(Messages.Error.UserMessage.NotAbleToChangeEmail);
            }

            _mapper.Map(model, existingUser);
            existingUser.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
            existingUser.UpdatedBy = updatedBy;

            await _userService.UpdateAsync(existingUser);

            await UpdateUserPermissionsIfNeeded(existingUser.Role, model, decryptedUserId, updatedBy);

            await AssignedOfficesUser(model.AssignedOffices, decryptedUserId, updatedBy);

            User? updatedUser = await _userService.GetAsync(u => u.Id == decryptedUserId && u.IsDeleted != true, u => u.RoleNavigation, u => u.AssignedOfficeUsers);
            return _mapper.Map<UserVM>(updatedUser);
        }

        public async Task<UpdateUserVM> GetUserByIdAsync(int id)
        {
            UserRoles currentUserRole = GetCurrentUserRole();

            User targetUser = await GetTargetUserByIdAsync(id);

            ValidateViewAuthorization(currentUserRole, (UserRoles)targetUser.Role);

            return _mapper.Map<UpdateUserVM>(targetUser);
        }

        public async Task<bool> DeleteUserByIdAsync(int id)
        {
            UserRoles currentUserRole = GetCurrentUserRole();

            User user = await GetUserForDeleteAsync(id);

            ValidateDeleteAuthorization(currentUserRole, (UserRoles)user.Role);

            user.IsDeleted = true;
            await _userService.UpdateAsync(user);

            return true;
        }

        public async Task<IEnumerable<OfficeUserVM>> GetAllOfficeUsersAsync()
        {

            Expression<Func<User, bool>> predicate = u => u.IsDeleted == false && u.Role == 2;
            IEnumerable<OfficeUserVM> usersResponses = await _userService.GetAllAsync(predicate, u => new OfficeUserVM
            {
                Id = u.Id,
                UserName = u.UserName,
                Name = (u.FirstName ?? "") + " " + (u.LastName ?? "")
            });
            return usersResponses.ToList();
        }

        private async Task SendUserCredentialsAsync(CreateUserVM user, string password)
        {

            string relativePath = ConfigItems.EmailTemplateCredentialsPath;
            string templatePath = Path.Combine(_env.ContentRootPath, relativePath);
            string htmlBody = await File.ReadAllTextAsync(templatePath);

            htmlBody = htmlBody.Replace("{{UserName}}", user.UserName)
                               .Replace("{{FirstName}}", user.FirstName)
                               .Replace("{{LastName}}", user.LastName)
                               .Replace("{{Password}}", password);

            await _emailSender.SendEmailAsync(
                from: ConfigItems.FromMail,
                to: user.Email,
                subject: AppConstants.Constants.PasswordEmailTemplateSubject,
                html: htmlBody
            );
        }

        #endregion

        private string GetUserRoleFromClaims()
        {
            ClaimsIdentity? identity = _httpContextAccessor.HttpContext?.User?.Identity as ClaimsIdentity;

            if (identity == null || !identity.IsAuthenticated)
                return string.Empty;

            return identity.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty;
        }

        public static class EnumHelper
        {
            public static TEnum? GetValueFromDescription<TEnum>(string description) where TEnum : struct, Enum
            {
                foreach (var field in typeof(TEnum).GetFields())
                {
                    var attribute = Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) as DescriptionAttribute;
                    if ((attribute != null && attribute.Description == description) || field.Name == description)
                    {
                        return (TEnum)field.GetValue(null);
                    }
                }

                return null;
            }
        }

        private UserRoles GetTargetRole(UserRoles currentUserRole)
        {
            return currentUserRole switch
            {
                UserRoles.Admin => UserRoles.OfficeUser,
                _ => UserRoles.User
            };
        }

        private UserFilterRequestVM ParseSearchFilters(string? searchKey)
        {
            if (string.IsNullOrWhiteSpace(searchKey))
                return new UserFilterRequestVM();

            UserFilterRequestVM? deserialized = JsonConvert.DeserializeObject<UserFilterRequestVM>(searchKey);
            return deserialized ?? new UserFilterRequestVM();
        }

        private Expression<Func<User, bool>> BuildFilterPredicate(int userId, UserRoles targetRole, UserFilterRequestVM filters)
        {
            string? lowerUserName = filters.UserName?.ToLower();
            string? lowerOfficeUser = filters.OfficeUser?.ToLower();

            return (User user) =>
                user.Role == (int)targetRole &&
                user.CreatedBy == userId &&
                user.IsDeleted != true &&
                (string.IsNullOrWhiteSpace(lowerUserName) || user.UserName.ToLower().Contains(lowerUserName)) &&
                (string.IsNullOrWhiteSpace(lowerOfficeUser) ||
                    (user.FirstName + " " + user.LastName).ToLower().Contains(lowerOfficeUser)) &&
                (!filters.RoleType.HasValue || user.Role == filters.RoleType.Value);
        }

        private async Task<User> GetExistingUserAsync(int id)
        {
            User? user = await _userService.GetAsync(
                u => u.Id == id && u.IsDeleted != true,
                u => u.UserRolePermissionUsersNavigations,
                u => u.AssignedOfficeUsers
            );

            if (user == null)
                throw new DataNotFoundException(Messages.Error.UserMessage.UserNotFoundMessage);

            return user;
        }

        private async Task EnsureNoDuplicateUser(UpdateUserVM model, int userId)
        {
            User? duplicateUser = await _userService.GetAsync(
                u => (u.UserName == model.UserName.Trim() || u.Email == model.Email) && u.Id != userId
            );

            if (duplicateUser != null)
                throw new DataConflictException(Messages.Error.UserMessage.UserAlreadyExists);
        }

        private async Task UpdateUserPermissionsIfNeeded(int role, UpdateUserVM model, int userId, int updatedBy)
        {

            UserRolePermission? existingPermission = await _permissionService.GetAsync(p => p.Users == userId);

            if (existingPermission != null)
            {
                existingPermission.PrivilegeDelete = model.PrivilegeDelete;
                existingPermission.PrivilegeDownload = model.PrivilegeDownload;
                existingPermission.PrivilegeView = model.PrivilegeView;
                existingPermission.HideLockTabs = model.HideLockTabs;
                existingPermission.UpdatedBy = updatedBy;
                existingPermission.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
                await _permissionService.UpdateAsync(existingPermission);
            }
            else
            {
                UserRolePermission newPermission = _mapper.Map<UserRolePermission>(model);
                newPermission.Users = userId;
                newPermission.CreatedBy = updatedBy;
                newPermission.CreatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
                await _permissionService.InsertAsync(newPermission);
            }
        }
        private UserRoles GetCurrentUserRole()
        {
            string roleClaim = GetUserRoleFromClaims();
            UserRoles? parsedRole = EnumHelper.GetValueFromDescription<UserRoles>(roleClaim);
            return parsedRole ?? UserRoles.User;
        }

        private async Task<User> GetTargetUserByIdAsync(int id)
        {
            User? user = await _userService.GetAsync(
                u => u.Id == id && u.IsDeleted != true,
                u => u.UserRolePermissionUsersNavigations,
                u => u.AssignedOfficeUsers
            );

            if (user == null)
            {
                throw new DataNotFoundException(Messages.Error.UserMessage.UserNotFoundMessage);
            }

            return user;
        }

        private async Task<User> GetUserForDeleteAsync(int id)
        {
            User? user = await _userService.GetAsync(u => u.Id == id && u.IsDeleted != true);

            if (user == null)
            {
                throw new DataNotFoundException(Messages.Error.UserMessage.UserNotFoundMessage);
            }

            return user;
        }

        private void ValidateViewAuthorization(UserRoles currentUserRole, UserRoles targetUserRole)
        {
            switch (currentUserRole)
            {
                case UserRoles.Admin when targetUserRole != UserRoles.OfficeUser:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.AdminViewRestriction);

                case UserRoles.OfficeUser when targetUserRole != UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.OfficeUserViewRestriction);

                case UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.SubUserCannotView);
            }
        }

        private void ValidateDeleteAuthorization(UserRoles currentUserRole, UserRoles targetUserRole)
        {
            switch (currentUserRole)
            {
                case UserRoles.Admin when targetUserRole != UserRoles.OfficeUser:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.AdminDeleteRestriction);

                case UserRoles.OfficeUser when targetUserRole != UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.OfficeUserDeleteRestriction);

                case UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.SubUserCannotDelete);
            }
        }

        private void ValidateRoleUpdateAuthorization(UserRoles existingRole)
        {
            UserRoles currentUserRole = GetCurrentUserRole();

            switch (currentUserRole)
            {
                case UserRoles.Admin when existingRole != UserRoles.OfficeUser:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.AdminUpdateRestriction);

                case UserRoles.OfficeUser when existingRole != UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.OfficeUserUpdateRestriction);

                case UserRoles.User:
                    throw new UnauthorizedAccessException(Messages.Error.UserMessage.SubUserCannotUpdate);
            }

        }

        private static Expression<Func<User, UserVM>> ProjectToUserVM()
        {
            return user => new UserVM
            {
                Id = user.Id.ToString(),
                UserName = user.UserName,
                Email = user.Email,
                Name = user.FirstName + " " + user.LastName,
                Role = user.Role,
                PhoneNumber = user.PhoneNumber.ToString(),
                PostalCode = user.PostalCode,
                Address = user.Address,
                City = user.City,
                IsActive = user.IsActive,
                CreatedAt = user.CreatedAt,
                MaxTabLimit = user.MaxTabLimit,
                PrivilegeView = user.UserRolePermissionUsersNavigations
                            .Where(r => r != null)
                            .Select(r => r.PrivilegeView)
                            .FirstOrDefault() == true,
                PrivilegeDownload = user.UserRolePermissionUsersNavigations
                            .Where(r => r != null)
                            .Select(r => r.PrivilegeDownload)
                            .FirstOrDefault() == true,
                PrivilegeDelete = user.UserRolePermissionUsersNavigations
                            .Where(r => r != null)
                            .Select(r => r.PrivilegeDelete)
                            .FirstOrDefault() == true,
                HideLockTabs = user.UserRolePermissionUsersNavigations
                            .Where(r => r != null)
                            .Select(r => r.HideLockTabs)
                            .FirstOrDefault() == true,
                AssignedOffices = string.Join(",", user.AssignedOfficeUsers
                            .Where(a => a.IsDeleted != true)
                            .Select(a => a.AssignedUser))
            };
        }

        private async Task AssignedOfficesUser(string officeUsers, int id, int updatedBy)
        {
            AssignedOffice? existingAssignedOfficeUser = await _assignedOfficeService.GetAsync(p => p.UserId == id);

            if (existingAssignedOfficeUser != null)
            {
                existingAssignedOfficeUser.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
                existingAssignedOfficeUser.UpdatedBy = updatedBy;
                existingAssignedOfficeUser.AssignedUser = officeUsers;

                await _assignedOfficeService.UpdateAsync(existingAssignedOfficeUser);
            }
            else
            {
                AssignedOffice newAssignedOfficeUser = new AssignedOffice();
                newAssignedOfficeUser.AssignedUser = officeUsers;
                newAssignedOfficeUser.CreatedBy = updatedBy;
                newAssignedOfficeUser.UserId = id;
                newAssignedOfficeUser.CreatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);

                await _assignedOfficeService.InsertAsync(newAssignedOfficeUser);
            }
        }

        private string GeneratePassword()
        {
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string digits = "0123456789";
            const string specialChars = "@$!%*?&";
            const string allChars = upper + lower + digits + specialChars;

            Random randomChar = new();

            List<char> passwordChars = new()
            {
                upper[randomChar.Next(upper.Length)],
                lower[randomChar.Next(lower.Length)],
                digits[randomChar.Next(digits.Length)],
                specialChars[randomChar.Next(specialChars.Length)]
            };

            while (passwordChars.Count < 8)
            {
                passwordChars.Add(allChars[randomChar.Next(allChars.Length)]);
            }

            return new string(passwordChars.OrderBy(_ => randomChar.Next()).ToArray());
        }

    }
}
