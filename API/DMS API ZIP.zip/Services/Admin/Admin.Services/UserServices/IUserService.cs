using Admin.Entities.ViewModels.User;
using Infrastructure.Entities;
using Shared.ViewModels.Base;

namespace Admin.Services.UserServices
{
    public interface IUserService
    {
        Task<UserVM> CreateAsync(CreateUserVM model, int userId);
        Task<PaginationResponseVM<UserVM>> GetAllUsersAsync(int userId, PaginationRequestVM request);
        Task<UpdateUserVM> GetUserByIdAsync(int id);
        Task<UserVM> UpdateAsync(UpdateUserVM user, int updatedBy);
        Task<bool> DeleteUserByIdAsync(int id);
        Task<IEnumerable<OfficeUserVM>> GetAllOfficeUsersAsync();
    }
}
