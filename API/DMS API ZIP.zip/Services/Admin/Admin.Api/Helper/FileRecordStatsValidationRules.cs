using Admin.Entities.ViewModels.UserAnalytics;
using FluentValidation;
using Shared.Constant;

namespace Admin.Api.Helper
{
    public class FileRecordStatsValidationRules
    {
        public static AbstractValidator<FileRecordStatsRequest> FileRecordStatsValidator()
        {
            var validator = new InlineValidator<FileRecordStatsRequest>();

            validator.RuleFor(x => x.DateRangeType)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(FileRecordStatsRequest.DateRangeType)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(FileRecordStatsRequest.DateRangeType), 50));

            validator.RuleFor(x => x.CustomStartDate)
                .NotEmpty()
                .When(x => string.Equals(x.DateRangeType, "custom", StringComparison.OrdinalIgnoreCase))
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(FileRecordStatsRequest.CustomStartDate)));

            validator.RuleFor(x => x.CustomEndDate)
                .NotEmpty()
                .When(x => string.Equals(x.DateRangeType, "custom", StringComparison.OrdinalIgnoreCase))
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(FileRecordStatsRequest.CustomEndDate)));

            validator.RuleFor(x => x.CustomStartDate)
                .LessThanOrEqualTo(x => x.CustomEndDate)
                .When(x => x.CustomStartDate.HasValue && x.CustomEndDate.HasValue)
                .WithMessage(Messages.Error.General.InvalidDateRangeMessage);

            return validator;
        }

    }
}