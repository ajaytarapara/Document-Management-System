using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.FolderTemplate;
using FluentValidation;
using Shared.Constant;
using Shared.Helper;

namespace Admin.Api.Helper
{
    public static class AdminValidationRules
    {
        public static AbstractValidator<LoginRequestVM> LoginValidator()
        {
            var validator = new InlineValidator<LoginRequestVM>();

            validator.RuleFor(x => x.Username)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(LoginRequestVM.Username)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(LoginRequestVM.Username), 50));

            validator.RuleFor(x => x.Password)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(LoginRequestVM.Password)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(LoginRequestVM.Password), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);



            return validator;
        }

        public static AbstractValidator<UpdateAccountUserRequestVM> UpdateAccountUserValidator()
        {
            var validator = new InlineValidator<UpdateAccountUserRequestVM>();
            validator.RuleFor(x => x.Id)
                .GreaterThan(0)
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.Id)));

            validator.RuleFor(x => x.FirstName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.FirstName)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.FirstName), 50));

            validator.RuleFor(x => x.LastName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.LastName)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.LastName), 50));

            validator.RuleFor(x => x.Email)
                .NotEmpty().WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.Email)))
                .MaximumLength(200).WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.Email), 200))
                .Matches(AppConstants.RegularExpression.Email).WithMessage(Messages.Error.General.InvalidEmailMessage);

            validator.RuleFor(x => x.Role)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.Role)));

            validator.RuleFor(x => x.UserName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.UserName)))
                .Matches(AppConstants.RegularExpression.UserName)
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.UserName), 50));

            validator.RuleFor(x => x.PhoneNumber)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.PhoneNumber)))
                .Matches(AppConstants.RegularExpression.PhoneNumber)
                .WithMessage(Messages.Error.Validation.InvalidIndianPhoneNumber);

            validator.RuleFor(x => x.Address)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.Address)))
                .MaximumLength(200)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.Address), 200));

            validator.RuleFor(x => x.PostalCode)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateAccountUserRequestVM.PostalCode)))
                .InclusiveBetween(100000, 999999)
                .WithMessage(Messages.Error.Validation.InvalidPostalCode);

            validator.RuleFor(x => x.City)
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateAccountUserRequestVM.City), 100));

            return validator;
        }

        public static AbstractValidator<ChangePasswordRequestVM> ChangePasswordRequestVMValidator()
        {
            var validator = new InlineValidator<ChangePasswordRequestVM>();

            validator.RuleFor(x => x.CurrentPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ChangePasswordRequestVM.CurrentPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(ChangePasswordRequestVM.CurrentPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            validator.RuleFor(x => x.NewPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ChangePasswordRequestVM.NewPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(ChangePasswordRequestVM.NewPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            return validator;
        }

        public static AbstractValidator<AddUserTemplateRequest> AddUserTemplateValidator()
        {
            var validator = new InlineValidator<AddUserTemplateRequest>();

            validator.RuleFor(x => x.UserId)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(AddUserTemplateRequest.UserId)));

            validator.RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(AddUserTemplateRequest.Name)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(AddUserTemplateRequest.Name), 50));

            validator.RuleFor(x => x.Tabs)
                .NotNull()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(AddUserTemplateRequest.Tabs)))
                .Must(tabs => tabs.Count > 0)
                .WithMessage("At least one tab is required.");

            validator.RuleForEach(x => x.Tabs).SetValidator(UserTemplateTabValidator());

            return validator;
        }

        public static AbstractValidator<UpdateUserTemplateRequest> UpdateUserTemplateValidator()
        {
            var validator = new InlineValidator<UpdateUserTemplateRequest>();

            validator.RuleFor(x => x.Id)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateUserTemplateRequest.Id)));

            validator.RuleFor(x => x.UserId)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateUserTemplateRequest.UserId)));

            validator.RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateUserTemplateRequest.Name)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UpdateUserTemplateRequest.Name), 50));

            validator.RuleFor(x => x.Tabs)
                .NotNull()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UpdateUserTemplateRequest.Tabs)))
                .Must(tabs => tabs.Count > 0)
                .WithMessage("At least one tab is required.");

            validator.RuleForEach(x => x.Tabs).SetValidator(UserTemplateTabValidator());

            return validator;
        }

        public static AbstractValidator<UserTemplateTabRequest> UserTemplateTabValidator()
        {
            var validator = new InlineValidator<UserTemplateTabRequest>();

            validator.RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UserTemplateTabRequest.Name)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UserTemplateTabRequest.Name), 50));

            validator.RuleFor(x => x.Color)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(UserTemplateTabRequest.Color)))
                .MaximumLength(20)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(UserTemplateTabRequest.Color), 20));

            return validator;
        }

        public static AbstractValidator<ForgotPasswordVM> ForgotPasswordRequestVMValidator()
        {
            var validator = new InlineValidator<ForgotPasswordVM>();

            validator.RuleFor(x => x.Username)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ForgotPasswordVM.Username)));

            return validator;
        }

        public static AbstractValidator<VerifyOTPRequestVM> VerifyOTPRequestVMValidator()
        {
            var validator = new InlineValidator<VerifyOTPRequestVM>();

            validator.RuleFor(x => x.Username)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(VerifyOTPRequestVM.Username)));
            validator.RuleFor(x => x.Otp)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(VerifyOTPRequestVM.Otp)))
                .MaximumLength(4)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(VerifyOTPRequestVM.Otp), 4));

            return validator;
        }

        public static AbstractValidator<ResetPasswordRequestVM> ResetPasswordRequestVMValidator()
        {
            var validator = new InlineValidator<ResetPasswordRequestVM>();

            validator.RuleFor(x => x.ConfirmPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ResetPasswordRequestVM.ConfirmPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(ResetPasswordRequestVM.ConfirmPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            validator.RuleFor(x => x.NewPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ResetPasswordRequestVM.NewPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(ResetPasswordRequestVM.NewPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            validator.RuleFor(x => x.Username)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(ResetPasswordRequestVM.Username)));

            return validator;
        }

        public static AbstractValidator<SetUpPasswordRequestVM> SetUpPasswordRequestVMValidator()
        {
            var validator = new InlineValidator<SetUpPasswordRequestVM>();

            validator.RuleFor(x => x.ConfirmPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SetUpPasswordRequestVM.ConfirmPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(SetUpPasswordRequestVM.ConfirmPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            validator.RuleFor(x => x.NewPassword)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SetUpPasswordRequestVM.NewPassword)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(SetUpPasswordRequestVM.NewPassword), 100))
                .Matches(AppConstants.RegularExpression.StrongPassword)
                .WithMessage(Messages.Error.General.InvalidPasswordMessage);

            return validator;
        }
    }
}
