using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Admin.Entities.ViewModels.DmsForms;
using FluentValidation;
using Shared.Constant;

namespace Admin.Api.Helper
{
    public class DmsFormShareValidationRules
    {
        public static AbstractValidator<ShareDmsFormVM> ShareDmsFormValidator()
        {
            var validator = new InlineValidator<ShareDmsFormVM>();

            validator.RuleFor(x => x.FromEmail)
                .NotEmpty().WithMessage(Messages.Error.Validation.ValidFromEmailRequired)
                .EmailAddress().WithMessage(Messages.Error.Validation.ValidFromEmailRequired);

            validator.RuleFor(x => x.ToEmail)
                .NotEmpty().WithMessage(Messages.Error.Validation.ValidToEmailRequired)
                .Must(toEmail =>
                {
                    string[] emails = toEmail.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                    return emails.All(email => new EmailAddressAttribute().IsValid(email));
                })
                .WithMessage(Messages.Error.Validation.ValidToEmailRequired);

            validator.RuleFor(x => x.ToName)
                .NotEmpty().WithMessage(Messages.Error.Validation.RecipientNameRequired);

            validator.RuleFor(x => x.Subject)
                .NotEmpty().WithMessage(Messages.Error.Validation.SubjectRequired);

            validator.RuleFor(x => x.LinkExpiration)
                .InclusiveBetween(1, 168)
                .WithMessage(Messages.Error.Validation.LinkExpirationRange);

            return validator;
        }
    }
}