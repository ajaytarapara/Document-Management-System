using Admin.Entities.ViewModels.User;
using FluentValidation;
using Shared.Constant;

namespace Admin.Api.Helper
{
    public class UserValidationRules
    {
        public static AbstractValidator<CreateUserVM> UserValidator()
        {
            InlineValidator<CreateUserVM> validator = new();

            validator.RuleFor(x => x.FirstName)
                .NotEmpty().WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.FirstName)))
                .MaximumLength(50).WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.FirstName), 50));

            validator.RuleFor(x => x.LastName)
                .NotEmpty().WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.LastName)))
                .MaximumLength(50).WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.LastName), 50));

            validator.RuleFor(x => x.Email)
                .NotEmpty().WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.Email)))
                .MaximumLength(200).WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.Email), 200))
                .Matches(AppConstants.RegularExpression.Email).WithMessage(Messages.Error.General.InvalidEmailMessage);

            validator.RuleFor(x => x.PhoneNumber)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.PhoneNumber)))
                .Matches(AppConstants.RegularExpression.PhoneNumber)
                .WithMessage(Messages.Error.Validation.InvalidIndianPhoneNumber);

            validator.RuleFor(x => x.UserName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.UserName)))
                .Matches(AppConstants.RegularExpression.UserName)
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.UserName), 50));

            validator.RuleFor(x => x.Address)
                .MaximumLength(200)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.Address), 200));

            validator.RuleFor(x => x.City)
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(CreateUserVM.City), 100));

            validator.RuleFor(x => x.PostalCode)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(CreateUserVM.PostalCode)))
                .InclusiveBetween(100000, 999999)
                .WithMessage(Messages.Error.Validation.InvalidPostalCode);
            return validator;
        }
    }
}
