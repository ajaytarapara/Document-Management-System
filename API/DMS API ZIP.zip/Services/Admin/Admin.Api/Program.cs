using Admin.Services.Mapper;
using ProgramExtensions.Extensions;
using Shared.ConfigItems;
using Infrastructure.Context;
using Microsoft.AspNetCore.Authentication.Cookies;
using Admin.Services.Token;
using Microsoft.AspNetCore.Authentication.OAuth;
using Microsoft.EntityFrameworkCore;
using Shared.Helper;

var builder = WebApplication.CreateBuilder(args);

//set configuration
ConfigItems.Configuration = builder.Configuration;

// Load configuration
builder.Configuration.AddAppConfiguration(builder.Environment).AddAesConfiguration();

// Logging
builder.Logging.ClearProviders();

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
})
.AddCookie()
.AddGoogle("Google", options =>
{
    options.ClientId = ConfigItems.GoogleClientId;
    options.ClientSecret = ConfigItems.GoogleClientSecret;
    options.CallbackPath = "/signin-google";
    options.Events = new OAuthEvents
    {
        OnRemoteFailure = context =>
        {
            context.Response.Redirect($"{ConfigItems.FrontendOAuthRedirectUrl}?error=access_denied");
            context.HandleResponse();
            return Task.CompletedTask;
        }
    };
})
.AddMicrosoftAccount("Microsoft", options =>
{
    options.ClientId = ConfigItems.MicrosoftClientId;
    options.ClientSecret = ConfigItems.MicrosoftClientSecret;
    options.CallbackPath = "/signin-microsoft";
    options.Events = new OAuthEvents
    {
        OnRemoteFailure = context =>
        {
            context.Response.Redirect($"{ConfigItems.FrontendOAuthRedirectUrl}?error=access_denied");
            context.HandleResponse();
            return Task.CompletedTask;
        }
    };
});

// Register services
builder.Services
    .AddAppServices<ApplicationDBContext>(builder.Configuration)
    .AddAppLocalization()
    .AddAppSwagger("Admin")
    .AddAppAuthentication()
    .AddAppControllers()
    .RegisterServices(["Admin.Services", "Admin.Entities"]);

// register the auto mapper profile
builder.Services.AddAutoMapper(typeof(AutoMapperProfile));
builder.Services.AddScoped<JwtTokenHelper>();
builder.Services.AddScoped<IEmailSender, SmtpEmailSender>();

// Configure ApplicationDBContext
builder.Services.AddDbContext<ApplicationDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();
app.UseCors("AllowAll");
// Middleware pipeline
app.UseAppPipeline();

app.Run();
