using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Microsoft.AspNetCore.Authentication;
using Shared.ConfigItems;
using Admin.Services.AuthServices;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Shared.ViewModels.Base;
using Admin.Entities.ViewModels;
using static Shared.Constant.Enums;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.Helper;
using Admin.Api.Helper;
using Microsoft.AspNetCore.Authorization;

namespace Admin.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController(IAuthService authService, IUserLoginService userLoginService) : BaseController
    {
        #region Properties
        private readonly IAuthService _authService = authService;
        private readonly IUserLoginService _userLoginService = userLoginService;
        #endregion

        #region constructor
        #endregion

        /// <summary>
        /// Authenticates an administrator based on the provided login credentials.
        /// </summary>
        /// <param name="login">An object containing the login credentials (e.g., email and password).</param>
        /// <returns>
        /// A success response containing authentication details, such as user information and a token,
        /// if the login is successful.
        /// </returns>
        /// <remarks>
        /// This method validates the input credentials using predefined rules,
        /// then calls the authentication service to perform login.
        /// </remarks>
        [HttpPost]
        public async Task<BaseResponse> Login([FromBody] LoginRequestVM login)
        {
            Validator.ValidateAndThrow(login, AdminValidationRules.LoginValidator());
            LoginResponseVM loginResponse = await _authService.Login(login);
            return ApiSuccess(ResponseStatusCode.Ok, loginResponse, Messages.Success.Auth.LoginSuccess);
        }

        /// <summary>
        /// Logs out a user by their ID.
        /// </summary>
        /// <param name="id">The ID of the user to be logged out.</param>
        /// <returns>
        /// A successful base response indicating the user has been logged out.
        /// </returns>
        [HttpPost("logout")]
        public async Task<BaseResponse> Logout()
        {
            await _userLoginService.Logout();
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.LogoutSuccess);
        }

        /// <summary>
        /// Initiates the Google OAuth sign-in process.
        /// </summary>
        /// <returns>A challenge result that redirects the user to Google's OAuth login page.</returns>
        [HttpGet("signin-google")]
        public IActionResult SignInWithGoogle()
        {
            var redirectUri = ConfigItems.GoogleCallBackUrl;
            return Challenge(new AuthenticationProperties { RedirectUri = redirectUri }, Messages.Success.General.Google);
        }

        /// <summary>
        /// Initiates the Microsoft OAuth sign-in process.
        /// </summary>
        /// <returns>A challenge result that redirects the user to Microsoft's OAuth login page.</returns>
        [HttpGet("signin-microsoft")]
        public IActionResult SignInWithMicrosoft()
        {
            var redirectUri = ConfigItems.MicrosoftCallBackUrl;
            return Challenge(new AuthenticationProperties { RedirectUri = redirectUri }, Messages.Success.General.Microsoft);
        }


        /// <summary>
        /// Handles the OAuth callback after successful authentication with an external provider.
        /// Generates a one-time authorization code if the user exists and is active,
        /// and redirects to the frontend with the code or an error parameter.
        /// </summary>
        /// <returns>
        /// A redirect response to the frontend with either:
        /// - <c>?code={authCode}</c> if the user is valid and registered
        /// </returns>
        [HttpGet("oauth-success")]
        public async Task<IActionResult> OAuthSuccess()
        {
            AuthenticateResult result = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (!result.Succeeded || result.Principal == null)
                return Redirect($"{ConfigItems.FrontendOAuthRedirectUrl}?error=unauthorized");

            string email = result.Principal.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrWhiteSpace(email))
                return Redirect($"{ConfigItems.FrontendOAuthRedirectUrl}?error=email_not_found");

            (string authCode, bool isSuccess) = await _authService.HandleOAuthSuccess(email);

            string redirectUrl = (isSuccess, authCode) switch
            {
                (true, not null) when !string.IsNullOrWhiteSpace(authCode) =>
                    $"{ConfigItems.FrontendOAuthRedirectUrl}?code={authCode}",

                (_, var message) when message == Messages.Error.UserMessage.NotAllowedWithSsoException =>
                    $"{ConfigItems.FrontendOAuthRedirectUrl}?error=not_allowed_method",

                _ => $"{ConfigItems.FrontendOAuthRedirectUrl}?error=user_not_found"
            };

            return Redirect(redirectUrl);
        }

        /// <summary>
        /// Exchanges an authentication code for a valid login response.
        /// </summary>
        /// <param name="code">The one-time code received via OAuth redirect.</param>
        /// <returns>The login response with token and user info.</returns>
        [HttpPost("exchange-code")]
        public async Task<BaseResponse> ExchangeCode([FromQuery] string code)
        {
            LoginResponseVM loginResponse = await _authService.Retrieve(code) ?? throw new DataNotFoundException(Messages.Error.UserMessage.CodeNotFoundOrExpired);
            return ApiSuccess(ResponseStatusCode.Ok, loginResponse, Messages.Success.Auth.LoginSuccess);
        }

        /// <summary>
        /// Retrieves the count of unique user logins for each of the last 7 days.
        /// Each day will include the login count and the day of the week.
        /// </summary>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a <see cref="UserLoginSummaryResponseVM"/>
        /// with login data for the past 7 days.
        /// </returns>
        [Authorize]
        [HttpGet("last-7-days-logins")]
        public async Task<BaseResponse> GetLast7DaysLogins()
        {
            UserLoginSummaryResponseVM userLoginSummaryResponseVM = await _userLoginService.GetLast7DaysLogins();
            return ApiSuccess(ResponseStatusCode.Ok, userLoginSummaryResponseVM, Messages.Success.Auth.LastDaysRecordSuccess);
        }


        /// <summary>
        /// Retrieves paginated login details for a specific date. Optionally filters by user ID.
        /// </summary>
        /// <param name="userLoginDetailRequestVM">
        /// A request object containing the target date, optional user ID, pagination settings, and sorting options.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a paginated list of <see cref="UserLoginDetailResponseVM"/>
        /// with login records for the specified date.
        /// </returns>
        [Authorize]
        [HttpPost("details-by-date")]
        public async Task<BaseResponse> GetUserLoginDetailsByDate([FromBody] UserLoginDetailRequestVM userLoginDetailRequestVM)
        {
            PaginatedResponse<UserLoginDetailResponseVM> result = await _userLoginService.GetLoginDetailsByDate(userLoginDetailRequestVM);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Auth.LoginRecordForSelectedDateSuccess);
        }

        [Authorize]
        [HttpGet("get-all-activeusers")]
        public async Task<BaseResponse> GetAllActiveUsersList()
        {
            List<UsersResponse> result = await _authService.GetAllActiveUsersList();
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Auth.AllUserslistfetchedSuccess);
        }

        /// <summary>
        /// Updates the account information of an existing user.
        /// </summary>
        /// <param name="userVm">The view model containing updated user details.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the success or failure of the operation.
        /// </returns>
        /// <response code="200">Returns success if the account was updated successfully.</response>
        /// <response code="400">Returns bad request if validation fails.</response>
        /// <response code="500">Returns internal server error if an unexpected issue occurs.</response>
        [HttpPut("update-account")]
        [Authorize]
        public async Task<BaseResponse> UpdateUser([FromBody] UpdateAccountUserRequestVM userVm)
        {
            Validator.ValidateAndThrow(userVm, AdminValidationRules.UpdateAccountUserValidator());
            await _authService.UpdateAccountUserAsync(userVm);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.AccountProfileSuccess);
        }

        /// <summary>
        /// Retrieves user account details by user ID.
        /// </summary>
        /// <param name="id">The unique identifier of the user.</param>
        /// <returns>A <see cref="BaseResponse"/> containing the user's account details.</returns>
        [HttpGet("get-account/{id}")]
        [Authorize]
        public async Task<BaseResponse> GetUserById(int id)
        {
            UpdateAccountUserRequestVM userVm = await _authService.AccountUser(id);
            return ApiSuccess(ResponseStatusCode.Ok, userVm);
        }

        /// <summary>
        /// Changes the current user's password.
        /// </summary>
        /// <param name="model">An instance of <see cref="ChangePasswordRequestVM"/> containing the current and new password.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating whether the password change was successful.
        /// </returns>
        /// <exception cref="ValidationException">
        /// Thrown when the model fails FluentValidation rules.
        /// </exception>
        [HttpPut("change-password")]
        [Authorize]
        public async Task<BaseResponse> ChangePassword([FromBody] ChangePasswordRequestVM model)
        {
            Validator.ValidateAndThrow(model, AdminValidationRules.ChangePasswordRequestVMValidator());
            await _authService.ChangePasswordAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.UserProfilePwdUpdateSuccess);
        }
        /// <summary>
        /// Sends a one-time password (OTP) to the user's registered email or phone
        /// for password reset verification.
        /// </summary>
        /// <param name="model">The user details (e.g., username or email) to identify the account.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing the generated OTP and a success message,
        /// if the user is found and OTP is sent successfully.
        /// </returns>
        /// <response code="200">OTP sent successfully.</response>
        /// <response code="404">User not found.</response>
        /// <response code="400">Invalid request payload.</response>
        [HttpPost("forgotPassword/send-otp")]
        public async Task<BaseResponse> SendOTP([FromBody] ForgotPasswordVM model)
        {
            Validator.ValidateAndThrow(model, AdminValidationRules.ForgotPasswordRequestVMValidator());
            string OTP = await _authService.ForgotPasswordAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, OTP, Messages.Success.Auth.OTPSentSuccessfully);
        }

        /// <summary>
        /// Verifies the OTP (One-Time Password) entered by the user during the password reset process.
        /// </summary>
        /// <param name="model">The OTP verification request containing the username and OTP code.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating whether the OTP is valid and verified successfully.
        /// </returns>
        /// <response code="200">OTP verified successfully.</response>
        /// <response code="400">Invalid OTP or request format.</response>
        /// <response code="404">User not found.</response>
        [HttpPost("verify-otp")]
        public async Task<BaseResponse> VerifyOTP([FromBody] VerifyOTPRequestVM model)
        {
            Validator.ValidateAndThrow(model, AdminValidationRules.VerifyOTPRequestVMValidator());
            bool isVerify = await _authService.VerifyPasswordAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, isVerify, Messages.Success.Auth.OTPVerifiedSuccessfully);
        }

        /// <summary>
        /// Resets the user's password after successful OTP verification.
        /// </summary>
        /// <param name="model">
        /// The password reset request containing the username and new password.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> confirming the password has been changed successfully.
        /// </returns>
        /// <response code="200">Password changed successfully.</response>
        /// <response code="400">Invalid request data or OTP not verified.</response>
        /// <response code="404">User not found.</response>
        [HttpPost("reset-password")]
        public async Task<BaseResponse> ResetPassword([FromBody] ResetPasswordRequestVM model)
        {
            Validator.ValidateAndThrow(model, AdminValidationRules.ResetPasswordRequestVMValidator());
            await _authService.ResetPasswordAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.PasswordChange);
        }

        /// <summary>
        /// Starts impersonation by generating a JWT token for the selected sub-user.
        /// </summary>
        /// <param name="model">Contains the ID of the sub-user to impersonate.</param>
        /// <returns>A new JWT token that represents the impersonated user.</returns>
        [Authorize]
        [HttpPost("impersonate")]
        public async Task<BaseResponse> Impersonate([FromBody] ImpersonateRequestVM model)
        {
            string token = await _authService.ImpersonateAsync(model.SubUserId);
            return ApiSuccess(ResponseStatusCode.Ok, new { token }, Messages.Success.Auth.ImpersonateSuccessfully);
        }

        /// <summary>
        /// Stops the current impersonation and returns a JWT token for the original user.
        /// </summary>
        /// <returns>A new JWT token that represents the original authenticated user.</returns>
        [Authorize]
        [HttpPost("stop-impersonation/{id}")]
        public async Task<BaseResponse> StopImpersonation(int id)
        {
            var token = await _authService.StopImpersonateAsync(id);
            return ApiSuccess(ResponseStatusCode.Ok, new { token }, Messages.Success.Auth.StopImpersonateSuccessfully);
        }

        /// <summary>
        /// Retrieves a list of sub-users associated with the currently authenticated user.
        /// </summary>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="SubUserListResponseVM"/> 
        /// and a success message if the operation completes successfully.
        /// </returns>
        [Authorize]
        [HttpGet("sub-users")]
        public async Task<BaseResponse> GetSubUsers()
        {
            IEnumerable<SubUserListResponseVM> subUsers = await _authService.GetSubUsers();
            return ApiSuccess(ResponseStatusCode.Ok, subUsers, Messages.Success.General.Success);
        }

        /// <summary>
        /// Allows an authenticated user to set up their password during first-time login.
        /// </summary>
        /// <param name="model">The password setup request containing the new password.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating whether the password setup was successful.
        /// </returns>
        /// <remarks>
        /// This endpoint requires authentication. Validation is applied to ensure the request is valid,
        /// and the user must be logging in for the first time. If successful, the user's password is updated.
        /// </remarks>
        [Authorize]
        [HttpPost("setUp-password")]
        public async Task<BaseResponse> SetUpPassword([FromBody] SetUpPasswordRequestVM model)
        {
            Validator.ValidateAndThrow(model, AdminValidationRules.SetUpPasswordRequestVMValidator());
            await _authService.SetUpPasswordAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.SetUpPasswordSuccessfully);
        }

        /// <summary>
        /// Retrieves the maximum tab limit for a user based on the provided user ID.
        /// </summary>
        /// <param name="id">The unique identifier of the user.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing an integer value representing the maximum tab limit 
        /// and a success message if the operation completes successfully.
        /// </returns>
        [Authorize]
        [HttpGet("get-max-tab-limit/{userId}")]
        public async Task<BaseResponse> GetMaxTabLimit(int userId)
        {
            int maxTabLimit = await _authService.GetMaxTabLimit(userId);
            return ApiSuccess(ResponseStatusCode.Ok, maxTabLimit);
        }
    }
}