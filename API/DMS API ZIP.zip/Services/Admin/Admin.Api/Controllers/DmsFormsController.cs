using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.ViewModels.Base;
using static Shared.Constant.Enums;
using Shared.Constant;
using Admin.Services.DmsFormService;
using Admin.Entities.ViewModels.DmsForms;
using Shared.Helper;
using Admin.Api.Helper;
using Shared.ViewModels.DmsForms;

namespace Admin.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DmsFormsController : BaseController
    {
        #region Properties

        private readonly IDmsFormService _dmsFormService;

        #endregion

        #region Constructor

        public DmsFormsController(IDmsFormService dmsFormService)
        {
            _dmsFormService = dmsFormService;
        }

        #endregion

        #region Endpoints   

        /// <summary>
        /// Upload one or more DMS forms for a specific user.
        /// </summary>
        /// <param name="model">The upload model containing files and user ID.</param>
        /// <returns>A success message with result metadata.</returns>
        [HttpPost("upload")]
        public async Task<BaseResponse?> UploadDmsForms([FromBody] UploadDmsFormsVM model)
        {
            if (!int.TryParse(HttpContext?.User.FindFirst("userId")?.Value, out int createdBy))
                return ApiSuccess(ResponseStatusCode.BadRequest, Messages.Error.Validation.InvalidUser);

            string result = await _dmsFormService.AddDmsForm(model, model.UserId, createdBy);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileUploadSuccessMessage);
        }

        /// <summary>
        /// Get a paginated list of all uploaded DMS forms for a user.
        /// </summary>
        /// <param name="request">Pagination and filter data.</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPost("all")]
        public async Task<BaseResponse> GetAllDMSForms([FromBody] PaginationRequestVM request, [FromQuery] int userId)
        {
            string baseUrl = $"{Request.Scheme}://{Request.Host}";
            PaginationResponseVM<DMSFormFileVM> result = await _dmsFormService.GetAllDmsFormsAsync(request, userId, baseUrl);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }

        /// <summary>
        /// Rename a previously uploaded DMS form.
        /// </summary>
        /// <param name="model">Rename details (ID and new name).</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPut("rename")]
        public async Task<BaseResponse> RenameFile([FromBody] RenameFileVM model, [FromQuery] int userId)
        {
            bool result = await _dmsFormService.RenameDmsFormFileAsync(model.DmsFormId, model.NewFileName, userId);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileUpdateSuccessMessage);
        }

        /// <summary>
        /// Delete an uploaded DMS form after validation.
        /// </summary>
        /// <param name="request">Delete request containing ID and password.</param>
        [HttpPost("delete")]
        public async Task<BaseResponse> DeleteFile([FromBody] DeleteFileRequest request)
        {
            bool result = await _dmsFormService.DeleteDmsFormFileAsync(request);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileDeleteSuccessMessage);
        }

        /// <summary>
        /// Retrieves the details of a DMS form by its encrypted form ID and user ID.
        /// </summary>
        /// <param name="getFormRequest">
        /// The request containing the encrypted form ID (<see cref="GetFormRequest.FormId"/>)
        /// and the target user ID (<see cref="GetFormRequest.UserId"/>).
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing the DMS form details (<see cref="DMSFormFileVM"/>).
        /// </returns>
        [HttpPost("getByFormId")]
        public async Task<BaseResponse> GetFileByFormId([FromBody] GetFormRequest getFormRequest)
        {
            DMSFormFileVM result = await _dmsFormService.GetDmsFormByIdAsync(getFormRequest.FormId, getFormRequest.UserId);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }

        /// <summary>
        /// Shares one or more DMS forms with specified recipients.
        /// </summary>
        /// <param name="dmsFormVM">
        /// The share request model containing the form IDs, recipient details,
        /// message content, and link expiration settings.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the result of the share operation,
        /// along with the original share request data if successful.
        /// </returns>
        [HttpPatch("share-dmsforms")]
        public async Task<BaseResponse> ShareDmsForms([FromBody] ShareDmsFormVM dmsFormVM)
        {
            Validator.ValidateAndThrow(dmsFormVM, DmsFormShareValidationRules.ShareDmsFormValidator());
            int userId = int.Parse(HttpContext?.User.FindFirst("userId")?.Value);

            await _dmsFormService.ShareDmsFormAsync(dmsFormVM, userId);
            return ApiSuccess(ResponseStatusCode.Ok, dmsFormVM, Messages.Success.DMSForm.DmsFormSharedSuccessMessage);
        }

        /// <summary>
        /// Saves the edited version of a DMS form with updated field values or metadata.
        /// </summary>
        /// <param name="model">
        /// The request model containing the edited form data, including form ID,
        /// updated fields, and any additional metadata required for saving.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the result of the save operation,
        /// including a success flag if the form was updated successfully.
        /// </returns>
        [HttpPost("save-edited")]
        public async Task<BaseResponse> SaveEditedForm([FromBody] SaveEditedFormVM model)
        {
            bool result = await _dmsFormService.SaveEditedFormAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.DmsFormUpdateSuccessMessage);
        }
        /// <summary>
        /// Submit an edited DMS form.
        /// </summary>
        /// <param name="model">The request model containing form data, fields, and file information.</param>
        /// <returns>A response indicating whether the submission was successful.</returns>
        [HttpPost("submit-edited")]
        public async Task<BaseResponse> SubmitEditedForm([FromBody] SubmittedDmsFromRequest model)
        {
            bool result = await _dmsFormService.SubmitEditedFormAsync(model);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.DmsFormSubmitSuccessMessage);
        }

        /// <summary>
        /// Get a paginated list of all submitted DMS forms for a user.
        /// </summary>
        /// <param name="request">Pagination and filter data.</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPost("submitted/all")]
        public async Task<BaseResponse> GetAllSubmittedDmsForms([FromBody] PaginationRequestVM request, [FromQuery] int userId)
        {
            string baseUrl = $"{Request.Scheme}://{Request.Host}";
            PaginationResponseVM<DMSFormFileVM> result = await _dmsFormService.GetAllSubmittedDmsFormsAsync(request, userId, baseUrl);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }


        #endregion
    }
}
