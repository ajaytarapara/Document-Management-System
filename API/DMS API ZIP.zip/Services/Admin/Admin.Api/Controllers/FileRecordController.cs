using Admin.Api.Helper;
using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.UserAnalytics;
using Admin.Services.AuthServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.Helper;
using Shared.ViewModels.Base;
using static Shared.Constant.Enums;

namespace Admin.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FileRecordController(IFileRecordService fileRecordService) : BaseController
    {
        #region Properties
        private readonly IFileRecordService _fileRecordService = fileRecordService;
        #endregion

        #region constructor
        #endregion

        #region Methods
        /// <summary>
        /// Retrieves paginated file record statistics based on the provided request parameters.
        /// </summary>
        /// <param name="request">The filtering, paging, and sorting criteria for retrieving file record statistics.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing the paginated list of <see cref="FileRecordStatsResponse"/> 
        /// and a success message upon successful retrieval.
        /// </returns>
        [HttpPost("filerecord/stats")]
        public async Task<BaseResponse> GetFileRecordStats([FromBody] FileRecordStatsRequest request)
        {
            Validator.ValidateAndThrow(request, FileRecordStatsValidationRules.FileRecordStatsValidator());
            PaginatedResponse<FileRecordStatsResponse> result = await _fileRecordService.GetFileRecordStats(request);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Auth.FileRecordStatsReturnSuccess);
        }
        #endregion
    }
}