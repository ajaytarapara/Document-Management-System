using Admin.Api.Helper;
using Admin.Entities.ViewModels;
using Admin.Entities.ViewModels.FolderTemplate;
using Admin.Services.AuthServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.Helper;
using Shared.ViewModels.Base;
using static Shared.Constant.Enums;

namespace Admin.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FolderTemplateController(IFolderTemplateService folderTemplateService) : BaseController
    {
        #region Properties
        private readonly IFolderTemplateService _folderTemplateService = folderTemplateService;
        #endregion

        #region constructor
        #endregion

        /// <summary>
        /// Retrieves a list of all active office users.
        /// - Requires authorization.
        /// - Calls the service to get active office users from the system.
        /// - Returns a successful API response with the list of users and a success message.
        /// </summary>
        /// <returns>A <see cref="BaseResponse"/> containing the list of active office users.</returns>
        [Authorize]
        [HttpGet("get-all-activeofficeusers")]
        public async Task<BaseResponse> GetAllActiveOfficeUsersList()
        {
            List<UsersResponse> result = await _folderTemplateService.GetAllActiveOfficeUsersList();
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Auth.AllOfficeUserslistfetchedSuccess);
        }

        /// <summary>
        /// Retrieves paginated folder templates for a specific user based on query parameters.
        /// - Requires authorization.
        /// - Accepts filter, sorting, and pagination parameters via query string.
        /// - Calls the service to fetch the templates.
        /// - Returns a successful API response with the paginated list of templates.
        /// </summary>
        /// <param name="userTemplateRequest">The request parameters including userId, page number, page size, sorting options, etc.</param>
        /// <returns>A <see cref="BaseResponse"/> containing the paginated list of templates.</returns>
        [Authorize]
        [HttpPost("get-user-templates")]
        public async Task<BaseResponse> GetUserTemplates([FromBody] UserTemplateRequest userTemplateRequest)
        {
            PaginatedResponse<UserTemplateResponseVM> result = await _folderTemplateService.GetUserTemplatesByUserIdAsync(userTemplateRequest);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Auth.OfficeUserTemplateReturnSuccess);
        }

        /// <summary>
        /// Adds a new folder template for a user.
        /// - Requires authorization.
        /// - Validates the request payload using the `AddUserTemplateValidator`.
        /// - Calls the service method to add the folder template.
        /// - Returns a success response with status code 201 (Created).
        /// </summary>
        /// <param name="request">The folder template data to be added.</param>
        /// <returns>A <see cref="BaseResponse"/> indicating success or failure of the operation.</returns>
        [Authorize]
        [HttpPost("add-folder-template")]
        public async Task<BaseResponse> AddFolderTemplate([FromBody] AddUserTemplateRequest request)
        {
            Validator.ValidateAndThrow(request, AdminValidationRules.AddUserTemplateValidator());
            await _folderTemplateService.AddFolderTemplateAsync(request);
            return ApiSuccess(ResponseStatusCode.Created, null, Messages.Success.Auth.FolderTemplateAddReturnSuccess);
        }

        /// <summary>
        /// Deletes a folder template by its ID.
        /// - Requires authorization.
        /// - Calls the service to delete the folder template with the specified ID.
        /// - Returns a success response with status code 201 (Created) and a success message.
        /// </summary>
        /// <param name="id">The ID of the folder template to delete.</param>
        /// <returns>A <see cref="BaseResponse"/> indicating the result of the delete operation.</returns>
        [HttpDelete("delete-folder-template/{deleteId}")]
        [Authorize]
        public async Task<BaseResponse> DeleteFolder(int deleteId)
        {
            await _folderTemplateService.DeleteFolderAsync(deleteId);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.FolderTemplateDeleteSuccess);
        }

        /// <summary>
        /// Retrieves a folder template along with its tabs by template ID.
        /// - Requires authorization.
        /// - Calls the service to fetch the folder template details using the provided ID.
        /// - Returns a success response with the folder template data.
        /// </summary>
        /// <param name="id">The ID of the folder template to retrieve.</param>
        /// <returns>A <see cref="BaseResponse"/> containing the folder template and its associated tabs.</returns>
        [HttpGet("get-folder-template/{templateId}")]
        [Authorize]
        public async Task<BaseResponse> GetFolderTemplateById(int templateId)
        {
            UserTemplateResponseWithTabsVM result = await _folderTemplateService.GetFolderTemplateById(templateId);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }

        /// <summary>
        /// Updates an existing folder template.
        /// - Requires authorization.
        /// - Validates the request body using the `UpdateUserTemplateValidator`.
        /// - Calls the service method to update the folder template.
        /// - Returns a success response with status code 200 (OK) and a confirmation message.
        /// </summary>
        /// <param name="request">The updated folder template data.</param>
        /// <returns>A <see cref="BaseResponse"/> indicating the result of the update operation.</returns>
        [Authorize]
        [HttpPut("update-folder-template")]
        public async Task<BaseResponse> UpdateFolderTemplate([FromBody] UpdateUserTemplateRequest request)
        {
            Validator.ValidateAndThrow(request, AdminValidationRules.UpdateUserTemplateValidator());
            await _folderTemplateService.UpdateFolderTemplateAsync(request);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Auth.FolderTemplateUpdateReturnSuccess);
        }
    }
}