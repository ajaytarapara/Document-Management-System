using Admin.Api.Helper;
using Admin.Entities.ViewModels.User;
using Admin.Services.UserServices;
using Infrastructure.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.Helper;
using Shared.ViewModels.Base;
using static Shared.Constant.Enums;

namespace Admin.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : BaseController
    {
        #region Properties
        private readonly IUserService _userService;

        #endregion

        #region Constructor
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        #endregion

        #region Endpoints

        /// <summary>
        /// Lists all users with pagination.
        /// </summary>
        [HttpPost("get-all-user")]
        public async Task<BaseResponse> GetAllUsers([FromBody] UserFilterRequestVM request)
        {
            int userId = int.Parse(HttpContext?.User.FindFirst("userId")?.Value);

            var users = await _userService.GetAllUsersAsync(userId, request);
            return ApiSuccess(ResponseStatusCode.Ok, users, Messages.Error.UserMessage.SuccessMessage);
        }

        /// <summary>
        /// Lists all office users.
        /// </summary>
        [HttpGet("office-users")]
        public async Task<BaseResponse> GetAllOfficeUsers()
        {
            IEnumerable<OfficeUserVM> users = await _userService.GetAllOfficeUsersAsync();
            return ApiSuccess(ResponseStatusCode.Ok, users, Messages.Error.UserMessage.SuccessMessage);
        }


        /// <summary>
        /// Lists user with selected ID.
        /// </summary>
        [HttpGet("{userId}")]
        public async Task<BaseResponse> GetUserById(int userId)
        {
            var user = await _userService.GetUserByIdAsync(userId);
            return ApiSuccess(ResponseStatusCode.Ok, user, "");
        }

        /// <summary>
        /// Creates a new user.
        /// </summary>
        [HttpPost]
        public async Task<BaseResponse> CreateUser([FromBody] CreateUserVM model)
        {
            Validator.ValidateAndThrow(model, UserValidationRules.UserValidator());

            int userId = int.Parse(HttpContext?.User.FindFirst("userId")?.Value);

            UserVM user = await _userService.CreateAsync(model, userId);
            return ApiSuccess(ResponseStatusCode.Created, user, Messages.Error.UserMessage.CreateUserSuccessMessage);
        }

        /// <summary>
        /// Updates an existing user.
        /// </summary>
        [HttpPut]
        public async Task<BaseResponse> UpdateUser([FromBody] UpdateUserVM model)
        {
            Validator.ValidateAndThrow(model, UpdateUserValidationRules.UserValidator());

            int updatedBy = int.Parse(HttpContext?.User.FindFirst("userId")?.Value);

            UserVM user = await _userService.UpdateAsync(model, updatedBy);
            return ApiSuccess(ResponseStatusCode.Ok, user, Messages.Error.UserMessage.UserUpdateSuccessMessage);
        }

        /// <summary>
        /// Deletes a user by ID.
        /// </summary>
        [HttpDelete("{userId}")]
        public async Task<BaseResponse> DeleteUser(int userId)
        {
            bool result = await _userService.DeleteUserByIdAsync(userId);
            return ApiSuccess(ResponseStatusCode.Ok, new { deleted = result }, Messages.Error.UserMessage.UserDeleteSuccessMessage);
        }

        #endregion
    }
}
