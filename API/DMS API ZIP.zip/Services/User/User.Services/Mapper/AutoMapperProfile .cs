using System.Runtime.Intrinsics.Arm;
using Infrastructure.Entities;
using Shared.Constant;
using Shared.Helper;
using User.Entities.ViewModels;
using User.Entities.ViewModels.DmsForms;
using User.Entities.ViewModels.SplitAndUpload;

namespace User.Services.Mapper
{
    public class AutoMapperProfile : AutoMapper.Profile
    {
        /// <summary>
        /// AutoMapper Profile
        /// </summary>
        public AutoMapperProfile()
        {
            CreateMap<CreateFolderDto, Folder>()
           .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.UtcNow))
           .ForMember(dest => dest.IsActive, opt => opt.MapFrom(_ => true))
           .ForMember(dest => dest.FolderTabs, opt => opt.Ignore())
           .ForMember(dest => dest.TemplateId, opt => opt.MapFrom(src =>
                            string.IsNullOrEmpty(src.TemplateId)
                                ? (int?)null
                                : (AesEncryptionHelper.DecryptId(src.TemplateId) == 0
                                    ? (int?)null
                                    : AesEncryptionHelper.DecryptId(src.TemplateId))
                        ));

            // Tab mapping
            CreateMap<CreateFolderTabDto, FolderTab>()
                .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom((src, dest, _, context) => context.Items["CurrentUserId"]))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.UtcNow))
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(_ => true));

            CreateMap<FolderTab, FolderTabDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id))); ;

            CreateMap<Folder, FolderDto>()
                .ForMember(dest => dest.TabCount, opt => opt.MapFrom(src => src.FolderTabs.Count))
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)))
                .ForMember(dest => dest.Tabs, opt => opt.MapFrom(src =>
                    src.FolderTabs.Where(t => t.IsDeleted == false && t.IsActive == true)
                ));


            CreateMap<FolderDto, Folder>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedAt, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedBy, opt => opt.Ignore())
                .ForMember(dest => dest.IsDeleted, opt => opt.Ignore())
                .ForMember(dest => dest.IsActive, opt => opt.Ignore())
                .ForMember(dest => dest.FolderTabs, opt => opt.Ignore());

            CreateMap<FolderTabDto, FolderTab>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.Folder, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedAt, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedBy, opt => opt.Ignore())
                .ForMember(dest => dest.UpdatedAt, opt => opt.Ignore())
                .ForMember(dest => dest.UpdatedBy, opt => opt.Ignore())
                .ForMember(dest => dest.IsDeleted, opt => opt.Ignore())
                .ForMember(dest => dest.IsActive, opt => opt.Ignore());

            CreateMap<UpdateFolderDto, Folder>();
            CreateMap<Folder, GetFolderDto>()
                .ForMember(dest => dest.TabCount, opt => opt.MapFrom(src => src.FolderTabs.Count(t => t.IsDeleted == false && t.IsActive == true)))
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)))
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.UserId ?? 0)));

            CreateMap<UserTemplate, UserTemplateResponseVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)))
                .ReverseMap();

            CreateMap<UserTemplateTab, TemplateTabResponseVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)))
                .ReverseMap();

            CreateMap<UserTemplateTabVM, UserTemplateTab>()
                .ForMember(dest => dest.UserTemplate, opt => opt.MapFrom(src => AesEncryptionHelper.DecryptId(src.TemplateId)))
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.TabName))
                .ForMember(dest => dest.Color, opt => opt.MapFrom(src => src.Color))
                .ForMember(dest => dest.IsLock, opt => opt.MapFrom(src => src.IsLock ?? false))
                .ForMember(dest => dest.CreatedAt, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedBy, opt => opt.Ignore())
                .ForMember(dest => dest.IsActive, opt => opt.Ignore()).ReverseMap();

            CreateMap<Folder, FolderListResponseVM>()
                .ForMember(dest => dest.TabsCount,
                    opt => opt.MapFrom(src => src.FolderTabs.Count(t => t.IsDeleted != true)));


            CreateMap<SplitFileUploadDto, SplitAndUpload>()
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.Type))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(_ => DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc)))
                .ForMember(dest => dest.IsActive, opt => opt.MapFrom(_ => true))
                .ForMember(dest => dest.IsDeleted, opt => opt.MapFrom(_ => false));

            /// <summary>
            // Map from DmsForm to DMSFormFileVM entity
            /// </summary>
            CreateMap<DmsForm, DMSFormFileVM>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => src.Id))
                .ForMember(dest => dest.Size, opt => opt.MapFrom(src => Convert.ToInt64(src.Size)))
                .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt.ToString(AppConstants.Constants.DateFormate))).ReverseMap();

            CreateMap<FileRecord, FileListDto>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(src => AesEncryptionHelper.EncryptId(src.Id)));
        }



    }
}
