using System.ComponentModel;
using System.Text;
using System.Text.Json;
using AutoMapper;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Microsoft.Extensions.Hosting;
using Shared.ConfigItems;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.Helper;
using Shared.ViewModels.Base;
using Shared.ViewModels.DmsForms;
using User.Entities.ViewModels.DmsForms;
using User.Services.DmsFormService;

namespace Admin.Services.DmsFormService;

[ScopedDependency(ServiceType = typeof(IDmsFormService))]
public class DmsFormService : IDmsFormService
{
    #region Fields
    private readonly IGenericService<DmsForm, ApplicationDBContext> _genericDmsFormService;
    private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _generiUserService;
    private readonly ICurrentUserService _currentUserService;
    private readonly IGenericService<DmsSubmittedForm, ApplicationDBContext> _genericSubmittedFormService;
    private readonly IEmailSender _emailSender;
    private readonly IMapper _mapper;
    private readonly IHostEnvironment _env;
    #endregion

    #region Constructor

    public DmsFormService(
        IGenericService<DmsForm, ApplicationDBContext> genericDmsFormService,
        IGenericService<Infrastructure.Entities.User, ApplicationDBContext> generiUserService,
        IGenericService<DmsSubmittedForm, ApplicationDBContext> genericSubmittedFormService,
        ICurrentUserService currentUserService,
        IMapper mapper,
        IEmailSender emailSender,
        IHostEnvironment env)
    {
        _genericDmsFormService = genericDmsFormService;
        _generiUserService = generiUserService;
        _currentUserService = currentUserService;
        _mapper = mapper;
        _emailSender = emailSender;
        _env = env;
        _genericSubmittedFormService = genericSubmittedFormService;
    }

    #endregion

    #region Public Methods

    public async Task<string> AddDmsForm(UploadDmsFormsVM dmsForms, string userId, int createdBy)
    {
        int decryptedUserId = AesEncryptionHelper.DecryptId(userId);
        ValidateUploadRequest(dmsForms, decryptedUserId);

        string uploadsFolder = GetUserFolderPath(decryptedUserId);
        EnsureDirectoryExists(uploadsFolder);

        List<DmsForm> formEntities = new List<DmsForm>();

        foreach (UploadedFile file in dmsForms.DmsForms)
        {
            if (string.IsNullOrWhiteSpace(file.Content) || string.IsNullOrWhiteSpace(file.Name))
                continue;

            await EnsureFileNameIsUniqueAsync(decryptedUserId, file.Name);

            string filePath = Path.Combine(uploadsFolder, file.Name);
            await WriteFileAsync(filePath, file.Content);

            CreateDmsFormEntityRequest createRequest = new CreateDmsFormEntityRequest
            {
                File = file,
                FilePath = filePath,
                UserId = decryptedUserId,
                CreatedBy = createdBy
            };

            DmsForm entity = CreateDmsFormEntity(createRequest);
            formEntities.Add(entity);
        }

        if (formEntities.Any())
        {
            await _genericDmsFormService.InsertManyAsync(formEntities);
        }

        return userId;
    }

    public async Task<PaginationResponseVM<DMSFormFileVM>> GetAllDmsFormsAsync(PaginationRequestVM request, int userId, string baseUrl)
    {
        IEnumerable<DmsForm> allForms = await _genericDmsFormService.GetAllAsync(f =>
            f.SelectedUserId == userId && !(f.IsDeleted ?? false));

        IEnumerable<DmsForm> sortDmsForms = SortDmsForms(allForms, request);
        PaginatedDmsFormResponseVM pagedResult = Paginate(sortDmsForms, request);

        List<DMSFormFileVM> items = pagedResult.Items.Select(f => new DMSFormFileVM
        {
            Id = f.Id,
            Name = f.Name,
            Size = f.Size,
            CreatedAt = f.CreatedAt,
            Status = f.Status,
            Url = $"{baseUrl}{f.Url}"
        }).ToList();


        return new PaginationResponseVM<DMSFormFileVM>
        {
            Items = items,
            TotalCount = pagedResult.TotalCount,
            PageIndex = pagedResult.PageIndex,
            PageSize = pagedResult.PageSize,
            SortColumn = pagedResult.SortColumn,
            SortDirection = pagedResult.SortDirection
        };
    }

    public async Task<bool> RenameDmsFormFileAsync(string dmsFormId, string newFileName, int userId)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(dmsFormId);
        if (string.IsNullOrWhiteSpace(newFileName))
            throw new InvalidDataException(Messages.Error.Validation.InvalidFileName);

        DmsForm dmsForm = await GetValidDmsFormAsync(decryptedDmsFormId, userId);
        await EnsureFileNameIsUniqueAsync(userId, newFileName);

        string oldPath = Path.Combine(GetUserFolderPath(userId), dmsForm.Name);
        string newPath = Path.Combine(GetUserFolderPath(userId), newFileName);

        if (!File.Exists(oldPath))
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        File.Move(oldPath, newPath);

        dmsForm.Name = newFileName;
        dmsForm.Url = $"/dmsform/{userId}/{newFileName}";
        dmsForm.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);

        await _genericDmsFormService.UpdateAsync(dmsForm);
        return true;
    }

    public async Task<bool> DeleteDmsFormFileAsync(DeleteFileRequest model)
    {

        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(model.DmsFormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(model.UserId);
        DmsForm dmsForm = await GetValidDmsFormAsync(decryptedDmsFormId, decryptedUserId);
        int loggedInUserId = _currentUserService.GetUserId();
        Infrastructure.Entities.User user = await _generiUserService.GetAsync(u => u.Id == loggedInUserId);

        if (!PasswordHelper.ValidatePassword(model.Password, user.PasswordHash))
            throw new DataNotFoundException(Messages.Error.General.InvalidCredentialMessage);

        string filePath = Path.Combine(GetUserFolderPath(decryptedUserId), dmsForm.Name);
        if (File.Exists(filePath))
            File.Delete(filePath);

        await _genericDmsFormService.DeleteAsync(dmsForm);
        return true;
    }

    public async Task<DMSFormFileVM> GetDmsFormByIdAsync(string dmsFormId, string userId)
    {
        int decryptedDmsFormId = AesEncryptionHelper.DecryptId(dmsFormId);
        int decryptedUserId = AesEncryptionHelper.DecryptId(userId);
        DmsForm? dmsForm = await _genericDmsFormService.GetAsync(f => f.Id == decryptedDmsFormId);

        if (dmsForm == null || dmsForm.IsDeleted == true || dmsForm.SelectedUserId != decryptedUserId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        DMSFormFileVM vm = _mapper.Map<DMSFormFileVM>(dmsForm);
        vm.Fields = string.IsNullOrEmpty(dmsForm.FieldsJson)
                    ? new List<FieldBaseVM>()
                    : JsonSerializer.Deserialize<List<FieldBaseVM>>(dmsForm.FieldsJson);


        // Build physical file path correctly
        string filePath = Path.Combine(GetUserFolderPath(dmsForm.SelectedUserId), dmsForm.Name);
        if (!File.Exists(filePath))
        {
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);
        }

        return vm;
    }

    public async Task<ShareDmsFormVM> ShareDmsFormAsync(ShareDmsFormVM dmsForm, int userId)
    {
        string[] emails = SplitAndTrim(dmsForm.ToEmail);
        string[] names = SplitAndTrim(dmsForm.ToName);

        if (emails.Length != names.Length)
            throw new InvalidOperationException(Messages.Error.UserMessage.MismatchEmailAndName);

        string baseUrl = ConfigItems.BaseUrl;
        DateTime expiresAt = DateTime.UtcNow.AddHours(dmsForm.LinkExpiration);

        string templatePath = Path.Combine(_env.ContentRootPath, ConfigItems.EmailTemplateShareDmsFormPath);
        if (!File.Exists(templatePath))
            throw new FileNotFoundException(Messages.Error.Validation.EmailTemplateNotFound, templatePath);

        string templateHtml = await File.ReadAllTextAsync(templatePath);

        for (int i = 0; i < emails.Length; i++)
        {
            string email = emails[i];
            string name = names[i];

            string formLinks = BuildFormLinks(new BuildFormLinksRequest
            {
                FormIds = dmsForm.FormIds,
                BaseUrl = baseUrl,
                Email = email,
                ExpiresAt = expiresAt,
                ViewOnly = dmsForm.ViewOnly,
                UserId = userId
            });

            string bodyHtml = templateHtml
                .Replace("{{UserName}}", name)
                .Replace("{{Message}}", dmsForm.Message ?? Messages.Success.DMSForm.FormSharedSuccessMessage)
                .Replace("{{Links}}", formLinks)
                .Replace("{{LinkText}}", "")
                .Replace("{{Expiration}}", $"{expiresAt.ToString(AppConstants.Constants.DateFormate)} UTC");

            await _emailSender.SendEmailAsync(
                from: ConfigItems.FromMail,
                to: email,
                subject: dmsForm.Subject,
                html: bodyHtml
            );
        }

        return dmsForm;
    }

    #endregion

    #region Private Helper Methods

    private void ValidateUploadRequest(UploadDmsFormsVM dmsForms, int userId)
    {
        if (dmsForms == null || dmsForms.DmsForms == null || !dmsForms.DmsForms.Any())
            throw new InvalidDataException(Messages.Error.Validation.InvalidFileContext);
        if (userId <= 0)
            throw new InvalidDataException(Messages.Error.Validation.InvalidUser);
    }

    private string GetUserFolderPath(int userId)
    {
        return Path.Combine(Directory.GetCurrentDirectory(), AppConstants.Constants.RootPath, AppConstants.Constants.DmsFolderPath, userId.ToString());
    }

    private void EnsureDirectoryExists(string path)
    {
        if (!Directory.Exists(path))
            Directory.CreateDirectory(path);
    }

    private async Task EnsureFileNameIsUniqueAsync(int userId, string fileName)
    {
        DmsForm existing = await _genericDmsFormService.GetAsync(f =>
            f.SelectedUserId == userId &&
            f.Name == fileName &&
            !(f.IsDeleted ?? false));

        if (existing != null)
            throw new DataConflictException(Messages.Error.Exception.RequiredFieldMessage(existing.Name));
    }

    private async Task WriteFileAsync(string path, string base64Content)
    {
        byte[] bytes = Convert.FromBase64String(base64Content);
        await File.WriteAllBytesAsync(path, bytes);
    }

    private DmsForm CreateDmsFormEntity(CreateDmsFormEntityRequest request)
    {
        FileInfo fileInfo = new FileInfo(request.FilePath);
        return new DmsForm
        {
            Name = request.File.Name,
            Size = fileInfo.Length.ToString(),
            Url = $"/dmsform/{request.UserId}/{request.File.Name}",
            Status = "Uploaded",
            CreatedBy = request.CreatedBy,
            CreatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc),
            IsActive = true,
            IsDeleted = false,
            SelectedUserId = request.UserId
        };
    }


    private async Task<DmsForm> GetValidDmsFormAsync(int formId, int userId)
    {
        DmsForm form = await _genericDmsFormService.GetAsync(f =>
            f.Id == formId && !(f.IsDeleted ?? false));

        if (form == null || form.SelectedUserId != userId)
            throw new FileNotFoundException(Messages.Error.Validation.FileNotFound);

        return form;
    }

    private PaginatedDmsFormResponseVM Paginate(IEnumerable<DmsForm> forms, PaginationRequestVM request)
    {
        int totalCount = forms.Count();
        int pageIndex = Math.Max(request.PageNumber, 1);
        int pageSize = Math.Max(request.PageSize, 5);

        List<DMSFormFileVM> items = forms
            .Skip((pageIndex - 1) * pageSize)
            .Take(pageSize)
            .Select(f => new DMSFormFileVM
            {
                Id = AesEncryptionHelper.EncryptId(f.Id),
                Name = f.Name,
                Size = Convert.ToInt64(f.Size),
                Url = f.Url,
                Status = f.Status,
                CreatedAt = f.CreatedAt.ToString(AppConstants.Constants.DateFormate)
            })
            .ToList();

        return new PaginatedDmsFormResponseVM
        {
            Items = items,
            TotalCount = totalCount,
            PageIndex = pageIndex,
            PageSize = pageSize,
            SortColumn = request.SortBy,
            SortDirection = request.SortOrder.ToString()
        };
    }

    private IEnumerable<DmsForm> SortDmsForms(IEnumerable<DmsForm> forms, PaginationRequestVM request)
    {
        string sortColumn = string.IsNullOrWhiteSpace(request.SortBy) ? nameof(DMSFormFileVM.Id) : request.SortBy;
        bool isDescending = request.SortOrder.ToString().Equals("Desc", StringComparison.OrdinalIgnoreCase);

        return sortColumn switch
        {
            nameof(DMSFormFileVM.Size) => isDescending
                ? forms.OrderByDescending(f => Convert.ToInt64(f.Size)).ToList()
                : forms.OrderBy(f => Convert.ToInt64(f.Size)).ToList(),

            nameof(DMSFormFileVM.CreatedAt) => isDescending
                ? forms.OrderByDescending(f => f.CreatedAt).ToList()
                : forms.OrderBy(f => f.CreatedAt).ToList(),

            _ => isDescending
                ? forms.OrderByDescending(f => f.Name).ToList()
                : forms.OrderBy(f => f.Name).ToList()
        };
    }

    private string GenerateShareToken(GenerateShareTokenRequest request)
    {
        var tokenPayload = new
        {
            formId = request.FormId,
            email = request.Email,
            request.ViewOnly,
            userId = request.UserId,
            expiresAt = new DateTimeOffset(request.Expires).ToUnixTimeSeconds()
        };

        string json = JsonSerializer.Serialize(tokenPayload);
        string base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        return base64;
    }
    private static string[] SplitAndTrim(string input) =>
       input.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .ToArray();
    private string BuildFormLinks(BuildFormLinksRequest request)
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<ul>");

        foreach (string formId in request.FormIds)
        {
            string token = GenerateShareToken(new GenerateShareTokenRequest
            {
                FormId = AesEncryptionHelper.DecryptId(formId),
                Email = request.Email,
                Expires = request.ExpiresAt,
                ViewOnly = request.ViewOnly,
                UserId = request.UserId,
            });

            string url = $"{request.BaseUrl}{AppConstants.ApiEndpoints.ViewSharedFromEndpoint}?shareToken={token}";
            string linkText = request.ViewOnly ? AppConstants.Constants.View : AppConstants.Constants.Download;
            sb.Append($"<li><a href='{url}' target='_blank' style='color: #7e57c2; text-decoration: underline;'>{linkText} Form #{formId}</a></li>");
        }

        sb.Append("</ul>");
        return sb.ToString();
    }

    #endregion
}
