using System.Linq.Expressions;
using AutoMapper;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.Helper;
using User.Entities.ViewModels;

namespace User.Services.UserServices
{
    [ScopedDependency(ServiceType = typeof(IUserTemplateService))]
    public class UserTemplateService : IUserTemplateService
    {
        #region Fields
        private readonly IGenericService<UserTemplate, ApplicationDBContext> _userTemplateService;
        private readonly ICurrentUserService _currentUserService;
        private readonly IMapper _mapper;
        private readonly IGenericService<UserTemplateTab, ApplicationDBContext> _userTemplateTabsService;
        private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userService;
        private readonly IGenericService<FolderTab, ApplicationDBContext> _folderTabService;
        private readonly IGenericService<Folder, ApplicationDBContext> _folderService;
        #endregion

        #region Constructor

        public UserTemplateService(IGenericService<UserTemplate, ApplicationDBContext> userTemplateService, ICurrentUserService currentUserService, IMapper mapper, IGenericService<UserTemplateTab, ApplicationDBContext> userTemplateTabsService, IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userService, IGenericService<FolderTab, ApplicationDBContext> folderTabService, IGenericService<Folder, ApplicationDBContext> folderService)
        {
            _userTemplateService = userTemplateService;
            _currentUserService = currentUserService;
            _mapper = mapper;
            _userTemplateTabsService = userTemplateTabsService;
            _userService = userService;
            _folderTabService = folderTabService;
            _folderService = folderService;
        }
        #endregion

        #region IUserTemplateService Members
        public async Task<IEnumerable<UserTemplateResponseVM>> GetUserTemplate()
        {
            int userId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await GetActiveUserAsync(userId);
            IEnumerable<UserTemplate> userTemplates = await _userTemplateService.GetAllAsync(x => x.Users == userId && x.IsActive && x.IsDeleted == false) ??
                throw new DataNotFoundException(Messages.Error.Exception.UserTemplateNotFoundMessage);
            return _mapper.Map<IEnumerable<UserTemplateResponseVM>>(userTemplates);
        }

        public async Task<IEnumerable<TemplateTabResponseVM>> GetTemplateTabs(int templateId)
        {
            IEnumerable<UserTemplateTab> userTemplateTabs = await _userTemplateTabsService.GetAllAsync(x => x.UserTemplate == templateId && x.IsActive && x.IsDeleted == false) ??
                throw new DataNotFoundException(Messages.Error.Exception.UserTemplateTabsNotFoundMessage);
            return _mapper.Map<IEnumerable<TemplateTabResponseVM>>(userTemplateTabs);
        }

        public async Task AddTemplateTabs(AddTemplateTabRequestVM request)
        {
            int decryptedTemplateId = AesEncryptionHelper.DecryptId(request.TemplateId);
            int currentUserId = _currentUserService.GetUserId();
            DateTime nowUtc = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);

            Infrastructure.Entities.User user = await GetActiveUserAsync(currentUserId);
            UserTemplate template = await GetUserTemplateAsync(decryptedTemplateId, currentUserId);

            int totalTabs = await ValidateTabLimitAsync(request.TemplateTabs.Count, user.MaxTabLimit, decryptedTemplateId);
            await EnsureTabNamesAreUniqueAsync(decryptedTemplateId, request.TemplateTabs.Select(t => t.TabName));

            List<UserTemplateTab> mappedTabs = _mapper.Map<List<UserTemplateTab>>(request.TemplateTabs);

            foreach (UserTemplateTab tab in mappedTabs)
            {
                tab.UserTemplate = decryptedTemplateId;
                tab.CreatedBy = currentUserId;
                tab.CreatedAt = nowUtc;
                tab.IsActive = true;
            }

            await _userTemplateTabsService.InsertManyAsync(mappedTabs);
            template.TabsCount = totalTabs.ToString();
            await _userTemplateService.UpdateAsync(template);
        }
        private async Task<Infrastructure.Entities.User> GetActiveUserAsync(int userId)
        {
            Infrastructure.Entities.User? user = await _userService.GetAsync(u =>
                u.Id == userId &&
                (u.IsDeleted ?? false) == false &&
                u.IsActive);

            return user ?? throw new DataNotFoundException(Messages.Error.General.UserIsNotActive);
        }

        private async Task<UserTemplate> GetUserTemplateAsync(int templateId, int userId)
        {
            UserTemplate? template = await _userTemplateService.GetAsync(t =>
                t.Id == templateId &&
                t.Users == userId &&
                t.IsActive &&
                (t.IsDeleted ?? false) == false);

            return template ?? throw new DataNotFoundException(Messages.Error.General.TemplateNotFound);
        }

        private async Task EnsureTabNamesAreUniqueAsync(int templateId, IEnumerable<string> newTabNames)
        {
            List<string> normalizedNames = newTabNames
                .Select(name => name.Trim().ToLower())
                .ToList();

            IEnumerable<UserTemplateTab> existingTabs = await _userTemplateTabsService.GetAllAsync(t =>
                t.UserTemplate == templateId &&
                (t.IsDeleted ?? false) == false &&
                normalizedNames.Contains(t.Name.Trim().ToLower()));

            if (existingTabs.Any())
            {
                string duplicates = string.Join(", ", existingTabs.Select(e => e.Name));
                throw new InvalidOperationException(Messages.Error.General.DuplicateTabNamesInTemplate(duplicates));
            }
        }

        private async Task<int> ValidateTabLimitAsync(int newTabCount, int maxAllowed, int templateId)
        {
            int existingCount = await _userTemplateTabsService.CountAsync(t =>
                t.UserTemplate == templateId &&
                (t.IsDeleted ?? false) == false);

            int totalTabs = existingCount + newTabCount;

            if (totalTabs > maxAllowed)
            {
                throw new InvalidOperationException(Messages.Error.General.TabLimitExceededMessage(maxAllowed));

            }

            return totalTabs;
        }

        public async Task<IEnumerable<FolderListResponseVM>> GetFolderListByTemplate(int templateId, int newTabCount)
        {
            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await GetActiveUserAsync(currentUserId);
            int userLimit = user.MaxTabLimit;

            Expression<Func<Folder, object>>[] includes = new Expression<Func<Folder, object>>[]
            {
             f => f.FolderTabs
            };

            IList<Folder> allFolders = await _folderService.GetAllAsync(
                f => f.TemplateId == templateId && f.IsDeleted == false && f.IsActive == true,
                includes
            );

            List<Folder> eligibleFolders = new List<Folder>();

            foreach (Folder folder in allFolders)
            {
                int existingTabCount = folder.FolderTabs.Count(tab => tab.IsDeleted == false);
                if (existingTabCount + newTabCount <= userLimit)
                {
                    eligibleFolders.Add(folder);
                }
            }

            IEnumerable<FolderListResponseVM> folderList = _mapper.Map<IEnumerable<FolderListResponseVM>>(eligibleFolders);
            return folderList;
        }

        public async Task ApplyFolderTab(ApplyFolderTabRequestVM applyFolderTabRequestVM)
        {
            if (applyFolderTabRequestVM?.selectedFolder == null || !applyFolderTabRequestVM.TemplateTabs.Any())
                return;

            int currentUserId = _currentUserService.GetUserId();
            DateTime currentTime = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
            List<FolderTab> folderTabsToInsert = new List<FolderTab>();

            foreach (int folderId in applyFolderTabRequestVM.selectedFolder)
            {
                var existingTabs = await _folderTabService.GetAllAsync(
            t => t.Folder == folderId && t.IsDeleted == false);
                foreach (UserTemplateTabVM tab in applyFolderTabRequestVM.TemplateTabs)
                {
                    bool duplicateExists = existingTabs.Any(et =>
                et.TabName.Equals(tab.TabName, StringComparison.OrdinalIgnoreCase) ||
                et.Color.Equals(tab.Color, StringComparison.OrdinalIgnoreCase)
            );

                    if (duplicateExists)
                        continue;
                    folderTabsToInsert.Add(new FolderTab
                    {
                        TabName = tab.TabName,
                        Color = tab.Color,
                        IsLock = tab.IsLock,
                        Folder = folderId,
                        CreatedBy = currentUserId,
                        CreatedAt = currentTime,
                        IsActive = true,
                        IsDeleted = false
                    });
                }
            }

            await _folderTabService.InsertManyAsync(folderTabsToInsert);
        }

        public async Task<IEnumerable<UserTemplateResponseVM>> GetUserTemplateAvailableToAdd()
        {
            int userId = _currentUserService.GetUserId();
            var user = await GetActiveUserAsync(userId);
            int maxTabLimit = user.MaxTabLimit;
            var includes = new Expression<Func<UserTemplate, object>>[]
                   {
                   f => f.UserTemplateTabs
                   };
            var userTemplates = await _userTemplateService.GetAllAsync(
                x => x.Users == userId && x.IsActive && (x.IsDeleted == null || x.IsDeleted == false),
               includes
            ) ?? throw new DataNotFoundException(Messages.Error.Exception.UserTemplateNotFoundMessage);
            var filteredTemplates = userTemplates
                .Where(template =>
                    template.UserTemplateTabs.Count(tab =>
                        tab.IsActive && (tab.IsDeleted == null || tab.IsDeleted == false)
                    ) < maxTabLimit
                )
                .ToList();

            return _mapper.Map<IEnumerable<UserTemplateResponseVM>>(filteredTemplates);
        }

        #endregion
    }
}
