namespace User.Services.UserServices
{
    public interface IFileService
    {
        Task<List<string>> UploadFileAsync(FileUploadDto dto, int userId, string uploadsFolder);
        Task UpdateFileNameAsync(UpdateFileNameDto dto, int userId);
        Task MoveFileAsync(MoveFileDto dto, int userId);
        Task ChangeTabAsync(MoveFiletabDto dto, int userId);
        Task<string> delteFile(int fileId);
        Task<FolderTabDtos> GetTabsByFolderIdAsync(int folderId, int currentUserId);
        Task<FileListDtos> GetFilesByTabPaginatedAsync(int tabId, int page, int pageSize, string sortDirection = "asc",
        string sortColumn = "Id",
        string searchTerm = "");
        Task ShareFileAsync(int fileId, ShareFolderDto dto);
        Task ShareMultipleFileAsync(MultipleFileDto dto);
        Task<FileListDtos> GetFilesByIds(MultipleFilesVM ids, int page,
    int pageSize,
    string sortDirection = "asc",
    string sortColumn = "Id",
    string searchTerm = "");
    }
}