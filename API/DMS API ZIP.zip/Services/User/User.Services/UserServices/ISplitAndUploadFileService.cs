using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;

namespace User.Services.UserServices
{
    public interface ISplitAndUploadFileService
    {
        public Task UploadFilesForSplit(FileUploadRequest fileUploadRequest, string fileUploadDirectory);
        public Task<PaginatedResponse<FileUploadResponseForSplitVM>> GetUploadedFiles(PaginatedRequest paginatedRequest);
        public Task DeleteUploadedFile(int id);
        public Task UpdateUploadedFileName(FileNameUpdateRequest fileNameUpdateRequest);
        public Task<List<FolderListResponse>> GetFolderList();
        public Task<List<TabListResponse>> GetTabList(int folderId);
        public Task SplitAndReplace(SplitPdfRequest splitPdfRequest);
    }
}