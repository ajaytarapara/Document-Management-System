using User.Entities.ViewModels;

namespace User.Services.UserServices
{
    public interface IUserTemplateService
    {
        Task<IEnumerable<UserTemplateResponseVM>> GetUserTemplate();
        Task<IEnumerable<TemplateTabResponseVM>> GetTemplateTabs(int templateId);
        Task AddTemplateTabs(AddTemplateTabRequestVM addTemplateTabRequestVM);
        Task<IEnumerable<FolderListResponseVM>> GetFolderListByTemplate(int templateId, int newTabCount);
        Task ApplyFolderTab(ApplyFolderTabRequestVM applyFolderTabRequestVM);
        Task<IEnumerable<UserTemplateResponseVM>> GetUserTemplateAvailableToAdd();
    }
}