using Infrastructure.DependencyInjection;

namespace User.Services.UserServices;

[ScopedDependency(ServiceType = typeof(IUserService))]
public class UserService : IUserService
{
    #region fields

    #endregion

    #region constructor
    public UserService()
    {
       
    }
    #endregion

    #region methods

    #endregion

}