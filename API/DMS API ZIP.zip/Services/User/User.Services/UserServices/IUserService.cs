using Shared.ViewModels.Base;

namespace User.Services.UserServices
{
    public interface IUserService
    {
       
    }
}
