using User.Entities.ViewModels.BatchShare;
using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;

namespace User.Services.UserServices
{
    public interface IBatchShareService
    {
        public Task<List<FolderListResponse>> GetFolderList();
        public Task<PaginatedResponse<BatchShareTabAndFileResponse>> GetFileByTabId(BatchShareTabAndFileRequest batchShareTabAndFileRequest);
        public Task<List<TabListResponse>> GetTabList(int folderId);
        Task ShareBatchShareFiles(BatchShareMultipleFileShareRequest dto);
    }
}