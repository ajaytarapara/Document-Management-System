using System.Linq.Expressions;
using System.Text.Json;
using AutoMapper;
using CoreServices.Generic;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Microsoft.Extensions.Configuration;
using Shared.Helper;
using User.Services.UserServices;
using Microsoft.AspNetCore.Hosting;
using static Shared.Constant.Enums;

namespace User.Services.FolderService;

[ScopedDependency(ServiceType = typeof(IFolderService))]
public class FolderService : IFolderService
{
    #region fields

    #endregion

    #region constructor
    private readonly IGenericService<Folder, ApplicationDBContext> _folderService;
    private readonly IGenericService<FolderTab, ApplicationDBContext> _folderTabService;
    private readonly IGenericService<UserRolePermission, ApplicationDBContext> _userRolePermissionService;

    private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userService;
    private readonly IMapper _mapper;
    private readonly IEmailSender _emailSender;
    private readonly IConfiguration _config;
    private readonly IGenericService<FileRecord, ApplicationDBContext> _fileService;


    public FolderService(
        IGenericService<Folder, ApplicationDBContext> folderService,
        IGenericService<FolderTab, ApplicationDBContext> folderTabService,
         IGenericService<UserRolePermission, ApplicationDBContext> userRolePermissionService,
        IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userService, IMapper mapper, IConfiguration config, IEmailSender emailSender,
        IGenericService<FileRecord, ApplicationDBContext> fileService)
    {
        _folderService = folderService;
        _folderTabService = folderTabService;
        _userRolePermissionService = userRolePermissionService;
        _userService = userService;
        _mapper = mapper;
        _config = config;
        _emailSender = emailSender;
        _fileService = fileService;
    }

    public async Task CreateFolderWithTabsAsync(CreateFolderDto folderDto, int userId)
    {
        var user = await _userService.GetAsync(u => u.Id == userId && u.IsDeleted == false);
        if (user == null)
            throw new KeyNotFoundException("User not found");
        var createdById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0)
        ? user.CreatedBy
        : userId;

        bool duplicateExists = await _folderService.AnyAsync(f =>
       f.CreatedBy == createdById &&
       f.Foldername == folderDto.FolderName &&
       f.IsDeleted == false);

        if (duplicateExists)
        {
            throw new InvalidOperationException("A folder with the same FolderName already exists for this user.");
        }
        var duplicateTabNames = folderDto.Tabs.GroupBy(t => t.TabName.ToLower())
      .Where(g => g.Count() > 1)
      .Select(g => g.Key)
      .ToList();

        var duplicateColors = folderDto.Tabs.GroupBy(t => t.Color.ToLower())
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (duplicateTabNames.Any() || duplicateColors.Any())
        {
            throw new InvalidOperationException("Duplicate TabName or Color found in the request.");
        }
        var folder = _mapper.Map<Folder>(folderDto);
        folder.CreatedBy = createdById;
        folder.UserId = userId;
        folder = await _folderService.InsertAsync(folder);


        if (folderDto.Tabs.Any())
        {
            var tabs = folderDto.Tabs.Select(tab => new FolderTab
            {
                TabName = tab.TabName,
                Folder = folder.Id,
                Color = tab.Color,
                IsLock = tab.IsLock,
                CreatedBy = userId,
                CreatedAt = DateTime.UtcNow,
                IsActive = true
            }).ToList();
            await _folderTabService.InsertManyAsync(tabs);
        }
    }
    public async Task<FolderDto?> GetFolderByIdAsync(int id, int currentUserId)
    {
        // 1) Load current user
        var user = await _userService.GetAsync(u => u.Id == currentUserId && u.IsDeleted == false);
        if (user == null)
            throw new KeyNotFoundException("User not found");

        var allTrue = user.Role == (int)UserRoles.OfficeUser;

        UserRolePermission? perm = null;
        if (!allTrue)
        {
            perm = await _userRolePermissionService.GetAsync(p =>
                p.Users == currentUserId &&
                p.IsDeleted == false &&
                p.IsActive == true);
        }

        // 2) Load folder + tabs
        var folder = await _folderService.GetAsync(
            f => f.Id == id && f.IsDeleted == false && f.IsActive == true,
            f => f.FolderTabs);

        if (folder == null) return null;

        // 3) If role = 3 and HideLockTabs = true, filter locked tabs
        if (user.Role == (int)UserRoles.User && perm?.HideLockTabs == true)
        {
            folder.FolderTabs = folder.FolderTabs
               .Where(t => !(t.IsLock ?? false))
                .ToList();
        }

        // 4) Map to DTO
        return _mapper.Map<FolderDto>(folder);
    }
    public async Task<FolderDownloadDto> DownloadFolderAsync(int folderId, int currentUserId)
    {
        var user = await _userService.GetAsync(u => u.Id == currentUserId && u.IsDeleted == false);
        if (user == null)
            throw new KeyNotFoundException("User not found");

        var allTrue = user.Role == (int)UserRoles.OfficeUser;
        var folder = await _folderService.GetAsync(u => u.Id == folderId && u.IsDeleted == false);
        UserRolePermission? perm = null;
        if (!allTrue)
        {
            perm = await _userRolePermissionService.GetAsync(p =>
                p.Users == currentUserId &&
                p.IsDeleted == false &&
                p.IsActive == true);
        }
        IEnumerable<TabListDto> tab;

        // 3) If role = 3 and HideLockTabs = true, filter locked tabs
        if (user.Role == (int)UserRoles.User && perm?.HideLockTabs == true)
        {
            tab = await _folderTabService.GetAllAsync(
              f => f.Folder == folderId && f.IsDeleted == false && !(f.IsLock ?? false),
               x => new TabListDto
               {
                   TabName = x.TabName,
                   fileListDto = x.FileRecords.Select(fr => new FileListDto
                   {
                       Id = fr.Id.ToString(),
                       Name = fr.Name,
                       Url = fr.Url,
                       Type = fr.Type,
                       Size = fr.Size,
                       CreatedAt = fr.CreatedAt
                   })
               });
        }
        else
        {
            tab = await _folderTabService.GetAllAsync(
           f => f.Folder == folderId && f.IsDeleted == false,
               x => new TabListDto
               {
                   TabName = x.TabName,
                   fileListDto = x.FileRecords.Where(f => f.IsDeleted == false).Select(fr => new FileListDto
                   {
                       Id = fr.Id.ToString(),
                       Name = fr.Name,
                       Url = fr.Url,
                       Type = fr.Type,
                       Size = fr.Size,
                       CreatedAt = fr.CreatedAt
                   })
               });
        }
        return new FolderDownloadDto
        {
            folderName = folder.Foldername,
            tabListDto = tab
        };
    }

    public async Task<int> GetMaxTabLimitAsync(int userId)
    {
        var maxTabLimit = await _userService.GetFirstOrDefaultAsync(
            f => f.Id == userId,
            f => f.MaxTabLimit
        );

        return maxTabLimit;
    }


    public async Task<FoldersWithPermissionsDto> GetFoldersByUserIdAsync(
     int userId,
     int pageIndex = 1,
     int pageSize = 10,
     string sortDirection = "asc",
     string sortColumn = "Id",
     string searchTerm = "")
    {
        // 1) Load current user
        var user = await _userService.GetAsync(u => u.Id == userId && u.IsDeleted == false);
        if (user == null)
            throw new KeyNotFoundException("User not found");

        var createdById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0)
            ? user.CreatedBy
            : userId;

        var allTrue = user.Role == (int)UserRoles.OfficeUser;

        UserRolePermission perm = null!;
        if (!allTrue)
        {
            perm = await _userRolePermissionService.GetAsync(p =>
                p.Users == userId &&
                p.IsDeleted == false &&
                p.IsActive == true);
        }


        Expression<Func<Folder, bool>> filter = f =>
        f.CreatedBy == createdById &&
        f.IsDeleted == false &&
        f.IsActive == true &&
        (string.IsNullOrEmpty(searchTerm) ||
            f.Foldername.Contains(searchTerm) ||
            f.FirstName.Contains(searchTerm) ||
            f.LastName.Contains(searchTerm) ||
            f.FileNumber.Contains(searchTerm));
        var includes = new Expression<Func<Folder, object>>[]
        {
        f => f.FolderTabs
        };

        var mappedSortColumn = MapSortColumn(sortColumn);
        var paged = await _folderService.GetAllAsyncPagination(
            pageIndex,
            pageSize,
            filter,
            null,
            sortDirection,
            mappedSortColumn,
            includes);
        if (user.Role == (int)UserRoles.User && perm?.HideLockTabs == true)
        {
            foreach (var folder in paged.Items)
            {
                folder.FolderTabs = folder.FolderTabs
                    .Where(t => t.IsLock == false)
                    .ToList();
            }
        }

        var dtos = _mapper.Map<List<GetFolderDto>>(paged.Items);

        var permissionsDto = allTrue
            ? new PermissionsDto
            {
                PrivilegeDelete = true,
                PrivilegeDownload = true,
                PrivilegeView = false,
                HideLockTabs = true
            }
            : new PermissionsDto
            {
                PrivilegeDelete = perm?.PrivilegeDelete ?? false,
                PrivilegeDownload = perm?.PrivilegeDownload ?? false,
                PrivilegeView = perm?.PrivilegeView ?? false,
                HideLockTabs = perm?.HideLockTabs ?? false,
            };
        return new FoldersWithPermissionsDto
        {
            Items = dtos,
            TotalCount = paged.TotalCount,
            Permissions = permissionsDto
        };
    }
    public async Task<GetFolderList> getFolderList(int userId)
    {
        // 1) Load current user
        var user = await _userService.GetAsync(u => u.Id == userId && u.IsDeleted == false);
        if (user == null)
            throw new KeyNotFoundException("User not found");

        var createdById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0)
            ? user.CreatedBy
            : userId;

        var folder = await _folderService.GetAllAsync(
       x => x.CreatedBy == createdById && x.IsDeleted == false,
       x => new GetFolderDto
       {
           Id = AesEncryptionHelper.EncryptId(x.Id),
           FolderName = x.Foldername,
       });
        return new GetFolderList
        {
            GetFolderDto = folder,
        };
    }

    public async Task<bool> SoftDeleteFolderAsync(int id, int deletedByUserId, string rootPath)
    {
        var folder = await _folderService.GetAsync(
            f => f.Id == id && f.IsDeleted == false,
            f => f.FolderTabs, f => f.FileRecords);

        if (folder == null)
            throw new KeyNotFoundException("Folder not found");

        folder.IsDeleted = true;
        folder.DeletedAt = DateTime.UtcNow;
        folder.DeletedBy = deletedByUserId;
        folder.IsActive = false;

        await _folderService.UpdateAsync(folder);

        if (folder.FolderTabs != null && folder.FolderTabs.Any())
        {
            foreach (var tab in folder.FolderTabs)
            {
                tab.IsDeleted = true;
                tab.DeletedAt = DateTime.UtcNow;
                tab.DeletedBy = deletedByUserId;
                tab.IsActive = false;

                if (tab.FileRecords != null && tab.FileRecords.Any())
                {
                    foreach (var file in tab.FileRecords)
                    {
                        file.IsDeleted = true;
                        file.DeletedAt = DateTime.UtcNow;
                        file.DeletedBy = deletedByUserId;
                        file.IsActive = false;
                        var filePath = $"{rootPath}{Path.DirectorySeparatorChar}{file.Url}";
                        if (System.IO.File.Exists(filePath))
                        {
                            System.IO.File.Delete(filePath);
                        }
                    }
                    await _fileService.UpdateManyAsync(tab.FileRecords.ToList());
                }
            }
            await _folderTabService.UpdateManyAsync(folder.FolderTabs.ToList());
        }
        return true;
    }
    public async Task<FolderDto> UpdateFolderAsync(UpdateFolderDto dto, int userId, int Id)
    {
        var user = await _userService.GetAsync(u => u.Id == userId);
        var createdById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0)
        ? user.CreatedBy
        : userId;
        var folder = await _folderService.GetAsync(f => f.Id == Id && f.IsDeleted == false);
        if (folder == null)
            throw new KeyNotFoundException("Folder not found");

        bool duplicateExists = await _folderService.AnyAsync(f =>
            f.Id != Id &&
            f.CreatedBy == createdById &&
            f.Foldername == dto.FolderName &&
            f.IsDeleted == false);

        if (duplicateExists)
            throw new InvalidOperationException("Another folder with the same FolderName already exists.");

        _mapper.Map(dto, folder);
        folder.UpdatedBy = userId;
        folder.UpdatedAt = DateTime.UtcNow;

        await _folderService.UpdateAsync(folder);
        return _mapper.Map<FolderDto>(folder);
    }


    // public async Task ShareFolderAsync(int folderId, ShareFolderDto dto)
    // {
    //     //  Split emails & names
    //     var emails = dto.ToEmail
    //         .Split(';', StringSplitOptions.RemoveEmptyEntries)
    //         .Select(e => e.Trim())
    //         .ToArray();
    //     var names = dto.ToName
    //         .Split(';', StringSplitOptions.RemoveEmptyEntries)
    //         .Select(n => n.Trim())
    //         .ToArray();

    //     if (emails.Length != names.Length)
    //         throw new InvalidOperationException("Number of emails and names must match.");

    //     var baseUrl = _config["App:BaseUrl"];
    //     var expires = DateTime.UtcNow.AddHours(dto.LinkExpiration);

    //     for (int i = 0; i < emails.Length; i++)
    //     {
    //         var email = emails[i];
    //         var name = names[i];


    //         var token = GenerateShareToken(folderId, email, expires, dto.ViewOnly);

    //         var url = $"{baseUrl}/user/view-share-folder?shareToken={token}";

    //         var body = $@"
    //             Hello {name},<br/><br/>
    //             {dto.Message}<br/><br/>
    //             <a href=""{url}"">Click here to {(dto.ViewOnly ? "view" : "view/download")} the folder</a>.<br/>
    //             <small>This link expires on {expires:yyyy-MM-dd HH:mm} UTC.</small>
    //         ";

    //         await _emailSender.SendEmailAsync(
    //             from: dto.FromEmail,
    //             to: email,
    //             subject: dto.Subject,
    //             html: body
    //         );
    //     }
    // }
    public async Task ShareFolderAsync(int folderId, ShareFolderDto dto)
    {
        var shareDto = new ShareFolderDto
        {
            EntityId = folderId.ToString(),
            ToEmail = dto.ToEmail,
            ToName = dto.ToName,
            FromEmail = dto.FromEmail,
            Message = dto.Message,
            Subject = dto.Subject,
            ViewOnly = dto.ViewOnly,
            LinkExpiration = dto.LinkExpiration
        };

        await ShareEntityAsync(
            dto: shareDto,
            generateToken: (id, email, expires, viewOnly, type) => GenerateShareToken(int.Parse(id), email, expires, viewOnly),
            buildUrl: (token, typeStr) => $"{_config["App:BaseUrl"]}/user/view-share-files?shareToken={token}"
        );
    }


    public async Task RequestOTP(EmailDto dto)
    {
        var otp = new Random().Next(100000, 999999).ToString();
        var expiresAt = DateTime.UtcNow.AddMinutes(5);

        OtpStore.Store[dto.Email] = new OtpEntry { Code = otp, ExpiresAt = expiresAt };
        Console.WriteLine($"Stored OTP for {dto.Email}: {otp} (Expires: {expiresAt})");
        await _emailSender.SendEmailAsync(
            from: _config["App:FromMail"],
            to: dto.Email,
            subject: "OTP Code",
            html: $"<p>Your OTP is <strong>{otp}</strong></p>"
        );

    }
    public async Task VerifyOTP(OtpVerifyDto dto)
    {
        Console.WriteLine($"Current OTPs in store: {string.Join(", ", OtpStore.Store.Keys)}");
        if (!OtpStore.Store.TryGetValue(dto.Email, out var entry))
            throw new KeyNotFoundException("No OTP found");
        if (entry.ExpiresAt < DateTime.UtcNow)
            throw new InvalidOperationException("OTP expired");
        if (entry.Code != dto.Code)
            throw new InvalidOperationException("Incorrect OTP");
        OtpStore.Store.Remove(dto.Email);
    }
    private string MapSortColumn(string sortColumn)
    {
        return sortColumn.ToLower() switch
        {
            "id" => "Id",
            "foldername" or "folderName" => "Foldername",
            "filename" or "fileNumber" => "FileNumber",
            "createdat" => "CreatedAt",
            "firstname" => "FirstName",
            "lastname" => "LastName",
            "comment" => "Comment",
            _ => "Id"
        };
    }

    private string GenerateShareToken(int folderId, string email, DateTime expires, bool viewOnly)
    {
        var tokenPayload = new
        {
            folderId,
            email,
            viewOnly,
            expiresAt = new DateTimeOffset(expires).ToUnixTimeSeconds()
        };

        var json = JsonSerializer.Serialize(tokenPayload);
        var base64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(json));
        return base64;
    }

    public async Task ShareEntityAsync(
    ShareFolderDto dto,
    Func<string, string, DateTime, bool, string, string> generateToken,
    Func<string, string, string> buildUrl)
    {
        var emails = dto.ToEmail
            .Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Select(e => e.Trim())
            .ToArray();

        var names = dto.ToName
            .Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Select(n => n.Trim())
            .ToArray();

        if (emails.Length != names.Length)
            throw new InvalidOperationException("Number of emails and names must match.");

        var expires = DateTime.UtcNow.AddHours(dto.LinkExpiration);

        for (int i = 0; i < emails.Length; i++)
        {
            var email = emails[i];
            var name = names[i];

            string token = generateToken(dto.EntityId, email, expires, dto.ViewOnly, dto.Type);
            string url = buildUrl(token, dto.Type.ToLower());

            string body = $@"
            Hello {name},<br/><br/>
            {dto.Message}<br/><br/>
            <a href=""{url}"">Click here to {(dto.ViewOnly ? "view" : "view/download")} the {dto.Type}</a>.<br/>
            <small>This link expires on {expires:yyyy-MM-dd HH:mm} UTC.</small>
        ";

            await _emailSender.SendEmailAsync(
                from: dto.FromEmail,
                to: email,
                subject: dto.Subject,
                html: body
            );
        }
    }
    public async Task ShareMultipleFileAsync(
MultipleFileDto dto,
Func<string, string, DateTime, bool, string, string> generateToken,
Func<string, string, string> buildUrl)
    {
        var emails = dto.ToEmail
            .Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Select(e => e.Trim())
            .ToArray();

        var names = dto.ToName
            .Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Select(n => n.Trim())
            .ToArray();

        if (emails.Length != names.Length)
            throw new InvalidOperationException("Number of emails and names must match.");

        var expires = DateTime.UtcNow.AddHours(dto.LinkExpiration);

        for (int i = 0; i < emails.Length; i++)
        {
            var email = emails[i];
            var name = names[i];
            var idsString = string.Join(",", dto.EntityIds);
            string token = generateToken(idsString, email, expires, dto.ViewOnly, dto.Type);
            string url = buildUrl(token, dto.Type.ToLower());
            string body = $@"
            Hello {name},<br/><br/>
            {dto.Message}<br/><br/>
            <a href=""{url}"">Click here to {(dto.ViewOnly ? "view" : "view/download")} the {dto.Type}</a>.<br/>
            <small>This link expires on {expires:yyyy-MM-dd HH:mm} UTC.</small>
        ";

            await _emailSender.SendEmailAsync(
                from: dto.FromEmail,
                to: email,
                subject: dto.Subject,
                html: body
            );
        }
    }
    #endregion

    #region methods

    #endregion
}

