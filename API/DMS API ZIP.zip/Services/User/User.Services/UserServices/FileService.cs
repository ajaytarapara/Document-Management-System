using System.Text.Json;
using CoreServices.Generic;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using Microsoft.Extensions.Configuration;
using User.Services.UserServices;
using static Shared.Constant.Enums;
using System.Linq.Expressions;
using Shared.Helper;
using AutoMapper;

namespace User.Services.FileService;

[ScopedDependency(ServiceType = typeof(IFileService))]
public class FileService : IFileService
{
    #region fields

    #endregion

    #region constructor
    private readonly IGenericService<FileRecord, ApplicationDBContext> _fileService;
    private readonly IGenericService<Folder, ApplicationDBContext> _folderService;
    private readonly IGenericService<FolderTab, ApplicationDBContext> _foldertab;
    private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userService;
    private readonly IFolderService _folderBusinessLogic;
    private readonly IConfiguration _config;
    private readonly IGenericService<UserRolePermission, ApplicationDBContext> _userRolePermissionService;

    // private readonly IGenericService<FolderTab, ApplicationDBContext> _folderTabService;
    // private readonly IGenericService<UserRolePermission, ApplicationDBContext> _userRolePermissionService;

    // private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userService;
    private readonly IMapper _mapper;
    // private readonly IEmailSender _emailSender;
    // private readonly IConfiguration _config;


    public FileService(
        IGenericService<FileRecord, ApplicationDBContext> fileService,
        IGenericService<Folder, ApplicationDBContext> folderService,
        IGenericService<FolderTab, ApplicationDBContext> foldertab,
        IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userService,
        IFolderService folderBusinessLogic,
        IConfiguration config,
        IMapper mapper,
        IGenericService<UserRolePermission, ApplicationDBContext> userRolePermissionService
        // IGenericService<FolderTab, ApplicationDBContext> folderTabService,
        // IGenericService<UserRolePermission, ApplicationDBContext> userRolePermissionService,
        // IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userService, IMapper mapper, IConfiguration config, IEmailSender emailSender
        )
    {
        _fileService = fileService;
        _folderService = folderService;
        _foldertab = foldertab;
        _userService = userService;
        _folderBusinessLogic = folderBusinessLogic;
        _config = config;
        _mapper = mapper;
        _userRolePermissionService = userRolePermissionService;
        // _folderTabService = folderTabService;
        // _userRolePermissionService = userRolePermissionService;
        // _userService = userService;
        // _config = config;
        // _emailSender = emailSender;
    }
    public async Task<List<string>> UploadFileAsync(FileUploadDto dto, int userId, string uploadsFolder)
    {
        int decryptedFolderId = AesEncryptionHelper.DecryptId(dto.FolderId);

        var folder = await _folderService.GetAsync(u => u.Id == decryptedFolderId && u.IsDeleted == false)
            ?? throw new KeyNotFoundException("Folder not found.");

        var user = await _userService.GetAsync(x => x.Id == userId && x.IsDeleted == false)
            ?? throw new KeyNotFoundException("User not found.");

        if (user.Role == (int)UserRoles.User && folder.CreatedBy != user.CreatedBy)
            throw new InvalidOperationException("You are not authorized to upload to this folder.");
        else if (user.Role == (int)UserRoles.OfficeUser && folder.CreatedBy != user.Id)
            throw new InvalidOperationException("You are not authorized to upload to this folder.");

        if (!Directory.Exists(uploadsFolder))
            Directory.CreateDirectory(uploadsFolder);

        var fileEntities = new List<FileRecord>();
        List<string> duplicateFileNames = new List<string>();
        foreach (var file in dto.Files)
        {
            int decryptedFolderTabId = AesEncryptionHelper.DecryptId(file.FolderTabId);
            var existingFile = await _fileService.GetAsync(f =>
            f.Name == Path.GetFileNameWithoutExtension(file.FileName) &&
            f.Folder == decryptedFolderId &&
            f.FolderTab == decryptedFolderTabId &&
            f.IsDeleted == false
        );
            if (existingFile != null)
            {
                duplicateFileNames.Add(file.FileName);
                continue;
            }
            var folderTab = await _foldertab.GetAsync(u => u.Id == decryptedFolderTabId && u.IsDeleted == false)
            ?? throw new KeyNotFoundException("Folder tab not found.");
            var fileBytes = Convert.FromBase64String(file.Base64Content);
            var uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            await File.WriteAllBytesAsync(filePath, fileBytes);

            fileEntities.Add(new FileRecord
            {
                Name = Path.GetFileNameWithoutExtension(file.FileName),
                Url = $"/uploads/pdf/{uniqueFileName}",
                Type = file.ContentType,
                Size = FormatFileSize(fileBytes.Length),
                Folder = decryptedFolderId,
                FolderTab = decryptedFolderTabId,
                CreatedAt = DateTime.UtcNow,
                CreatedBy = userId,
                IsActive = true,
                IsDeleted = false
            });
        }

        await _fileService.InsertManyAsync(fileEntities);

        return duplicateFileNames;
    }
    public async Task UpdateFileNameAsync(UpdateFileNameDto dto, int userId)
    {
        int decryptedFileId = AesEncryptionHelper.DecryptId(dto.Id);
        var file = await _fileService.GetAsync(u => u.Id == decryptedFileId && u.IsDeleted == false);
        if (file == null)
            throw new KeyNotFoundException("File not found");
        var existingFile = await _fileService.GetAsync(f =>
        f.Id != decryptedFileId &&
        f.Name == Path.GetFileNameWithoutExtension(dto.Name) &&
        f.FolderTab == file.FolderTab &&
        f.IsDeleted == false
    );
        if (existingFile != null)
            throw new InvalidOperationException($"A file named '{dto.Name}' already exists in this folder tab.");
        file.Name = dto.Name;
        file.UpdatedAt = DateTime.UtcNow;
        file.UpdatedBy = userId;
        await _fileService.UpdateAsync(file);
    }
    public async Task MoveFileAsync(MoveFileDto dto, int userId)
    {
        int decryptedTargetFolderId = AesEncryptionHelper.DecryptId(dto.TargetFolderId);
        int decryptedTargetFolderTabId = AesEncryptionHelper.DecryptId(dto.TargetFolderTabId);
        var targetFolder = await _folderService.GetAsync(f => f.Id == decryptedTargetFolderId && f.IsDeleted == false)
            ?? throw new KeyNotFoundException("Target folder not found.");

        var targetTab = await _foldertab.GetAsync(t => t.Id == decryptedTargetFolderTabId && t.IsDeleted == false)
            ?? throw new KeyNotFoundException("Target folder tab not found.");

        var user = await _userService.GetAsync(x => x.Id == userId)
            ?? throw new KeyNotFoundException("User not found.");

        // Authorization check (once per request)
        if (user.Role == (int)UserRoles.User && targetFolder.CreatedBy != user.CreatedBy)
            throw new InvalidOperationException("You are not authorized to move files to this folder.");
        else if (user.Role == (int)UserRoles.OfficeUser && targetFolder.CreatedBy != user.Id)
            throw new InvalidOperationException("You are not authorized to move files to this folder.");

        foreach (var fileId in dto.FileId)
        {
            int decryptedFileId = AesEncryptionHelper.DecryptId(fileId);
            var file = await _fileService.GetAsync(f => f.Id == decryptedFileId && f.IsDeleted == false);
            if (file == null) continue;
            file.Folder = decryptedTargetFolderId;
            file.FolderTab = decryptedTargetFolderTabId;
            file.UpdatedAt = DateTime.UtcNow;
            file.UpdatedBy = userId;

            await _fileService.UpdateAsync(file);
        }
    }
    public async Task ChangeTabAsync(MoveFiletabDto dto, int userId)
    {
        int decryptedTargetFileId = AesEncryptionHelper.DecryptId(dto.FileId);
        int decryptedTargetFolderTabId = AesEncryptionHelper.DecryptId(dto.TargetFolderTabId);
        var file = await _fileService.GetAsync(f => f.Id == decryptedTargetFileId && f.IsDeleted == false)
            ?? throw new KeyNotFoundException("File not found.");

        var targetTab = await _foldertab.GetAsync(t => t.Id == decryptedTargetFolderTabId && t.IsDeleted == false)
            ?? throw new KeyNotFoundException("Target folder tab not found.");

        var user = await _userService.GetAsync(x => x.Id == userId)
            ?? throw new KeyNotFoundException("User not found.");
        if (user.Role == (int)UserRoles.User && targetTab.CreatedBy != user.CreatedBy)
            throw new InvalidOperationException("You are not authorized to move files to this foldertab.");
        else if (user.Role == (int)UserRoles.OfficeUser && targetTab.CreatedBy != user.Id)
            throw new InvalidOperationException("You are not authorized to move files to this foldertab.");

        file.FolderTab = decryptedTargetFolderTabId;
        file.UpdatedAt = DateTime.UtcNow;
        file.UpdatedBy = userId;

        await _fileService.UpdateAsync(file);
    }
    public async Task<FileListDtos> GetFilesByTabPaginatedAsync(
    int tabId,
    int page,
    int pageSize,
    string sortDirection = "asc",
    string sortColumn = "Id",
    string searchTerm = ""
)
    {
        var folderTab = await _foldertab.GetAsync(u => u.Id == tabId && u.IsDeleted == false)
            ?? throw new KeyNotFoundException("Folder tab not found.");

        Expression<Func<FileRecord, bool>> filter = x =>
            x.FolderTab == tabId &&
            x.IsDeleted == false &&
            (string.IsNullOrEmpty(searchTerm) || x.Name.Contains(searchTerm));

        int totalFiles = await _fileService.CountAsync(filter);

        IEnumerable<FileRecord> fileListDto = await _fileService.GetPaginatedAsync(
            page,
            pageSize,
            x => x,
            filter,
            sortBy: sortColumn ?? nameof(FileRecord.CreatedAt),
            sortDirection: sortDirection ?? "desc"
        );
        var fileListDtos = _mapper.Map<IEnumerable<FileListDto>>(fileListDto);
        return new FileListDtos
        {
            fileListDto = fileListDtos,
            TotalCount = totalFiles
        };
    }
    public async Task<FileListDtos> GetFilesByIds(MultipleFilesVM ids, int page,
    int pageSize,
    string sortDirection = "asc",
    string sortColumn = "Id",
    string searchTerm = ""
    )
    {
        // 1. Decrypt IDs
        var decryptedIds = ids.Id
            .Select(encId => AesEncryptionHelper.DecryptId(encId))
            .ToList();

        // 2. Build filter
        Expression<Func<FileRecord, bool>> filter = x =>
            decryptedIds.Contains(x.Id) &&
            x.IsDeleted == false &&
            (string.IsNullOrEmpty(searchTerm) || x.Name.Contains(searchTerm));

        // 3. Count total before pagination
        int totalFiles = await _fileService.CountAsync(filter);

        // 4. Fetch paginated + sorted result
        IEnumerable<FileRecord> fileListEntities = await _fileService.GetPaginatedAsync(
            page,
            pageSize,
            x => x,
            filter,
            sortBy: sortColumn ?? nameof(FileRecord.CreatedAt),
            sortDirection: sortDirection ?? "desc"
        );

        // 5. Map result
        var fileListDtos = fileListEntities.Select(x => new FileListDto
        {
            Id = AesEncryptionHelper.EncryptId(x.Id),
            Name = x.Name,
            Url = x.Url,
            Type = x.Type,
            Size = x.Size,
            CreatedAt = x.CreatedAt
        });

        // 6. Return with total count
        return new FileListDtos
        {
            fileListDto = fileListDtos,
            TotalCount = totalFiles
        };
    }
    public async Task<FolderTabDtos> GetTabsByFolderIdAsync(int folderId, int currentUserId)
    {
        var folder = await _folderService.GetAsync(u => u.Id == folderId && u.IsDeleted == false)
            ?? throw new KeyNotFoundException("Folder not found.");

        Expression<Func<FolderTab, bool>> filter;

        // If currentUserId = 0, we simulate as User role
        if (currentUserId == 0)
        {
            // Show only unlocked tabs
            filter = x => x.Folder == folderId && x.IsDeleted == false && x.IsLock == false;
        }
        else
        {
            var user = await _userService.GetAsync(u => u.Id == currentUserId && u.IsDeleted == false);
            var allTrue = user.Role == (int)UserRoles.OfficeUser;

            UserRolePermission? perm = null;
            if (!allTrue)
            {
                perm = await _userRolePermissionService.GetAsync(p =>
                    p.Users == currentUserId &&
                    p.IsDeleted == false &&
                    p.IsActive == true);
            }

            if (user.Role == (int)UserRoles.User && perm?.HideLockTabs == true)
            {
                filter = x => x.Folder == folderId && x.IsDeleted == false && x.IsLock == false;
            }
            else
            {
                filter = x => x.Folder == folderId && x.IsDeleted == false;
            }
        }

        var tabs = await _foldertab.GetAllAsync(
            filter,
            x => new FolderTabDto
            {
                Id = AesEncryptionHelper.EncryptId(x.Id),
                TabName = x.TabName,
                Color = x.Color,
                IsLock = x.IsLock
            });

        return new FolderTabDtos
        {
            folderTabDto = tabs,
            FolderName = folder.Foldername
        };
    }
    public async Task<string> delteFile(int fileId)
    {
        var file = await _fileService.GetAsync(f => f.Id == fileId && f.IsDeleted == false);

        if (file == null)
            throw new KeyNotFoundException("File not found.");
        file.IsDeleted = true;
        file.DeletedAt = DateTime.UtcNow;

        await _fileService.UpdateAsync(file);
        return file.Url;
    }
    public async Task ShareFileAsync(int fileId, ShareFolderDto dto)
    {
        var shareDto = new ShareFolderDto
        {
            EntityId = AesEncryptionHelper.EncryptId(fileId),
            ToEmail = dto.ToEmail,
            ToName = dto.ToName,
            FromEmail = dto.FromEmail,
            Message = dto.Message,
            Subject = dto.Subject,
            ViewOnly = dto.ViewOnly,
            LinkExpiration = dto.LinkExpiration,
            Type = dto.Type,
        };

        await _folderBusinessLogic.ShareEntityAsync(
            dto: shareDto,
            generateToken: (id, email, expires, viewOnly, type) => GenerateShareToken(id, email, expires, viewOnly, type),
            buildUrl: (token, typeStr) => $"{_config["App:BaseUrl"]}/user/view-share-files?shareToken={token}"
        );
    }
    public async Task ShareMultipleFileAsync(MultipleFileDto dto)
    {
        // Serialize all file IDs into a single string for token creation
        var idsString = string.Join(",", dto.EntityIds);

        var shareDto = new MultipleFileDto
        {
            EntityIds = dto.EntityIds,
            ToEmail = dto.ToEmail,
            ToName = dto.ToName,
            FromEmail = dto.FromEmail,
            Message = dto.Message,
            Subject = dto.Subject,
            ViewOnly = dto.ViewOnly,
            LinkExpiration = dto.LinkExpiration,
            Type = dto.Type,
        };

        await _folderBusinessLogic.ShareMultipleFileAsync(
            dto: shareDto,
            generateToken: (ids, email, expires, viewOnly, type) =>
                GenerateMultipleShareToken(idsString, email, expires, viewOnly, type),
            buildUrl: (token, typeStr) =>
                $"{_config["App:BaseUrl"]}/user/view-share-files?shareToken={token}"
        );
    }

    private string FormatFileSize(long bytes)
    {
        var sizes = new[] { "B", "KB", "MB", "GB" };
        double len = bytes;
        int order = 0;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len /= 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }
    private string GenerateShareToken(string folderId, string email, DateTime expires, bool viewOnly, string type)
    {
        var tokenPayload = new
        {
            folderId,
            email,
            viewOnly,
            expiresAt = new DateTimeOffset(expires).ToUnixTimeSeconds(),
            type
        };

        var json = JsonSerializer.Serialize(tokenPayload);
        var base64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(json));
        return base64;
    }
    private string GenerateMultipleShareToken(string ids, string email, DateTime expires, bool viewOnly, string type)
    {
        var payload = new
        {
            folderId = ids,
            email,
            expiresAt = new DateTimeOffset(expires).ToUnixTimeSeconds(),
            viewOnly,
            type
        };
        var jsonPayload = JsonSerializer.Serialize(payload);
        return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(jsonPayload));
    }
    #endregion

    #region methods

    #endregion
}