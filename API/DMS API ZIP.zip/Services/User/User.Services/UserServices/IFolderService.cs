using static Shared.Constant.Enums;

namespace User.Services.UserServices
{
    public interface IFolderService
    {
        public Task CreateFolderWithTabsAsync(CreateFolderDto folderDto, int userId);
        public Task<FolderDto?> GetFolderByIdAsync(int id, int currentUserId);
        public Task<FoldersWithPermissionsDto> GetFoldersByUserIdAsync(
        int userId,
        int pageIndex = 1,
        int pageSize = 10,
        string sortDirection = "asc",
        string sortColumn = "Id",
        string searchTerm = "");
        public Task<GetFolderList> getFolderList(int userId);
        public Task<bool> SoftDeleteFolderAsync(int id, int deletedByUserId,string rootPath);
        public Task<FolderDto> UpdateFolderAsync(UpdateFolderDto dto, int userId, int Id);
        public Task ShareFolderAsync(int folderId, ShareFolderDto dto);
        public Task<FolderDownloadDto> DownloadFolderAsync(int folderId, int currentUserId);
        public Task RequestOTP(EmailDto dto);
        public Task VerifyOTP(OtpVerifyDto dto);
        public Task ShareEntityAsync(
        ShareFolderDto dto,
        Func<string, string, DateTime, bool, string, string> generateToken,
        Func<string, string, string> buildUrl
        );
        public Task ShareMultipleFileAsync(
        MultipleFileDto dto,
        Func<string, string, DateTime, bool, string, string> generateToken,
        Func<string, string, string> buildUrl);
        Task<int> GetMaxTabLimitAsync(int userId);

    }
}