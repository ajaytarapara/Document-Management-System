using System.Linq.Expressions;
using AutoMapper;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using LinqKit;
using PdfSharpCore.Pdf.IO;
using PdfSharpCore.Pdf.IO.enums;
using Shared.ExceptionHandler;
using Shared.Helper;
using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;
using static Shared.Constant.Enums;

namespace User.Services.UserServices
{
    [ScopedDependency(ServiceType = typeof(ISplitAndUploadFileService))]
    public class SplitAndUploadFileService(IGenericService<UserRolePermission, ApplicationDBContext> userRolePermissionService, IGenericService<Folder, ApplicationDBContext> folderService, IGenericService<FileRecord, ApplicationDBContext> fileService, IGenericService<SplitAndUpload, ApplicationDBContext> splitAndUploadFileService, IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userService, IMapper mapper, ICurrentUserService currentUserService, IGenericService<FolderTab, ApplicationDBContext> folderTabService) : ISplitAndUploadFileService
    {
        #region fields
        private readonly IGenericService<SplitAndUpload, ApplicationDBContext> _splitAndUploadFileService = splitAndUploadFileService;
        private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userServivce = userService;
        private readonly IMapper _mapper = mapper;
        private readonly ICurrentUserService _currentUserService = currentUserService;
        private readonly IGenericService<Folder, ApplicationDBContext> _folderService = folderService;
        private readonly IGenericService<FileRecord, ApplicationDBContext> _fileService = fileService;
        private readonly IGenericService<FolderTab, ApplicationDBContext> _folderTabService = folderTabService;
        private readonly IGenericService<UserRolePermission, ApplicationDBContext> _userRolePermissionService = userRolePermissionService;
        #endregion

        #region constructor
        #endregion

        #region methods
        public async Task UploadFilesForSplit(FileUploadRequest fileUploadRequest, string fileUploadDirectory)
        {
            int currentUserId = _currentUserService.GetUserId();


            if (fileUploadRequest.Files == null || fileUploadRequest.Files.Count == 0)
                throw new DataNotFoundException("No files uploaded");


            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");

            if (user.Role == 1)
                throw new DataConflictException("You are not authorized to upload to this folder");

            if (!Directory.Exists(fileUploadDirectory))
                Directory.CreateDirectory(fileUploadDirectory);

            List<SplitAndUpload> uploads = [];

            foreach (SplitFileUploadDto file in fileUploadRequest.Files)
            {
                var existingFile = await _splitAndUploadFileService.GetAsync(f =>
            f.Name == Path.GetFileNameWithoutExtension(file.Name) &&
            f.UserId == currentUserId &&
            f.IsDeleted == false);

                if (existingFile != null)
                    continue;
                string base64Data = file.Base64;
                if (base64Data.Contains(','))
                    base64Data = base64Data.Split(',')[1];

                byte[] bytes = Convert.FromBase64String(base64Data);
                string fileName = $"{Guid.NewGuid()}_{file.Name}";
                string filePath = Path.Combine(fileUploadDirectory, fileName);

                await File.WriteAllBytesAsync(filePath, bytes);

                SplitAndUpload fileEntity = _mapper.Map<SplitAndUpload>(file);
                fileEntity.Name = Path.GetFileNameWithoutExtension(file.Name);
                fileEntity.Size = FormatFileSize(bytes.Length);
                fileEntity.Url = $"/splitandupload/pdf/{fileName}";
                fileEntity.UserId = currentUserId;
                fileEntity.CreatedBy = currentUserId;
                uploads.Add(fileEntity);
            }
            await _splitAndUploadFileService.InsertManyAsync(uploads);
        }

        private static string FormatFileSize(long bytes)
        {
            var sizes = new[] { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }

        public async Task<PaginatedResponse<FileUploadResponseForSplitVM>> GetUploadedFiles(PaginatedRequest paginatedRequest)
        {
            int currentUserId = _currentUserService.GetUserId();
            Expression<Func<SplitAndUpload, bool>> predicate = s =>
                s.IsActive == true && s.IsDeleted == false && s.UserId == currentUserId;

            if (!string.IsNullOrWhiteSpace(paginatedRequest.SearchTerm))
            {
                string searchTerm = paginatedRequest.SearchTerm.Trim().ToLower();
                predicate = predicate.And(s => s.Name.ToLower().Contains(searchTerm));
            }

            int totalRecords = await _splitAndUploadFileService.CountAsync(predicate);

            IEnumerable<FileUploadResponseForSplitVM> records = await _splitAndUploadFileService.GetPaginatedAsync(paginatedRequest.PageNumber, paginatedRequest.PageSize, x => new FileUploadResponseForSplitVM
            {
                Id = AesEncryptionHelper.EncryptId(x.Id),
                Name = x.Name,
                Type = x.Type,
                Url = x.Url,
                Size = x.Size,
                CreatedAt = x.CreatedAt ?? DateTime.MinValue,
            }, predicate, paginatedRequest.SortBy, paginatedRequest.SortDirection);

            PaginatedResponse<FileUploadResponseForSplitVM> paginatedResponse = new()
            {
                Items = records,
                PageNumber = paginatedRequest.PageNumber,
                PageSize = paginatedRequest.PageSize,
                TotalCount = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / paginatedRequest.PageSize)
            };

            return paginatedResponse;
        }

        public async Task DeleteUploadedFile(int id)
        {
            int currentUserId = _currentUserService.GetUserId();
            Expression<Func<SplitAndUpload, bool>> predicate = t => t.IsActive == true && t.IsDeleted == false && t.Id == id && t.UserId == currentUserId;
            SplitAndUpload splitAndUpload = await _splitAndUploadFileService.GetAsync(predicate) ?? throw new DataNotFoundException("File not found");

            splitAndUpload.IsDeleted = true;
            await _splitAndUploadFileService.UpdateAsync(splitAndUpload);

            if (!string.IsNullOrEmpty(splitAndUpload.Url))
            {
                string wwwrootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
                string fullPath = Path.Combine(wwwrootPath, splitAndUpload.Url.TrimStart('/'));

                if (System.IO.File.Exists(fullPath))
                {
                    System.IO.File.Delete(fullPath);
                }
            }
        }

        public async Task UpdateUploadedFileName(FileNameUpdateRequest request)
        {
            int decryptedId = AesEncryptionHelper.DecryptId(request.Id);
            int currentUserId = _currentUserService.GetUserId();
            Expression<Func<SplitAndUpload, bool>> predicate = t => t.IsActive == true && t.IsDeleted == false && t.Id == decryptedId && t.UserId == currentUserId;
            SplitAndUpload splitAndUpload = await _splitAndUploadFileService.GetFirstOrDefaultAsync(predicate) ?? throw new DataNotFoundException("File not found");
            splitAndUpload.Name = request.Name;

            await _splitAndUploadFileService.UpdateAsync(splitAndUpload);
        }

        public async Task<List<FolderListResponse>> GetFolderList()
        {
            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");
            int CreatedById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0) ? user.CreatedBy : currentUserId;

            Expression<Func<Folder, bool>> predicate = f => f.IsActive == true && f.IsDeleted == false && f.CreatedBy == CreatedById;
            IEnumerable<FolderListResponse> folderListResponses = await _folderService.GetAllAsync(predicate, fl => new FolderListResponse
            {
                Id = AesEncryptionHelper.EncryptId(fl.Id),
                FolderName = fl.Foldername,
            });
            return [.. folderListResponses];
        }


        public async Task<List<TabListResponse>> GetTabList(int folderId)
        {
            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");

            Expression<Func<FolderTab, bool>> predicate;
            predicate = ft => ft.IsActive == true && ft.IsDeleted == false && ft.Folder == folderId;
            if (user.Role == (int)UserRoles.User)
            {
                UserRolePermission userRolePermission = await _userRolePermissionService.GetFirstOrDefaultAsync(
                    ur => ur.Users == currentUserId && ur.IsActive == true && ur.IsDeleted == false
                );

                if (userRolePermission?.HideLockTabs == true)
                {
                    predicate = ft => ft.IsActive == true && ft.IsDeleted == false && ft.Folder == folderId && ft.IsLock == false;
                }
            }

            IEnumerable<TabListResponse> tabListResponses = await _folderTabService.GetAllAsync(predicate, fts => new TabListResponse
            {
                Id = AesEncryptionHelper.EncryptId(fts.Id),
                TabName = fts.TabName,
                TabColor = fts.Color,
            });
            return [.. tabListResponses];
        }

        public async Task SplitAndReplace(SplitPdfRequest splitPdfRequest)
        {
            int decryptedFolderId = AesEncryptionHelper.DecryptId(splitPdfRequest.FolderId);
            int decryptedTabId = AesEncryptionHelper.DecryptId(splitPdfRequest.TabId);

            FileRecord existingFile = await _fileService.GetAsync(f =>
            f.Name == Path.GetFileNameWithoutExtension(splitPdfRequest.NewSplitPdfFileName) &&
            f.Folder == decryptedFolderId &&
            f.FolderTab == decryptedTabId &&
            f.IsDeleted == false);

            if (existingFile != null)
                throw new DataConflictException($"A file named '{splitPdfRequest.NewSplitPdfFileName}' already exists in this folder tab.");

            if (string.IsNullOrEmpty(splitPdfRequest.OriginalFileNameFromUrl) || splitPdfRequest.SelectedPages == null || splitPdfRequest.SelectedPages.Count == 0)
                throw new DataNotFoundException("No file or pages selected");

            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");

            if (user.Role == 1)
                throw new DataConflictException("You are not authorized to split files");

            string uploadsDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", "pdf");
            if (!Directory.Exists(uploadsDir))
                Directory.CreateDirectory(uploadsDir);

            string originalFileDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "splitandupload", "pdf");
            string originalFilePath = Path.Combine(originalFileDirectory, splitPdfRequest.OriginalFileNameFromUrl);
            if (!System.IO.File.Exists(originalFilePath))
                throw new DataNotFoundException("Original file not found");

            byte[] pdfBytes = await System.IO.File.ReadAllBytesAsync(originalFilePath);
            using var inputStream = new MemoryStream(pdfBytes);
            PdfSharpCore.Pdf.PdfDocument inputDoc = PdfReader.Open(inputStream, PdfDocumentOpenMode.Import, PdfReadAccuracy.Moderate); ;

            PdfSharpCore.Pdf.PdfDocument splitPdf = new();
            foreach (int pageNum in splitPdfRequest.SelectedPages)
            {
                if (pageNum > 0 && pageNum <= inputDoc.PageCount)
                {
                    splitPdf.AddPage(inputDoc.Pages[pageNum - 1]);
                }
            }

            string splitFileName = splitPdfRequest.NewSplitPdfFileName.EndsWith(".pdf")
                ? $"{Guid.NewGuid()}_{splitPdfRequest.NewSplitPdfFileName}"
                : $"{Guid.NewGuid()}_{splitPdfRequest.NewSplitPdfFileName}.pdf";

            string splitFilePath = Path.Combine(uploadsDir, splitFileName);
            splitPdf.Save(splitFilePath);

            var updatedPdf = new PdfSharpCore.Pdf.PdfDocument();
            for (int i = 0; i < inputDoc.PageCount; i++)
            {
                if (!splitPdfRequest.SelectedPages.Contains(i + 1))
                {
                    updatedPdf.AddPage(inputDoc.Pages[i]);
                }
            }
            updatedPdf.Save(originalFilePath);

            Expression<Func<SplitAndUpload, bool>> predicate = s => s.IsActive == true && s.IsDeleted == false && s.Name == splitPdfRequest.OriginalFileName;
            SplitAndUpload originalRecord = await _splitAndUploadFileService.GetFirstOrDefaultAsync(predicate);
            if (originalRecord != null)
            {
                originalRecord.Size = FormatFileSize(new FileInfo(originalFilePath).Length);
                originalRecord.UpdatedBy = currentUserId;
                originalRecord.UpdatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc);
                await _splitAndUploadFileService.UpdateAsync(originalRecord);
            }

            FileRecord splitEntity = new()
            {
                Name = splitPdfRequest.NewSplitPdfFileName,
                Folder = decryptedFolderId,
                FolderTab = decryptedTabId,
                Type = "pdf",
                Size = FormatFileSize(new FileInfo(splitFilePath).Length),
                Url = $"/uploads/pdf/{splitFileName}",
                CreatedBy = currentUserId,
                CreatedAt = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Utc),
                IsActive = true,
                IsDeleted = false
            };
            await _fileService.InsertAsync(splitEntity);
        }
        #endregion
    }
}