
using System.Linq.Expressions;
using System.Text.Json;
using CoreServices.Generic;
using CoreServices.HttpClients;
using Infrastructure.Context;
using Infrastructure.DependencyInjection;
using Infrastructure.Entities;
using LinqKit;
using Microsoft.Extensions.Configuration;
using Shared.ExceptionHandler;
using Shared.Helper;
using User.Entities.ViewModels.BatchShare;
using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;
using static Shared.Constant.Enums;

namespace User.Services.UserServices
{
    [ScopedDependency(ServiceType = typeof(IBatchShareService))]
    public class BatchShareService(IEmailSender emailSender, IConfiguration config, IGenericService<UserRolePermission, ApplicationDBContext> userRolePermissionService, IGenericService<FolderTab, ApplicationDBContext> folderTabService, IGenericService<FileRecord, ApplicationDBContext> fileService, IGenericService<Folder, ApplicationDBContext> folderService, IGenericService<Infrastructure.Entities.User, ApplicationDBContext> userBatchServivce, ICurrentUserService currentUserService) : IBatchShareService
    {
        #region fields
        private readonly ICurrentUserService _currentUserService = currentUserService;
        private readonly IGenericService<Infrastructure.Entities.User, ApplicationDBContext> _userServivce = userBatchServivce;
        private readonly IGenericService<Folder, ApplicationDBContext> _folderService = folderService;
        private readonly IGenericService<FileRecord, ApplicationDBContext> _fileService = fileService;
        private readonly IGenericService<FolderTab, ApplicationDBContext> _folderTabService = folderTabService;
        private readonly IGenericService<UserRolePermission, ApplicationDBContext> _userRolePermissionService = userRolePermissionService;
        private readonly IConfiguration _config = config;
        private readonly IEmailSender _emailSender = emailSender;
        #endregion

        #region constructor
        #endregion

        #region methods
        public async Task<List<FolderListResponse>> GetFolderList()
        {
            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");
            int CreatedById = (user.Role == (int)UserRoles.User && user.CreatedBy > 0) ? user.CreatedBy : currentUserId;

            Expression<Func<Folder, bool>> predicate = f => f.IsActive == true && f.IsDeleted == false && f.CreatedBy == CreatedById;
            IEnumerable<FolderListResponse> folderListResponses = await _folderService.GetAllAsync(predicate, fl => new FolderListResponse
            {
                Id = AesEncryptionHelper.EncryptId(fl.Id),
                FolderName = fl.Foldername,
            });
            return [.. folderListResponses];
        }

        public async Task<PaginatedResponse<BatchShareTabAndFileResponse>> GetFileByTabId(BatchShareTabAndFileRequest batchShareTabAndFileRequest)
        {
            int decryptedTabId = AesEncryptionHelper.DecryptId(batchShareTabAndFileRequest.TabId);
            Expression<Func<FileRecord, bool>> predicate = fr => fr.FolderTab == decryptedTabId && fr.IsDeleted == false && fr.IsActive == true;

            if (!string.IsNullOrWhiteSpace(batchShareTabAndFileRequest.SearchTerm))
            {
                string searchTerm = batchShareTabAndFileRequest.SearchTerm.Trim().ToLower();
                predicate = predicate.And(s => s.Name.ToLower().Contains(searchTerm));
            }

            int totalRecords = await _fileService.CountAsync(predicate);

            IEnumerable<BatchShareTabAndFileResponse> records = await _fileService.GetPaginatedAsync(batchShareTabAndFileRequest.PageNumber, batchShareTabAndFileRequest.PageSize, x => new BatchShareTabAndFileResponse
            {
                Id = AesEncryptionHelper.EncryptId(x.Id),
                Name = x.Name,
                Type = x.Type,
                Url = x.Url,
                Size = x.Size,
                CreatedAt = x.CreatedAt ?? DateTime.MinValue,
            }, predicate, batchShareTabAndFileRequest.SortBy, batchShareTabAndFileRequest.SortDirection);

            PaginatedResponse<BatchShareTabAndFileResponse> paginatedResponse = new()
            {
                Items = records,
                PageNumber = batchShareTabAndFileRequest.PageNumber,
                PageSize = batchShareTabAndFileRequest.PageSize,
                TotalCount = totalRecords,
                TotalPages = (int)Math.Ceiling((double)totalRecords / batchShareTabAndFileRequest.PageSize)
            };
            return paginatedResponse;
        }

        public async Task<List<TabListResponse>> GetTabList(int folderId)
        {
            int currentUserId = _currentUserService.GetUserId();
            Infrastructure.Entities.User user = await _userServivce.GetFirstOrDefaultAsync(u => u.Id == currentUserId && u.IsDeleted == false && u.IsActive == true) ?? throw new DataNotFoundException("User not found");

            Expression<Func<FolderTab, bool>> predicate;
            predicate = ft => ft.IsActive == true && ft.IsDeleted == false && ft.Folder == folderId;
            if (user.Role == (int)UserRoles.User)
            {
                UserRolePermission userRolePermission = await _userRolePermissionService.GetFirstOrDefaultAsync(
                    ur => ur.Users == currentUserId && ur.IsActive == true && ur.IsDeleted == false
                );

                if (userRolePermission?.HideLockTabs == true)
                {
                    predicate = ft => ft.IsActive == true && ft.IsDeleted == false && ft.Folder == folderId && ft.IsLock == false;
                }
            }

            IEnumerable<TabListResponse> tabListResponses = await _folderTabService.GetAllAsync(predicate, fts => new TabListResponse
            {
                Id = AesEncryptionHelper.EncryptId(fts.Id),
                TabName = fts.TabName,
                TabColor = fts.Color,
            });
            return [.. tabListResponses];
        }

        public async Task ShareBatchShareFiles(BatchShareMultipleFileShareRequest request)
        {
            string idsString = string.Join(",", request.FileIds);

            BatchShareMultipleFileShareRequest shareDto = new()
            {
                FileIds = request.FileIds,
                ToEmail = request.ToEmail,
                ToName = request.ToName,
                FromEmail = request.FromEmail,
                Message = request.Message,
                Subject = request.Subject,
                ViewOnly = request.ViewOnly,
                LinkExpiration = request.LinkExpiration,
                Type = request.Type,
            };

            await ShareMultipleFileAsync(
                dto: shareDto,
                generateToken: (ids, email, expires, viewOnly) =>
                    GenerateMultipleShareToken(idsString, email, expires, viewOnly),
                buildUrl: (token, typeStr) =>
                    $"{_config["App:BaseUrl"]}/user/view-share-files?shareToken={token}"
            );
        }

        private static string GenerateMultipleShareToken(string ids, string email, DateTime expires, bool viewOnly)
        {
            var payload = new
            {
                folderId = ids,
                email,
                expiresAt = new DateTimeOffset(expires).ToUnixTimeSeconds(),
                viewOnly,
                type = "File"
            };
            var jsonPayload = JsonSerializer.Serialize(payload);
            return Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(jsonPayload));
        }

        public async Task ShareMultipleFileAsync(BatchShareMultipleFileShareRequest dto, Func<string, string, DateTime, bool, string> generateToken, Func<string, string, string> buildUrl)
        {
            string[] emails = [.. dto.ToEmail
                .Split(';', StringSplitOptions.RemoveEmptyEntries)
                .Select(e => e.Trim())];

            string[] names = [.. dto.ToName
                .Split(';', StringSplitOptions.RemoveEmptyEntries)
                .Select(n => n.Trim())];

            if (emails.Length != names.Length)
                throw new InvalidOperationException("Number of emails and names must match.");

            DateTime expires = DateTime.UtcNow.AddHours(dto.LinkExpiration);

            for (int i = 0; i < emails.Length; i++)
            {
                var email = emails[i];
                var name = names[i];
                var idsString = string.Join(",", dto.FileIds);
                string token = generateToken(idsString, email, expires, dto.ViewOnly);
                string url = buildUrl(token, dto.Type.ToLower());

                string body = $@"
                    Hello {name},<br/><br/>
                    {dto.Message}<br/><br/>
                    <a href=""{url}"">Click here to {(dto.ViewOnly ? "view" : "view/download")} the {dto.Type}</a>.<br/>
                    <small>This link expires on {expires:yyyy-MM-dd HH:mm} UTC.</small>
                ";

                await _emailSender.SendEmailAsync(
                    from: dto.FromEmail,
                    to: email,
                    subject: dto.Subject,
                    html: body
                );
            }
        }
        #endregion
    }
}