public class EmailDto
{
    public string Email { get; set; }
}

public class OtpVerifyDto
{
    public string Email { get; set; }
    public string Code { get; set; }
}

public class OtpEntry
{
    public string Code { get; set; }
    public DateTime ExpiresAt { get; set; }
}

public static class OtpStore
{
    public static Dictionary<string, OtpEntry> Store = new();
}