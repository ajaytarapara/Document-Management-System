using System.ComponentModel.DataAnnotations;

public class FolderDto
{
    public string Id { get; set; }
    public string FolderName { get; set; }
    public int TabCount { get; set; }
    public int UserId { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public string FileNumber { get; set; } = null!;
    public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; }
    public List<FolderTabDto> Tabs { get; set; } = new();
}