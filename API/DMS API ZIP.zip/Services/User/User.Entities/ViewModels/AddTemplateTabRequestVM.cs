using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.Entities.ViewModels
{
    public class AddTemplateTabRequestVM
    {
        /// <summary>
        /// A collection of user template tabs to be added.
        /// </summary>
        public List<UserTemplateTabVM> TemplateTabs { get; set; } = new List<UserTemplateTabVM>();

        public string TemplateId { get; set; } = string.Empty;
    }

    public class UserTemplateTabVM
    {
        /// <summary>
        /// The unique identifier of the template.
        /// </summary>
        public string TemplateId { get; set; } = string.Empty;

        /// <summary>
        /// The name of the tab within the template.
        /// </summary>
        public string TabName { get; set; }

        /// <summary>
        /// The color assigned to the tab.
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Indicates whether the tab is locked (true), unlocked (false), or unspecified (null).
        /// </summary>
        public bool? IsLock { get; set; }
    }
}
