
public class MultipleFilesVM
{
    public List<string> Id { get; set; }
}
