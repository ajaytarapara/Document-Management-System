using System;

namespace User.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// Represents the request payload for retrieving a DMS form
    /// using encrypted identifiers for both the form and the user.
    /// </summary>
    public class GetFormRequest
    {
        /// <summary>
        /// The encrypted identifier of the DMS form to retrieve.
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// The encrypted identifier of the user requesting the form.
        /// Defaults to an empty string if not provided.
        /// </summary>
        public string UserId { get; set; } = string.Empty;
    }
}
