using System.ComponentModel.DataAnnotations;

namespace User.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// ViewModel representing the data required to share one or more DMS forms with another user.
    /// </summary>
    public class ShareDmsFormVM
    {
        /// <summary>
        /// The list of form IDs to be shared.
        /// </summary>
        public List<string> FormIds { get; set; }

        /// <summary>
        /// The email address of the sender.
        /// </summary>
        public string FromEmail { get; set; }

        /// <summary>
        /// The email address of the recipient.
        /// </summary>
        public string ToEmail { get; set; }

        /// <summary>
        /// The name of the recipient.
        /// </summary>
        public string ToName { get; set; }

        /// <summary>
        /// The subject of the sharing email.
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// An optional message to include in the sharing email.
        /// </summary>
        public string? Message { get; set; }

        /// <summary>
        /// The number of hours the shared link will remain valid. Default is 24 hours.
        /// </summary>
        public int LinkExpiration { get; set; } = 24;

        /// <summary>
        /// Indicates whether the recipient has view-only access to the form(s).
        /// </summary>
        public bool ViewOnly { get; set; }
    }
}
