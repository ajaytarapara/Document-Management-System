using Shared.ViewModels.DmsForms;
namespace User.Entities.ViewModels.DmsForms
{
    /// <summary>
    /// ViewModel representing a file stored in the DMS (Document Management System).
    /// </summary>
    public class DMSFormFileVM
    {
        /// <summary>
        /// The unique identifier of the file.
        /// </summary>
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// The name of the file.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The size of the file in bytes.
        /// </summary>
        public long Size { get; set; }

        /// <summary>
        /// The URL where the file is stored or can be accessed.
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// The date and time when the file was created, represented as a string.
        /// </summary>
        public string CreatedAt { get; set; }

        /// <summary>
        /// The current status of the file (e.g., Active, Deleted).
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// A collection of fields associated with the form,
        /// containing metadata and values for each editable field.
        /// </summary>
        public List<FieldBaseVM> Fields { get; set; } = new();

        /// <summary>
        /// Email or identifier of the user who submitted the form.
        /// </summary>
        public string? SubmittedBy { get; set; }

        /// <summary>
        /// The date and time when the file was submitted, represented as a string.
        /// </summary>
        public string? SubmittedAt { get; set; }
    }
}
