namespace User.Entities.ViewModels
{
    public class TemplateTabResponseVM
    {
        /// <summary>
        /// The name of the user template.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// The unique identifier for the user template.
        /// </summary>
        public string Id { get; set; } = string.Empty;

        /// <summary>
        /// The color code associated with the template (e.g., for UI representation).
        /// </summary>
        public string Color { get; set; } = string.Empty;

        /// <summary>
        /// Indicates whether the template is locked.
        /// </summary>
        public bool IsLock { get; set; }
    }
}
