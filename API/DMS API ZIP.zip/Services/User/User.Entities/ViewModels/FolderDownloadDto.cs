public class FolderDownloadDto
{
    public string folderName { get; set; }
    public IEnumerable<TabListDto> tabListDto { get; set; }
}

public class TabListDto
{
    public string TabName { get; set; }
    public IEnumerable<FileListDto> fileListDto { get; set; }
}