namespace User.Entities.ViewModels
{
    /// <summary>
    /// View model representing the response for a user template.
    /// </summary>
    public class UserTemplateResponseVM
    {
        /// <summary>
        /// The name of the user template.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// The unique identifier for the user template.
        /// </summary>
        public string Id { get; set; } = string.Empty;
    }
}
