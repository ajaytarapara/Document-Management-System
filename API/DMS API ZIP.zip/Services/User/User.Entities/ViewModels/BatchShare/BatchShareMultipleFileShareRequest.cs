using System.ComponentModel.DataAnnotations;

namespace User.Entities.ViewModels.BatchShare
{
    public class BatchShareMultipleFileShareRequest
    {
        public List<string> FileIds { get; set; } = [];

        public string FromEmail { get; set; } = string.Empty;
        public string ToEmail { get; set; } = string.Empty;
        public string ToName { get; set; } = string.Empty;
        public string Subject { get; set; } = string.Empty;
        public string? Message { get; set; }

        [Range(1, 168)]
        public int LinkExpiration { get; set; }

        public bool ViewOnly { get; set; }
        public string Type { get; set; } = string.Empty;
    }
}