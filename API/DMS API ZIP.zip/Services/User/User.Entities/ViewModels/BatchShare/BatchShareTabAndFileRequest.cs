using User.Entities.ViewModels.Pagination;

namespace User.Entities.ViewModels.BatchShare
{
    public class BatchShareTabAndFileRequest : PaginatedRequest
    {
        public string TabId { get; set; } = string.Empty;
    }
}