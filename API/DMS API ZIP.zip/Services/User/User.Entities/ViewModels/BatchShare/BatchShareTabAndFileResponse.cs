namespace User.Entities.ViewModels.BatchShare
{
    public class BatchShareTabAndFileResponse
    {
        public string Id { get; set; } = string.Empty;

        public string Name { get; set; } = null!;

        public string Type { get; set; } = null!;

        public string Size { get; set; } = null!;

        public string Url { get; set; } = null!;
        public DateTime CreatedAt { get; set; }
    }
}