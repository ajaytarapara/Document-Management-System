namespace User.Entities.ViewModels.SplitAndUpload
{
    public class TabListResponse
    {
        public string Id { get; set; } = string.Empty;
        public string TabName { get; set; } = string.Empty;
        public string TabColor { get; set; } = string.Empty;
    }
}