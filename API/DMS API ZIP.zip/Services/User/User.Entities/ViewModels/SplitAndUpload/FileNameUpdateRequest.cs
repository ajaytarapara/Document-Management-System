namespace User.Entities.ViewModels.SplitAndUpload
{
    public class FileNameUpdateRequest
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}