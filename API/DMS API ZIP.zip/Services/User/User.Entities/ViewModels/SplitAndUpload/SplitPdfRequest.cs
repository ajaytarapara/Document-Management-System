namespace User.Entities.ViewModels.SplitAndUpload
{
    public class SplitPdfRequest
    {
        public string OriginalFileNameFromUrl { get; set; } = string.Empty;
        public string OriginalFileName { get; set; } = string.Empty;
        public string NewSplitPdfFileName { get; set; } = string.Empty;
        public string FolderId { get; set; } = string.Empty;
        public string TabId { get; set; } = string.Empty;
        public List<int> SelectedPages { get; set; } = [];
    }
}