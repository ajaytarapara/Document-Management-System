namespace User.Entities.ViewModels.SplitAndUpload
{
    public class FolderListResponse
    {
        public string Id { get; set; } = string.Empty;
        public string FolderName { get; set; } = string.Empty;
    }
}