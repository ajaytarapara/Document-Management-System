namespace User.Entities.ViewModels.SplitAndUpload
{
    public class FileUploadResponseForSplitVM
    {
        public string Id { get; set; } = string.Empty;

        public string Name { get; set; } = null!;

        public string Type { get; set; } = null!;

        public string Size { get; set; } = null!;

        public string Url { get; set; } = null!;
        public DateTime CreatedAt { get; set; }
    }
}