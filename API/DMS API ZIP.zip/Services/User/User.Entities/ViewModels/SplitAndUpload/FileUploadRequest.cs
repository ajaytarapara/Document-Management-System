namespace User.Entities.ViewModels.SplitAndUpload
{
    public class FileUploadRequest
    {
        public List<SplitFileUploadDto> Files { get; set; } = [];
    }

    public class SplitFileUploadDto
    {
        public string Name { get; set; } = null!;
        public string Type { get; set; } = null!;
        public string Base64 { get; set; } = null!;
    }
}