namespace User.Entities.ViewModels
{
    public class ApplyFolderTabRequestVM
    {
        public List<UserTemplateTabVM> TemplateTabs { get; set; } = new List<UserTemplateTabVM>();
        public List<int>? selectedFolder { get; set; }
    }
}