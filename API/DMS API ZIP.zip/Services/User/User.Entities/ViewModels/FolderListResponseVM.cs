namespace User.Entities.ViewModels
{
    /// <summary>
    /// Represents a response model for folder listing.
    /// </summary>
    public class FolderListResponseVM
    {
        /// <summary>
        /// The unique identifier of the folder or template.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The name of the folder.
        /// </summary>
        public string FolderName { get; set; }

        /// <summary>
        /// The first name of the user who owns or created the folder.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// The last name of the user who owns or created the folder.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// The file number associated with the folder.
        /// </summary>
        public string FileNumber { get; set; }

        /// <summary>
        /// The total number of tabs or documents contained within the folder.
        /// </summary>
        public int? TabsCount { get; set; }
    }
}
