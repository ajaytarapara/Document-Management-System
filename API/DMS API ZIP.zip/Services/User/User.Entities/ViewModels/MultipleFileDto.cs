using System.ComponentModel.DataAnnotations;

public class MultipleFileDto
{
    public List<string> EntityIds { get; set; }
    public string FromEmail { get; set; }
    public string Type { get; set; }

    public string ToEmail { get; set; }


    public string ToName { get; set; }


    public string Subject { get; set; }

    public string? Message { get; set; }

    [Range(1, 168)]
    public int LinkExpiration { get; set; }

    public bool ViewOnly { get; set; }
}