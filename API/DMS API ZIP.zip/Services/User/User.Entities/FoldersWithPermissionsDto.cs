public class FoldersWithPermissionsDto
{
    public IEnumerable<GetFolderDto> Items { get; set; }
    public int TotalCount { get; set; }
    public PermissionsDto Permissions { get; set; }
}
public class GetFolderDto
{
    public string Id { get; set; } = string.Empty;
    public string FolderName { get; set; } = null!;
    public int TabCount { get; set; }
    public string UserId { get; set; } = string.Empty;
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public string FileNumber { get; set; } = null!;
    public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; }
}
public class GetFolderList
{
    public IEnumerable<GetFolderDto> GetFolderDto { get; set; }
    
}

public class PermissionsDto
{
    public bool PrivilegeDelete { get; set; }
    public bool PrivilegeDownload { get; set; }
    public bool PrivilegeView { get; set; }
    public bool HideLockTabs { get; set; }
}
