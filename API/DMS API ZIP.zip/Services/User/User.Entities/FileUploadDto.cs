public class FileUploadDto
{
    public string FolderId { get; set; }
    public List<FileUploadItemDto> Files { get; set; }
}

public class FileUploadItemDto
{
    public string FileName { get; set; }
    public string ContentType { get; set; }
    public string Base64Content { get; set; }
    public string FolderTabId { get; set; }
}