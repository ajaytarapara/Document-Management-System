
public class CreateFolderTabDto
{
    public string TabName { get; set; } = null!;
    public string Color { get; set; } = null!;

    public bool IsLock { get; set; }
}