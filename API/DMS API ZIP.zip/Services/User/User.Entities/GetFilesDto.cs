public class FileListDto
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; }
    public string Url { get; set; }
    public string Type { get; set; }
    public string Size { get; set; }
    public DateTime? CreatedAt { get; set; }
}
public class FileListDtos
{
    public IEnumerable<FileListDto> fileListDto { get; set; }
    public int TotalCount { get; set; }
}