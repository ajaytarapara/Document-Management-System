
public class CreateFolderDto
{

    public string FirstName { get; set; }
    public string FolderName { get; set; }

    public string LastName { get; set; }

    public string FileNumber { get; set; }

    public string? Comment { get; set; }

    public string? TemplateId { get; set; }

    public List<CreateFolderTabDto> Tabs { get; set; } = new List<CreateFolderTabDto>();
}
