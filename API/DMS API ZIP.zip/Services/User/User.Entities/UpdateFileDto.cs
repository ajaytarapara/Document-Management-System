public class UpdateFileNameDto
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; }
}