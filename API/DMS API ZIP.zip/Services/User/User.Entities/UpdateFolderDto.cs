
public class UpdateFolderDto
{

    public string FolderName { get; set; }
    public string FirstName { get; set; } = null!;
    public string LastName { get; set; } = null!;
    public string FileNumber { get; set; } = null!;
}