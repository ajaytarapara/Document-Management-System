public class MoveFileDto
{
    public List<string> FileId { get; set; }
    public string TargetFolderId { get; set; }
    public string TargetFolderTabId { get; set; }
}
public class MoveFiletabDto
{
    public string FileId { get; set; }
    public string TargetFolderTabId { get; set; }
}