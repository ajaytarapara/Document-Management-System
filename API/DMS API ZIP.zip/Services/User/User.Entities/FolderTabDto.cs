public class FolderTabDto
{
    public string Id { get; set; }
    public string TabName { get; set; } = null!;
    public string Color { get; set; } = null!;
    public bool? IsLock { get; set; }
}

public class FolderTabDtos
{
    public IEnumerable<FolderTabDto> folderTabDto { get; set; }
    public string FolderName { get; set; } = null!;
}