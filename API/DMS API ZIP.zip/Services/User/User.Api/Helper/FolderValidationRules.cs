using FluentValidation;

public static class Validators
{
    public static AbstractValidator<CreateFolderDto> CreateFolderValidator()
    {
        var validator = new InlineValidator<CreateFolderDto>();

        validator.RuleFor(x => x.FirstName)
            .NotEmpty().WithMessage("First name is required.");

        validator.RuleFor(x => x.FolderName)
            .NotEmpty().WithMessage("Folder name is required.");

        validator.RuleFor(x => x.LastName)
            .NotEmpty().WithMessage("Last name is required.");

        validator.RuleFor(x => x.FileNumber)
            .NotEmpty().WithMessage("File number is required.");

        validator.RuleFor(x => x.Tabs)
            .NotNull().WithMessage("Tabs are required.")
            .Must(tabs => tabs.Count > 0).WithMessage("At least one tab is required.");

        validator.RuleForEach(x => x.Tabs)
            .SetValidator(CreateFolderTabValidator());

        return validator;
    }

    public static AbstractValidator<CreateFolderTabDto> CreateFolderTabValidator()
    {
        var validator = new InlineValidator<CreateFolderTabDto>();

        validator.RuleFor(x => x.TabName)
            .NotEmpty().WithMessage("Tab name is required.");

        validator.RuleFor(x => x.Color)
            .NotEmpty().WithMessage("Color is required.");

        return validator;
    }

    public static AbstractValidator<UpdateFolderDto> UpdateFolderValidator()
    {
        var validator = new InlineValidator<UpdateFolderDto>();

        validator.RuleFor(x => x.FolderName)
            .NotEmpty().WithMessage("Folder name is required.");

        validator.RuleFor(x => x.FirstName)
            .NotEmpty().WithMessage("First name is required.");

        validator.RuleFor(x => x.LastName)
            .NotEmpty().WithMessage("Last name is required.");

        validator.RuleFor(x => x.FileNumber)
            .NotEmpty().WithMessage("File number is required.");

        return validator;
    }

    public static AbstractValidator<ShareFolderDto> ShareFolderValidator()
    {
        var validator = new InlineValidator<ShareFolderDto>();

        validator.RuleFor(x => x.FromEmail)
            .NotEmpty().WithMessage("Valid 'from' email is required.");

        validator.RuleFor(x => x.ToEmail)
            .NotEmpty().WithMessage("Valid 'to' email is required.");

        validator.RuleFor(x => x.ToName)
            .NotEmpty().WithMessage("Recipient name is required.");

        validator.RuleFor(x => x.Subject)
            .NotEmpty().WithMessage("Subject is required.");

        validator.RuleFor(x => x.LinkExpiration)
            .InclusiveBetween(1, 168)
            .WithMessage("Link expiration must be between 1 and 168 hours.");

        return validator;
    }

    public static AbstractValidator<OtpVerifyDto> OtpVerifyValidator()
    {
        var validator = new InlineValidator<OtpVerifyDto>();

        validator.RuleFor(x => x.Email)
            .NotEmpty().WithMessage("A valid email is required.")
            .EmailAddress().WithMessage("A valid email is required.");

        validator.RuleFor(x => x.Code)
            .NotEmpty().WithMessage("OTP code is required.")
            .Length(6).WithMessage("OTP code must be 6 digits.");

        return validator;
    }

    public static AbstractValidator<EmailDto> EmailValidator()
    {
        var validator = new InlineValidator<EmailDto>();

        validator.RuleFor(x => x.Email)
            .NotEmpty().WithMessage("A valid email is required.")
            .EmailAddress().WithMessage("A valid email is required.");

        return validator;
    }
    public static AbstractValidator<FileUploadDto> FileUploadValidator()
    {
        var validator = new InlineValidator<FileUploadDto>();

        validator.RuleFor(x => x.Files)
            .NotNull().WithMessage("File(s) must be provided.")
            .Must(files => files.Any()).WithMessage("At least one file must be uploaded.");

        return validator;
    }

    public static AbstractValidator<UpdateFileNameDto> RenameFileValidator()
    {
        var validator = new InlineValidator<UpdateFileNameDto>();

        validator.RuleFor(x => x.Id)
            .NotEmpty().WithMessage("FileId must be a positive number.");

        validator.RuleFor(x => x.Name)
            .NotEmpty().WithMessage("New file name is required.");

        return validator;
    }


}