using FluentValidation;
using Shared.Constant;
using User.Entities.ViewModels.SplitAndUpload;

namespace User.Api.Helper
{
    public class SplitAndUploadFileValidationRules
    {
        public static AbstractValidator<FileNameUpdateRequest> UpdateUploadedFileNameRules()
        {
            var validator = new InlineValidator<FileNameUpdateRequest>();

            validator.RuleFor(x => x.Id)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(FileNameUpdateRequest.Id)));

            validator.RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(FileNameUpdateRequest.Name)))
                .MaximumLength(50)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(FileNameUpdateRequest.Name), 50));

            return validator;
        }

        public static AbstractValidator<SplitPdfRequest> SplitPdfRequestRules()
        {
            var validator = new InlineValidator<SplitPdfRequest>();

            validator.RuleFor(x => x.OriginalFileName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SplitPdfRequest.OriginalFileName)))
                .MaximumLength(255)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(SplitPdfRequest.OriginalFileName), 255));

            validator.RuleFor(x => x.NewSplitPdfFileName)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SplitPdfRequest.NewSplitPdfFileName)))
                .MaximumLength(100)
                .WithMessage(Messages.Error.General.MaxLengthExceededMessage(nameof(SplitPdfRequest.NewSplitPdfFileName), 100));

            validator.RuleFor(x => x.FolderId)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SplitPdfRequest.FolderId)));

            validator.RuleFor(x => x.TabId)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SplitPdfRequest.TabId)));

            validator.RuleFor(x => x.SelectedPages)
                .NotEmpty()
                .WithMessage(Messages.Error.General.RequiredFieldMessage(nameof(SplitPdfRequest.SelectedPages)));

            return validator;
        }
    }
}