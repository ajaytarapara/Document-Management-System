using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Shared.ViewModels.Base;
using Shared.BaseController;
using static Shared.Constant.Enums;

namespace User.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : BaseController
    {
        #region Properties
        #endregion

        #region constructor
        public UserController()
        {

        }

        #endregion
        /// <summary>
        /// Retrieves the details of a specific organization by its unique identifier.
        /// </summary>
        /// <param name="id">The unique identifier (GUID) of the organization.</param>
        /// <returns>A success response containing the organization details.</returns>
        [HttpGet("{id}")]
        public async Task<BaseResponse> GetById(int id)
        {
            return ApiSuccess(ResponseStatusCode.Ok, "HELLO user");
        }
      
    }
}