using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.Constant;
using Shared.ViewModels.Base;
using User.Entities.ViewModels.DmsForms;
using static Shared.Constant.Enums;
using Shared.BaseController;
using Shared.Helper;
using User.Api.Helper;
using User.Services.DmsFormService;
using CoreServices.HttpClients;
using Shared.ViewModels.DmsForms;
using System.Text.Json;
using Shared.ConfigItems;

namespace User.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class UserDmsFormsController : BaseController
    {

        #region Properties
        private readonly IDmsFormService _dmsFormService;
        private readonly IHttpClientService _httpClientService;

        #endregion

        #region Constructor
        public UserDmsFormsController(IDmsFormService dmsFormService, IHttpClientService httpClientService)
        {
            _dmsFormService = dmsFormService;
            _httpClientService = httpClientService;
        }

        #endregion

        #region Endpoints

        /// <summary>
        /// Upload one or more DMS forms for a specific user.
        /// </summary>
        /// <param name="model">The upload model containing files and user ID.</param>
        /// <returns>A success message with result metadata.</returns>
        [HttpPost("upload")]
        public async Task<BaseResponse?> UploadDmsForms([FromBody] UploadDmsFormsVM model)
        {
            if (!int.TryParse(HttpContext?.User.FindFirst("userId")?.Value, out int createdBy))
                return ApiSuccess(ResponseStatusCode.BadRequest, Messages.Error.Validation.InvalidUser);

            string result = await _dmsFormService.AddDmsForm(model, model.UserId, createdBy);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileUploadSuccessMessage);
        }

        /// <summary>
        /// Get a paginated list of all uploaded DMS forms for a user.
        /// </summary>
        /// <param name="request">Pagination and filter data.</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPost("all")]
        public async Task<BaseResponse> GetAllDMSForms([FromBody] PaginationRequestVM request, [FromQuery] int userId)
        {
            string baseUrl = $"{Request.Scheme}://{Request.Host}";
            PaginationResponseVM<DMSFormFileVM> result = await _dmsFormService.GetAllDmsFormsAsync(request, userId, baseUrl);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }

        /// <summary>
        /// Rename a previously uploaded DMS form.
        /// </summary>
        /// <param name="model">Rename details (ID and new name).</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPut("rename")]
        public async Task<BaseResponse> RenameFile([FromBody] RenameFileVM model, [FromQuery] int userId)
        {
            bool result = await _dmsFormService.RenameDmsFormFileAsync(model.DmsFormId, model.NewFileName, userId);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileUpdateSuccessMessage);
        }

        /// <summary>
        /// Delete an uploaded DMS form after validation.
        /// </summary>
        /// <param name="request">Delete request containing ID and password.</param>
        [HttpPost("delete")]
        public async Task<BaseResponse> DeleteFile([FromBody] DeleteFileRequest request)
        {
            bool result = await _dmsFormService.DeleteDmsFormFileAsync(request);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.FileDeleteSuccessMessage);
        }

        /// <summary>
        /// Get a DMS form's details by its ID.
        /// </summary>
        /// <param name="id">Form ID.</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPost("getByFormId")]
        public async Task<BaseResponse> GetFileByFormId([FromBody] GetFormRequest getFormRequest)
        {
            DMSFormFileVM result = await _dmsFormService.GetDmsFormByIdAsync(getFormRequest.FormId, getFormRequest.UserId);
            return ApiSuccess(ResponseStatusCode.Ok, result);
        }

        /// <summary>
        /// Shares one or more DMS forms with specified recipients.
        /// </summary>
        /// <param name="dmsFormVM">
        /// The share request model containing the form IDs, recipient details,
        /// message content, and link expiration settings.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the result of the share operation,
        /// along with the original share request data if successful.
        /// </returns>
        [HttpPatch("share-userdmsforms")]
        public async Task<BaseResponse> ShareDmsForms([FromBody] ShareDmsFormVM dmsFormVM)
        {
            Validator.ValidateAndThrow(dmsFormVM, DmsFormShareValidationRules.ShareDmsFormValidator());
            int userId = int.Parse(HttpContext?.User.FindFirst("userId")?.Value);
            await _dmsFormService.ShareDmsFormAsync(dmsFormVM, userId);
            return ApiSuccess(ResponseStatusCode.Ok, dmsFormVM, Messages.Success.DMSForm.DmsFormSharedSuccessMessage);
        }

        /// <summary>
        /// Submit an edited DMS form.
        /// </summary>
        /// <param name="model">The request model containing form data, fields, and file information.</param>
        /// <returns>A response indicating whether the submission was successful.</returns>
        [HttpPost("submit-edited")]
        public async Task<BaseResponse> SubmitEditedForm([FromBody] SubmittedDmsFromRequest model)
        {
            model.FilePath = GetUserFolderPath();
            model.IsUser = true;
            BaseResponse result = await _httpClientService.PostAsync<SubmittedDmsFromRequest, BaseResponse>(ConfigItems.AdminServiceBaseUrl + AppConstants.ApiEndpoints.SubmitEditedFromEndpoint, model, model.Token);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.DmsFormSubmitSuccessMessage);
        }

        /// <summary>
        /// Saves the edited version of a DMS form with updated field values or metadata.
        /// </summary>
        /// <param name="model">
        /// The request model containing the edited form data, including form ID,
        /// updated fields, and any additional metadata required for saving.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the result of the save operation,
        /// including a success flag if the form was updated successfully.
        /// </returns>
        [HttpPost("save-edited")]
        public async Task<BaseResponse> SaveEditedForm([FromBody] SaveEditedFormVM model)
        {
            model.FilePath = GetUserFolderPath();
            model.IsUser = true;
            BaseResponse result = await _httpClientService.PostAsync<SaveEditedFormVM, BaseResponse>(ConfigItems.AdminServiceBaseUrl + AppConstants.ApiEndpoints.SaveEditedFormsEndpoint, model, model.Token);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.DMSForm.DmsFormUpdateSuccessMessage);
        }

        /// <summary>
        /// Get a paginated list of all submitted DMS forms for a user.
        /// </summary>
        /// <param name="request">Pagination and filter data.</param>
        /// <param name="userId">Target user's ID.</param>
        [HttpPost("submitted/all")]
        public async Task<BaseResponse> GetAllSubmittedDmsForms([FromBody] PaginationRequestVM request, [FromQuery] int userId)
        {
            string encryptedUserId = AesEncryptionHelper.EncryptId(userId);

            string url = ConfigItems.AdminServiceBaseUrl + AppConstants.ApiEndpoints.GetAllSubmittedFormsEndpoint + encryptedUserId;

            EncryptedResponse baseResult = await _httpClientService.PostAsync<PaginationRequestVM, EncryptedResponse>(url, request, request.Token);

            string decryptedJson = AesEncryptionHelper.Decrypt(baseResult.Data);

            HttpBaseResponse<PaginationResponseVM<DMSFormFileVM>> res = JsonSerializer.Deserialize<HttpBaseResponse<PaginationResponseVM<DMSFormFileVM>>>(decryptedJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new HttpBaseResponse<PaginationResponseVM<DMSFormFileVM>>();

            return ApiSuccess(ResponseStatusCode.Ok, res.data, Messages.Success.DMSForm.DmsFormUpdateSuccessMessage);
        }

        #endregion

        #region Private Helper Methods

        private string GetUserFolderPath()
        {
            return Path.Combine(Directory.GetCurrentDirectory(), AppConstants.Constants.RootPath, AppConstants.Constants.DmsFolderPath);
        }

        #endregion
    }
}