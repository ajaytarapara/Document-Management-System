using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.ViewModels.Base;
using User.Entities.ViewModels.BatchShare;
using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;
using User.Services.UserServices;
using static Shared.Constant.Enums;

namespace User.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class BatchShareController(IBatchShareService batchShareService) : BaseController
    {
        #region Properties
        private readonly IBatchShareService _batchShareService = batchShareService;
        #endregion

        #region Constructor
        #endregion

        #region Methods

        /// <summary>
        /// Retrieves a list of all available folders.
        /// </summary>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="FolderListResponse"/> objects 
        /// and a success status.
        /// </returns>
        [HttpGet("get-folder-list")]
        public async Task<BaseResponse> GetFolderList()
        {
            List<FolderListResponse> result = await _batchShareService.GetFolderList();
            return ApiSuccess(ResponseStatusCode.Ok, result, "");
        }

        /// <summary>
        /// Retrieves a list of all available file.
        /// </summary>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="PaginatedResponse<BatchShareTabAndFileResponse>"/> objects 
        /// and a success status.
        /// </returns>
        [HttpPost("get-file-tabid")]
        public async Task<BaseResponse> GetFileByTabId([FromBody] BatchShareTabAndFileRequest batchShareTabAndFileRequest)
        {
            PaginatedResponse<BatchShareTabAndFileResponse> result = await _batchShareService.GetFileByTabId(batchShareTabAndFileRequest);
            return ApiSuccess(ResponseStatusCode.Ok, result, "");
        }

        /// <summary>
        /// Retrieves the list of tabs associated with a specific folder.
        /// </summary>
        /// <param name="folderId">
        /// The unique identifier of the folder for which to fetch the tab list.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="TabListResponse"/> objects 
        /// and a success status.
        /// </returns>
        [HttpGet("get-tab-list/{folderId}")]
        public async Task<BaseResponse> GetTabList(int folderId)
        {
            List<TabListResponse> result = await _batchShareService.GetTabList(folderId);
            return ApiSuccess(ResponseStatusCode.Ok, result, "");
        }

        /// <summary>
        /// Shares multiple files by sending an email with a secure access link.
        /// </summary>
        [HttpPost("share-files")]
        public async Task<BaseResponse> ShareBatchShareFiles([FromBody] BatchShareMultipleFileShareRequest request)
        {
            await _batchShareService.ShareBatchShareFiles(request);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.shareFileMail);
        }
        #endregion
    }
}