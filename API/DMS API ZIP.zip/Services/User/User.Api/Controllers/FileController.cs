using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.ExceptionHandler;
using Shared.ViewModels.Base;
using User.Services.UserServices;
using static Shared.Constant.Enums;


namespace User.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FileController : BaseController
    {

        private readonly IFileService _fileService;
        private readonly IWebHostEnvironment _environment;
        private readonly IWebHostEnvironment _env;

        public FileController(IFileService fileService, IWebHostEnvironment environment, IWebHostEnvironment env)
        {
            _fileService = fileService;
            _environment = environment;
            _env = env;
        }
        /// <summary>
        /// <summary>
        /// Uploads one or multiple files to a folder/tab for the authenticated user.
        /// </summary>
        /// <param name="dto">File upload details including folder ID, tab ID, and base64 encoded files.</param>
        /// <returns>Response with success or validation errors.</returns>
        [HttpPost("upload")]
        public async Task<BaseResponse> UploadFile([FromBody] FileUploadDto dto)
        {
            // Validate input DTO
            var validator = Validators.FileUploadValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            // Ensure at least one file is uploaded
            if (dto.Files == null || !dto.Files.Any())
                throw new KeyNotFoundException("No files uploaded.");

            // File storage path
            string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", "pdf");

            // Extract user ID from JWT claims
            string userId = HttpContext.User.FindFirst("userId")?.Value;

            // Delegate to service
            var duplicate = await _fileService.UploadFileAsync(dto, int.Parse(userId), uploadsFolder);
            return ApiSuccess(ResponseStatusCode.Ok, duplicate, Messages.Success.SplitAndUploadFile.uploadFile);
        }

        /// <summary>
        /// Renames an existing file.
        /// </summary>
        /// <param name="dto">New file name and file ID.</param>
        [HttpPut("rename")]
        public async Task<BaseResponse> RenameFile([FromBody] UpdateFileNameDto dto)
        {
            var validator = Validators.RenameFileValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            string userId = HttpContext.User.FindFirst("userId")?.Value;
            await _fileService.UpdateFileNameAsync(dto, int.Parse(userId));

            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.editFile);
        }

        /// <summary>
        /// Moves one or more files to a different folder/tab.
        /// </summary>
        [HttpPost("move")]
        public async Task<BaseResponse> MoveFile([FromBody] MoveFileDto dto)
        {
            var userId = HttpContext.User.FindFirst("userId")?.Value;
            await _fileService.MoveFileAsync(dto, int.Parse(userId));
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.moveFile);
        }

        /// <summary>
        /// Changes a file's tab within the same folder.
        /// </summary>
        [HttpPost("changeTab")]
        public async Task<BaseResponse> ChangeTab([FromBody] MoveFiletabDto dto)
        {
            var userId = HttpContext.User.FindFirst("userId")?.Value;
            await _fileService.ChangeTabAsync(dto, int.Parse(userId));
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.tabChange);
        }


        /// <summary>
        /// Retrieves all tabs for a specific folder (alternative endpoint for tab list).
        /// </summary>
        [HttpGet("folder-tabList/{folderId}")]
        public async Task<BaseResponse> GetFolderTabList(int folderId)
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;
            int userId = 0;
            if (!string.IsNullOrEmpty(userIdClaim))
            {
                int.TryParse(userIdClaim, out userId);
            }
            var result = await _fileService.GetTabsByFolderIdAsync(folderId, userId);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.SplitAndUploadFile.getSucessTabs);
        }

        /// <summary>
        /// Retrieves paginated files within a specific folder tab.
        /// </summary>
        [HttpGet("folder-tab-files/{tabId}")]
        public async Task<BaseResponse> GetFilesByTab(
            int tabId,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string sortDirection = "asc",
            [FromQuery] string sortColumn = "Id",
            [FromQuery] string searchTerm = "")
        {
            var result = await _fileService.GetFilesByTabPaginatedAsync(tabId, page, pageSize, sortDirection, sortColumn, searchTerm);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.SplitAndUploadFile.getSucessFile);
        }

        /// <summary>
        /// Deletes a file (marks it as deleted in DB and removes from physical storage).
        /// </summary>
        [HttpDelete("{fileId}")]
        public async Task<BaseResponse> DeleteFile(int fileId)
        {
            string url = await _fileService.delteFile(fileId);
            var rootPath = _env.WebRootPath;
            var filePath = Path.Combine(rootPath, url);

            // Delete from storage if it still exists
            if (System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
            }

            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.deleteFile);
        }

        /// <summary>
        /// Shares a file by sending an email with a secure access link.
        /// </summary>
        [HttpPatch("share/{fileId}")]
        public async Task<BaseResponse> ShareFile(int fileId, [FromBody] ShareFolderDto dto)
        {
            var validator = Validators.ShareFolderValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            await _fileService.ShareFileAsync(fileId, dto);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.shareFileMail);
        }

        /// <summary>
        /// Shares multiple files by sending an email with a secure access link.
        /// </summary>
        [HttpPost("share-multiple-file")]
        public async Task<BaseResponse> ShareMultipleFile(MultipleFileDto files)
        {
            await _fileService.ShareMultipleFileAsync(files);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.shareFileMail);
        }
        [HttpPost("get-files")]
        public async Task<BaseResponse> ShareMultipleFile(MultipleFilesVM files, [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10,
            [FromQuery] string sortDirection = "asc",
            [FromQuery] string sortColumn = "Id",
            [FromQuery] string searchTerm = "")
        {
            var result = await _fileService.GetFilesByIds(files, page, pageSize, sortDirection, sortColumn, searchTerm);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.SplitAndUploadFile.shareFileMail);
        }
    }
}