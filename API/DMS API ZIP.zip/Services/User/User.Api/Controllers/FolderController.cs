
using Microsoft.AspNetCore.Mvc;
using Shared.ViewModels.Base;
using Shared.BaseController;
using static Shared.Constant.Enums;
using User.Services.UserServices;
using Shared.Constant;
using Shared.ExceptionHandler;
using User.Entities.ViewModels.Pagination;

namespace User.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FolderController : BaseController
    {
        #region Propertiesa
        #endregion
        private readonly IFolderService _folderService;
        private readonly IWebHostEnvironment _env;
        #region constructor
        public FolderController(IFolderService folderService, IWebHostEnvironment env)
        {
            _folderService = folderService;
            _env = env;
        }

        #endregion
        /// <summary>
        /// Creates a new folder along with its default tabs for the logged-in user.
        /// </summary>
        /// <param name="folderDto">Folder details including name and optional tab definitions.</param>
        [HttpPost("create")]
        public async Task<BaseResponse> CreateFolderWithTabs([FromBody] CreateFolderDto folderDto)
        {
            var validator = Validators.CreateFolderValidator();
            var result = validator.Validate(folderDto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;

            await _folderService.CreateFolderWithTabsAsync(folderDto, int.Parse(userIdClaim));

            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Folder.FolderCreate);
        }

        /// <summary>
        /// Retrieves paginated folders for the logged-in user.
        /// </summary>
        [HttpPost("user")]
        public async Task<BaseResponse> GetFoldersByUserId(PaginatedRequest paginatedRequest)
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;

            var result = await _folderService.GetFoldersByUserIdAsync(
                int.Parse(userIdClaim),
                paginatedRequest.PageNumber,
                paginatedRequest.PageSize,
                paginatedRequest.SortDirection,
                paginatedRequest.SortBy,
                paginatedRequest.SearchTerm);

            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Folder.getSucess);
        }

        /// <summary>
        /// Retrieves all folders for the logged-in user (non-paginated).
        /// </summary>
        [HttpGet("getFolderList")]
        public async Task<BaseResponse> GetFoldersByUserId()
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;

            var result = await _folderService.getFolderList(int.Parse(userIdClaim));

            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Folder.getSucess);
        }

        /// <summary>
        /// Retrieves a folder by its unique ID.
        /// </summary>
        [HttpGet("{folderId}")]
        public async Task<IActionResult> GetFolderById(int folderId)
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;
            var folder = await _folderService.GetFolderByIdAsync(folderId, int.Parse(userIdClaim));
            if (folder == null)
            {
                return NotFound();
            }

            return Ok(folder);
        }
        [HttpDelete("{folderId}")]
        public async Task<BaseResponse> SoftDeleteFolder(int folderId)
        {
            var rootPath = _env.WebRootPath;
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;
            var result = await _folderService.SoftDeleteFolderAsync(folderId, int.Parse(userIdClaim), rootPath);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Folder.deleteSucess);
        }
        [HttpPut("update/{folderId}")]
        public async Task<BaseResponse> UpdateFolder([FromBody] UpdateFolderDto dto, int folderId)
        {
            var validator = Validators.UpdateFolderValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;
            var updatedFolder = await _folderService.UpdateFolderAsync(dto, int.Parse(userIdClaim), folderId);
            return ApiSuccess(ResponseStatusCode.Ok, updatedFolder, Messages.Success.Folder.updateSucess);
        }

        /// <summary>
        /// Shares a folder with specified users by sending them an email invite.
        /// </summary>
        [HttpPatch("share/{folderId}")]
        public async Task<IActionResult> ShareFolder([FromBody] ShareFolderDto dto, int folderId)
        {
            var validator = Validators.ShareFolderValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            await _folderService.ShareFolderAsync(folderId, dto);

            return Ok(new { message = "Share emails sent." });
        }
        /// <summary>
        /// Get files of particular folder
        /// </summary>
        [HttpGet("download/{folderId}")]
        public async Task<BaseResponse> DownloadFolder(int folderId)
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;
            var result = await _folderService.DownloadFolderAsync(folderId, int.Parse(userIdClaim));

            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.Folder.updateSucess);
        }

        /// <summary>
        /// Sends an OTP to the provided email for verification before sharing a folder.
        /// </summary>
        [HttpPost("verify/request-otp")]
        public async Task<IActionResult> RequestOtp([FromBody] EmailDto dto)
        {
            var validator = Validators.EmailValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            await _folderService.RequestOTP(dto);

            return Ok();
        }

        /// <summary>
        /// Verifies an OTP provided by the user for folder sharing.
        /// </summary>
        [HttpPost("verify/otp")]
        public async Task<IActionResult> VerifyOtp([FromBody] OtpVerifyDto dto)
        {
            var validator = Validators.OtpVerifyValidator();
            var result = validator.Validate(dto);
            if (!result.IsValid)
                throw new DataValidationException(result.Errors);

            await _folderService.VerifyOTP(dto);

            return Ok(new { verified = true });
        }

        /// <summary>
        /// Retrieves the maximum allowed number of tabs for the logged-in user's folders.
        /// </summary>
        [HttpGet("getTabLimit")]
        public async Task<IActionResult> GetTab()
        {
            var userIdClaim = HttpContext.User.FindFirst("userId")?.Value;

            int id = await _folderService.GetMaxTabLimitAsync(int.Parse(userIdClaim));

            return Ok(new { maxTabLimit = id });
        }
    }
}