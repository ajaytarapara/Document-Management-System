using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.Helper;
using Shared.ViewModels.Base;
using User.Api.Helper;
using User.Entities.ViewModels.Pagination;
using User.Entities.ViewModels.SplitAndUpload;
using User.Services.UserServices;
using static Shared.Constant.Enums;

namespace User.Api.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class SplitAndUploadFileController(ISplitAndUploadFileService splitAndUploadFileService, IWebHostEnvironment webHostEnvironment) : BaseController
    {
        #region Properties
        private readonly ISplitAndUploadFileService _splitAndUploadFileService = splitAndUploadFileService;
        private readonly IWebHostEnvironment _webHostEnvironment = webHostEnvironment;
        #endregion

        #region constructor
        #endregion

        /// <summary>
        /// Handles uploading files for splitting and categorizes them into subfolders based on file type.
        /// </summary>
        /// <param name="fileUploadRequest">
        /// The request payload containing the list of files to upload.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating success and containing a confirmation message.
        /// </returns>
        [HttpPost("upload-file-for-split")]
        public async Task<BaseResponse> UploadFilesForSplit([FromBody] FileUploadRequest fileUploadRequest)
        {
            string subFolder = string.Empty;

            var firstFile = fileUploadRequest.Files.FirstOrDefault();
            if (firstFile != null && !string.IsNullOrEmpty(firstFile.Name))
            {
                string extension = Path.GetExtension(firstFile.Name).ToLower();

                if (extension == ".pdf")
                    subFolder = "pdf";
            }
            string fileUploadDirectory = Path.Combine(_webHostEnvironment.WebRootPath, "splitandupload", subFolder);
            await _splitAndUploadFileService.UploadFilesForSplit(fileUploadRequest, fileUploadDirectory);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.FileUploadSuccess); ;
        }

        /// <summary>
        /// Retrieves a paginated list of uploaded files for splitting.
        /// </summary>
        /// <param name="paginatedRequest">
        /// The pagination and sorting parameters provided via query string.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a paginated list of 
        /// <see cref="FileUploadResponseForSplitVM"/> objects and a success message.
        /// </returns>
        [HttpPost("get-all-uploadedfile-for-split")]
        public async Task<BaseResponse> GetUploadedFiles([FromBody] PaginatedRequest paginatedRequest)
        {
            PaginatedResponse<FileUploadResponseForSplitVM> result = await _splitAndUploadFileService.GetUploadedFiles(paginatedRequest);
            return ApiSuccess(ResponseStatusCode.Ok, result, Messages.Success.SplitAndUploadFile.FileUploadListSuccess);
        }

        /// <summary>
        /// Deletes an uploaded file by its unique identifier.
        /// </summary>
        /// <param name="id">
        /// The ID of the uploaded file to be deleted.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating success and containing 
        /// a success message when the file is removed.
        /// </returns>
        [HttpDelete("delete-uploaded-file/{deleteId}")]
        public async Task<BaseResponse> DeleteUploadedFile(int deleteId)
        {
            await _splitAndUploadFileService.DeleteUploadedFile(deleteId);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.FileRemoveSuccess);
        }

        /// <summary>
        /// Updates the name of an uploaded file.
        /// </summary>
        /// <param name="request">
        /// The request payload containing the file ID and the new file name.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating success and containing 
        /// a confirmation message upon successful update.
        /// </returns>
        [HttpPut("update-uploaded-file")]
        public async Task<BaseResponse> UpdateUploadedFileName([FromBody] FileNameUpdateRequest request)
        {
            Validator.ValidateAndThrow(request, SplitAndUploadFileValidationRules.UpdateUploadedFileNameRules());
            await _splitAndUploadFileService.UpdateUploadedFileName(request);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.FileUpdateSuccess);
        }

        /// <summary>
        /// Retrieves a list of all available folders.
        /// </summary>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="FolderListResponse"/> objects 
        /// and a success status.
        /// </returns>
        [HttpGet("get-folder-list")]
        public async Task<BaseResponse> GetFolderList()
        {
            List<FolderListResponse> result = await _splitAndUploadFileService.GetFolderList();
            return ApiSuccess(ResponseStatusCode.Ok, result, "");
        }

        /// <summary>
        /// Retrieves the list of tabs associated with a specific folder.
        /// </summary>
        /// <param name="folderId">
        /// The unique identifier of the folder for which to fetch the tab list.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing a list of <see cref="TabListResponse"/> objects 
        /// and a success status.
        /// </returns>
        [HttpGet("get-tab-list/{folderId}")]
        public async Task<BaseResponse> GetTabList(int folderId)
        {
            List<TabListResponse> result = await _splitAndUploadFileService.GetTabList(folderId);
            return ApiSuccess(ResponseStatusCode.Ok, result, "");
        }

        /// <summary>
        /// Splits a PDF file into multiple parts and replaces the original file with the result.
        /// </summary>
        /// <param name="splitPdfRequest">
        /// The request payload containing details such as the file ID, page ranges, and target folder.
        /// </param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating success and containing a confirmation message 
        /// when the split-and-replace operation completes successfully.
        /// </returns>
        [HttpPost("split-and-replace")]
        public async Task<BaseResponse> SplitAndReplace([FromBody] SplitPdfRequest splitPdfRequest)
        {
            Validator.ValidateAndThrow(splitPdfRequest, SplitAndUploadFileValidationRules.SplitPdfRequestRules());
            await _splitAndUploadFileService.SplitAndReplace(splitPdfRequest);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.SplitAndUploadFile.SplitAndReplaceSuccess);
        }
    }
}