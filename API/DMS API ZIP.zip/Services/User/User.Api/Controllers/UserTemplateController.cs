using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Shared.BaseController;
using Shared.Constant;
using Shared.ViewModels.Base;
using User.Entities.ViewModels;
using User.Services.UserServices;
using static Shared.Constant.Enums;

namespace User.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserTemplateController(IUserTemplateService userTemplateService) : BaseController
    {
        #region Properties
        private readonly IUserTemplateService _userTemplateService = userTemplateService;
        #endregion

        #region constructor
        #endregion

        #region Methods

        /// <summary>
        /// Retrieves all user templates.
        /// </summary>
        /// <returns>A list of user templates wrapped in a BaseResponse.</returns>
        [HttpGet]
        public async Task<BaseResponse> GetUserTemplate()
        {
            IEnumerable<UserTemplateResponseVM> userTemps = await _userTemplateService.GetUserTemplate();
            return ApiSuccess(ResponseStatusCode.Ok, userTemps, Messages.Success.General.Success);
        }

        /// <summary>
        /// Retrieves all tabs associated with a specific user template.
        /// </summary>
        /// <param name="id">The ID of the user template.</param>
        /// <returns>A list of template tabs wrapped in a BaseResponse.</returns>
        [HttpGet("template-tabs/{templateId}")]
        public async Task<BaseResponse> GetTemplateTabs(int templateId)
        {
            IEnumerable<TemplateTabResponseVM> userTempTabs = await _userTemplateService.GetTemplateTabs(templateId);
            return ApiSuccess(ResponseStatusCode.Ok, userTempTabs, Messages.Success.General.Success);
        }

        /// <summary>
        /// Adds new tabs to a user template.
        /// </summary>
        /// <param name="addTabs">The tab data to be added to the template.</param>
        /// <returns>A BaseResponse indicating the result of the operation.</returns>
        [HttpPost("add-tabs-template")]
        public async Task<BaseResponse> AddTemplateTab(AddTemplateTabRequestVM addTabs)
        {
            await _userTemplateService.AddTemplateTabs(addTabs);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Folder.TemplateTabSuccess);
        }

        /// <summary>
        /// Retrieves a list of folders for a given template where new tabs can be added,
        /// based on the user's maximum allowed tab limit.
        /// </summary>
        /// <param name="templateId">The ID of the template to fetch folders from.</param>
        /// <param name="newTabCount">The number of new tabs intended to be added.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> containing the list of folders where new tabs can be added,
        /// or an appropriate success message if no eligible folders are found.
        /// </returns>
        [Authorize]
        [HttpGet("folder/{templateId}/{newTabCount}")]
        public async Task<BaseResponse> GetFolderByTemplate(int templateId, int newTabCount)
        {
            IEnumerable<FolderListResponseVM> folders = await _userTemplateService.GetFolderListByTemplate(templateId, newTabCount);
            return ApiSuccess(ResponseStatusCode.Ok, folders, Messages.Success.Folder.FolderFetchedSuccess);
        }

        /// <summary>
        /// Adds one or more folder tabs to the specified folders using the provided template tabs.
        /// </summary>
        /// <param name="applyFolderTabRequestVM">The request object containing selected folder IDs and template tab definitions.</param>
        /// <returns>
        /// A <see cref="BaseResponse"/> indicating the result of the operation.
        /// </returns>
        /// <remarks>
        /// This endpoint is authorized and requires a valid user token.
        /// It delegates the business logic to the _userTemplateService.ApplyFolderTab method,
        /// which handles inserting multiple FolderTab records into the database.
        /// </remarks>
        [Authorize]
        [HttpPost("add-folder-tabs")]
        public async Task<BaseResponse> AddFolderByTemplateTabs(ApplyFolderTabRequestVM applyFolderTabRequestVM)
        {
            await _userTemplateService.ApplyFolderTab(applyFolderTabRequestVM);
            return ApiSuccess(ResponseStatusCode.Ok, null, Messages.Success.Folder.AddedTabSuccess);
        }

        /// <summary>
        /// Retrieves the list of user templates that are available for adding new tabs.
        /// </summary>
        /// <remarks>
        /// This endpoint fetches templates that are eligible for adding additional tabs, 
        /// typically those not exceeding the tab limit or already fully configured.
        /// </remarks>
        /// <returns>A successful response containing a list of available user templates.</returns>
        [HttpGet("available-tabs")]
        public async Task<BaseResponse> GetUserTemplateAvailableToAddTabs()
        {
            IEnumerable<UserTemplateResponseVM> userTemps = await _userTemplateService.GetUserTemplateAvailableToAdd();
            return ApiSuccess(ResponseStatusCode.Ok, userTemps, Messages.Success.General.Success);
        }

        #endregion
    }
}