using User.Services.Mapper;
using ProgramExtensions.Extensions;
using Shared.ConfigItems;
using Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using Shared.Helper;

var builder = WebApplication.CreateBuilder(args);

//set configuration
ConfigItems.Configuration = builder.Configuration;
builder.Configuration.AddAppConfiguration(builder.Environment).AddAesConfiguration();


// Logging
builder.Logging.ClearProviders();

// Register services
builder.Services
    .AddAppServices<ApplicationDBContext>(builder.Configuration)
    .AddAppLocalization()
    .AddAppSwagger("User")
    .AddAppAuthentication()
    .AddAppControllers()
    .RegisterServices(["User.Services", "User.Entities"]);

// register the auto mapper profile
builder.Services.AddHttpContextAccessor();
builder.Services.AddAutoMapper(typeof(AutoMapperProfile));
builder.Services.AddScoped<IEmailSender, SmtpEmailSender>();
// Configure ApplicationDBContext
builder.Services.AddDbContext<ApplicationDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();
app.UseCors("AllowAll");
// Middleware pipeline
app.UseAppPipeline();

app.Run();
