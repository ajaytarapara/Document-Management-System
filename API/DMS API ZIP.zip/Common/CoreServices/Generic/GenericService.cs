﻿using Infrastructure.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Shared.ViewModels.Base;
using System.Linq.Expressions;

namespace CoreServices.Generic
{
    /// <summary>
    /// GenericService
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="TContext"></param>
    [TransientDependency(ServiceType = typeof(IGenericService<,>))]
    public class GenericService<T, TContext> : IGenericService<T, TContext>
    where T : class
    where TContext : DbContext
    {
        protected readonly TContext _dbContext;
        protected readonly DbSet<T> _dbSet;

        public GenericService(TContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _dbSet = _dbContext.Set<T>();
        }

        /// <summary>
        /// Get all data from table.
        /// </summary>
        /// <returns>Returns all data from table.</returns>
        public async Task<IList<T>> GetAllAsync(Expression<Func<T, bool>>? expression = null, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _dbContext.Set<T>().AsQueryable();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            if (expression != null)
                query = query.Where(expression);

            return await query.ToListAsync();
        }

        /// <summary>
        /// Get data based on condition.
        /// </summary>
        /// <param name="expression">Linq condition</param>
        /// <param name="includes">Navigation properties to include</param>
        /// <returns>Returns conditional data from table.</returns>
        public async Task<T?> GetAsync(Expression<Func<T, bool>> expression, params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _dbContext.Set<T>();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            return await query.FirstOrDefaultAsync(expression);
        }

        /// <summary>
        /// Insert new record in table.
        /// </summary>
        /// <param name="entity"></param>
        public async Task<T> InsertAsync(T entity)
        {
            // Attempt to add and save the entity
            var response = await _dbContext.Set<T>().AddAsync(entity);
            await _dbContext.SaveChangesAsync();
            return response.Entity;
        }

        /// <summary>
        /// Insert new records in table.
        /// </summary>
        /// <param name="entity"></param>
        public async Task<IEnumerable<T>> InsertManyAsync(IEnumerable<T> entity)
        {
            await _dbContext.Set<T>().AddRangeAsync(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        /// <summary>
        /// Update record in table.
        /// </summary>
        /// <param name="entity"></param>
        public async Task<T> UpdateAsync(T entity)
        {
            _dbContext.Set<T>().Update(entity);
            await _dbContext.SaveChangesAsync();
            return entity;
        }

        /// <summary>
        /// Update multiple record in table.
        /// </summary>
        /// <param name="entities"></param>
        public virtual async Task<IEnumerable<T>> UpdateManyAsync(IEnumerable<T> entities)
        {
            entities.ToList().ForEach(entity => _dbContext.Entry(entity).State = EntityState.Modified);
            await _dbContext.SaveChangesAsync();
            return entities;
        }

        /// <summary>
        /// Delete record in table.
        /// </summary>
        /// <param name="entity"></param>
        public async Task DeleteAsync(T entity)
        {
            _dbContext.Set<T>().Remove(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteManyAsync(Expression<Func<T, bool>> predicate)
        {
            var entities = await _dbContext.Set<T>().Where(predicate).ToListAsync();
            _dbContext.Set<T>().RemoveRange(entities);
            await _dbContext.SaveChangesAsync();
        }


        /// <summary>
        /// Delete multiple records in table.
        /// </summary>
        /// <param name="entities"></param>
        public async Task DeleteAllAsync(IEnumerable<T> entities)
        {
            _dbContext.Set<T>().RemoveRange(entities);
            await _dbContext.SaveChangesAsync();
        }

        /// <summary>
        /// Get paginated response.
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="filter"></param>
        /// <param name="orderBy"></param>
        /// <param name="sortDirection"></param>
        /// <param name="sortColumn"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        public async Task<PaginationResponseVM<T>> GetAllAsyncPagination(
                                                int pageIndex = 1,
                                                int pageSize = 10,
                                                Expression<Func<T, bool>>? filter = null,
                                                Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
                                                string sortDirection = "asc",
                                                string sortColumn = "Id",
                                                params Expression<Func<T, object>>[] includes)
        {
            IQueryable<T> query = _dbContext.Set<T>();

            foreach (var include in includes)
            {
                query = query.Include(include);
            }

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (orderBy != null)
            {
                query = orderBy(query);
            }
            else
            {
                // Apply default sorting if orderBy is not provided
                query = sortDirection.Equals("desc", StringComparison.CurrentCultureIgnoreCase)
                    ? query.OrderByDescending(e => EF.Property<object>(e, sortColumn))
                    : query.OrderBy(e => EF.Property<object>(e, sortColumn));
            }

            int totalCount = await query.CountAsync();
            List<T> items = await query
                .Skip((pageIndex - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return new PaginationResponseVM<T>(items, totalCount, pageIndex, pageSize);
        }

        /// <summary>
        /// Checks if any records match the specified condition.
        /// </summary>
        /// <param name="expression"></param>
        /// <returns>return a boolean value indicating whether any records match the condition.</returns>
        public async Task<bool> AnyAsync(Expression<Func<T, bool>> expression)
        {
            return await _dbContext.Set<T>().AnyAsync(expression);
        }

        /// <summary>
        /// Get IDbContextTransaction context for transaction
        /// </summary>
        /// <returns></returns>
        public async Task<Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction> BeginTransaction() => await _dbContext.Database.BeginTransactionAsync();

        /// <summary>
        /// Get the count of records from the table.
        /// </summary>
        /// <param name="expression">Optional filter expression.</param>
        /// <returns>Returns the count of records.</returns>
        public async Task<int> CountAsync(Expression<Func<T, bool>>? expression = null)
        {
            IQueryable<T> query = _dbContext.Set<T>().AsQueryable();

            if (expression is null)
            {
                return await query.CountAsync();
            }
            return await query.CountAsync(expression);
        }

        public IQueryable<T> GetQueryable()
        {
            return _dbContext.Set<T>().AsQueryable();
        }

        public virtual async Task<IEnumerable<TT>> GetPaginatedAsync<TT>(
            int pageNumber,
            int pageSize,
            Expression<Func<T, TT>> select,
            Expression<Func<T, bool>> predicate,
            string sortBy = null,
            string sortDirection = "asc")
        {
            IQueryable<T> filteredQuery = _dbSet.Where(predicate);
            IQueryable<TT> projectedQuery = filteredQuery.Select(select);

            if (!string.IsNullOrWhiteSpace(sortBy))
            {
                projectedQuery = ApplyOrdering(projectedQuery, sortBy, sortDirection);
            }

            return await projectedQuery
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
        }

        private IQueryable<TT> ApplyOrdering<TT>(IQueryable<TT> source, string sortBy, string sortDirection)
        {
            var parameter = Expression.Parameter(typeof(TT), "x");
            var property = Expression.PropertyOrField(parameter, sortBy);
            var lambda = Expression.Lambda(property, parameter);

            string methodName = sortDirection.ToLower() == "desc" ? "OrderByDescending" : "OrderBy";

            var result = typeof(Queryable).GetMethods()
                .Where(m => m.Name == methodName && m.GetParameters().Length == 2)
                .Single()
                .MakeGenericMethod(typeof(TT), property.Type)
                .Invoke(null, new object[] { source, lambda });

            return (IQueryable<TT>)result;
        }

        public async Task<IEnumerable<TT>> GetAllAsync<TT>(Expression<Func<T, bool>> predicate, Expression<Func<T, TT>> select)
        {
            return await _dbSet.Where(predicate).Select(select).ToListAsync();
        }

        public virtual async Task<IEnumerable<T>> GetAllAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbSet.Where(predicate).ToListAsync();
        }
        public async Task<T> GetFirstOrDefaultAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbSet.FirstOrDefaultAsync(predicate);
        }

        public async Task<TT> GetFirstOrDefaultAsync<TT>(Expression<Func<T, bool>> predicate, Expression<Func<T, TT>> select)
        {
            return await _dbSet.Where(predicate).Select(select).FirstOrDefaultAsync();
        }
    }
}
