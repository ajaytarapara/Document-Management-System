﻿using Microsoft.EntityFrameworkCore;
using Shared.ViewModels.Base;
using System.Linq.Expressions;

namespace CoreServices.Generic
{
    public interface IGenericService<T, TContext> where T : class
                                                  where TContext : DbContext
    {
        Task<bool> AnyAsync(Expression<Func<T, bool>> expression);
        Task DeleteAllAsync(IEnumerable<T> entities);
        Task DeleteAsync(T entity);
        Task DeleteManyAsync(Expression<Func<T, bool>> predicate);
        Task<PaginationResponseVM<T>> GetAllAsyncPagination(int pageIndex = 1, int pageSize = 10, Expression<Func<T, bool>>? filter = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string sortDirection = "asc", string sortColumn = "Id", params Expression<Func<T, object>>[] includes);
        Task<T?> GetAsync(Expression<Func<T, bool>> expression, params Expression<Func<T, object>>[] includes);
        Task<T> InsertAsync(T entity);
        Task<IEnumerable<T>> InsertManyAsync(IEnumerable<T> entity);
        Task<T> UpdateAsync(T entity);
        Task<IEnumerable<T>> UpdateManyAsync(IEnumerable<T> entities);
        Task<IList<T>> GetAllAsync(Expression<Func<T, bool>>? expression = null, params Expression<Func<T, object>>[] includes);
        IQueryable<T> GetQueryable();
        Task<IEnumerable<TT>> GetPaginatedAsync<TT>(int pageNumber, int pageSize, Expression<Func<T, TT>> select, Expression<Func<T, bool>> predicate, string? sortBy, string? sortDirection);
        Task<int> CountAsync(Expression<Func<T, bool>>? expression = null);
        Task<IEnumerable<TT>> GetAllAsync<TT>(Expression<Func<T, bool>> predicate, Expression<Func<T, TT>> select);
        Task<IEnumerable<T>> GetAllAsync(Expression<Func<T, bool>> predicate);
        Task<T> GetFirstOrDefaultAsync(Expression<Func<T, bool>> predicate);
        Task<TT> GetFirstOrDefaultAsync<TT>(Expression<Func<T, bool>> predicate, Expression<Func<T, TT>> select);
    }
}
