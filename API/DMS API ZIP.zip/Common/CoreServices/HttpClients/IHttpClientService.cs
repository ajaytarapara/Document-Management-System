﻿namespace CoreServices.HttpClients
{
    public interface IHttpClientService
    {
        Task<TResponse> PostAsync<TRequest, TResponse>(string url, TRequest data, string? token);
    }
}
