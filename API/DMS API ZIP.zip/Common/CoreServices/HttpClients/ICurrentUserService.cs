using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreServices.HttpClients
{
    public interface ICurrentUserService
    {
        int GetUserId();
        int GetOriginalUserId();
    }
}