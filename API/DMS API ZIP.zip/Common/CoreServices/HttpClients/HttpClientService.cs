﻿using Infrastructure.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Shared.Constant;
using Shared.ExceptionHandler;
using System.Net.Http.Json;

namespace CoreServices.HttpClients
{
    /// <summary>
    /// Provides a wrapper around <see cref="HttpClient"/> for sending HTTP requests
    /// (GET, POST, PUT, DELETE) with common headers, error handling, and deserialization.
    /// </summary>
    [TransientDependency(ServiceType = typeof(IHttpClientService))]
    public class HttpClientService : IHttpClientService
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpClientService"/> class.
        /// </summary>
        /// <param name="httpClientFactory">Factory for creating <see cref="HttpClient"/> instances.</param>
        /// <param name="httpContextAccessor">Accessor to the current HTTP context.</param>
        public HttpClientService(IHttpClientFactory httpClientFactory, IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClientFactory.CreateClient(); // optionally pass name if using named client
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Sends a POST request with a JSON body and deserializes the response to the given type.
        /// </summary>
        /// <typeparam name="TRequest">The type of the request payload.</typeparam>
        /// <typeparam name="TResponse">The expected response type.</typeparam>
        /// <param name="url">The target URL.</param>
        /// <param name="data">The request body to send.</param>
        /// <param name="token">Optional Bearer token for authorization.</param>
        /// <returns>The deserialized response of type <typeparamref name="TResponse"/>.</returns>
        public async Task<TResponse> PostAsync<TRequest, TResponse>(string url, TRequest data, string? token = null)
        {
            RequestHeaders(token);
            var response = await _httpClient.PostAsJsonAsync(url, data);
            await HandleErrors(response, url);
            return await DeserializeResponse<TResponse>(response);
        }

        /// <summary>
        /// Sends a GET request and deserializes the response to the given type.
        /// </summary>
        /// <typeparam name="TResponse">The expected response type.</typeparam>
        /// <param name="url">The target URL.</param>
        /// <returns>The deserialized response of type <typeparamref name="TResponse"/>.</returns>
        public async Task<TResponse> GetAsync<TResponse>(string url)
        {
            RequestHeaders();
            var response = await _httpClient.GetAsync(url);
            await HandleErrors(response, url);
            return await DeserializeResponse<TResponse>(response);
        }

        /// <summary>
        /// Sends a PUT request with a JSON body and deserializes the response to the given type.
        /// </summary>
        /// <typeparam name="TRequest">The type of the request payload.</typeparam>
        /// <typeparam name="TResponse">The expected response type.</typeparam>
        /// <param name="url">The target URL.</param>
        /// <param name="data">The request body to send.</param>
        /// <returns>The deserialized response of type <typeparamref name="TResponse"/>.</returns>
        public async Task<TResponse> PutAsync<TRequest, TResponse>(string url, TRequest data)
        {
            RequestHeaders();
            var response = await _httpClient.PutAsJsonAsync(url, data);
            await HandleErrors(response, url);
            return await DeserializeResponse<TResponse>(response);
        }

        /// <summary>
        /// Sends a DELETE request to the given URL.
        /// </summary>
        /// <param name="url">The target URL.</param>
        public async Task DeleteAsync(string url)
        {
            RequestHeaders();
            var response = await _httpClient.DeleteAsync(url);
            await HandleErrors(response, url);
        }

        /// <summary>
        /// Ensures the response was successful; otherwise throws <see cref="HttpRequestFailedException"/>.
        /// </summary>
        /// <param name="response">The <see cref="HttpResponseMessage"/> to validate.</param>
        /// <param name="url">The URL used in the request (for error context).</param>
        private async Task HandleErrors(HttpResponseMessage response, string url)
        {
            if (!response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                throw new HttpRequestFailedException(
                    Messages.Error.General.HttpClientRequestFailedMessage(url, (int)response.StatusCode, response.ReasonPhrase ?? string.Empty),
                    response.StatusCode,
                    content
                );
            }
        }

        /// <summary>
        /// Deserializes the response content into the specified type.
        /// </summary>
        /// <typeparam name="T">The expected response type.</typeparam>
        /// <param name="response">The HTTP response message.</param>
        /// <returns>The deserialized object.</returns>
        /// <exception cref="InvalidOperationException">
        /// Thrown when the response content is empty or cannot be deserialized.
        /// </exception>
        private static async Task<T> DeserializeResponse<T>(HttpResponseMessage response)
        {
            // Handle empty responses or calls expecting "object"
            if (typeof(T) == typeof(object) || response.Content.Headers.ContentLength == 0)
            {
                return (T)(object)new(); // or return default;
            }

            var result = await response.Content.ReadFromJsonAsync<T>();
            if (result == null)
            {
                throw new InvalidOperationException("Response content is null or cannot be deserialized.");
            }

            return result;
        }

        /// <summary>
        /// Configures request headers, including Accept and optional Authorization headers.
        /// </summary>
        /// <param name="token">Optional Bearer token for authorization.</param>
        private void RequestHeaders(string? token = null)
        {
            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            if (!string.IsNullOrEmpty(token))
            {
                _httpClient.DefaultRequestHeaders.Authorization =
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            }
        }
    }
}
