
using System.Security.Claims;
using Infrastructure.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Shared.Constant;

namespace CoreServices.HttpClients
{
    [ScopedDependency(ServiceType = typeof(ICurrentUserService))]
    public class CurrentUserService : ICurrentUserService
    {

        #region fields
        private readonly IHttpContextAccessor _httpContextAccessor;
        #endregion fields

        #region constructor
        public CurrentUserService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        #endregion constructor

        #region methods

        /// <summary>
        /// Retrieves the current user's ID from the JWT claims.
        /// </summary>
        /// <returns>The user ID as an integer.</returns>
        /// <exception cref="UnauthorizedAccessException">
        /// Thrown when the user is not authenticated or the ID claim is missing.
        /// </exception>
        public int GetUserId()
        {
            // Attempt to find the user ID from the JWT claims
            var userIdClaim = _httpContextAccessor.HttpContext?.User?.FindFirst(AppConstants.Constants.UserId);

            if (userIdClaim == null)
                throw new UnauthorizedAccessException(Messages.Error.General.InvalidCredentialMessage);

            // Parse and return the user ID
            return int.Parse(userIdClaim.Value);
        }

         public int GetOriginalUserId()
        {
            // Attempt to find the user ID from the JWT claims
            var userIdClaim = _httpContextAccessor.HttpContext?.User?.FindFirst(AppConstants.Constants.OriginalUserId);

            if (userIdClaim == null)
                throw new UnauthorizedAccessException(Messages.Error.General.InvalidCredentialMessage);

            // Parse and return the user ID
            return int.Parse(userIdClaim.Value);
        }


        #endregion methods

        #region helperMethods
        #endregion helperMethods

    }
}
