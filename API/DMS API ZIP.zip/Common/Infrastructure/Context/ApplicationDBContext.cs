﻿using System;
using System.Collections.Generic;
using Infrastructure.Entities;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Context;

public partial class ApplicationDBContext : DbContext
{
    public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AssignedOffice> AssignedOffices { get; set; }

    public virtual DbSet<DmsForm> DmsForms { get; set; }

    public virtual DbSet<DmsSubmittedForm> DmsSubmittedForms { get; set; }

    public virtual DbSet<FileRecord> FileRecords { get; set; }

    public virtual DbSet<Folder> Folders { get; set; }

    public virtual DbSet<FolderTab> FolderTabs { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<SplitAndUpload> SplitAndUploads { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserLogin> UserLogins { get; set; }

    public virtual DbSet<UserRolePermission> UserRolePermissions { get; set; }

    public virtual DbSet<UserTemplate> UserTemplates { get; set; }

    public virtual DbSet<UserTemplateTab> UserTemplateTabs { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AssignedOffice>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("assigned_offices_pkey");

            entity.ToTable("assigned_offices");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AssignedUser).HasColumnName("assigned_user");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.AssignedOfficeCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("assigned_offices_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.AssignedOfficeDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("assigned_offices_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.AssignedOfficeUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("assigned_offices_updated_by_fkey");

            entity.HasOne(d => d.User).WithMany(p => p.AssignedOfficeUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("assigned_offices_user_id_fkey");
        });

        modelBuilder.Entity<DmsForm>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("ed_forms_pkey");

            entity.ToTable("dms_forms");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.FieldsJson)
                .HasColumnType("jsonb")
                .HasColumnName("fields_json");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
            entity.Property(e => e.SelectedUserId).HasColumnName("selected_user_id");
            entity.Property(e => e.Size)
                .HasMaxLength(100)
                .HasColumnName("size");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasColumnName("status");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Url).HasColumnName("url");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.DmsFormCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_created_by");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.DmsFormDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("fk_deleted_by");

            entity.HasOne(d => d.SelectedUser).WithMany(p => p.DmsFormSelectedUsers)
                .HasForeignKey(d => d.SelectedUserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_selected_user");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.DmsFormUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("fk_updated_by");
        });

        modelBuilder.Entity<DmsSubmittedForm>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("dms_submitted_forms_pkey");

            entity.ToTable("dms_submitted_forms");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.FieldsJson)
                .HasColumnType("jsonb")
                .HasColumnName("fields_json");
            entity.Property(e => e.FormId).HasColumnName("form_id");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
            entity.Property(e => e.Size)
                .HasMaxLength(100)
                .HasColumnName("size");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasColumnName("status");
            entity.Property(e => e.SubmittedAt)
                .HasDefaultValueSql("now()")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("submitted_at");
            entity.Property(e => e.SubmittedByEmail)
                .HasMaxLength(255)
                .HasColumnName("submitted_by_email");
            entity.Property(e => e.Url).HasColumnName("url");

            entity.HasOne(d => d.Form).WithMany(p => p.DmsSubmittedForms)
                .HasForeignKey(d => d.FormId)
                .HasConstraintName("fk_form");
        });

        modelBuilder.Entity<FileRecord>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("files_pkey");

            entity.ToTable("file_records");

            entity.Property(e => e.Id)
                .HasDefaultValueSql("nextval('files_id_seq'::regclass)")
                .HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.Folder).HasColumnName("folder");
            entity.Property(e => e.FolderTab).HasColumnName("folder_tab");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
            entity.Property(e => e.Size)
                .HasMaxLength(100)
                .HasColumnName("size");
            entity.Property(e => e.Type)
                .HasMaxLength(100)
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Url).HasColumnName("url");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.FileRecordCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("fk_created_by");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.FileRecordDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("fk_deleted_by");

            entity.HasOne(d => d.FolderNavigation).WithMany(p => p.FileRecords)
                .HasForeignKey(d => d.Folder)
                .HasConstraintName("fk_folder");

            entity.HasOne(d => d.FolderTabNavigation).WithMany(p => p.FileRecords)
                .HasForeignKey(d => d.FolderTab)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("fk_folder_tab");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.FileRecordUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("fk_updated_by");
        });

        modelBuilder.Entity<Folder>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("folder_pkey");

            entity.ToTable("folder");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Comment).HasColumnName("comment");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.FileNumber)
                .HasMaxLength(255)
                .HasColumnName("file_number");
            entity.Property(e => e.FirstName)
                .HasMaxLength(255)
                .HasColumnName("first_name");
            entity.Property(e => e.Foldername)
                .HasMaxLength(255)
                .HasDefaultValueSql("''::character varying")
                .HasColumnName("foldername");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.LastName)
                .HasMaxLength(255)
                .HasColumnName("last_name");
            entity.Property(e => e.TemplateId).HasColumnName("template_id");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.FolderCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("folder_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.FolderDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("folder_deleted_by_fkey");

            entity.HasOne(d => d.Template).WithMany(p => p.Folders)
                .HasForeignKey(d => d.TemplateId)
                .HasConstraintName("folder_template_id_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.FolderUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("folder_updated_by_fkey");

            entity.HasOne(d => d.User).WithMany(p => p.FolderUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("folder_user_id_fkey");
        });

        modelBuilder.Entity<FolderTab>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("folder_tabs_pkey");

            entity.ToTable("folder_tabs");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Color)
                .HasMaxLength(50)
                .HasColumnName("color");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.Folder).HasColumnName("folder");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.IsLock)
                .HasDefaultValue(false)
                .HasColumnName("is_lock");
            entity.Property(e => e.TabName)
                .HasMaxLength(255)
                .HasColumnName("tab_name");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.FolderTabCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("folder_tabs_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.FolderTabDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("folder_tabs_deleted_by_fkey");

            entity.HasOne(d => d.FolderNavigation).WithMany(p => p.FolderTabs)
                .HasForeignKey(d => d.Folder)
                .HasConstraintName("folder_tabs_folder_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.FolderTabUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("folder_tabs_updated_by_fkey");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("roles_pkey");

            entity.ToTable("roles");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Name).HasColumnName("name");
        });

        modelBuilder.Entity<SplitAndUpload>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("split_and_upload_pkey");

            entity.ToTable("split_and_upload");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.Name)
                .HasMaxLength(255)
                .HasColumnName("name");
            entity.Property(e => e.Size)
                .HasMaxLength(50)
                .HasColumnName("size");
            entity.Property(e => e.Type)
                .HasMaxLength(100)
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Url).HasColumnName("url");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.SplitAndUploadCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("split_and_upload_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.SplitAndUploadDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("split_and_upload_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.SplitAndUploadUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("split_and_upload_updated_by_fkey");

            entity.HasOne(d => d.User).WithMany(p => p.SplitAndUploadUsers)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("split_and_upload_user_id_fkey");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("users_pkey");

            entity.ToTable("users");

            entity.HasIndex(e => e.Email, "users_email_key").IsUnique();

            entity.HasIndex(e => e.UserName, "users_user_name_key").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Address).HasColumnName("address");
            entity.Property(e => e.City).HasColumnName("city");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.FirstName).HasColumnName("first_name");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.IsFirstTimeLogin)
                .HasDefaultValue(true)
                .HasColumnName("is_first_time_login");
            entity.Property(e => e.IsOtpVerified)
                .HasDefaultValue(false)
                .HasColumnName("is_otp_verified");
            entity.Property(e => e.LastName).HasColumnName("last_name");
            entity.Property(e => e.LoginType)
                .HasDefaultValueSql("'username'::text")
                .HasColumnName("login_type");
            entity.Property(e => e.MaxTabLimit)
                .HasDefaultValue(1)
                .HasColumnName("max_tab_limit");
            entity.Property(e => e.OtpCode)
                .HasMaxLength(4)
                .HasColumnName("otp_code");
            entity.Property(e => e.PasswordHash).HasColumnName("password_hash");
            entity.Property(e => e.PhoneNumber).HasColumnName("phone_number");
            entity.Property(e => e.PostalCode).HasColumnName("postal_code");
            entity.Property(e => e.Role).HasColumnName("role");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.UserName).HasColumnName("user_name");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.InverseCreatedByNavigation)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("users_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.InverseDeletedByNavigation)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("users_deleted_by_fkey");

            entity.HasOne(d => d.RoleNavigation).WithMany(p => p.Users)
                .HasForeignKey(d => d.Role)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("users_role_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.InverseUpdatedByNavigation)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("users_updated_by_fkey");
        });

        modelBuilder.Entity<UserLogin>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("user_login_pkey");

            entity.ToTable("user_login");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.LoginAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("login_at");
            entity.Property(e => e.LogoutAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("logout_at");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Users).HasColumnName("users");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.UserLoginCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_login_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.UserLoginDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("user_login_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.UserLoginUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("user_login_updated_by_fkey");

            entity.HasOne(d => d.UsersNavigation).WithMany(p => p.UserLoginUsersNavigations)
                .HasForeignKey(d => d.Users)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_login_users_fkey");
        });

        modelBuilder.Entity<UserRolePermission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("user_role_permissions_pkey");

            entity.ToTable("user_role_permissions");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("CURRENT_TIMESTAMP")
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.HideLockTabs)
                .HasDefaultValue(false)
                .HasColumnName("hide_lock_tabs");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.PrivilegeDelete)
                .HasDefaultValue(false)
                .HasColumnName("privilege_delete");
            entity.Property(e => e.PrivilegeDownload)
                .HasDefaultValue(false)
                .HasColumnName("privilege_download");
            entity.Property(e => e.PrivilegeView)
                .HasDefaultValue(false)
                .HasColumnName("privilege_view");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Users).HasColumnName("users");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.UserRolePermissionCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("user_role_permissions_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.UserRolePermissionDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("user_role_permissions_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.UserRolePermissionUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("user_role_permissions_updated_by_fkey");

            entity.HasOne(d => d.UsersNavigation).WithMany(p => p.UserRolePermissionUsersNavigations)
                .HasForeignKey(d => d.Users)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_role_permissions_users_fkey");
        });

        modelBuilder.Entity<UserTemplate>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("user_template_pkey");

            entity.ToTable("user_template");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.Name)
                .HasColumnType("character varying")
                .HasColumnName("name");
            entity.Property(e => e.TabsCount)
                .HasColumnType("character varying")
                .HasColumnName("tabs_count");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Users).HasColumnName("users");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.UserTemplateCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_template_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.UserTemplateDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("user_template_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.UserTemplateUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("user_template_updated_by_fkey");

            entity.HasOne(d => d.UsersNavigation).WithMany(p => p.UserTemplateUsersNavigations)
                .HasForeignKey(d => d.Users)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_template_users_fkey");
        });

        modelBuilder.Entity<UserTemplateTab>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("user_template_tabs_pkey");

            entity.ToTable("user_template_tabs");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Color)
                .HasColumnType("character varying")
                .HasColumnName("color");
            entity.Property(e => e.CreatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.DeletedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.IsDeleted)
                .HasDefaultValue(false)
                .HasColumnName("is_deleted");
            entity.Property(e => e.IsLock)
                .HasDefaultValue(false)
                .HasColumnName("is_lock");
            entity.Property(e => e.Name)
                .HasColumnType("character varying")
                .HasColumnName("name");
            entity.Property(e => e.UpdatedAt)
                .HasColumnType("timestamp without time zone")
                .HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.UserTemplate).HasColumnName("user_template");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.UserTemplateTabCreatedByNavigations)
                .HasForeignKey(d => d.CreatedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_template_tabs_created_by_fkey");

            entity.HasOne(d => d.DeletedByNavigation).WithMany(p => p.UserTemplateTabDeletedByNavigations)
                .HasForeignKey(d => d.DeletedBy)
                .HasConstraintName("user_template_tabs_deleted_by_fkey");

            entity.HasOne(d => d.UpdatedByNavigation).WithMany(p => p.UserTemplateTabUpdatedByNavigations)
                .HasForeignKey(d => d.UpdatedBy)
                .HasConstraintName("user_template_tabs_updated_by_fkey");

            entity.HasOne(d => d.UserTemplateNavigation).WithMany(p => p.UserTemplateTabs)
                .HasForeignKey(d => d.UserTemplate)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("user_template_tabs_user_template_fkey");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
