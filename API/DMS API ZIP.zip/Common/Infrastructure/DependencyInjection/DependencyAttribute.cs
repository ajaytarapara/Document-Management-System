﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Infrastructure.DependencyInjection
{
    /// <summary>
    /// DependencyAttribute
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
    public abstract class DependencyAttribute : Attribute
    {
        public ServiceLifetime DependencyType { get; set; }

        public Type? ServiceType { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DependencyAttribute"/> class.
        /// </summary>
        /// <param name="dependencyType">The lifetime of the service.</param>
        protected DependencyAttribute(ServiceLifetime dependencyType)
        {
            DependencyType = dependencyType;
        }

        /// <summary>
        /// Builds the service descriptor for the specified type.
        /// </summary>
        /// <param name="type">The type information of the service.</param>
        /// <returns>A <see cref="ServiceDescriptor"/> representing the service.</returns>
        public ServiceDescriptor BuildServiceDescriptor(TypeInfo type)
        {
            var serviceType = ServiceType ?? type.AsType();
            return new ServiceDescriptor(serviceType, type.AsType(), DependencyType);
        }
    }

    /// <summary>
    /// Attribute to register a service as scoped.
    /// </summary>
    public class ScopedDependencyAttribute : DependencyAttribute
    {
        public ScopedDependencyAttribute()
            : base(ServiceLifetime.Scoped)
        { }
    }

    /// <summary>
    /// Attribute to register a service as singleton.
    /// </summary>
    public class SingletonDependencyAttribute : DependencyAttribute
    {
        public SingletonDependencyAttribute()
            : base(ServiceLifetime.Singleton)
        { }
    }

    /// <summary>
    /// Attribute to register a service as transient.
    /// </summary>
    public class TransientDependencyAttribute : DependencyAttribute
    {
        public TransientDependencyAttribute()
            : base(ServiceLifetime.Scoped)
        { }
    }
}