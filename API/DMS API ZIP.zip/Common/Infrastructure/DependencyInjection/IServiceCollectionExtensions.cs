﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Infrastructure.DependencyInjection
{
    /// <summary>
    /// IServiceCollectionExtensions
    /// </summary>
    public static class IServiceCollectionExtensions
    {
        /// <summary>
        /// Adds the dependency scanning service to the specified IServiceCollection.
        /// </summary>
        /// <param name="services">The IServiceCollection to add the scanner to.</param>
        /// <returns>The updated IServiceCollection.</returns>
        public static IServiceCollection AddDependencyScanning(this IServiceCollection services)
        {
            services.AddSingleton<Scanner>();
            return services;
        }

        /// <summary>
        /// Scans the specified assembly and registers its dependencies.
        /// </summary>
        /// <param name="services">The IServiceCollection to register dependencies with.</param>
        /// <param name="assemblyName">The name of the assembly to scan.</param>
        /// <returns>The updated IServiceCollection.</returns>
        /// <exception cref="ArgumentNullException">Thrown if assemblyName is null.</exception>
        public static IServiceCollection ScanFromAssembly(this IServiceCollection services, AssemblyName assemblyName)
        {
            var scanner = services.GetScanner();
            scanner.RegisterAssembly(services, assemblyName);
            return services;
        }

        /// <summary>
        /// Scans predefined assemblies and registers their dependencies.
        /// </summary>
        /// <param name="services">The IServiceCollection to register dependencies with.</param>
        /// <returns>The updated IServiceCollection.</returns>
        public static IServiceCollection ScanAssembly(this IServiceCollection services, List<string> assemblyNames)
        {
            foreach (var assemblyName in assemblyNames)
            {
                services.ScanFromAssembly(new AssemblyName(assemblyName));
            }
            services.ScanFromAssembly(new AssemblyName("CoreServices"));
            services.ScanFromAssembly(new AssemblyName("Shared"));
            return services;
        }

        /// <summary>
        /// Retrieves the Scanner instance from the IServiceCollection.
        /// </summary>
        /// <param name="services">The IServiceCollection from which to retrieve the Scanner.</param>
        /// <returns>The Scanner instance.</returns>
        /// <exception cref="InvalidOperationException">Thrown if the scanner cannot be resolved.</exception>
        private static Scanner GetScanner(this IServiceCollection services)
        {
            var scanner = services.BuildServiceProvider().GetService<Scanner>();
            if (null == scanner)
            {
                throw new InvalidOperationException("Unable to resolve scanner. Did you forget to call services.AddDependencyScanning?");
            }
            return scanner;
        }
    }
}
