﻿using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.DependencyInjection
{
    /// <summary>
    /// EngineContext
    /// </summary>
    public static class EngineContext
    {
        static EngineContext()
        {
            if (StaticContext == null)
                StaticContext = new List<object>();
        }

        public static IList<object> StaticContext { get; set; }

        public static bool IsStaticContext { get; set; }

        /// <summary>
        /// Adds a service to the static context.
        /// </summary>
        /// <param name="item">The service to add.</param>
        public static void AddService(object item)
        {
            if (StaticContext == null)
                StaticContext = new List<object>();
            StaticContext.Insert(StaticContext != null ? StaticContext.Count : 0, item);
        }

        /// <summary>
        /// Retrieves a service of the specified type from the static context.
        /// </summary>
        /// <typeparam name="T">The type of service to retrieve.</typeparam>
        /// <returns>The requested service.</returns>
        /// <exception cref="InvalidOperationException">Thrown if the service is not found.</exception>
        public static T GetService<T>()
        {
            var obj = StaticContext.First(d => d is T);
            return (T)obj;
        }

        /// <summary>
        /// Retrieves a service of the specified type from the static context.
        /// </summary>
        /// <param name="t">The type of service to retrieve.</param>
        /// <returns>The requested service.</returns>
        /// <exception cref="InvalidOperationException">Thrown if the service is not found.</exception>
        public static object GetService(Type t)
        {
            return StaticContext.First(d => t.IsInstanceOfType(d));
        }

        /// <summary>
        /// Resolves a service of the specified type from the ASP.NET Core dependency injection container.
        /// </summary>
        /// <typeparam name="T">The type of service to resolve.</typeparam>
        /// <returns>The resolved service.</returns>
        public static T Resolve<T>()
        {
            return (T)HttpHelper.HttpContext.RequestServices.GetRequiredService(typeof(T));
        }

        /// <summary>
        /// Resolves a service of the specified type from the ASP.NET Core dependency injection container.
        /// </summary>
        /// <param name="t">The type of service to resolve.</param>
        /// <returns>The resolved service.</returns>
        public static object GetInstance(Type t)
        {
            return HttpHelper.HttpContext.RequestServices.GetRequiredService(t);
        }
    }
}
