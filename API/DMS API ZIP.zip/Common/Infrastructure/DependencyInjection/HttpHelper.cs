﻿using Microsoft.AspNetCore.Http;

namespace Infrastructure.DependencyInjection
{
    /// <summary>
    /// Provides helper methods for working with HTTP context and requests.
    /// </summary>
    public static class HttpHelper
    {
        private static IHttpContextAccessor _httpContextAccessor;
        public static HttpContext HttpContext => _httpContextAccessor.HttpContext;

        /// <summary>
        /// Configures the <see cref="HttpHelper"/> with an instance of <see cref="IHttpContextAccessor"/>.
        /// </summary>
        /// <param name="httpContextAccessor">The HTTP context accessor to set.</param>
        public static void Configure(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// Determines whether the request is an AJAX request.
        /// </summary>
        /// <param name="request">The HTTP request to check.</param>
        /// <returns><c>true</c> if the request is an AJAX request; otherwise, <c>false</c>.</returns>
        /// <exception cref="ArgumentNullException">Thrown when the <paramref name="request"/> is <c>null</c>.</exception>
        public static bool IsAjaxRequest(this HttpRequest request)
        {
            if (request == null)
                throw new ArgumentNullException(nameof(request));

            if (request.Headers != null)
                return request.Headers["X-Requested-With"] == "XMLHttpRequest";
            return false;
        }
    }
}
