﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace Infrastructure.DependencyInjection
{
    /// <summary>
    /// Scanner
    /// </summary>
    public class Scanner
    {
        /// <summary>
        /// Registers dependencies from the specified assembly.
        /// </summary>
        /// <param name="services">The IServiceCollection to register dependencies with.</param>
        /// <param name="assemblyName">The name of the assembly to scan.</param>
        /// <exception cref="ArgumentNullException">Thrown if services or assemblyName is null.</exception>
        public void RegisterAssembly(IServiceCollection services, AssemblyName assemblyName)
        {
            var assembly = AssemblyLoader(assemblyName);
            foreach (var type in assembly.DefinedTypes)
            {
                var dependencyAttributes = type.GetCustomAttributes<DependencyAttribute>();
                // each dependency can be registered as various types
                foreach (var dependencyAttribute in dependencyAttributes)
                {
                    var serviceDescriptor = dependencyAttribute.BuildServiceDescriptor(type);
                    services.Add(serviceDescriptor);
                }
            }
        }

        /// <summary>
        /// Loads an assembly by its name.
        /// </summary>
        /// <param name="assemblyName">The name of the assembly to load.</param>
        /// <returns>The loaded assembly.</returns>
        /// <exception cref="ArgumentNullException">Thrown if assemblyName is null.</exception>
        public static Assembly AssemblyLoader(AssemblyName assemblyName)
        {
            return Assembly.Load(assemblyName);
        }
    }
}