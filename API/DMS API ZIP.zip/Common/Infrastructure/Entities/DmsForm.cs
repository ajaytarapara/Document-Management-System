﻿using System;
using System.Collections.Generic;

namespace Infrastructure.Entities;

public partial class DmsForm
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Size { get; set; } = null!;

    public string Url { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int CreatedBy { get; set; }

    public DateTime CreatedAt { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? IsDeleted { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedAt { get; set; }

    public bool? IsActive { get; set; }

    public int SelectedUserId { get; set; }
    
    public string? FieldsJson { get; set; }

    public virtual User CreatedByNavigation { get; set; } = null!;

    public virtual User? DeletedByNavigation { get; set; }

    public virtual ICollection<DmsSubmittedForm> DmsSubmittedForms { get; set; } = new List<DmsSubmittedForm>();

    public virtual User SelectedUser { get; set; } = null!;

    public virtual User? UpdatedByNavigation { get; set; }
}
