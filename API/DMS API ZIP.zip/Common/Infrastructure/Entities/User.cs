﻿using System;
using System.Collections.Generic;

namespace Infrastructure.Entities;

public partial class User
{
    public int Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string PasswordHash { get; set; } = null!;

    public int Role { get; set; }

    public string UserName { get; set; } = null!;

    public string Address { get; set; } = null!;

    public int PostalCode { get; set; }

    public long PhoneNumber { get; set; }

    public bool IsActive { get; set; }

    public int CreatedBy { get; set; }

    public DateTime CreatedAt { get; set; }

    public string? City { get; set; }

    public int? UpdatedBy { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public bool? IsDeleted { get; set; }

    public int? DeletedBy { get; set; }

    public DateTime? DeletedAt { get; set; }

    public string? OtpCode { get; set; }

    public bool? IsOtpVerified { get; set; }

    public int MaxTabLimit { get; set; }

    public string LoginType { get; set; } = null!;

    public bool IsFirstTimeLogin { get; set; }

    public virtual ICollection<AssignedOffice> AssignedOfficeCreatedByNavigations { get; set; } = new List<AssignedOffice>();

    public virtual ICollection<AssignedOffice> AssignedOfficeDeletedByNavigations { get; set; } = new List<AssignedOffice>();

    public virtual ICollection<AssignedOffice> AssignedOfficeUpdatedByNavigations { get; set; } = new List<AssignedOffice>();

    public virtual ICollection<AssignedOffice> AssignedOfficeUsers { get; set; } = new List<AssignedOffice>();

    public virtual User CreatedByNavigation { get; set; } = null!;

    public virtual User? DeletedByNavigation { get; set; }

    public virtual ICollection<DmsForm> DmsFormCreatedByNavigations { get; set; } = new List<DmsForm>();

    public virtual ICollection<DmsForm> DmsFormDeletedByNavigations { get; set; } = new List<DmsForm>();

    public virtual ICollection<DmsForm> DmsFormSelectedUsers { get; set; } = new List<DmsForm>();

    public virtual ICollection<DmsForm> DmsFormUpdatedByNavigations { get; set; } = new List<DmsForm>();

    public virtual ICollection<FileRecord> FileRecordCreatedByNavigations { get; set; } = new List<FileRecord>();

    public virtual ICollection<FileRecord> FileRecordDeletedByNavigations { get; set; } = new List<FileRecord>();

    public virtual ICollection<FileRecord> FileRecordUpdatedByNavigations { get; set; } = new List<FileRecord>();

    public virtual ICollection<Folder> FolderCreatedByNavigations { get; set; } = new List<Folder>();

    public virtual ICollection<Folder> FolderDeletedByNavigations { get; set; } = new List<Folder>();

    public virtual ICollection<FolderTab> FolderTabCreatedByNavigations { get; set; } = new List<FolderTab>();

    public virtual ICollection<FolderTab> FolderTabDeletedByNavigations { get; set; } = new List<FolderTab>();

    public virtual ICollection<FolderTab> FolderTabUpdatedByNavigations { get; set; } = new List<FolderTab>();

    public virtual ICollection<Folder> FolderUpdatedByNavigations { get; set; } = new List<Folder>();

    public virtual ICollection<Folder> FolderUsers { get; set; } = new List<Folder>();

    public virtual ICollection<User> InverseCreatedByNavigation { get; set; } = new List<User>();

    public virtual ICollection<User> InverseDeletedByNavigation { get; set; } = new List<User>();

    public virtual ICollection<User> InverseUpdatedByNavigation { get; set; } = new List<User>();

    public virtual Role RoleNavigation { get; set; } = null!;

    public virtual ICollection<SplitAndUpload> SplitAndUploadCreatedByNavigations { get; set; } = new List<SplitAndUpload>();

    public virtual ICollection<SplitAndUpload> SplitAndUploadDeletedByNavigations { get; set; } = new List<SplitAndUpload>();

    public virtual ICollection<SplitAndUpload> SplitAndUploadUpdatedByNavigations { get; set; } = new List<SplitAndUpload>();

    public virtual ICollection<SplitAndUpload> SplitAndUploadUsers { get; set; } = new List<SplitAndUpload>();

    public virtual User? UpdatedByNavigation { get; set; }

    public virtual ICollection<UserLogin> UserLoginCreatedByNavigations { get; set; } = new List<UserLogin>();

    public virtual ICollection<UserLogin> UserLoginDeletedByNavigations { get; set; } = new List<UserLogin>();

    public virtual ICollection<UserLogin> UserLoginUpdatedByNavigations { get; set; } = new List<UserLogin>();

    public virtual ICollection<UserLogin> UserLoginUsersNavigations { get; set; } = new List<UserLogin>();

    public virtual ICollection<UserRolePermission> UserRolePermissionCreatedByNavigations { get; set; } = new List<UserRolePermission>();

    public virtual ICollection<UserRolePermission> UserRolePermissionDeletedByNavigations { get; set; } = new List<UserRolePermission>();

    public virtual ICollection<UserRolePermission> UserRolePermissionUpdatedByNavigations { get; set; } = new List<UserRolePermission>();

    public virtual ICollection<UserRolePermission> UserRolePermissionUsersNavigations { get; set; } = new List<UserRolePermission>();

    public virtual ICollection<UserTemplate> UserTemplateCreatedByNavigations { get; set; } = new List<UserTemplate>();

    public virtual ICollection<UserTemplate> UserTemplateDeletedByNavigations { get; set; } = new List<UserTemplate>();

    public virtual ICollection<UserTemplateTab> UserTemplateTabCreatedByNavigations { get; set; } = new List<UserTemplateTab>();

    public virtual ICollection<UserTemplateTab> UserTemplateTabDeletedByNavigations { get; set; } = new List<UserTemplateTab>();

    public virtual ICollection<UserTemplateTab> UserTemplateTabUpdatedByNavigations { get; set; } = new List<UserTemplateTab>();

    public virtual ICollection<UserTemplate> UserTemplateUpdatedByNavigations { get; set; } = new List<UserTemplate>();

    public virtual ICollection<UserTemplate> UserTemplateUsersNavigations { get; set; } = new List<UserTemplate>();
}
