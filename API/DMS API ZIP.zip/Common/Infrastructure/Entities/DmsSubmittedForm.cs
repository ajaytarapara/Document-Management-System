﻿using System;
using System.Collections.Generic;

namespace Infrastructure.Entities;

public partial class DmsSubmittedForm
{
    public int Id { get; set; }

    public int FormId { get; set; }

    public string Name { get; set; } = null!;

    public string Size { get; set; } = null!;

    public string Url { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int CreatedBy { get; set; }

    public DateTime CreatedAt { get; set; }

    public string FieldsJson { get; set; } = null!;

    public string SubmittedByEmail { get; set; } = null!;

    public DateTime? SubmittedAt { get; set; }

    public virtual DmsForm Form { get; set; } = null!;
}
