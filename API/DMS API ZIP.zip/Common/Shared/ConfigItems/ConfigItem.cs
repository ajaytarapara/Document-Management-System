﻿using Microsoft.Extensions.Configuration;

namespace Shared.ConfigItems
{
    /// <summary>
    /// ConfigItems
    /// </summary>
    public class ConfigItems
    {
        public static IConfiguration Configuration { get; set; } = null!;

        #region Common
        public static string NexusConnectionString => Configuration["Data:DatabaseConnection:NexusConnectionString"] ?? "";
        public static string OrganizationConnectionString => Configuration["Data:DatabaseConnection:OrganizationConnectionString"] ?? "";
        public static bool IsDevelopmentMode => Convert.ToBoolean(Configuration["Data:IsDevelopmentMode"]);
        public static int SessionIdleTimeoutInMinute => Convert.ToInt32(Configuration["Data:SessionIdleTimeoutInMinute"]);
        public static string GUIDKey => Configuration["Data:GUIDKey"] ?? "";
        #endregion

        #region JWT Keys
        public static string JwtLiveKey => Configuration["JwtSettings:Key"] ?? "";
        public static string JwtIssuer => Configuration["JwtSettings:Issuer"] ?? "";
        public static string JwtAudience => Configuration["JwtSettings:Audience"] ?? "";
        public static string JwtExpiryInDays => Configuration["JwtSettings:TokenExpiryInDays"] ?? "";
        #endregion

        #region Nexus SecretKeys
        public static string NexusSecretLocalKey => Configuration["Data:NexusSecret:LocalKey"] ?? "";
        public static string NexusSecretLiveKey => Configuration["Data:NexusSecret:LiveKey"] ?? "";
        public static string NexusSecretAnonymousKey => Configuration["Data:NexusSecret:AnonymousKey"] ?? "";
        #endregion

        #region GoogleMicrosoftKey
        public static string GoogleCallBackUrl => Configuration["Authentication:Google:CallbackUrl"] ?? "";
        public static string MicrosoftCallBackUrl => Configuration["Authentication:Microsoft:CallbackUrl"] ?? "";
        public static string FrontendOAuthRedirectUrl => Configuration["FrontendOAuthRedirectUrl:CallbackUrl"] ?? "";
        public static string GoogleClientId => Configuration["Authentication:Google:ClientId"] ?? "";
        public static string GoogleClientSecret => Configuration["Authentication:Google:ClientSecret"] ?? "";
        public static string MicrosoftClientId => Configuration["Authentication:Microsoft:ClientId"] ?? "";
        public static string MicrosoftClientSecret => Configuration["Authentication:Microsoft:ClientSecret"] ?? "";
        #endregion

        #region EmailTemplate
        public static string EmailTemplateOtpPath => Configuration["EmailTemplates:OtpPath"] ?? "";
        public static string EmailTemplateCredentialsPath => Configuration["EmailTemplates:CredentialsPath"] ?? "";
        public static string EmailTemplateShareDmsFormPath => Configuration["EmailTemplates:DmsFormSharePath"] ?? "";
        public static string FromMail => Configuration["App:FromMail"] ?? "";
        public static string BaseUrl => Configuration["App:BaseUrl"] ?? "";
        public static string AdminServiceBaseUrl => Configuration["App:AdminApiBaseUrl"] ?? "";
        public static string UserServiceBaseUrl => Configuration["App:UserApiBaseUrl"] ?? "";

        #endregion
    }
}
