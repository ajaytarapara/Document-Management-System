﻿namespace Shared.Constant
{
    /// <summary>
    /// AppConstants
    /// </summary>
    public class AppConstants
    {
        #region RegularExpression
        /// <summary>
        /// Regular Expression
        /// </summary>
        public static class RegularExpression
        {
            public const string Email = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$";
            public const string EnumName = @"([a-z])([A-Z])";
            public const string StrongPassword = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$";
            public const string UserName = @"^[a-zA-Z][a-zA-Z0-9_]{2,19}$";
            public const string PhoneNumber = @"^(\+91)?[6-9]\d{9}$";

        }
        #endregion RegularExpression

        #region Constants
        /// <summary>
        /// Constant string
        /// </summary>
        public static class Constants
        {
            public const string UserId = "userId";
            public const string OtpCode = "OTP Code";
            public const string OriginalUserId = "originalUserId";
            public const string PasswordEmailTemplateSubject = "Your Account Credentials";
            public const string DateFormate = "dd-MM-yyyy HH:mm";
            public const string RootPath = "wwwroot";
            public const string DmsFolderPath = "dmsform";
            public const string View = "View";
            public const string Download = "View/Download";
        }

        #endregion Constants

        #region ApiEndpoints
        /// <summary>
        /// API endpoint constants for DMS forms.
        /// </summary>
        public static class ApiEndpoints
        {
            public const string SaveEditedFormsEndpoint = "/api/dmsforms/save-edited";
            public const string GetAllSubmittedFormsEndpoint = "/api/dmsforms/submitted/all?userId=";
            public const string SubmitEditedFromEndpoint = "/api/dmsforms/submit-edited";
            public const string ViewSharedFromEndpoint = "/subUser/view-share-dms-form";
        }

        #endregion ApiEndpoints
    }
}
