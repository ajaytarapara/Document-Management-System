﻿namespace Shared.Constant
{
    /// <summary>
    /// Messages
    /// </summary>
    public class Messages
    {
        /// <summary>
        /// Success messages
        /// </summary>
        public static class Success
        {
            /// <summary>
            /// General success messages
            /// </summary>
            public static class General
            {
                public const string Success = "Success";
                public const string Google = "Google";
                public const string Microsoft = "Microsoft";
                public const string ContentType = "application/json";
            }


            public static class Auth
            {
                public const string LoginSuccess = "Logged in successfully";
                public const string LogoutSuccess = "Logged out successfully";
                public const string AllOfficeUserslistfetchedSuccess = "All Office Users list fetched";
                public const string AccountProfileSuccess = "User profile successfully";
                public const string LastDaysRecordSuccess = "Fetched login records for the last 7 days";
                public const string LoginRecordForSelectedDateSuccess = "Login records for selected date";
                public const string AllUserslistfetchedSuccess = "All Users list fetched";
                public static readonly string UserProfilePwdUpdateSuccess = "Profile Password Update successfully";
                public const string OfficeUserTemplateReturnSuccess = "Templates for the user fetched successfully";
                public const string FolderTemplateAddReturnSuccess = "Folder template created successfully";
                public const string FolderTemplateDeleteSuccess = "Folder template deleted successfully";
                public const string FolderTemplateUpdateReturnSuccess = "Folder template updated successfully";
                public static readonly string OTPSentSuccessfully = "An OTP has been sent successfully to your registered email address.";
                public static readonly string OTPVerifiedSuccessfully = "OTP has been verified successfully.";
                public static readonly string PasswordChange = "Your password has been changed successfully.";
                public static readonly string ImpersonateSuccessfully = "Impersonate Successfully.";
                public static readonly string StopImpersonateSuccessfully = "Stopped Impersonate Successfully.";
                public static readonly string SetUpPasswordSuccessfully = "Your password has been set up successfully.";
                public const string FileRecordStatsReturnSuccess = "Analytics record fetched successfully";

            }
            public static class Folder
            {
                public const string updateSucess = "Folder Update Sucessfully";
                public const string FolderCreate = "Folder Created Sucessfully";
                public const string deleteSucess = "Folder deleted Sucessfully";
                public const string getSucess = "Folder got Sucessfully";
                public const string AddedTabSuccess = "Folder tab added successfully."; 
                public const string FolderFetchedSuccess = "Folder fetched  successfully.";
                public const string TemplateTabSuccess = "User template tab added successfully.";
                public const string DownloadSucess = "File Download Started.";

            }

            public static class DMSForm
            {
                public const string FileUploadSuccessMessage = "DMS forms added successfully";
                public const string FileUpdateSuccessMessage = "DMS form name updated successfully";
                public const string FileDeleteSuccessMessage = "DMS form deleted successfully";
                public const string FormSharedSuccessMessage = "Documents have been shared with you.";
                public const string DmsFormSharedSuccessMessage = "DMS forms shared successfully.";
                public const string DmsFormUpdateSuccessMessage = "DMS forms saved successfully.";
                public const string DmsFormSubmitSuccessMessage = "DMS form submitted successfully.";
                public const string UploadedStatus = "Uploaded";
                public const string SubmittedStatus = "Submitted";
                public const string InputRadioType = "radio";
            }

            public static class SplitAndUploadFile
            {
                public const string FileUploadSuccess = "File Uploaded Sucessfully";
                public const string FileUploadListSuccess = "File list fetched Sucessfully";
                public const string FileRemoveSuccess = "File removed Sucessfully";
                public const string FileUpdateSuccess = "Filename updated Sucessfully";
                public const string SplitAndReplaceSuccess = "PDF split successfully";
                public const string getSucessTabs = "Tabs got Sucessfully";
                public const string getSucessFile = "Files got Sucessfully";
                public const string uploadFile = "Files uploaded successfully";
                public const string editFile = "File name updated successfully";
                public const string moveFile = "File moved successfully.";
                public const string tabChange = "Tab Changed Sucessfully";
                public const string deleteFile = "file deleted Sucessfully";
                public const string shareFileMail = "Share emails sent.";


            }
        }

        public static class Error
        {
            /// <summary>
            /// Exception messages
            /// </summary>
            public static class Exception
            {
                public const string InternalServerErrorMessage = "An Error has occurred, and we are working to fix the problem! We will be up and running shortly";
                public const string UnauthorizedErrorMessage = "You are not authorized to perform this action. Please contact your administrator.";
                public const string BadRequestErrorMessage = "We couldn't process your request. Please try again later";
                public const string DataValidationErrorMessage = "One or more validation error occurred.";
                public const string DataNotFoundExceptionMessage = "Data not found.";
                public const string DataConflictExceptionMessage = "Data conflict exception occurred.";
                public const string InvalidOperationExceptionMessage = "Invalid operation exception occurred.";
                public const string AESKeyInvalidExceptionMessage = "AesSettings:Key must be 32 characters long (AES-256)";
                public const string AESIVInvalidExceptionMessage = "AesSettings:IV must be 16 characters long (AES-CBC)";
                public const string NotAbleToPersonateMessage = "You are not impersonating anyone.";
                public const string SubUserNotFound = "Sub-user does not belong to the original user.";
                public const string NotAllowedWithUsernameException = "Your account is set up for Single Sign-On (SSO). Please use your SSO credentials to sign in.";
                public const string UserTemplateNotFoundMessage = "User template not found.";
                public const string UserTemplateTabsNotFoundMessage = "User template tabs not found.";
                public static readonly Func<string, string> RequiredFieldMessage = (fileName) => $"File with name '{fileName}' already exists for the selected user.";

            }

            /// <summary>
            /// General error messages
            /// </summary>
            public static class General
            {
                public static readonly Func<string, string> NotFoundMessage = (entityName) => $"{entityName} not found.";
                public static readonly Func<string, string> ConflictMessage = (entityName) => $"{entityName} with same name already present.";
                public static readonly Func<string, string> AddError = (entityName) => $"Error occurred while adding {entityName}.";
                public static readonly Func<string, string> UpdateError = (entityName) => $"Error occurred while updating {entityName}.";
                public static readonly Func<string, string> DeleteError = (entityName) => $"Error occurred while deleting {entityName}.";
                public static readonly Func<string, string> NotExists = (entityName) => $"The given {entityName} does not exist. Please verify the {entityName} and try again.";
                public const string InvalidEmailMessage = "Invalid email. Please enter a valid one.";
                public static readonly Func<string, string> RequiredFieldMessage = (fieldName) => $"{fieldName} is required.";
                public static readonly Func<string, int, string> MaxLengthExceededMessage = (fieldName, maxLength) => $"{fieldName} must not exceed {maxLength} characters.";
                public static readonly Func<string, string> AlreadyExistMessage = (entityName) => $"{entityName} is already exist.";
                public static readonly Func<string, int, string, string> HttpClientRequestFailedMessage = (url, statusCode, message) => $"Request to '{url}' failed with status code {statusCode}: {message}";
                public const string InvalidDeserializationMessage = "Response content is null or cannot be deserialized.";
                public static string InvalidPasswordMessage => "Password must be at least 8 characters long, with at least one uppercase letter, one lowercase letter, one digit, and one special character.";
                public static string InvalidCredentialMessage => "Credential is invalid.";
                public const string AuthError = "Unauthorized access. Please provide a valid token.";
                public const string PermissionError = "You do not have permission to access this resource.";
                public static string SameBothInputPwdMessage => "New password cannot be the same as the current password.";
                public static readonly string CurrentPwdIncorrect = "Current password is incorrect.";
                public static readonly string NewPwdSameAsCurrentPwd = "New password must not same as current password.";
                public static readonly string OtpNotVerified = "OTP is not verified yet. Please verify the OTP to continue.";
                public static readonly string OtpIncorrect = "The OTP you entered is incorrect. Please try again.";
                public static readonly string UserIsNotActive = "Active user not found.";
                public static readonly string TemplateNotFound = "Template not found or not accessible by the user.";
                public static readonly Func<string, string> DuplicateTabNamesInTemplate =
                  (tabNames) => $"The following tab name(s) already exist in this template: {tabNames}.";
                public static readonly Func<int, string> TabLimitExceededMessage =
                  (limit) => $"Cannot add more tabs. The maximum limit of {limit} tabs has been reached.";
                public static readonly string NewPwdSameAsOldPwd = "New password cannot be the same as the old password.";
                public static readonly string NewPwdSameAsTempPwd = "The new password must be different from the temporary password.";
                public static readonly string FirstTimeLoginUserError = "This is not first time logged user.";
                public static string InvalidDateRangeMessage => "Start date must be earlier than or equal to end date.";
            }

            /// <summary>
            /// Organization service related error messages
            /// </summary>
            public static class Org
            {
                public static readonly Func<string, string> OrgAlreadyExist = (orgName) => $"Organization with name {orgName} already exists.";
            }

            public static class UserMessage
            {
                public const string UserNotFoundMessage = "User not found.";
                public const string CodeNotFoundOrExpired = "Invalid or expired code";
                public const string UserAlreadyExists = "A user with the same username or email already exists.";
                public const string SubUserCannotUpdate = "Access denied: Sub Users are not authorized to update other users.";
                public const string SubUserCannotView = "Access denied: Sub Users are not authorized to view other users.";
                public const string SubUserCannotDelete = "Users are not authorized to delete users.";
                public const string AdminUpdateRestriction = "Access denied: Admins can only update Office Users.";
                public const string OfficeUserUpdateRestriction = "Access denied: Office Users can only update Sub Users.";
                public const string AdminViewRestriction = "Access denied: Admins are only allowed to view Office Users.";
                public const string OfficeUserViewRestriction = "Access denied: Office Users can only view Sub Users.";
                public const string AdminDeleteRestriction = "Admins can only delete Office Users.";
                public const string OfficeUserDeleteRestriction = "Office Users can only delete Sub Users.";
                public const string SuccessMessage = "Users fetched successfully";
                public const string CreateUserSuccessMessage = "User created successfully";
                public const string UserUpdateSuccessMessage = "User updated successfully";
                public const string UserDeleteSuccessMessage = "User deleted successfully";
                public const string NotAbleToChangeEmail = "You can't change email address if your login type is SSO or Both";
                public const string NotAllowedWithSsoException = "This account is not configured for SSO. Please login using your username and password.";
                public const string MismatchEmailAndName = "Mismatch between number of emails and names.";
            }
            public static class Validation
            {
                public const string InvalidIndianPhoneNumber = "Phone number must be a valid Indian number with optional +91 and 10 digits starting with 6-9.";
                public const string InvalidStrongPassword = "Password must be at least 8 characters long, and include at least one uppercase letter, one lowercase letter, one digit, and one special character.";
                public const string InvalidPostalCode = "Postal code must be exactly 6 digits.";
                public const string InvalidFileName = "New file name cannot be empty.";
                public const string FileNotFound = "File not found or access denied.";
                public const string InvalidUser = "Invalid user context.";
                public const string InvalidFileContext = "Invalid files";
                public const string EmailTemplateNotFound = "Email template not found.";
                public const string ValidFromEmailRequired = "Please enter a valid sender email address.";
                public const string ValidToEmailRequired = "Please enter a valid recipient email address.";
                public const string RecipientNameRequired = "Please enter the recipient's name.";
                public const string SubjectRequired = "Please provide a subject for the message.";
                public const string LinkExpirationRange = "Link expiration time must be between 1 and 168 hours (up to 7 days).";
            }

            public static class SortMessages
            {
                public static readonly Func<string, string> InvalidSortColumn = (column) => $"Invalid sort column: {column}";
            }




        }
    }
}
