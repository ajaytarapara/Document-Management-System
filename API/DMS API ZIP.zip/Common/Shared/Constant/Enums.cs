﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Shared.Constant
{
    /// <summary>
    /// Enums
    /// </summary>
    public class Enums
    {
        /// <summary>
        /// Retrieves the description of an enum value.
        /// </summary>
        /// <param name="value">The enum value.</param>
        /// <returns>The description if it exists; otherwise, the enum value as a string.</returns>
        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        /// <summary>
        /// Retrieves the description of an enum value given its name.
        /// </summary>
        /// <typeparam name="T">The enum type.</typeparam>
        /// <param name="value">The name of the enum value.</param>
        /// <returns>The description if it exists; otherwise, the name of the enum value.</returns>
        public static string GetEnumDescription<T>(string value)
        {
            Type enumType = typeof(T);
            FieldInfo fi = enumType.GetField(value.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        /// <summary>
        /// Retrieves the description of an enum value given its integer representation.
        /// </summary>
        /// <typeparam name="T">The enum type.</typeparam>
        /// <param name="value">The integer value of the enum.</param>
        /// <returns>The description if it exists; otherwise, an empty string.</returns>
        /// <exception cref="ArgumentException">Thrown when the type T is not an enum.</exception>
        public static string GetEnumDescription<T>(int value)
        {
            Type enumType = typeof(T);
            if (enumType.BaseType != typeof(Enum))
                throw new ArgumentException("T must be of type System.Enum");

            Array enumValArray = Enum.GetValues(enumType);
            Array enumNameArray = Enum.GetNames(enumType);
            List<SelectListItem> enumValList = new(enumValArray.Length);

            int index = 0;
            foreach (int val in enumValArray)
            {
                SelectListItem opt = new(GetEnumDescription<T>(enumNameArray.GetValue(index++).ToString()), val.ToString());
                if (value == Convert.ToUInt32(opt.Value))
                {
                    return opt.Text.ToString();
                }
            }

            return string.Empty;
        }

        public static string GetEnumDescriptionByValue<T>(short enumValue) where T : Enum
        {
            Type enumType = typeof(T);
            FieldInfo? field = enumType.GetField(Enum.GetName(enumType, enumValue));
            DescriptionAttribute? attribute = (DescriptionAttribute)Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute));

            return attribute?.Description ?? Enum.GetName(enumType, enumValue) ?? string.Empty;
        }

        public static string GetEnumName(Enum value)
        {
            return Regex.Replace(value.ToString(), AppConstants.RegularExpression.EnumName, "$1 $2");
        }

        /// <summary>
        /// Enumeration for Nexus status codes.
        /// </summary>
        public enum ResponseStatusCode
        {
            ModelStateError = -1,
            Ok = 200,
            Created = 201,
            BadRequest = 400,
            NotFound = 404, // also use for data not found
            ServerError = 500,
            UnAuthorized = 401,
            AccessDenied = 403,
            NotAllowed = 405,
            Conflict = 409
        }

        /// <summary>
        /// Enumeration for user caching times in minutes.
        /// </summary>
        public enum UserCachingTime
        {
            VeryShort = 2,
            SemiShort = 5,
            Short = 10,
            Medium = 30,
            Long = 60,
            SemiLong = 90,
            VeryLong = 180
        }

        /// <summary>
        /// Enumeration for log types with descriptions.
        /// </summary>
        public enum LogType
        {
            [Description("Information")]
            Info = 1,
            [Description("Error")]
            Error = 2
        }

        /// <summary>
        /// Enumeration for user roles with descriptions
        /// </summary>
        public enum UserRoles
        {
            [Description("Admin")]
            Admin = 1,

            [Description("Office_User")]
            OfficeUser = 2,

            [Description("User")]
            User = 3
        }

        /// <summary>
        /// Enumeration for Submission status.
        /// </summary>
        public enum SubmissionStatus
        {
            [Description("Uploaded")]
            Uploaded = 1,

            [Description("Submitted")]
            Submitted = 2
        }

        /// <summary>
        /// Enumeration for sorting order.
        /// </summary>
        public enum SortOrder
        {
            Asc,
            Desc
        }
        public enum ShareEntityType
        {
            Folder,
            File,
            Tab
        }

        public enum LoginTypeEnum
        {
            [Description("username")]
            USERNAME,

            [Description("sso")]
            SSO,

            [Description("both")]
            BOTH
        }

        /// <summary>
        /// Enumeration for input Type.
        /// </summary>
        public enum InputType
        {
            [Description("radio")]
            Radio = 1,
        }
    }
}
