﻿using FluentValidation.Results;
using System.Net;

namespace Shared.ExceptionHandler
{

    /// <summary>
    /// Data validation custom exception
    /// </summary>
    public class DataValidationException : Exception
    {
        public HttpStatusCode StatusCode { get; private set; }
        public IList<ValidationDetailModel> Error { get; private set; }

        public DataValidationException(IEnumerable<ValidationFailure> validationFailures, string message = "") : base(message)
        {
            StatusCode = HttpStatusCode.BadRequest;
            Error = validationFailures.Select(ex => new ValidationDetailModel { InputName = ex.PropertyName, ValidationMessage = ex.ErrorMessage }).ToList();
        }
    }

    /// <summary>
    /// Data not found custom exception
    /// </summary>
    /// <param name="message"></param>
    public class DataNotFoundException(string message) : Exception(message)
    {
        public HttpStatusCode StatusCode { get; private set; } = HttpStatusCode.NotFound;
        public string Message { get; private set; } = message;
    }

    /// <summary>
    /// Data conflict custom exception
    /// </summary>
    /// <param name="message"></param>
    public class DataConflictException(string message) : Exception(message)
    {
        public HttpStatusCode StatusCode { get; private set; } = HttpStatusCode.Conflict;
        public string Message { get; private set; } = message;
    }

    /// <summary>
    /// Http request failed custom exception
    /// </summary>
    public class HttpRequestFailedException : Exception
    {
        public HttpStatusCode StatusCode { get; }
        public string? ResponseContent { get; }

        public HttpRequestFailedException(string message, HttpStatusCode statusCode, string? responseContent = null)
            : base(message)
        {
            StatusCode = statusCode;
            ResponseContent = responseContent;
        }
    }
}
