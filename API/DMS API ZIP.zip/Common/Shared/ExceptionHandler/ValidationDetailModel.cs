﻿namespace Shared.ExceptionHandler
{
    /// <summary>
    /// Validation detail model
    /// </summary>
    public class ValidationDetailModel
    {
        public string? InputName { get; set; }
        public string? ValidationMessage { get; set; }
    }
}
