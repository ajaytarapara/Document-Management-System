﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Shared.Constant;
using Shared.Helper;
using Shared.ViewModels.Base;
using static Shared.Constant.Enums;

namespace Shared.BaseController
{
    [ApiController]
    public class BaseController : ControllerBase
    {
        /// <summary>
        /// Creates a successful API response with the specified status code, data, and message.
        /// common api return function for all kind of response with success in project
        /// </summary>
        /// <param name="statusCode">The status code indicating the result of the operation.</param>
        /// <param name="data">Optional data to include in the response. Default is null.</param>
        /// <param name="message">Optional message to include in the response. Default is a general success message.</param>
        /// <returns>A <see cref="BaseResponse"/> object representing a successful response.</returns>
        protected BaseResponse ApiSuccess(ResponseStatusCode statusCode, object? data = null, string message = Messages.Success.General.Success)
        {
            var response = new BaseResponse()
            {
                IsSuccessful = true,
                StatusCode = statusCode,
                Message = message,
                Data = data
            };

            return response;
        }

        /// <summary>
        /// Creates a successful encrypted API response with consistent structure.
        /// </summary>
        /// <param name="statusCode">Custom status code indicating operation result.</param>
        /// <param name="data">Payload to include in the response.</param>
        /// <param name="message">Success message.</param>
        /// <returns>EncryptedResponse object containing AES-encrypted data.</returns>
        protected EncryptedResponse ApiSuccessEncrypted(ResponseStatusCode statusCode, object? data, string message)
        {
            BaseResponse response = new BaseResponse
            {
                IsSuccessful = true,
                StatusCode = statusCode,
                Message = message,
                Data = data
            };

            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                Formatting = Formatting.None
            };

            string json = JsonConvert.SerializeObject(response, settings);
            string encryptedData = AesEncryptionHelper.Encrypt(json);

            EncryptedResponse encryptedResponse = new EncryptedResponse
            {
                Data = encryptedData
            };

            return encryptedResponse;
        }

    }
}
