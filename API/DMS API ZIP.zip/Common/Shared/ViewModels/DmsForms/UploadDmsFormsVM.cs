namespace Shared.ViewModels.DmsForms
{

    /// <summary>
    /// ViewModel representing the request to upload DMS form files.
    /// </summary>
    public class UploadDmsFormsVM
    {
        /// <summary>
        /// The unique identifier of the user uploading the forms.
        /// </summary>
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// The list of DMS form files to be uploaded.
        /// </summary>
        public List<UploadedFile> DmsForms { get; set; }
    }
}