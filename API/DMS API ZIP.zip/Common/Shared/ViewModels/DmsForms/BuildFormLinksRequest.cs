namespace Shared.ViewModels.DmsForms
{
    public class BuildFormLinksRequest
    {
        /// <summary>
        /// List of DMS form IDs to include in the share links.
        /// </summary>
        public required IEnumerable<string> FormIds { get; set; }

        /// <summary>
        /// Base URL for the application.
        /// </summary>
        public required string BaseUrl { get; set; }

        /// <summary>
        /// Recipient's email address.
        /// </summary>
        public required string Email { get; set; }

        /// <summary>
        /// Expiration date and time for the share link.
        /// </summary>
        public DateTime ExpiresAt { get; set; }

        /// <summary>
        /// Whether the recipient can only view the forms.
        /// </summary>
        public bool ViewOnly { get; set; }

        /// <summary>
        /// Id of sender user.
        /// </summary>
        public int? UserId { get; set; }
    }
}