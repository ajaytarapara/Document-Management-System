namespace Shared.ViewModels.DmsForms
{
    public class GenerateShareTokenRequest
    {
        /// <summary>
        /// Unique ID of the DMS form to share.
        /// </summary>
        public int FormId { get; set; }

        /// <summary>
        /// Email address of the recipient.
        /// </summary>
        public required string Email { get; set; }

        /// <summary>
        /// Expiration date and time of the share link.
        /// </summary>
        public DateTime Expires { get; set; }

        /// <summary>
        /// Flag indicating whether the form is view-only.
        /// </summary>
        public bool ViewOnly { get; set; }

        /// <summary>
        /// Id of sender user.
        /// </summary>
        public int? UserId { get; set; }
    }
}