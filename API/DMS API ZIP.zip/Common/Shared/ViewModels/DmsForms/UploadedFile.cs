namespace Shared.ViewModels.DmsForms
{
    public class UploadedFile
    {
        /// <summary>
        /// Gets or sets the file's name, including its extension.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the MIME type of the file (e.g., "application/pdf", "image/png").
        /// </summary>
        public string Type { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the file's content as a Base64-encoded string.
        /// </summary>
        public string Content { get; set; } = string.Empty;
    }
}