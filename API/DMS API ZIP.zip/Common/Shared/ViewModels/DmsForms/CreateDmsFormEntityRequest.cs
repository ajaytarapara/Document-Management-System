namespace Shared.ViewModels.DmsForms
{
    public class CreateDmsFormEntityRequest
    {
        /// <summary>
        /// Uploaded file details including name, type, and content.
        /// </summary>
        public required UploadedFile File { get; set; }

        /// <summary>
        /// Full file path where the file will be stored.
        /// </summary>
        public required string FilePath { get; set; }

        /// <summary>
        /// ID of the user the DMS form belongs to.
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// ID of the user who created the DMS form record.
        /// </summary>
        public int CreatedBy { get; set; }
    }
}