namespace Shared.ViewModels.DmsForms
{

    /// <summary>
    /// Represents the request model for saving an edited DMS form,
    /// including updated file content and field data.
    /// </summary>
    public class SaveEditedFormVM
    {
        /// <summary>
        /// The unique identifier of the form being edited.
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// The unique identifier of the user performing the save operation.
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// The file content of the edited form, encoded as a Base64 string.
        /// </summary>
        public string File { get; set; }

        /// <summary>
        /// The collection of editable fields within the form,
        /// including their metadata and updated values.
        /// </summary>
        public List<FieldBaseVM> Fields { get; set; }

        /// <summary>
        /// Gets or sets the authentication token used to validate the user’s identity
        /// during API requests.
        /// </summary>
        public string? Token { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the file path associated with the request or response.
        /// Can be used to locate or reference a specific file.
        /// </summary>
        public string? FilePath { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the request is made by a user.
        /// Defaults to <c>false</c>.
        /// </summary>
        public bool? IsUser { get; set; } = false;

    }
}