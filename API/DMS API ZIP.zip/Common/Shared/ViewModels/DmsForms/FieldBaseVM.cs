namespace Shared.ViewModels.DmsForms
{
    /// <summary>
    /// Represents a base field within a DMS form,
    /// containing positioning, display, and value details.
    /// </summary>
    public class FieldBaseVM
    {
        /// <summary>
        /// The unique identifier of the field.
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// The type of field (e.g., TextBox, Checkbox, Radio, Dropdown).
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// The index of the page where the field is placed (0-based).
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// The horizontal position of the field, as a percentage of the page width.
        /// </summary>
        public double XPct { get; set; }

        /// <summary>
        /// The vertical position of the field, as a percentage of the page height.
        /// </summary>
        public double YPct { get; set; }

        /// <summary>
        /// The width of the field, as a percentage of the page width (nullable).
        /// </summary>
        public double? WPct { get; set; }

        /// <summary>
        /// The height of the field, as a percentage of the page height (nullable).
        /// </summary>
        public double? HPct { get; set; }

        /// <summary>
        /// The internal name of the field, often used as a key.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The display label for the field, shown to end users.
        /// </summary>
        public string Label { get; set; }

        /// <summary>
        /// The placeholder text displayed inside the field (if applicable).
        /// </summary>
        public string Placeholder { get; set; }

        /// <summary>
        /// The list of selectable options (used for dropdowns, radios, checkboxes).
        /// </summary>
        public List<string>? Options { get; set; }

        /// <summary>
        /// The current or default value of the field.
        /// </summary>
        public string? Value { get; set; }

        /// <summary>
        /// The value of the field required or not.
        /// </summary>
        public bool? Required { get; set; }

        /// <summary>
        /// Identifier for grouping radio buttons. Radios with the same GroupId behave as one group.
        /// </summary>
        public string? GroupId { get; set; }

        /// <summary>
        /// Minimum length allowed for the field value. Optional.
        /// </summary>
        public int? MinLength { get; set; }

        /// <summary>
        /// Maximum length allowed for the field value. Optional.
        /// </summary>
        public int? MaxLength { get; set; }

        /// <summary>
        /// Regular expression pattern to validate the field value. Optional.
        /// </summary>
        public string? Regx { get; set; }

        /// <summary>
        /// Custom error message to display when validation fails. Optional.
        /// </summary>
        public string? ErrorMessage { get; set; }

        /// <summary>
        /// Whether the field label should be visible on the PDF.
        /// </summary>
        public bool? IsLabelVisible { get; set; }
    }
}