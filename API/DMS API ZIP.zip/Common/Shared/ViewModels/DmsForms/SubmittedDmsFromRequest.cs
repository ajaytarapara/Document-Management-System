namespace Shared.ViewModels.DmsForms
{
    public class SubmittedDmsFromRequest
    {
        /// <summary>
        /// The unique identifier of the form being edited.
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// The unique identifier of the user performing the save operation.
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// The unique identifier of the user performing the submit operation.
        /// </summary>
        public string SubmittedBy { get; set; }

        /// <summary>
        /// The file content of the edited form, encoded as a Base64 string.
        /// </summary>
        public string File { get; set; }

        /// <summary>
        /// The collection of editable fields within the form,
        /// including their metadata and updated values.
        /// </summary>
        public List<FieldBaseVM> Fields { get; set; }

        /// <summary>
        /// Gets or sets the authentication token used to validate the user’s identity
        /// during API requests.
        /// </summary>
        public string? Token { get; set; }

        /// <summary>
        /// Gets or sets the file path associated with the current request or resource.
        /// This can be used to locate, access, or reference a specific file.
        /// </summary>
        public string? FilePath { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the current context belongs to a user.
        /// Defaults to <c>false</c>.
        /// </summary>
        public bool? IsUser { get; set; } = false;
    }
}