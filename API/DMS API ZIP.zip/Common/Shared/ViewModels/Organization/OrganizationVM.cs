﻿namespace Shared.ViewModels.Organization
{
    /// <summary>
    /// Organization response model
    /// </summary>
    public class OrganizationVM
    {
        /// <summary>
        /// Unique identifier for the organization
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Name of the organization
        /// </summary>
        public required string Name { get; set; }

        /// <summary>
        /// Description of the organization
        /// </summary>
        public string? ContactNumber { get; set; }

        /// <summary>
        /// Email address of the organization
        /// </summary>
        public required string Email { get; set; }

        /// <summary>
        /// URL of the organization's website
        /// </summary>
        public string? Url { get; set; }

        /// <summary>
        /// Domain name associated with the organization
        /// </summary>
        public string? Domain { get; set; }
    }
}
