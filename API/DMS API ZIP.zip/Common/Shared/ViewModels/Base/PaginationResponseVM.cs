﻿namespace Shared.ViewModels.Base
{
    /// <summary>
    /// Generic pagination response view model.
    /// </summary>
    /// <typeparam name="T">Type of the paginated data.</typeparam>
    public class PaginationResponseVM<T> where T : class
    {
        /// <summary>
        /// The list of items in the current page.
        /// </summary>
        public IEnumerable<T> Items { get; set; } = new List<T>();

        /// <summary>
        /// Total number of records available.
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// Current page index (1-based).
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// Number of records per page.
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// Total number of pages based on count and page size.
        /// </summary>
        public int TotalPages => PageSize > 0 ? (int)Math.Ceiling(TotalCount / (double)PageSize) : 0;

        /// <summary>
        /// Sorting direction (Asc or Desc).
        /// </summary>
        public string? SortDirection { get; set; }

        /// <summary>
        /// The column name being sorted on.
        /// </summary>
        public string? SortColumn { get; set; }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public PaginationResponseVM() { }

        /// <summary>
        /// Fully-initialized constructor for paginated data.
        /// </summary>
        public PaginationResponseVM(IEnumerable<T> items, int totalCount, int pageIndex, int pageSize, string? sortDirection = null, string? sortColumn = null)
        {
            Items = items ?? new List<T>();
            TotalCount = totalCount;
            PageIndex = pageIndex;
            PageSize = pageSize;
            SortDirection = sortDirection;
            SortColumn = sortColumn;
        }
    }
}
