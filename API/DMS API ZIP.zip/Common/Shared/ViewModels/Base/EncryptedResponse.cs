namespace Shared.ViewModels.Base
{
    /// <summary>
    /// Represents an encrypted response returned by the API.
    /// </summary>
    /// <remarks>
    /// The Data property holds the AES-encrypted response payload,
    /// typically a serialized JSON object that has been encrypted and Base64-encoded.
    /// </remarks>
    public class EncryptedResponse
    {
        /// <summary>
        /// AES-encrypted string containing the response data.
        /// This should be a Base64-encoded string.
        /// </summary>
        public required string Data { get; set; }
    }
}
