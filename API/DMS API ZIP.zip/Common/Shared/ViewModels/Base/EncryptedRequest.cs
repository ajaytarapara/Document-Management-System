namespace Shared.ViewModels.Base
{
    /// <summary>
    /// Represents an incoming encrypted API request.
    /// </summary>
    /// <remarks>
    /// The Data property contains the AES-encrypted payload, typically a serialized JSON string.
    /// This is decrypted server-side before deserialization into the expected request model.
    /// </remarks>
    public class EncryptedRequest<T>
    {
        public required T Data { get; set; }
    }

}
