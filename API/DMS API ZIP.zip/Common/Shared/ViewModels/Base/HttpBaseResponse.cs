using static Shared.Constant.Enums;

namespace Shared.ViewModels.Base
{
    public class HttpBaseResponse<T>
    {
        /// <summary>
        /// Indicates whether the request was successful.
        /// Defaults to <c>true</c>.
        /// </summary>
        public bool IsSuccessful { get; set; } = true;

        /// <summary>
        /// The status code representing the outcome of the API request.
        /// Uses values from <see cref="ResponseStatusCode"/>.
        /// </summary>
        public ResponseStatusCode StatusCode { get; set; }

        /// <summary>
        /// A descriptive message providing additional context about the request outcome.
        /// Can be used for success messages, error details, or validation notes.
        /// </summary>
        public string Message { get; set; } = string.Empty;

        /// <summary>
        /// The data payload returned by the API request.
        /// This will be of type <typeparamref name="T"/> or <c>null</c> if no data is available.
        /// </summary>
        public T? data { get; set; }
    }
}
