﻿using static Shared.Constant.Enums;

namespace Shared.ViewModels.Base
{
    /// <summary>
    /// Base response
    /// </summary>
    public class BaseResponse
    {
        // request is successful or not
        public bool IsSuccessful { get; set; } = true;

        // request api status code
        public ResponseStatusCode StatusCode { get; set; }

        // add any message that regarding request api
        public string Message { get; set; } = string.Empty;

        // data that need to provide on response of request api
        public object? Data { get; set; } = null;
    }
}
