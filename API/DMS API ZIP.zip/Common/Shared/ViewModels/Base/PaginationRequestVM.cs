﻿using static Shared.Constant.Enums;

namespace Shared.ViewModels.Base
{
    public class PaginationRequestVM
    {
        private int _pageNumber = 1;
        /// <summary>
        /// Gets or sets the current page number.
        /// Defaults to 1 if a value less than or equal to 0 is provided.
        /// </summary>
        public int PageNumber
        {
            get => _pageNumber;
            set => _pageNumber = value <= 0 ? 1 : value;
        }

        private int _pageSize = 10;
        /// <summary>
        /// Gets or sets the number of records per page.
        /// Defaults to 10. If a value less than or equal to 0 or greater than 50 is provided, it defaults to 50.
        /// </summary>
        public int PageSize
        {
            get => _pageSize;
            set => _pageSize = (value <= 0 || value > 50) ? 50 : value;
        }

        /// <summary>
        /// Gets or sets the field name by which the result should be sorted.
        /// </summary>
        public string? SortBy { get; set; }

        /// <summary>
        /// Gets or sets the sort order (Ascending or Descending).
        /// Default is <see cref="SortOrder.Asc"/>.
        /// </summary>
        public SortOrder SortOrder { get; set; } = SortOrder.Asc;

        /// <summary>
        /// Gets or sets the search keyword used for filtering results.
        /// </summary>
        public string? SearchKey { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaginationRequestVM"/> class
        /// with default values.
        /// </summary>
        public PaginationRequestVM() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="PaginationRequestVM"/> class
        /// with custom page number and page size.
        /// </summary>
        /// <param name="pageNumber">The page number (defaults to 1 if invalid).</param>
        /// <param name="pageSize">The page size (defaults to 50 if invalid).</param>
        public PaginationRequestVM(int pageNumber = 1, int pageSize = 10)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
        }

        /// <summary>
        /// Token used for authentication or user validation in paginated requests.
        /// </summary>
        public string? Token { get; set; }

        /// <summary>
        /// Indicates whether the user is a sub-user (child account) under a parent user.
        /// </summary>
        public bool? IsSubUser { get; set; }
    }
}
