namespace Shared.ViewModels.Base
{
    public class EncryptedWrapper
    {
        public string data { get; set; }
    }
}