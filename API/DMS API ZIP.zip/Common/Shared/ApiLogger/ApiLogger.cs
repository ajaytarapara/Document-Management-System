﻿
namespace Shared.ApiLogger
{
    /// <summary>
    /// Provides a static logger for the Nexus API using NLog.
    /// </summary>
    public static class ApiLogger
    {

    }
}
