using System.Security.Cryptography;

namespace Shared.Helper
{
    /// <summary>
    /// Provides functionality to generate secure numeric OTPs (One-Time Passwords).
    /// </summary>
    public static class OtpGenerator
    {
        /// <summary>
        /// Generates a cryptographically secure numeric OTP of the specified length.
        /// </summary>
        /// <param name="length">The length of the OTP to generate. Default is 4 digits.</param>
        /// <returns>A randomly generated numeric OTP as a string.</returns>
        /// <remarks>
        /// This method uses <see cref="RandomNumberGenerator"/> to ensure the OTP is secure.
        /// </remarks>
        public static string GenerateNumericOTP(int length = 4)
        {
            const string digits = "0123456789";
            var otp = new char[length];
            using var rng = RandomNumberGenerator.Create();

            var data = new byte[length];
            rng.GetBytes(data);

            for (int i = 0; i < length; i++)
            {
                otp[i] = digits[data[i] % digits.Length];
            }

            return new string(otp);
        }
    }
}