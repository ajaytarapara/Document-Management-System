﻿namespace Shared.Helper
{
    public static class Helper
    {
        /// <summary>
        /// Converts the input string to PascalCase.
        /// Words are split by spaces, underscores, or hyphens, capitalized, and concatenated without separators.
        /// </summary>
        /// <param name="input">The input string to convert.</param>
        /// <returns>A PascalCase formatted string, or the original input if null or whitespace.</returns>
        public static string ToPascalCase(this string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            return string.Join(string.Empty, input
                .Split(new[] { ' ', '_', '-' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(word => char.ToUpperInvariant(word[0]) + word.Substring(1).ToLowerInvariant()));
        }

        /// <summary>
        /// Converts the input string to camelCase.
        /// The first character is lowercase, and subsequent words are capitalized and concatenated.
        /// </summary>
        /// <param name="input">The input string to convert.</param>
        /// <returns>A camelCase formatted string, or the original input if null or empty.</returns>
        public static string ToCamelCase(this string input)
        {
            var pascal = input.ToPascalCase();
            if (string.IsNullOrEmpty(pascal)) return pascal;

            return char.ToLowerInvariant(pascal[0]) + pascal.Substring(1);
        }

        /// <summary>
        /// Converts a comma-separated string to a list of integers.
        /// Ignores non-numeric or malformed values safely.
        /// </summary>
        public static List<int> ToIntList(this string? csv)
        {
            if (string.IsNullOrWhiteSpace(csv))
                return new List<int>();

            return csv.Split(',', StringSplitOptions.RemoveEmptyEntries)
                      .Select(s => int.TryParse(s.Trim(), out var id) ? id : (int?)null)
                      .Where(id => id.HasValue)
                      .Select(id => id!.Value)
                      .ToList();
        }
    }
}
