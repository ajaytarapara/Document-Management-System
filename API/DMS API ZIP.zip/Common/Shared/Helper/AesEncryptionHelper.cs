using System.Security.Cryptography;
using System.Text;
namespace Shared.Helper
{
    /// <summary>
    /// Provides static methods for AES encryption and decryption of string data.
    /// This class must be configured once with a valid Key and IV using the <see cref="Configure"/> method.
    /// </summary>
    public static class AesEncryptionHelper
    {
        private static string? _key;
        private static string? _iv;

        /// <summary>
        /// Configures the AES encryption key and IV.
        /// Must be called once during application startup.
        /// </summary>
        /// <param name="key">A 32-character AES encryption key (for AES-256).</param>
        /// <param name="iv">A 16-character initialization vector (for AES-CBC mode).</param>
        public static void Configure(string key, string iv)
        {
            _key = key;
            _iv = iv;
        }

        /// <summary>
        /// Encrypts the given plain text string using AES encryption (CBC mode).
        /// </summary>
        /// <param name="plainText">The plain text string to encrypt.</param>
        /// <returns>Base64-encoded encrypted string.</returns>
        /// <exception cref="ArgumentNullException">Thrown if encryption key or IV is not set.</exception>
        public static string Encrypt(string plainText)
        {
            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(_key);
            aes.IV = Encoding.UTF8.GetBytes(_iv);

            var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            using var ms = new MemoryStream();
            using var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write);
            using (var sw = new StreamWriter(cs)) sw.Write(plainText);
            return Convert.ToBase64String(ms.ToArray());
        }

        /// <summary>
        /// Decrypts an AES-encrypted Base64 string back to plain text.
        /// </summary>
        /// <param name="cipherText">The encrypted string (Base64 encoded).</param>
        /// <returns>The decrypted plain text string.</returns>
        /// <exception cref="ArgumentNullException">Thrown if encryption key or IV is not set.</exception>
        public static string Decrypt(string cipherText)
        {
            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(_key);
            aes.IV = Encoding.UTF8.GetBytes(_iv);

            var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
            using var ms = new MemoryStream(Convert.FromBase64String(cipherText));
            using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
            using var sr = new StreamReader(cs);
            return sr.ReadToEnd();
        }

        /// <summary>
        /// Encrypts an integer ID into a URL-safe Base64 string using AES (CBC mode, PKCS7 padding).
        /// </summary>
        /// <param name="id">The integer ID to encrypt.</param>
        /// <returns>Encrypted string (URL-safe Base64 format, no padding characters).</returns>
        public static string EncryptId(int id)
        {
            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(_key);
            aes.IV = Encoding.UTF8.GetBytes(_iv);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var encryptor = aes.CreateEncryptor();
            var plainBytes = Encoding.UTF8.GetBytes(id.ToString());
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
            var base64 = Convert.ToBase64String(cipherBytes);

            return base64.Replace('+', '-').Replace('/', '_').Replace("=", "");
        }

        /// <summary>
        /// Decrypts a URL-safe Base64 AES-encrypted ID string back into an integer.
        /// </summary>
        /// <param name="encryptedId">The encrypted ID string (URL-safe Base64 format).</param>
        /// <returns>Decrypted integer ID.</returns>
        public static int DecryptId(string encryptedId)
        {
            var base64 = encryptedId.Replace('-', '+').Replace('_', '/');

            switch (base64.Length % 4)
            {
                case 2: base64 += "=="; break;
                case 3: base64 += "="; break;
            }

            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(_key);
            aes.IV = Encoding.UTF8.GetBytes(_iv);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using var decryptor = aes.CreateDecryptor();

            var cipherBytes = Convert.FromBase64String(base64);
            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            var plainText = Encoding.UTF8.GetString(plainBytes);

            return int.Parse(plainText);
        }
    }
}