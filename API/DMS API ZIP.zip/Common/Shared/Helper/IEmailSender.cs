namespace Shared.Helper;

public interface IEmailSender
{
    Task SendEmailAsync(string from, string to, string subject, string html);
}
