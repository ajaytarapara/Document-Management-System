﻿using FluentValidation;
using Shared.ExceptionHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.Helper
{
    /// <summary>
    /// Validator
    /// </summary>
    public static class Validator
    {
        /// <summary>
        /// Validate request and throw exception if invalid
        /// </summary>
        /// <typeparam name="TRequest"></typeparam>
        /// <param name="request"></param>
        /// <param name="validator"></param>
        /// <exception cref="DataValidationException"></exception>
        public static void ValidateAndThrow<TRequest>(TRequest request, AbstractValidator<TRequest> validator)
        {
            var result = validator.Validate(request);

            if (!result.IsValid)
            {
                throw new DataValidationException(result.Errors);
            }
        }
    }
}
