﻿namespace Shared.Helper
{
    public static class CommonValidationRules
    {

    }
}
