﻿using System.Reflection;
using System.Text;

namespace Shared.Helper
{
    /// <summary>
    /// EncryptionDecryption
    /// </summary>
    public class EncryptionDecryption
    {
        #region Variable Declaration

        public static string keyString
        {
            get { return ConfigItems.ConfigItems.GUIDKey; }
        }

        private static byte[] _keyByte = { };
        private static byte[] _ivByte = { 0x01, 0x12, 0x23, 0x34, 0x45, 0x56, 0x67, 0x78 };

        #endregion

        #region Methods/Functions

        /// <summary>
        /// Encrypts the passed value and returns the encrypted string.
        /// </summary>
        /// <param name="value">The value to be encrypted.</param>
        /// <returns>The encrypted string.</returns>
        public static string GetEncrypt(string value)
        {
            return Encrypt(value);
        }

        /// <summary>
        /// Decrypts the passed encrypted string and returns the original value.
        /// </summary>
        /// <param name="value">The encrypted string to be decrypted.</param>
        /// <returns>The decrypted original value.</returns>
        public static string GetDecrypt(string value)
        {
            return Decrypt(value);
        }

        /// <summary>
        /// Encrypts the passed value using TripleDES encryption.
        /// </summary>
        /// <param name="value">The value to be encrypted.</param>
        /// <returns>The encrypted string in Base64 format, replacing certain characters for URL-safe encoding.</returns>
        private static string Encrypt(string value)
        {
            try
            {
                System.Security.Cryptography.TripleDES des = CreateDES();
                System.Security.Cryptography.ICryptoTransform ct = des.CreateEncryptor();
                byte[] input = Encoding.Default.GetBytes(value);
                return Convert.ToBase64String(ct.TransformFinalBlock(input, 0, input.Length)).Replace("/", "_").Replace("+", "-");//.Replace("=", "%3D")
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Creates a TripleDES encryption service provider using a key derived from MD5 hashing.
        /// </summary>
        /// <returns>A configured TripleDES instance.</returns>
        public static System.Security.Cryptography.TripleDES CreateDES()
        {
            string Key = keyString;
            System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
            System.Security.Cryptography.TripleDES des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            des.Key = md5.ComputeHash(Encoding.Unicode.GetBytes(Key));
            des.IV = new byte[des.BlockSize / 8];
            return des;
        }

        /// <summary>
        /// Decrypts the passed encrypted value and returns the original string.
        /// </summary>
        /// <param name="value">The encrypted value to be decrypted.</param>
        /// <returns>The decrypted original string.</returns>
        public static string Decrypt(string value)
        {
            try
            {
                value = value.Replace("_", "/").Replace("-", "+");//.Replace("%3D", "=")
                byte[] b = Convert.FromBase64String(value);
                System.Security.Cryptography.TripleDES des = CreateDES();
                System.Security.Cryptography.ICryptoTransform ct = des.CreateDecryptor();
                byte[] output = ct.TransformFinalBlock(b, 0, b.Length);
                return Encoding.Default.GetString(output);
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Verifies if the provided password matches the stored encrypted password.
        /// </summary>
        /// <param name="storedEncryptedPassword">The stored encrypted password to verify against.</param>
        /// <param name="password">The plain-text password to be verified.</param>
        /// <returns><c>true</c> if the password matches; otherwise, <c>false</c>.</returns>
        public static bool VerifyPassword(string storedEncryptedPassword, string password)
        {
            try
            {
                // Encrypt the input password to match it with the stored password
                string encryptedInputPassword = GetEncrypt(password);

                // Compare the encrypted input password with the stored encrypted password
                return storedEncryptedPassword == encryptedInputPassword;
            }
            catch
            {
                return false;
            }
        }

        public static class IdConverter
        {
            private static int ConvertToInt(string value)
            {
                try
                {
                    return AesEncryptionHelper.DecryptId(value);
                }
                catch
                {
                    return 0;
                }
            }

            public static TOut ConvertIds<TIn, TOut>(TIn obj)
                where TIn : class, new()
                where TOut : class, new()
            {
                if (obj == null) return null;

                var inType = typeof(TIn);
                var outType = typeof(TOut);

                var newObj = new TOut();

                foreach (var inProp in inType.GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    var outProp = outType.GetProperty(inProp.Name);
                    if (outProp == null || !outProp.CanWrite) continue;

                    var value = inProp.GetValue(obj);

                    if (inProp.PropertyType == typeof(string) && outProp.PropertyType == typeof(int) &&
                        inProp.Name.EndsWith("Id", StringComparison.OrdinalIgnoreCase))
                    {
                        int intValue = ConvertToInt(value as string);
                        outProp.SetValue(newObj, intValue);
                    }
                    else if (inProp.PropertyType == typeof(List<string>) &&
                             outProp.PropertyType == typeof(List<int>) &&
                             inProp.Name.EndsWith("Ids", StringComparison.OrdinalIgnoreCase))
                    {
                        var list = (value as List<string>) ?? new List<string>();
                        var intList = list.Select(ConvertToInt).ToList();
                        outProp.SetValue(newObj, intList);
                    }
                    else if (outProp.PropertyType == inProp.PropertyType)
                    {
                        outProp.SetValue(newObj, value);
                    }
                }

                return newObj;
            }
        }
        #endregion
    }
}
