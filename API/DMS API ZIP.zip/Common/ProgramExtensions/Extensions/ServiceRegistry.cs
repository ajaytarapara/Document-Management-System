﻿using Infrastructure.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace ProgramExtensions.Extensions
{
    /// <summary>
    /// ServiceRegistry
    /// </summary>
    public static class ServiceRegistry
    {
        /// <summary>
        /// Registers application services with the specified service collection.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection"/> to register services with.</param>
        public static void RegisterServices(this IServiceCollection services, List<string> assemblies)
        {
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // scan all dependency of solution
            services.AddDependencyScanning().ScanAssembly(assemblies);
        }
    }
}
