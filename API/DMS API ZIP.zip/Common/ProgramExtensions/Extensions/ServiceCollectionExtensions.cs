﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Localization.Routing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Shared.ConfigItems;
using System.Globalization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Serialization;
using Shared.Constant;


namespace ProgramExtensions.Extensions
{
    /// <summary>
    /// Extension methods for configuring application services.
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// Registers core application services including logging, session, CORS, antiforgery, and custom scoped services.
        /// </summary>
        /// <param name="services">The service collection to add services to.</param>
        /// <param name="configuration">The application configuration.</param>
        /// <returns>The updated service collection.</returns>
        public static IServiceCollection AddAppServices<ApplicationDBContext>(this IServiceCollection services, IConfiguration configuration) where ApplicationDBContext : DbContext
        {
            services.AddLogging();

            // Add DbContext using PostgreSQL
            services.AddDbContext<ApplicationDBContext>(options =>
                        options.UseNpgsql(ConfigItems.NexusConnectionString));

            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            services.AddHttpClient(); // registers IHttpClientFactory
            services.AddHttpContextAccessor();
            services.AddMemoryCache();

            services.AddDistributedMemoryCache();
            services.AddSession(s => s.IdleTimeout = TimeSpan.FromMinutes(1440));

            services.AddRouting(options => options.LowercaseUrls = true);

            services.Configure<IISServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });

            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy", builder =>
                 builder
                     .WithOrigins("http://localhost:3000")
                     .AllowAnyMethod()
                     .AllowAnyHeader()
                     .AllowCredentials()
             );
            });

            services.AddAntiforgery(options =>
            {
                options.HeaderName = "CSRF-TOKEN-NexusAPI-HEADER";
                options.Cookie.Name = "CSRF-TOKEN-NexusAPI-COOKIE";
                options.FormFieldName = "CSRF-TOKEN-NexusAPI-FORM";
            });

            return services;
        }

        /// <summary>
        /// Configures JWT Bearer authentication using settings from configuration.
        /// </summary>
        /// <param name="services">The service collection to add authentication services to.</param>
        /// <param name="configuration">The application configuration.</param>
        /// <returns>The updated service collection.</returns>
        public static IServiceCollection AddAppAuthentication(this IServiceCollection services)
        {
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })

                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = ConfigItems.JwtIssuer,
                        ValidAudience = ConfigItems.JwtAudience,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(ConfigItems.JwtLiveKey)),
                        RoleClaimType = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"
                    };
                    options.Events = new JwtBearerEvents
                    {
                        OnChallenge = context =>
                        {
                            context.HandleResponse();
                            context.Response.StatusCode = 401;
                            context.Response.ContentType = Messages.Success.General.ContentType;
                            var result = System.Text.Json.JsonSerializer.Serialize(new
                            {
                                success = false,
                                message = Messages.Error.General.AuthError,
                                data = (object)null
                            });

                            return context.Response.WriteAsync(result);
                        },
                        OnForbidden = context =>
                        {
                            context.Response.StatusCode = 403;
                            context.Response.ContentType = Messages.Success.General.ContentType;
                            var result = System.Text.Json.JsonSerializer.Serialize(new
                            {
                                success = false,
                                message = Messages.Error.General.PermissionError,
                                data = (object)null
                            });
                            return context.Response.WriteAsync(result);
                        }
                    };
                });
            return services;
        }

        /// <summary>
        /// Configures localization options including supported cultures and a route data request culture provider.
        /// </summary>
        /// <param name="services">The service collection to add localization services to.</param>
        /// <returns>The updated service collection.</returns>
        public static IServiceCollection AddAppLocalization(this IServiceCollection services)
        {
            var requestProvider = new RouteDataRequestCultureProvider();
            services.Configure<RequestLocalizationOptions>(options =>
            {
                var supportCulture = new List<CultureInfo>
            {
                new("en-US"),
                new("en")
            };

                options.DefaultRequestCulture = new Microsoft.AspNetCore.Localization.RequestCulture("en", "en-US");
                options.SupportedCultures = supportCulture;
                options.SupportedUICultures = supportCulture;
                options.RequestCultureProviders.Insert(0, requestProvider);
            });

            return services;
        }

        /// <summary>
        /// Adds Swagger generation and configures security definitions and requirements for JWT Bearer and API key authentication.
        /// </summary>
        /// <param name="services">The service collection to add Swagger services to.</param>
        /// <returns>The updated service collection.</returns>
        public static IServiceCollection AddAppSwagger(this IServiceCollection services, string title)
        {
            services.AddEndpointsApiExplorer();

            services.AddSwaggerGen(opt =>
            {
                opt.SwaggerDoc("v1", new OpenApiInfo { Title = title, Version = "v1" });

                opt.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter the JWT token",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "bearer",
                });

                opt.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
                    },
                    Array.Empty<string>()
                }
            });
            });

            return services;
        }

        /// <summary>
        /// Configures and adds MVC controllers to the service collection with JSON serialization settings.
        /// Uses Newtonsoft.Json with camel case property naming and support for handling reference loops.
        /// </summary>
        /// <param name="services">The service collection to which the controllers are added.</param>
        /// <returns>The updated <see cref="IServiceCollection"/> with controller services registered.</returns>
        public static IServiceCollection AddAppControllers(this IServiceCollection services)
        {
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            });

            return services;
        }

    }
}
