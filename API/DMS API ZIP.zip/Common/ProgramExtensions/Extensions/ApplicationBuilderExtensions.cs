﻿using System.Diagnostics;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using ProgramExtensions.Middleware.AntiXss;
using ProgramExtensions.Middleware.GlobalException;
using Microsoft.Extensions.FileProviders;
namespace ProgramExtensions.Extensions
{
    /// <summary>
    /// Extension methods for configuring the middleware pipeline for the web API application.
    /// </summary>
    public static class ApplicationBuilderExtensions
    {
        /// <summary>
        /// Configures the middleware pipeline for the web API application, including 
        /// exception handling, CORS, session, authentication, HTTPS redirection, 
        /// static files, and controller mapping.
        /// </summary>
        /// <param name="app">The <see cref="WebApplication"/> instance.</param>
        /// <returns>The configured <see cref="WebApplication"/> instance.</returns>
        public static WebApplication UseAppPipeline(this WebApplication app)
        {
            AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
                app.UseDeveloperExceptionPage();
                string? configUrl = app.Configuration["ASPNETCORE_URLS"] ?? app.Configuration["applicationUrl"];

                if (!string.IsNullOrEmpty(configUrl))
                {
                    try
                    {
                        string? url = configUrl.Split(';').FirstOrDefault();
                        if (!string.IsNullOrEmpty(url))
                        {
                            Process.Start(new ProcessStartInfo
                            {
                                FileName = $"{url}/swagger",
                                UseShellExecute = true
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Could not open browser: {ex.Message}");
                    }
                }
            }
            else
            {
                app.UseExceptionHandler("/404");
                app.UseHsts();
            }
            app.UseHttpsRedirection();

            var env = app.Environment;
            var uploadsPath = Path.Combine(env.ContentRootPath, "splitandupload");

            if (!Directory.Exists(uploadsPath))
            {
                Directory.CreateDirectory(uploadsPath);
            }

            app.UseStaticFiles();

            app.UseStaticFiles(new StaticFileOptions
            {
                FileProvider = new PhysicalFileProvider(uploadsPath),
                RequestPath = "/splitandupload"
            });

            app.UseRouting();
            app.UseMiddleware<EncryptionMiddleware>();

            app.UseSession();
            app.UseCors("CorsPolicy");
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseMiddleware<AntiXssMiddleware>();

            app.UseMiddleware<ExceptionMiddleware>();

            app.MapControllers();

            return app;
        }
    }

}
