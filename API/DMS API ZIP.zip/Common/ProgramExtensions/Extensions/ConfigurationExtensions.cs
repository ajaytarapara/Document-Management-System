﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace ProgramExtensions.Extensions
{
    /// <summary>
    /// Extension methods for the <see cref="IConfigurationBuilder"/> class.
    /// </summary>
    public static class ConfigurationExtensions
    {
        /// <summary>
        /// Adds application configuration sources to the <see cref="IConfigurationBuilder"/>,
        /// including the base appsettings.json file, environment-specific settings,
        /// and environment variables.
        /// </summary>
        /// <param name="configBuilder">The configuration builder to add sources to.</param>
        /// <param name="env">The hosting environment used to determine the environment-specific configuration file.</param>
        /// <returns>The updated <see cref="IConfigurationBuilder"/> instance.</returns>
        public static IConfigurationBuilder AddAppConfiguration(this IConfigurationBuilder configBuilder, IWebHostEnvironment env)
        {
            return configBuilder
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
        }
    }
}
