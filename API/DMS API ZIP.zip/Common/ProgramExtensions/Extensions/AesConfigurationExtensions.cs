using Microsoft.Extensions.Configuration;
using Shared.Constant;
using Shared.Helper;

namespace ProgramExtensions.Extensions
{
    /// <summary>
    /// Extension method for setting up AES configuration by reading from appsettings.
    /// </summary>
    public static class AesConfigurationExtensions
    {
        /// <summary>
        /// Reads AES key and IV from configuration and configures the AesEncryptionHelper.
        /// Ensures the key is 32 characters (for AES-256) and IV is 16 characters (for AES-CBC).
        /// </summary>
        /// <param name="configBuilder">The configuration builder used during startup.</param>
        /// <returns>The original IConfigurationBuilder with AES configured.</returns>
        public static IConfigurationBuilder AddAesConfiguration(this IConfigurationBuilder configBuilder)
        {
            IConfigurationRoot configurationRoot = configBuilder.Build();

            string? aesKey = configurationRoot["AesSettings:Key"];
            string? aesIV = configurationRoot["AesSettings:IV"];

            if (string.IsNullOrWhiteSpace(aesKey) || aesKey.Length != 32)
                throw new InvalidOperationException(Messages.Error.Exception.AESKeyInvalidExceptionMessage);

            if (string.IsNullOrWhiteSpace(aesIV) || aesIV.Length != 16)
                throw new InvalidOperationException(Messages.Error.Exception.AESIVInvalidExceptionMessage);

            // Configure the AES encryption helper with validated key and IV
            AesEncryptionHelper.Configure(aesKey, aesIV);

            return configBuilder;
        }
    }

}