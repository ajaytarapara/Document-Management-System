using Newtonsoft.Json;
using System.Text;
using Shared.Helper;
using Microsoft.AspNetCore.Http;
using Shared.ViewModels.Base;

/// <summary>
/// Middleware to handle AES-based encryption and decryption for HTTP requests and responses.
/// 
/// Features:
/// 1. Decrypts encrypted JSON request bodies before they hit controllers.
/// 2. Decrypts route parameters that end with "Id".
/// 3. Decrypts query string parameters named "id" or ending with "Id".
/// 4. Encrypts HTTP 200 responses before sending them to the client.
/// 
/// This helps secure IDs and payloads against tampering or direct exposure.
/// </summary>
public class EncryptionMiddleware
{
    private readonly RequestDelegate _next;

    /// <summary>
    /// Constructor to initialize middleware with the next request delegate.
    /// </summary>
    public EncryptionMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    /// <summary>
    /// Main middleware execution method. Intercepts requests and responses
    /// to perform encryption/decryption logic.
    /// </summary>
    public async Task Invoke(HttpContext context)
    {
        try
        {
            if (context.Request.ContentType != null &&
                context.Request.ContentType.Contains("application/json", StringComparison.OrdinalIgnoreCase))
            {
                context.Request.EnableBuffering();
                using var reader = new StreamReader(context.Request.Body, Encoding.UTF8, leaveOpen: true);
                var rawBody = await reader.ReadToEndAsync();
                context.Request.Body.Position = 0;

                try
                {
                    var encryptedRequest = JsonConvert.DeserializeObject<EncryptedWrapper>(rawBody);
                    if (encryptedRequest != null && !string.IsNullOrWhiteSpace(encryptedRequest.data))
                    {
                        var decryptedJson = AesEncryptionHelper.Decrypt(encryptedRequest.data);
                        var decryptedBytes = Encoding.UTF8.GetBytes(decryptedJson);

                        context.Request.Body = new MemoryStream(decryptedBytes);
                        context.Request.Body.Seek(0, SeekOrigin.Begin);
                        context.Request.ContentLength = decryptedBytes.Length;
                    }
                }
                catch (Exception ex)
                {
                    await WriteErrorResponse(context, StatusCodes.Status400BadRequest, "Request decryption failed", ex.Message);
                    return;
                }
            }

            foreach (var key in context.Request.RouteValues.Keys.ToList())
            {
                if (key.Equals("id", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine($"Skipping decryption for route param '{key}' (expected plain int)");
                    continue;
                }

                if (key.EndsWith("Id", StringComparison.OrdinalIgnoreCase) &&
                    context.Request.RouteValues[key] is string encryptedId)
                {
                    if (!TryDecryptId(encryptedId, out int id, out string error))
                    {
                        await WriteErrorResponse(context, StatusCodes.Status400BadRequest, $"Invalid encrypted route ID for {key}", error);
                        return;
                    }
                    context.Request.RouteValues[key] = id;
                }
            }

            var queryCollection = Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseQuery(context.Request.QueryString.Value ?? "");
            var updatedQuery = new Dictionary<string, Microsoft.Extensions.Primitives.StringValues>();
            bool queryChanged = false;

            foreach (var kvp in queryCollection)
            {
                if (kvp.Key.Equals("id", StringComparison.OrdinalIgnoreCase) ||
                    kvp.Key.EndsWith("Id", StringComparison.OrdinalIgnoreCase))
                {
                    if (TryDecryptId(kvp.Value.ToString(), out int id, out string error))
                    {
                        updatedQuery[kvp.Key] = id.ToString();
                        queryChanged = true;
                    }
                    else
                    {
                        await WriteErrorResponse(context, StatusCodes.Status400BadRequest, $"Invalid encrypted query ID for {kvp.Key}", error);
                        return;
                    }
                }
                else
                {
                    updatedQuery[kvp.Key] = kvp.Value;
                }
            }

            if (queryChanged)
            {
                var newQueryString = Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString("", updatedQuery);
                context.Request.QueryString = new QueryString(newQueryString);
            }

            var originalBodyStream = context.Response.Body;
            using var newBody = new MemoryStream();
            context.Response.Body = newBody;

            await _next(context);

            if (context.Response.StatusCode == 200)
            {
                newBody.Seek(0, SeekOrigin.Begin);
                using var reader = new StreamReader(newBody);
                var plainResponse = await reader.ReadToEndAsync();

                var encrypted = AesEncryptionHelper.Encrypt(plainResponse);
                var encryptedJson = JsonConvert.SerializeObject(new EncryptedWrapper { data = encrypted });

                var encryptedBytes = Encoding.UTF8.GetBytes(encryptedJson);
                context.Response.Body = originalBodyStream;
                context.Response.ContentType = "application/json";
                context.Response.ContentLength = encryptedBytes.Length;
                await context.Response.Body.WriteAsync(encryptedBytes);
            }
            else
            {
                newBody.Seek(0, SeekOrigin.Begin);
                await newBody.CopyToAsync(originalBodyStream);
            }
        }
        catch (Exception ex)
        {
            await WriteErrorResponse(context, StatusCodes.Status500InternalServerError, "Internal Server Error", ex.Message);
        }
    }

    /// <summary>
    /// Writes a JSON error response to the client.
    /// </summary>
    private static async Task WriteErrorResponse(HttpContext context, int statusCode, string error, string message)
    {
        var errorResponse = new
        {
            StatusCode = statusCode,
            Error = error,
            Message = message,
            IsSuccess = false
        };

        var json = JsonConvert.SerializeObject(errorResponse);
        var bytes = Encoding.UTF8.GetBytes(json);

        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/json";
        context.Response.ContentLength = bytes.Length;
        await context.Response.Body.WriteAsync(bytes);
    }

    /// <summary>
    /// Attempts to decrypt an encrypted ID string back to an integer.
    /// Returns true if successful, false if not.
    /// </summary>
    private static bool TryDecryptId(string encryptedValue, out int id, out string error)
    {
        id = 0;
        error = string.Empty;

        try
        {
            var base64 = encryptedValue.Replace('-', '+').Replace('_', '/');
            switch (base64.Length % 4)
            {
                case 2: base64 += "=="; break;
                case 3: base64 += "="; break;
            }

            var decryptedString = AesEncryptionHelper.Decrypt(base64);

            if (!int.TryParse(decryptedString, out id))
            {
                error = "Decrypted value is not a valid number";
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            return false;
        }
    }
}
