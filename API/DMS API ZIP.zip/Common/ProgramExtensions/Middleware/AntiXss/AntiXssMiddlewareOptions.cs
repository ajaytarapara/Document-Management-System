﻿namespace ProgramExtensions.Middleware.AntiXss
{
    /// <summary>
    /// Options for the AntiXssMiddleware.
    /// </summary>
    public class AntiXssMiddlewareOptions
    {
        public string ErrorMessage
        {
            get
            {
                return "This request contains dangerous content";
            }
        }
    }
}