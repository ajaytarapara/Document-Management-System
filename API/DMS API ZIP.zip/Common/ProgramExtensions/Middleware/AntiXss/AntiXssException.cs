﻿namespace ProgramExtensions.Middleware.AntiXss
{
    /// <summary>
    /// AntiXssException
    /// </summary>
    [Serializable]
    internal class AntiXssException : Exception
    {
        public string ErrorMessage;

        /// <summary>
        /// Initializes a new instance of the <see cref="AntiXssException"/> class.
        /// </summary>
        public AntiXssException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AntiXssException"/> class
        /// with a specified error message.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        public AntiXssException(string message)
        {
            ErrorMessage = message;
        }

    }
}