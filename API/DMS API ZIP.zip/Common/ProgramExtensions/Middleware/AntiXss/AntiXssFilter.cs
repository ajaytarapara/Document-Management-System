﻿using Microsoft.AspNetCore.Mvc.TagHelpers;

namespace ProgramExtensions.Middleware.AntiXss
{
    /// <summary>
    /// AntiXssFilter
    /// </summary>
    public static class AntiXssFilter
    {
        private static readonly char[] StartingChars = { '<', '&' };

        #region Public methods

        /// <summary>
        /// Determines if the provided URL is considered dangerous.
        /// Only accepts http: and https: protocols, as well as protocolless URLs.
        /// Used by web parts to validate import and editor input on Url properties. 
        /// Review: is there a way to escape colon that will still be recognized by IE?
        /// %3a does not work with IE.
        /// </summary>
        /// <param name="s">The URL to validate.</param>
        /// <returns>true if the URL is dangerous; otherwise, false.</returns>
        public static bool IsDangerousUrl(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return false;
            }

            // Trim the string inside this method, since a Url starting with whitespace
            // is not necessarily dangerous.  This saves the caller from having to pre-trim 
            // the argument as well.
            s = s.Trim();

            var len = s.Length;

            if (len > 4 &&
                (s[0] == 'h' || s[0] == 'H') &&
                (s[1] == 't' || s[1] == 'T') &&
                (s[2] == 't' || s[2] == 'T') &&
                (s[3] == 'p' || s[3] == 'P'))
            {
                if (s[4] == ':' || len > 5 && (s[4] == 's' || s[4] == 'S') && s[5] == ':')
                {
                    return false;
                }
            }

            var colonPosition = s.IndexOf(':');
            return colonPosition != -1;
        }

        /// <summary>
        /// Checks if the provided string contains dangerous characters or patterns.
        /// </summary>
        /// <param name="s">The string to validate.</param>
        /// <param name="matchIndex">The index of the matched dangerous character, if found.</param>
        /// <returns>true if the string contains dangerous content; otherwise, false.</returns>
        public static bool IsDangerousString(string s, out int matchIndex)
        {
            //bool inComment = false;
            matchIndex = 0;

            for (var i = 0; ;)
            {

                // Look for the start of one of our patterns 
                var n = s.IndexOfAny(StartingChars, i);

                // If not found, the string is safe
                if (n < 0) return false;

                // If it's the last char, it's safe 
                if (n == s.Length - 1) return false;

                matchIndex = n;

                switch (s[n])
                {
                    case '<':
                        // If the < is followed by a letter or '!', it's unsafe (looks like a tag or HTML comment)
                        if (IsAtoZ(s[n + 1]) || s[n + 1] == '!' || s[n + 1] == '/' || s[n + 1] == '?') return true;
                        break;
                    case '&':
                        // If the & is followed by a #, it's unsafe (e.g. S) 
                        if (s[n + 1] == '#') return true;
                        break;

                }

                // Continue searching
                i = n + 1;
            }
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Checks if a character is an uppercase or lowercase letter (A-Z).
        /// </summary>
        /// <param name="c">The character to check.</param>
        /// <returns>true if the character is a letter; otherwise, false.</returns>
        private static bool IsAtoZ(char c)
        {
            return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z';
        }

        #endregion
    }
}
