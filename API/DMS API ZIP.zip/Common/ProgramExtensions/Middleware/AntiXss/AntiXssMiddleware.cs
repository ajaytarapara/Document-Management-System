﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text;

namespace ProgramExtensions.Middleware.AntiXss
{
    /// <summary>
    /// AntiXssMiddleware
    /// </summary>
    public class AntiXssMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly AntiXssMiddlewareOptions _options;
        private readonly ILogger<AntiXssMiddleware> _logger;


        /// <summary>
        /// Initializes a new instance of the <see cref="AntiXssMiddleware"/> class.
        /// </summary>
        /// <param name="next">The next middleware in the pipeline.</param>
        /// <exception cref="ArgumentNullException">Thrown when the next parameter is null.</exception>
        public AntiXssMiddleware(RequestDelegate next, ILogger<AntiXssMiddleware> logger)
        {
            if (next == null)
            {
                throw new ArgumentNullException(nameof(next));
            }

            _next = next;
            _options = new AntiXssMiddlewareOptions();
            _logger = logger;
        }

        /// <summary>
        /// Invokes the middleware to check for XSS vulnerabilities in the HTTP request.
        /// </summary>
        /// <param name="context">The HTTP context.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task Invoke(HttpContext context)
        {
            try
            {
                // Check XSS in URL
                if (!string.IsNullOrWhiteSpace(context.Request.Path.Value))
                {
                    var url = context.Request.Path.Value;

                    int matchIndex; 
                    if (AntiXssFilter.IsDangerousString(url, out matchIndex))
                    {
                        throw new AntiXssException(_options.ErrorMessage + $"/ url : {url}");
                    }
                }
                
                // Check XSS in query string
                if (!string.IsNullOrWhiteSpace(context.Request.QueryString.Value))
                {
                    var queryString = WebUtility.UrlDecode(context.Request.QueryString.Value);

                    int matchIndex;
                    if (AntiXssFilter.IsDangerousString(queryString, out matchIndex))
                    {
                        throw new AntiXssException(_options.ErrorMessage + $"/ queryString : {queryString}");
                    }
                }

                // Check XSS in request content
                var originalBody = context.Request.Body;
                try
                {
                    var content = await ReadRequestBody(context);

                    int matchIndex;
                    if (AntiXssFilter.IsDangerousString(content, out matchIndex))
                    {
                        if (!content.Contains("Content-Type: application/pdf") // allow PDF files
                         && !content.Contains("Content-Type: application/vnd.ms-excel") // allow Excel files
                         && !content.Contains("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") // allow LibreOffice Excel files
                         && !content.Contains("Content-Type: application/msword") // allow Word (.doc) files
                         && !content.Contains("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document") // allow Word (.docx) files
                         && !content.Contains("Content-Type: image/") // allow Image files
                         && !content.Contains("Content-Type: video/")) // allow all Video files
                        {
                            throw new AntiXssException(_options.ErrorMessage + $"/ content : {content}");

                        }
                    }

                    await _next(context);

                }
                finally
                {
                    context.Request.Body = originalBody;
                }
            }
            catch (AntiXssException ex)
            {
                _logger.LogCritical(ex, ex.ErrorMessage);
                context.Response.Clear();
                await context.Response.WriteAsync(_options.ErrorMessage);
                return;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                await _next(context);
            }
        }

        /// <summary>
        /// Reads the request body content as a string.
        /// </summary>
        /// <param name="context">The HTTP context.</param>
        /// <returns>The request body content as a string.</returns>
        private static async Task<string> ReadRequestBody(HttpContext context)
        {
            try
            {
                var buffer = new MemoryStream();
                await context.Request.Body.CopyToAsync(buffer);
                context.Request.Body = buffer;
                buffer.Position = 0;

                var encoding = Encoding.UTF8;
                var contentType = context.Request.GetTypedHeaders().ContentType;
                if (contentType?.Charset != null && contentType.Charset.HasValue)
                    encoding = Encoding.GetEncoding(contentType.Charset.Value);

                var requestContent = await new StreamReader(buffer, encoding).ReadToEndAsync();
                context.Request.Body.Position = 0;

                return requestContent;
            }
            catch (Exception ex)
            {
                return "";
            }
        }
    }
}
