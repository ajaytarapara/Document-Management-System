﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Shared.Constant;
using Shared.ExceptionHandler;
using System.Diagnostics;
using System.Net;
using System.Text.Json;

namespace ProgramExtensions.Middleware.GlobalException
{
    /// <summary>
    /// Exception middleware to handle all the exception
    /// </summary>
    public class ExceptionMiddleware
    {

        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionMiddleware> _logger;

        public ExceptionMiddleware(RequestDelegate next, ILogger<ExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        /// <summary>
        /// Invoke method for each api request to handle exception
        /// </summary>
        /// <param name="httpContext"></param>
        public async Task InvokeAsync(HttpContext httpContext)
        {
            var stopwatch = Stopwatch.StartNew();
            try
            {
                await _next(httpContext);
            }
            catch (UnauthorizedAccessException uaEx)
            {
                _logger.LogWarning(uaEx, "Unauthorized access.");
                await HandleExceptionAsync(httpContext, uaEx, HttpStatusCode.Unauthorized);
            }
            catch (DataValidationException dvEx)
            {
                _logger.LogWarning(dvEx, "Data validation failed.");
                await HandleExceptionAsync(httpContext, dvEx, HttpStatusCode.BadRequest);
            }
            catch (BadHttpRequestException brEx)
            {
                _logger.LogWarning(brEx, "Bad HTTP request.");
                await HandleExceptionAsync(httpContext, brEx, HttpStatusCode.BadRequest);
            }
            catch (DataConflictException dcEx)
            {
                _logger.LogWarning(dcEx, "Data conflict occurred.");
                await HandleExceptionAsync(httpContext, dcEx, HttpStatusCode.Conflict);
            }
            catch (DataNotFoundException dnEx)
            {
                _logger.LogWarning(dnEx, "Data not found.");
                await HandleExceptionAsync(httpContext, dnEx, HttpStatusCode.NotFound);
            }
            catch (InvalidOperationException dnEx)
            {
                _logger.LogWarning(dnEx, "Data not found.");
                await HandleExceptionAsync(httpContext, dnEx, HttpStatusCode.NotFound);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception occurred.");
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        /// <summary>
        /// Handle exception
        /// </summary>
        /// <param name="context"></param>
        /// <param name="exception"></param>
        /// <param name="statusCode"></param>
        /// <returns>Error details with exception status code</returns>
        private static async Task HandleExceptionAsync(
                HttpContext context,
            Exception exception,
            HttpStatusCode statusCode = HttpStatusCode.InternalServerError
        )
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)statusCode;

            string customException = exception switch
            {
                DataValidationException => Messages.Error.Exception.DataValidationErrorMessage,
                UnauthorizedAccessException => Messages.Error.Exception.UnauthorizedErrorMessage,
                BadHttpRequestException => Messages.Error.Exception.BadRequestErrorMessage,
                DataNotFoundException => Messages.Error.Exception.DataNotFoundExceptionMessage,
                DataConflictException => Messages.Error.Exception.DataConflictExceptionMessage,
                InvalidOperationException => Messages.Error.Exception.InvalidOperationExceptionMessage,
                _ => exception.Message ?? Messages.Error.Exception.InternalServerErrorMessage
            };

            string messages = exception switch
            {
                DataValidationException => JsonSerializer.Serialize(((DataValidationException)exception)?.Error),
                DataNotFoundException => exception.Message ?? string.Empty,
                DataConflictException => exception.Message ?? string.Empty,
                UnauthorizedAccessException => exception.Message ?? string.Empty,
                BadHttpRequestException => exception.Message ?? string.Empty,
                InvalidOperationException => exception.Message ?? string.Empty,
                _ => Messages.Error.Exception.InternalServerErrorMessage,
            };

            await context.Response.WriteAsync(
                new ErrorDetails()
                {
                    StatusCode = context.Response.StatusCode,
                    Error = customException,
                    IsSuccess = false,
                    Message = messages
                }.ToString());
        }
    }
}
